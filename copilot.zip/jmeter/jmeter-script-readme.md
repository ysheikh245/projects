﻿**Agency-Copilot JMeter Script Execution Documentation**

**Overview**

This document provides instructions for running Agency-Copilot  JMeter script using Apache JMeter.

**Prerequisites**

Before you begin, make sure you have the following in your machine:

- Java 
- Apache JMeter
- The JMeter script file (.jmx file) – Refer to agency-copilot app jmeter folder
- The JMeter config file (.csv) – Refer to agency-copilot app jmeter folder

**Running the JMeter Script**

Follow below steps:

- Launch Apache JMeter from your local machine.
- Open the JMeter script file (.jmx file) by selecting File > Open and navigating to the location of the file.
- Review the config csv file and provide proper details for environment and execution cycle
- Click the Run button in the JMeter UI.
- The script will begin running and will generate output in real-time. You can monitor the progress of the script by reviewing the summary and graph results.
- Once the script has completed running, you can review the results in more detail by selecting View Results Tree in the JMeter UI.
- To run script from terminal and generate web output use below steps:
  - Open a terminal
  - Change the directory to where JMeter is installed (JMeter's bin folder). For example cd /path/to/apache-jmeter/bin
  - Run the JMeter script with the desired options. Use the following command: ./jmeter -n -t /path/to/your/test\_plan.jmx -l /path/to/your/output.csv -e -o /path/to/your/report
  - JMeter will run your test plan in non-GUI mode and save the results in the output CSV file and create html report to /reports folder specified above

**Troubleshooting**

If you encounter any issues while running the JMeter script, try the following troubleshooting steps:

- Check that Apache JMeter is installed correctly and is running.
- Verify that you have the correct script and config files.
- Check that you have the correct environment URLs and other parameters for the listed in config file.
- Verify that the application being tested is running and accessible.
