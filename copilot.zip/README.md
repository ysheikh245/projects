[![Build Status](https://portaltest4.pmic.com/jenkins/buildStatus/icon?job=/customer-apps/pmic-web-template-customer-portal/)](https://portaltest4.pmic.com/jenkins/buildStatus/icon?job=/customer-apps/pmic-web-template-customer-portal/)
# Agency Co Pilot
## JAVA and Nativescript
 
The My Account repo is used to generate 3 deployable artifacts using Angular to create a Web Front End with Java API's as well as a apk (Android) and ipa (iOS) using Nativescript to communicate with the Java backends.

Please go to the following to set up your [Nativescript Environment](https://docs.nativescript.org/environment-setup.html).

[Python Issue with NativeScript and macOS 12.3+ and NativeScript 8.2 and lower](https://github.com/NativeScript/NativeScript/issues/9833#issuecomment-1111357544).

Once set up the following command should be executed to run locally

`npm run ios:debug -- --env.pmicEnv=${environment}`

`npm run android:debug -- --env.pmicEnv=${environment}`

With `environment` being one of the following

- local (http://127.0.0.1:8080 - iOS local)
- androidLocal (http://10.0.2.2:8080 Android local)
- dev (https://customertest4.pmic.com)
- qa (https://wwwtest3.physiciansmutual.com)
- preprod (https://wwwtest1.physiciansmutual.com)
- prod (https://www.physiciansmutual.com)


With this being said the Mac Dev build can only be uploaded via developer at this time so the following commands should be ran when your code has been merged into a releaseable branch, these commands are executed from the `./agency-copilot` directory.

``node ./pre-scripts/change $CHANNEL `git describe --tags $(git rev-list --tags --max-count=1)`-rc``

`node ./post-scripts/build-upload.js test $CHANNEL`

Or

`node ./post-scripts/change-build-upload.js dev test`

This will build and deploy both Android and iOS to [Pantry](https://portaltest4.pmic.com/pantry/home).  **This will make changes to your local workspace and should be reverted and not checked in.**

**Note: With minSdk being set to minSDK >= 23 in the app.gradle the apk size will almost double due to the `lib/*.so` files being [uncompressed](https://stackoverflow.com/questions/68186329/changing-minsdkversion-from-16-to-26-increased-release-apk-size-from-17-to-39-mb). So, to reduce that back down to a "maintainable size" in the app.gradle we added the [following](https://developer.android.com/reference/tools/gradle-api/7.1/com/android/build/api/dsl/JniLibsPackagingOptions#uselegacypackaging)**:

```
packagingOptions { 
  jniLibs { 
    useLegacyPackaging true 
  } 
}
```
## Gradle  


To run this locally, you'll need to generate `application.properties` like the docker image does.

- Use the following command to print the properties, then either put them in `src/main/resources/application.properties`, or in your `C:/Users/aXXXXXX/application.properties`.
  ```
  awk 'FNR==1{print ""}1' agency-copilot.*
  ```

- Add the values for the `username`/`password` properties. 
- Spring takes presidence upon which properties files it reads, meaning that if you check in or build a jar with properties in `src/main/resources/application.properties` they will override the properties in `C:/Users/aXXXXXX/application.properties`.  As a general rule keep the application.properties either application specific and something that will never change, or keep it blank in git.  Mainly it would behoove of you to just create a `application.properties` in your user home directory and keep that up to date.

## Docker

### Generate secrets/configs:
```
docker config create agency-copilot.config agency-copilot.config
docker secret create agency-copilot.secret agency-copilot.secret
```
 
If the configs/secrets already exist, you can delete them with:
```
docker config rm agency-copilot.config
docker secret rm agency-copilot.secret
```
Also if you have the `pmdev-cli` installed you can edit your configs and secrets with the following commands
```
pmdev docker config edit agency-copilot.config
pmdev docker secret edit agency-copilot.secret
```
This will open up vim and can then be edited in the command line or you can execute

```
pmdev docker config edit agency-copilot.config -f ./agency-copilot.config
pmdev docker secret edit agency-copilot.secret -f ./agency-copilot.secret
```
To override the current config/secret with a config/secret file


### Build: 
```
docker-compose build
```
### Deploy:
```
docker stack deploy -c docker-compose.yml agency-copilot
```
### Stop/Remove:
```
docker stack rm agency-copilot
```
*** Force rebuild


**** Force rebuild My CM


**** Force rebuild My CM

**** force rebuild pipeline failed Hamsa
 
