package com.pm.api.agencycopilot.constants;

public class TestConstants {
    public static final String API_URL = "http://localhost:8080/test";
    public static final String POLICY_STATUS_ACTIVE = "A01";
    public static final String POLICY_STATUS_PENDING = "P04";

    public static final String DEMO = "DEMO";
    public static final String[] STATUSES = {"Active", "Pending"};
    public static final String NPN = "8309043";
    public static final String NPN_2 = "18144484";

    public static final String POLICY_NUMBER = "H710433487";
    public static final String FULL_NAME = "James Web";
    public static final String PARTY_ID = "501426";
    public static final String PENDING = "Pending";
    public static final String PAGE = "1";
    public static final String SORT_DESC = "DESC";
    public static final String SORT_ASC = "ASC";

    public static final String DAYS = "60";


}
