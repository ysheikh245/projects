package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.constants.TestConstants;
import com.pm.api.agencycopilot.services.MessageService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class MessageControllerTest {

    private MockMvc mvc;
    @InjectMocks
    private MessageController controller;
    @Mock
    private MessageService messageService;

    @BeforeEach
    void setup() {
        mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();
    }

    @Test
    void testGetMessage() throws Exception {
        Mockito.when(messageService.getMessage()).thenReturn(TestConstants.DEMO);

        mvc.perform(MockMvcRequestBuilders.get("/message"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();

    }

}
