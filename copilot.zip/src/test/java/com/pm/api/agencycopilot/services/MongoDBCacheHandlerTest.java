package com.pm.api.agencycopilot.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicySearchStatus;
import com.pm.api.agencycopilot.repository.PolicyCachingStatusRepository;
import com.pm.api.agencycopilot.repository.PolicyCategoriesRepository;
import com.pm.api.agencycopilot.repository.PolicyRepository;
import com.pm.api.agencycopilot.services.impl.MongoDBCacheHandlerImpl;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.context.ActiveProfiles;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
public class MongoDBCacheHandlerTest {

    @InjectMocks
    MongoDBCacheHandlerImpl mongoDBCahceHandler;
    @Mock
    PolicyRepository policyRepository;

    @Mock
    PolicyCachingStatusRepository policyCachingStatusRepository;

    @Mock
    MongoTemplate mongoTemplate;

    @Mock
    PolicyCategoriesRepository policyCategoriesRepository;

    @Mock
    Query query;


    List<PolicyVO> policyVOList;
    ApplicationStatusRequest applicationStatusRequest;

    @BeforeEach
    public void setup() throws Exception {
        policyVOList = JsonTransformationUtils.transformApplicationStatusStringToObject().getPolicy();
        applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
    }

    @Test
    public void testsaveToPolicyDocument() {
        when(policyRepository.save(any())).thenReturn(new PolicyDatabaseRecord());
        mongoDBCahceHandler.saveToPolicyDocument(policyVOList.get(0), applicationStatusRequest);
    }

    @Test
    public void testfindAndDeletePoliciesByNpn() {
        when(policyRepository.existsByNpnId(anyString())).thenReturn(true);
        mongoDBCahceHandler.findAndDeletePoliciesByNpn("TEST-NPN-ID");
    }

    @Test
    public void testsaveToPolicyCacheStatusDocument() {

        mongoDBCahceHandler.saveToPolicyCacheStatusDocument("TEST-NPN-ID", LocalDateTime.now(), new Date());
    }

    @Test
    public void testupdatePolicyCacheStatusDocument() {
        when(policyCachingStatusRepository.findByNpnId(anyString())).thenReturn(buildPolicyCachingStatusRecord());
        mongoDBCahceHandler.updatePolicyCacheStatusDocument("TEST-NPN-ID", LocalDateTime.now(), false, true, 10);
    }

    @Test
    public void testupdatePolicyCacheStatusDocumentisBackground() {
        when(policyCachingStatusRepository.findByNpnId(anyString())).thenReturn(buildPolicyCachingStatusRecord());
        mongoDBCahceHandler.updatePolicyCacheStatusDocument("TEST-NPN-ID", LocalDateTime.now(), true, false, 10);
    }

    @Test
    public void testupdatePolicyCacheStatusDocumentisBackgroundSearchComplete() {
        PolicyCachingStatusRecord policyCachingStatusRecord = buildPolicyCachingStatusRecord();
        policyCachingStatusRecord.getDefaultPolicySearchProcess().setTotalPoliciesFetched(20l);
        when(policyCachingStatusRepository.findByNpnId(anyString())).thenReturn(policyCachingStatusRecord);
        mongoDBCahceHandler.updatePolicyCacheStatusDocument("TEST-NPN-ID", LocalDateTime.now(), true, true, 10);
    }

    @Test
    public void testfindPolicyCachingStatusByNpnId() {
        mongoDBCahceHandler.findPolicyCachingStatusByNpnId("TEST-NPN-ID");
    }

    @Test
    public void testfindPoliciesByNPNId() {
        mongoDBCahceHandler.findPoliciesByNPNId("TEST-NPN-ID", mock(Pageable.class));
    }

    @Test
    public void testfindPoliciesByNPNIdAndPolicyNumber() {
        mongoDBCahceHandler.findPoliciesByNPNIdAndPolicyNumber("TEST-NPN-ID", "PolicyNumber", mock(Pageable.class));
    }

    @Test
    public void testfindPoliciesByNPNIdAndCustomerFullName() {
        mongoDBCahceHandler.findPoliciesByNPNIdAndCustomerFullName("TEST-NPN-ID", "John Doe", mock(Pageable.class));
    }

    @Test
    public void testfindPoliciesByNpnUsingCriteria() {
        when(mongoTemplate.find(any(), any())).thenReturn(new ArrayList<>());
        mongoDBCahceHandler.findPoliciesByNpnUsingCriteria(query);
    }

    @Test
    public void testfindApplicationStatusCodes() {
        when(policyCategoriesRepository.findByCodeAndIsActive(anyString(), anyBoolean())).thenReturn(new PolicyCategoriesRecord());
        mongoDBCahceHandler.findApplicationStatusCodes("A01", true);
    }

    @Test
    public void testinsertApplicationStatusCodes() {
        mongoDBCahceHandler.insertPolicyCategoryCodes(new ArrayList<PolicyCategoriesRecord>());
    }

    private PolicyCachingStatusRecord buildPolicyCachingStatusRecord() {
        PolicyCachingStatusRecord policyCachingStatusRecord = new PolicyCachingStatusRecord();
        PolicySearchStatus policySearchStatus = new PolicySearchStatus();
        policyCachingStatusRecord.setDefaultPolicySearchProcess(policySearchStatus);
        policyCachingStatusRecord.setBackgroundPolicySearchProcess(policySearchStatus);
        return policyCachingStatusRecord;
    }
}
