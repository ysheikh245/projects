package com.pm.api.agencycopilot.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.services.impl.ApplicationStatusHelperServiceImpl;
import com.pm.api.agencycopilot.services.impl.ApplicationStatusServiceImpl;
import com.pm.api.agencycopilot.services.impl.AsynchronousInvocationServiceHelper;
import com.pm.api.agencycopilot.utility.ApplicationStatusProperties;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
class ApplicationStatusServiceTest {

    @InjectMocks
    ApplicationStatusServiceImpl applicationStatusService;
    @Mock
    private ApplicationStatusHelperServiceImpl applicationStatusHelperService;

    @Mock
    private AsynchronousInvocationServiceHelper asynchronousInvocationServiceHelper;

    private String backgroundProcessingFlag;

    @Mock
    MongoDBCacheHandler mongoDBCacheHandler;

    @Mock
    ApplicationStatusProperties applicationStatusProperties;


    @Test
    void testProcessApplicationStatus() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(applicationStatusHelperService.processApplicationStatus(any(), anyBoolean()))
                .thenReturn(CompletableFuture.completedFuture(true));
        when(mongoDBCacheHandler.saveToPolicyCacheStatusDocument(
                anyString(),
                any(),
                any()
        )).thenReturn(new PolicyCachingStatusRecord());
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());
        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    void testProcessApplicationStatusBackgroundProcessComplete() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setPageNumber(8);
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now().minusDays(7));
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());

        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString()))
                .thenReturn(JsonTransformationUtils.transformStatusCacheStringToObject());

        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    void testProcessApplicationStatusBackgroundProcessNotCompleteFinallyComplete() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setPageNumber(8);
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now().minusDays(7));
        PolicyCachingStatusRecord policyCachingStatusRecord = JsonTransformationUtils.transformStatusCacheStringToObject();
        policyCachingStatusRecord.getBackgroundPolicySearchProcess().setSearchCompleted(false);
        when(applicationStatusProperties.getBackgroundProcessVerificationCount()).thenReturn(5);
        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString()))
                .thenReturn(policyCachingStatusRecord, JsonTransformationUtils.transformStatusCacheStringToObject());
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());
        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    void testProcessApplicationStatusBackgroundProcessNotCompleteAfter2Retries() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setPageNumber(8);
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now().minusDays(7));
        PolicyCachingStatusRecord policyCachingStatusRecord = JsonTransformationUtils.transformStatusCacheStringToObject();
        policyCachingStatusRecord.getBackgroundPolicySearchProcess().setSearchCompleted(false);
        when(applicationStatusProperties.getBackgroundProcessVerificationCount()).thenReturn(2);
        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString()))
                .thenReturn(policyCachingStatusRecord, policyCachingStatusRecord);

        Assertions.assertThrows(AgencyCoPilot4xxException.class, () ->
                applicationStatusService.processApplicationStatus(applicationStatusRequest));
    }

    @Test
    void testProcessApplicationStatusBackground() throws Exception {
        ReflectionTestUtils.setField(applicationStatusService, "backgroundProcessingFlag", "true");
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(applicationStatusHelperService.processApplicationStatus(any(), anyBoolean()))
                .thenReturn(CompletableFuture.completedFuture(true));
        when(mongoDBCacheHandler.saveToPolicyCacheStatusDocument(
                anyString(),
                any(),
                any()
        )).thenReturn(new PolicyCachingStatusRecord());
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());
        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    void testProcessApplicationStatusFilterApplied() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now().minusDays(7));
        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString())).thenReturn(JsonTransformationUtils.transformStatusCacheStringToObject());
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());
        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    void testProcessApplicationStatusFilterAppliedNoCachedRecord() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now().minusDays(7));
        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString())).thenReturn(null);
        when(applicationStatusHelperService.processApplicationStatus(any(), anyBoolean()))
                .thenReturn(CompletableFuture.completedFuture(true));
        when(mongoDBCacheHandler.saveToPolicyCacheStatusDocument(
                anyString(),
                any(),
                any()
        )).thenReturn(new PolicyCachingStatusRecord());
        when(applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(any()))
                .thenReturn(JsonTransformationUtils.transformApplicationStatusStringToObject());
        applicationStatusService.processApplicationStatus(applicationStatusRequest);
    }

    @Test
    public void testretrieveApplicationStatusByNPN() throws Exception {
        List<PolicyVO> policyVOList = JsonTransformationUtils.transformApplicationStatusStringToObject().getPolicy();
        List<PolicyDatabaseRecord> policyDatabaseRecordList = new ArrayList<>();
        PolicyDatabaseRecord policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(0));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(1));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        when(mongoDBCacheHandler.findPoliciesByNPNId(
                any(),
                any())).thenReturn(policyDatabaseRecordList);
        applicationStatusService.retrieveApplicationStatusByNPN("1234", 0, 3);
    }

    @Test
    public void testretrieveApplicationStatusCacheResults() throws Exception {
        when(mongoDBCacheHandler.findPolicyCachingStatusByNpnId(anyString()))
                .thenReturn(JsonTransformationUtils.transformStatusCacheStringToObject());
        applicationStatusService.retrieveApplicationStatusCacheResults("1234");
    }


}
