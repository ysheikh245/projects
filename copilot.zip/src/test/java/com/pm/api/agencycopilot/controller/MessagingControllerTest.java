package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.constants.TestConstants;
import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;
import com.pm.api.agencycopilot.services.MessagingServiceHandler;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class MessagingControllerTest {
    @InjectMocks
    private MessagingController controller;
    @Mock
    private MessagingServiceHandler messagingServiceHandler;

   /* @Test
    void testGetMessageOK() throws Exception {
        MockMvc mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();

        MessagingAPIRequest messagingAPIRequest = new MessagingAPIRequest();
        messagingAPIRequest.setNpn("Sample");
        when(messagingServiceHandler.sendEmail(messagingAPIRequest)).thenReturn(TestConstants.DEMO);

        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getAttribute("npnId")).thenReturn("8309043");

        mvc.perform(post("/web/send-email")
                        .content(new ObjectMapper().writeValueAsString(new MessagingAPIRequest()))
                        .contentType(MediaType.APPLICATION_JSON)
                ).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }*/
    /*@Test
    void testGetMessage() throws Exception {
        MockMvc mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();

        when(messagingServiceHandler.sendEmail(new MessagingAPIRequest()))
                .thenThrow(RuntimeException.class);

        try {
            mvc.perform(post("/web/send-email")
                            .content(new ObjectMapper().writeValueAsString(new MessagingAPIRequest()))
                            .contentType(MediaType.APPLICATION_JSON)
                    ).andDo(MockMvcResultHandlers.print())
                    .andExpect(MockMvcResultMatchers.status().is5xxServerError()).andReturn();
        } catch (Exception e) {
        }
    }*/
}
