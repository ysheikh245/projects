package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.NPN;
import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;
import com.pm.api.agencycopilot.models.external.agents.AgentsAPIResponse;
import com.pm.api.agencycopilot.models.external.agents.EmailAddressesItem;
import com.pm.api.agencycopilot.models.external.agents.PrimaryPhoneNumbersItem;
import com.pm.api.agencycopilot.models.external.agents.Response;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.services.impl.MessagingServicesHandlerImpl;
import com.pm.api.agencycopilot.utility.AgencyCoPilotConstants;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import com.pm.api.agencycopilot.utility.MessagingProperties;
import java.util.ArrayList;
import java.util.List;
import org.apache.tomcat.util.codec.binary.Base64;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.anyBoolean;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class MessagingServiceHandlerTest {

    @InjectMocks
    MessagingServicesHandlerImpl messagingServiceHandler;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private AgentsServiceHandler agentsServiceHandler;

    @Mock
    private MessagingProperties messagingProperties;

    @Mock
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Mock
    private ContentStackServiceHandler contentStackServiceHandler;

    @Mock
    private ResponseEntity<String> responseEntity;

    @Mock
    MaskedValueLogger maskedValueLogger;

    @BeforeEach
    void init() {

//        setField(messagingServiceHandler, "messagingAPIURL", API_URL);
//        setField(messagingServiceHandler, "messagingAPIPassword", DEMO);
//        setField(messagingServiceHandler, "messagingAPIUserName", DEMO);
        when(messagingProperties.getPrimaryCommunicationPreferenceType()).thenReturn("PRIMRES");
        when(messagingProperties.getClientHeader()).thenReturn("HEADER");
        when(messagingProperties.getEndUserId()).thenReturn("END-USER-ID");
        when(messagingProperties.getContextId()).thenReturn("CONTEXT_ID");
        when(messagingProperties.getExtRefId()).thenReturn("EXT_REF_ID");
        when(messagingProperties.getMessagingAPIUserName()).thenReturn("TEST-USER");
        when(messagingProperties.getMessagingAPIPassword()).thenReturn("TEST-PASSWORD");
        when(agentsServiceHandler.getAgentsDetail(anyString())).thenReturn(buildAgentsAPIResponse());
        when(productTypeCategoriesRepository.findByProductCodeAndIsActive(anyString(), anyBoolean())).thenReturn(buildProductTypeCategoriesRecord());

//        ArgumentMatchers.anyString(),
//                ArgumentMatchers.any(HttpMethod.class),
//                ArgumentMatchers.any(),
//                ArgumentMatchers.<Class<GetInteractionLogResponse>>any()
//        when(restTemplate.postForEntity(anyString(), ArgumentMatchers.<Class<HttpEntity>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(responseEntity);


    }

    private String buildContentStackResponse() {
        return "{ \"entries\": [ { \"_version\": 5, \"locale\": \"en-us\", \"uid\": \"bltf88ba82d5ff93eea\", \"ACL\": {}, \"_in_progress\": false, \"agent_image\": { \"parent_uid\": \"blt852a9013e75255f5\", \"uid\": \"blt3d23e92a5838dd2d\", \"created_by\": \"blt8ed501d52ad28dd3\", \"updated_by\": \"blt8ed501d52ad28dd3\", \"created_at\": \"2022-05-04T16:09:36.239Z\", \"updated_at\": \"2022-05-04T16:09:36.239Z\", \"content_type\": \"image/jpeg\", \"file_size\": \"37403\", \"filename\": \"9345961.jpg\", \"title\": \"9345961.jpg\", \"ACL\": {}, \"_version\": 1, \"is_dir\": false, \"tags\": [], \"publish_details\": { \"environment\": \"blt2bce21ea9a8ed081\", \"locale\": \"en-us\", \"time\": \"2022-05-04T16:10:36.434Z\", \"user\": \"blt8ed501d52ad28dd3\" }, \"url\": \"https://images.contentstack.io/v3/assets/blt904c85516bdf4ea0/blt3d23e92a5838dd2d/6272a540220ab5285f518abd/9345961.jpg\" }, \"agent_url\": \"Melinda_Harrison\", \"agentbecause\": \"Make a Difference\", \"agentdesignations\": [ \"LUTCF\" ], \"agenthobbies\": [ \"Sports\", \"Family\", \"Travel\", \"Music\" ], \"agentwhypmic\": \"Top-notch Customer Service\", \"created_at\": \"2021-05-24T12:08:47.650Z\", \"created_by\": \"bltca214878b44ae46c\", \"hide_california_license\": false, \"hide_division_office\": true, \"hide_state_license\": \"\", \"nickname\": \"Melinda\", \"npn\": \"9345961\", \"personal_address_city_state_zip\": \"Florence, SC 29506\", \"personal_address_line\": \"181 E EVANS ST STE C3\", \"socialfacebook\": \"\", \"sociallinkedin\": \"\", \"state_county\": [ \"SC, NC, GA, VA & TX \" ], \"tags\": [], \"title\": \"Melinda_Harrison\", \"updated_at\": \"2023-04-06T14:44:01.648Z\", \"updated_by\": \"blt1b4cef0d7f8a978a\", \"publish_details\": { \"environment\": \"blt2bce21ea9a8ed081\", \"locale\": \"en-us\", \"time\": \"2023-04-06T14:44:08.543Z\", \"user\": \"blt1b4cef0d7f8a978a\" } } ] }";

    }

    private ProductTypeCategoriesRecord buildProductTypeCategoriesRecord() {
        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setCategory("Life");
        productTypeCategoriesRecord.setProductCode("L01");
        productTypeCategoriesRecord.setActive(true);
        return productTypeCategoriesRecord;
    }

    private AgentsAPIResponse buildAgentsAPIResponse() {
        AgentsAPIResponse agentsAPIResponse = new AgentsAPIResponse();
        Response response = new Response();
        EmailAddressesItem emailAddressesItem = new EmailAddressesItem();
        emailAddressesItem.setEmailAddress("abc@gmail.com");
        emailAddressesItem.setPriorityLevel("TEST");
        emailAddressesItem.setContactPreferenceType("PRIMRES");
        List<EmailAddressesItem> emailAddressesItemList = new ArrayList<>();
        emailAddressesItemList.add(emailAddressesItem);
        response.setEmailAddresses(emailAddressesItemList);

        PrimaryPhoneNumbersItem primaryPhoneNumbersItem = new PrimaryPhoneNumbersItem();
        primaryPhoneNumbersItem.setAreaCode("302");
        primaryPhoneNumbersItem.setLocalPhoneNumber("3569999");
        primaryPhoneNumbersItem.setContactPreferenceType("PRIMRES");
        List<PrimaryPhoneNumbersItem> primaryPhoneNumbersItemList = new ArrayList<>();
        primaryPhoneNumbersItemList.add(primaryPhoneNumbersItem);
        response.setPrimaryPhoneNumbers(primaryPhoneNumbersItemList);

        response.setNpn("123456");
        response.setFirstName("James");
        response.setMiddleNames("Cameron");
        response.setLastName("Bond");
        agentsAPIResponse.setResponse(response);
        return agentsAPIResponse;
    }

    private String getBasicAuthToken(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }

    @Test
    void testSendEmail() {
        MessagingAPIRequest messagingAPIRequest = new MessagingAPIRequest();
        messagingAPIRequest.setNpn(NPN);
        messagingAPIRequest.setProductCode("L01");

        lenient().when(restTemplate.postForEntity(
                        anyString(),
                        any(HttpEntity.class),
                        ArgumentMatchers.<Class<String>>any()))
                .thenReturn(new ResponseEntity<>(DEMO, HttpStatus.OK));

//        Mockito.doReturn(HttpStatus.OK).when(responseEntity).getStatusCode();
        when(contentStackServiceHandler.getAgentProfileResponse(anyString())).thenReturn(buildContentStackResponse());
//        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);

        String result = messagingServiceHandler.sendEmail(messagingAPIRequest);
        Assertions.assertEquals(AgencyCoPilotConstants.BLANK, result);
    }

}
