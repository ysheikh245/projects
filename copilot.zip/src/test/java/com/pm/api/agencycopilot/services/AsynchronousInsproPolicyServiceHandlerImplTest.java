package com.pm.api.agencycopilot.services;

import com.atiam.policy._2008.GetPolicyDetailRequestType;
import com.atiam.policy._2008.GetPolicyDetailResponseType;
import com.atiam.policyservice._2008.PolicyService;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.impl.AsynchronousInvocationServiceHelper;
import com.pm.soap.client.InsproPolicyServiceClient;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
class AsynchronousInsproPolicyServiceHandlerImplTest {

    @InjectMocks
    AsynchronousInvocationServiceHelper agentsServiceHandler;

    @Mock
    InsproPolicyServiceClient insproPolicyServiceClient;

    @Mock
    PolicyService policyServiceSoap11;


    @Test
    void testInvokeInsproSOAPCall() {
        GetPolicyDetailRequestType request = new GetPolicyDetailRequestType();
        request.setPolicyNumber(POLICY_NUMBER);

        when(insproPolicyServiceClient.getPolicyService())
                .thenReturn(policyServiceSoap11);
        when(policyServiceSoap11.getPolicyDetail(any()))
                .thenReturn(new GetPolicyDetailResponseType());
        PolicyVO policyVO = new PolicyVO();
        policyVO.setPolicyNumber("POLICY_NUMBER");
        CompletableFuture<GetPolicyDetailResponseType> response =
                agentsServiceHandler.invokeInsproSOAPCall(policyVO);
        Assertions.assertNotNull(response);
    }
}