package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerRoleByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Policy;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.services.impl.PolicyServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import com.pm.api.agencycopilot.transformer.PolicyDetailTransformer;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
public class PolicyServiceHandlerTest {

    @InjectMocks
    PolicyServiceHandlerImpl policyServiceHandler;

    @Mock
    RestTemplate restTemplate;


    @Mock
    PolicyDetailTransformer policyDetailTransformer;

    PolicyV2Response mockResponse;

    @Mock
    RestHelperServiceImpl restHelperService;

    @Mock
    MaskedValueLogger maskedValueLogger;


    @BeforeEach
    void setup() {
        setField(policyServiceHandler, "pmapiEndUserId", DEMO);
        setField(policyServiceHandler, "pmapiPolicyEndpoint", DEMO);
        setField(policyServiceHandler, "rolesAPIEndPoint", DEMO);
        setField(policyServiceHandler, "agentRolAPIEndPoint", API_URL);
        setField(policyServiceHandler, "dependentsByPolicyAPIEndpoint", DEMO);
        setField(policyServiceHandler, "pmapiAuthUserName", DEMO);
        setField(policyServiceHandler, "pmapiAuthPassword", DEMO);
        setField(policyServiceHandler, "pmapiClientHeader", DEMO);
        setField(policyServiceHandler, "restHelperService", restHelperService);
        setField(policyServiceHandler, "restTemplate", restTemplate);
        setField(policyServiceHandler, "maskedValueLogger", maskedValueLogger);


        mockResponse = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setPolicyNumber(POLICY_NUMBER);
        policy.setDiscounts(List.of(new PolicyDiscounts()));
        policy.setRateChanges(List.of(new PolicyRateChange()));
        policy.setAdditionalCoverages(List.of(new AdditionalCoverage()));
        policy.setBeneficiaryDetails(List.of(new BeneficiaryDetails()));
        mockResponse.setPolicies(List.of(policy));


    }


    @Test
    void testGetPolicyDataFromPMAPIWithParams() throws Exception {

        List<String> params = Arrays.asList("rateChanges", "discounts");
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        PolicyV2Response response = policyServiceHandler.getPolicyDataFromPMAPI(POLICY_NUMBER, params);
        assertNotNull(response);
        assertTrue(response.getPolicies().size() > 0);
        assertEquals(POLICY_NUMBER, response.getPolicies().get(0).getPolicyNumber());

        List<PolicyDiscounts> discounts = policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER);
        assertNotNull(discounts);
        assertTrue(discounts.size() > 0);

        List<PolicyRateChange> rateChanges = policyServiceHandler.getPolicyRateChanges(POLICY_NUMBER);
        assertNotNull(rateChanges);
        assertTrue(rateChanges.size() > 0);


        List<CoverageDetailsVO> coverageDetails = policyServiceHandler.getPolicyCoverageDetails(POLICY_NUMBER);
        assertNotNull(coverageDetails);

        DependentsV2Reponse dependentsV2Reponse = new DependentsV2Reponse();
        ResponseEntity<DependentsV2Reponse> dpe
                = new ResponseEntity<>(dependentsV2Reponse, HttpStatus.OK);

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<DependentsV2Reponse>>any()))
                .thenReturn(dpe);


        DependentsV2Reponse dependentDetails = policyServiceHandler.getDependentDetails(POLICY_NUMBER);
        assertNotNull(dependentDetails);


        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenReturn(new ResponseEntity<>(new PolicyInfoV2Response(), HttpStatus.OK));


        PolicyInfoV2Response<AgentRole> agentRoles = policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER);
        assertNotNull(agentRoles);


        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenReturn(new ResponseEntity<>(new PolicyInfoV2Response(), HttpStatus.OK));

        PolicyInfoV2Response<Role> roles = policyServiceHandler.getRolesInfo(POLICY_NUMBER);
        assertNotNull(roles);

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        List<AdditionalCoverage> additionalCoverageList = policyServiceHandler.getAdditionalCoverages(POLICY_NUMBER);
        assertNotNull(additionalCoverageList);

        List<BeneficiaryDetails> beneficiaryDetails = policyServiceHandler.getBeneficiaryDetails(POLICY_NUMBER);
        assertNotNull(beneficiaryDetails);


    }

    @Test
    void testExceptionGetPolicyDiscountsRuntimeException() throws Exception {
        Policy policy = mock(Policy.class);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetPolicyDiscountsHttpClientException() throws Exception {
        Policy policy = mock(Policy.class);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot4xxException(new Exception("Unauthrozied"), HttpStatus.BAD_REQUEST, ""));

        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetPolicyDiscountsHttpServerException() throws Exception {
        Policy policy = mock(Policy.class);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER);
        });
    }


    @Test
    void testExceptionGetDependentDetailsRuntimeException() throws Exception {
        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<DependentsV2Reponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown"), HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getDependentDetails(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetDependentDetailsHttpClientException() throws Exception {
        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<DependentsV2Reponse>>any()))
                .thenThrow(new AgencyCoPilot4xxException(new Exception("Invalid Request"), HttpStatus.BAD_REQUEST, ""));
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            policyServiceHandler.getDependentDetails(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetDependentDetailsHttpClientException404() throws Exception {
        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<DependentsV2Reponse>>any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        Assertions.assertNull(policyServiceHandler.getDependentDetails(POLICY_NUMBER));
    }

    @Test
    void testExceptionGetDependentDetailsHttpServerException() throws Exception {
        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<DependentsV2Reponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getDependentDetails(POLICY_NUMBER);
        });
    }


    @Test
    void testExceptionGetAgentRolesInfoRuntimeException() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"), HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetAgentRolesInfoHttpClientException() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot4xxException(new Exception("Unauthorized"), HttpStatus.BAD_REQUEST, ""));
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetAgentRolesInfoHttpClientException404() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        Assertions.assertNull(policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER));
    }

    @Test
    void testExceptionGetAgentRolesInfoHttpServerException() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER);
        });
    }


    @Test
    void testExceptionGetBeneficiaryDetails() throws Exception {

        Policy policy = mock(Policy.class);
        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        policyServiceHandler.getBeneficiaryDetails(POLICY_NUMBER);
        assertTrue(true);
    }

    @Test
    void testExceptionGetAdditionalCoverages() throws Exception {
        Policy policy = mock(Policy.class);
        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> policyServiceHandler.getAdditionalCoverages(POLICY_NUMBER));
    }


    @Test
    void testExceptionGetPolicyRateChanges() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        PolicyV2Response policyDetails = mock(PolicyV2Response.class);
        policyServiceHandler.getPolicyRateChanges(POLICY_NUMBER);
        assertTrue(true);
    }

    @Test
    void testExceptionGetRolesInfo() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getRolesInfo(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetRolesInfoHttpClientError() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenThrow(new AgencyCoPilot4xxException(new Exception("Invalid Request Sent"), HttpStatus.BAD_REQUEST, ""));

        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            policyServiceHandler.getRolesInfo(POLICY_NUMBER);
        });
    }

    @Test
    void testExceptionGetRolesInfoHttpClientError404() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND));

        assertNull(policyServiceHandler.getRolesInfo(POLICY_NUMBER));
    }

    @Test
    void testExceptionGetRolesInfoHttpServerError() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyInfoV2Response>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown Error Occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            policyServiceHandler.getRolesInfo(POLICY_NUMBER);
        });
    }

    @Test
    void testGetPolicyDataFromPMAPI() throws Exception {
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        PolicyV2Response v2Response = policyServiceHandler.getPolicyDataFromPMAPI(POLICY_NUMBER);
        assertNotNull(v2Response);
        assertTrue(v2Response.getPolicies().size() > 0);
        assertEquals(POLICY_NUMBER, v2Response.getPolicies().get(0).getPolicyNumber());


    }

    @Test
    void testGetPolicyDetails() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<PolicyV2Response>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        PolicyV2Response response = policyServiceHandler.getPolicyDetails(POLICY_NUMBER);
        assertNotNull(response);
    }

    @Test
    void testGetCustomerRolesFromPMAPI() {
        FindCustomerRoleByPolicyResponse mockResponse = new FindCustomerRoleByPolicyResponse();

        when(restTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<FindCustomerRoleByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity(new FindCustomerRoleByPolicyResponse(), HttpStatus.OK));
        assertNotNull(policyServiceHandler.getCustomerRolesFromPMAPI(POLICY_NUMBER));
    }
}
