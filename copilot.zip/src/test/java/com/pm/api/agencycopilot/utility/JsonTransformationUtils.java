package com.pm.api.agencycopilot.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.internal.AgentInformationVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import static com.pm.api.agencycopilot.utility.MockResponseFileReader.readMockResponse;
import java.time.LocalDate;
import java.util.List;


public class JsonTransformationUtils {

    public static ObjectMapper objectMapper = new ObjectMapper();

    public static ApplicationStatusResponse transformApplicationStatusStringToObject() throws Exception {
        String applicationStatusResponseJson = "{\n" +
                "    \"policy\": [\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100190\",\n" +
                "            \"issueDate\": \"" + LocalDate.now().minusDays(5) + "\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Issued\",\n" +
                "            \"policyStatusCode\": \"A01\",\n" +
                "            \"policyDisplayText\": \"A01-Active, Premium Paying\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsinlesse Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        },\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100194\",\n" +
                "            \"issueDate\": \"" + LocalDate.now().minusDays(33) + "\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Issued\",\n" +
                "            \"policyStatusCode\": \"A01\",\n" +
                "            \"policyDisplayText\": \"A01-Active, Premium Paying\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsineight Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        },\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100201\",\n" +
                "            \"issueDate\": \"2023-04-24\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Decline/Withdrawn\",\n" +
                "            \"policyStatusCode\": \"A01\",\n" +
                "            \"policyDisplayText\": \"A01-Active, Premium Paying\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsineight Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        },\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100202\",\n" +
                "            \"issueDate\": \"2023-04-24\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Pending\",\n" +
                "            \"policyStatusCode\": \"A01\",\n" +
                "            \"policyDisplayText\": \"P05-Pending, Missing\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsineight Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        },\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100203\",\n" +
                "            \"issueDate\": \"2023-04-24\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Not Taken\",\n" +
                "            \"policyStatusCode\": \"P05\",\n" +
                "            \"policyDisplayText\": \"P05-Pending, Missing\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsineight Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        },\n" +
                "        {\n" +
                "            \"policyNumber\": \"H730100203\",\n" +
                "            \"issueDate\": \"2023-04-24\",\n" +
                "            \"submitDate\": \"2023-04-24\",\n" +
                "            \"productName\": \"S040 - Medicare Supplement\",\n" +
                "            \"policyStatus\": \"Exclude\",\n" +
                "            \"policyStatusCode\": \"T02\",\n" +
                "            \"policyDisplayText\": \"P05-Pending, Missing\",\n" +
                "            \"parties\": [\n" +
                "                {\n" +
                "                    \"fullName\": \"Wisconsineight Dms\",\n" +
                "                    \"partyId\": \"18796043\",\n" +
                "                    \"role\": \"Owner\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"thankyouEmailStatus\": false\n" +
                "        }\n" +

                "    ]\n" +
                "}";

//        List<PolicyVO> policyVOList = objectMapper.readValue(applicationStatusResponseJson, new TypeReference<List<PolicyVO>>() {
//        });
        return objectMapper.readValue(applicationStatusResponseJson, ApplicationStatusResponse.class);

    }

    public static PolicyCachingStatusRecord transformStatusCacheStringToObject() throws Exception {
        String policyCachingRecordJson = readMockResponse("applicationStatus", "policyCachingRecord.json");
        return objectMapper.readValue(policyCachingRecordJson, PolicyCachingStatusRecord.class);
    }

    public static List<PolicyCategoriesRecord> transformPoliciesCategoriesStringToObject() throws Exception {
        String policyCategoryJson = readMockResponse("policyCategory", "policyCategoryResponse.json");
        return objectMapper.readValue(policyCategoryJson, List.class);
    }

    public static List<CustomersVO> transformCustomerDetail() throws Exception {
        String customerDetailJson = readMockResponse("customers", "customerDetails.json");
        TypeReference<List<CustomersVO>> mapType = new TypeReference<List<CustomersVO>>() {
        };
        return objectMapper.readValue(customerDetailJson, mapType);
    }

    public static ApplicationStatusRequest buildApplicationStatusRequest() {
        ApplicationStatusRequest applicationStatusRequest = new ApplicationStatusRequest();
        AgentInformationVO agentInformationVO = new AgentInformationVO();
        agentInformationVO.setNpn("12345");
        applicationStatusRequest.setAgentInformation(agentInformationVO);

        FilterCriteriaVO filterCriteriaVO = new FilterCriteriaVO();
        filterCriteriaVO.setDays(7);
        filterCriteriaVO.setPageSize(3);
        filterCriteriaVO.setPageNumber(0);
        applicationStatusRequest.setFilterCriteria(filterCriteriaVO);

        return applicationStatusRequest;
    }

    static String searchPolicyResponseJson = "{\n" +
            "    \"response\": [\n" +
            "        {\n" +
            "            \"partyId\": \"18796043\",\n" +
            "            \"partyType\": \"Person\",\n" +
            "            \"companyCode\": \"PM\",\n" +
            "            \"partyCategory\": \"Customer\",\n" +
            "            \"originatingSource\": \"AEF\",\n" +
            "            \"externalReferenceList\": [\n" +
            "                {\n" +
            "                    \"customerId\": \"API_4144\",\n" +
            "                    \"customerIdType\": \"Majesco_Insured\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"PMPH231000255\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"Owner\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"CANCELLED\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"4US03JKXCPWH3\",\n" +
            "                    \"customerIdType\": \"Address_Link\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"4US021GL3PG7H\",\n" +
            "                    \"customerIdType\": \"Consumer_Link\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"018996932\",\n" +
            "                    \"customerIdType\": \"Individual\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"7001240673\",\n" +
            "                    \"customerIdType\": \"Cogen\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"H710451816\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"Insured\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"role\": \"Owner\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"A01\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"2036\",\n" +
            "                    \"customerIdType\": \"Majesco_Customer\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"I_7001136604_001\",\n" +
            "                    \"customerIdType\": \"Inspro\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"H710451816\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"Insured\"\n" +
            "                                },\n" +
            "                                {\n" +
            "                                    \"role\": \"Owner\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"A01\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"18796043\",\n" +
            "                    \"customerIdType\": \"FTNI\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"addressList\": [\n" +
            "                {\n" +
            "                    \"type\": \"Mailing Address\",\n" +
            "                    \"addressLine1\": \"1731 Warm River Dr\",\n" +
            "                    \"state\": \"UT\",\n" +
            "                    \"zip\": \"847904436\",\n" +
            "                    \"city\": \"Saint George\",\n" +
            "                    \"country\": \"US\",\n" +
            "                    \"postalBarCode\": \"847904436311\",\n" +
            "                    \"carrierCode\": \"R001\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"person\": {\n" +
            "                \"personNameList\": [\n" +
            "                    {\n" +
            "                        \"nameType\": \"Preferred\",\n" +
            "                        \"firstName\": \"Victor\",\n" +
            "                        \"middleName\": \"F\",\n" +
            "                        \"lastName\": \"Lorch\"\n" +
            "                    }\n" +
            "                ],\n" +
            "                \"gender\": \"M\",\n" +
            "                \"maritalStatus\": \"Unknown\",\n" +
            "                \"dateOfBirth\": \"1943-01-23\",\n" +
            "                \"dateOfDeath\": null\n" +
            "            },\n" +
            "            \"phone\": {\n" +
            "                \"primaryPhone\": \"4352167715\"\n" +
            "            },\n" +
            "            \"email\": {\n" +
            "                \"primaryEmail\": \"riskeduc8@gmail.com\"\n" +
            "            },\n" +
            "            \"userId\": \"AEF\",\n" +
            "            \"partyStatus\": \"Active\",\n" +
            "            \"inactiveFlag\": false,\n" +
            "            \"inactiveDate\": null\n" +
            "        },\n" +
            "        {\n" +
            "            \"partyId\": \"18796044\",\n" +
            "            \"partyType\": \"Person\",\n" +
            "            \"companyCode\": \"PM\",\n" +
            "            \"partyCategory\": \"Customer\",\n" +
            "            \"originatingSource\": \"AEF\",\n" +
            "            \"externalReferenceList\": [\n" +
            "                {\n" +
            "                    \"customerId\": \"4US03JKXCPWH3\",\n" +
            "                    \"customerIdType\": \"Address_Link\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"4US02K881BNDK\",\n" +
            "                    \"customerIdType\": \"Consumer_Link\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"018996933\",\n" +
            "                    \"customerIdType\": \"Individual\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"8001240673\",\n" +
            "                    \"customerIdType\": \"Cogen\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"H710451816\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"Spouse\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"A01\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"I_7001136604_002\",\n" +
            "                    \"customerIdType\": \"Inspro\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"H710451816\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"Spouse\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"A01\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                },\n" +
            "                {\n" +
            "                    \"customerId\": \"API_4913\",\n" +
            "                    \"customerIdType\": \"Majesco_Additional_Insured\",\n" +
            "                    \"policyList\": [\n" +
            "                        {\n" +
            "                            \"policyNumber\": \"PMPH231000255\",\n" +
            "                            \"policyRoleList\": [\n" +
            "                                {\n" +
            "                                    \"role\": \"CoOwner\"\n" +
            "                                }\n" +
            "                            ],\n" +
            "                            \"policyStatus\": \"CANCELLED\"\n" +
            "                        }\n" +
            "                    ]\n" +
            "                }\n" +
            "            ],\n" +
            "            \"addressList\": [\n" +
            "                {\n" +
            "                    \"type\": \"Mailing Address\",\n" +
            "                    \"addressLine1\": \"1731 Warm River Dr\",\n" +
            "                    \"state\": \"UT\",\n" +
            "                    \"zip\": \"847904436\",\n" +
            "                    \"city\": \"Saint George\",\n" +
            "                    \"country\": \"US\",\n" +
            "                    \"postalBarCode\": \"847904436311\",\n" +
            "                    \"carrierCode\": \"R001\"\n" +
            "                }\n" +
            "            ],\n" +
            "            \"person\": {\n" +
            "                \"personNameList\": [\n" +
            "                    {\n" +
            "                        \"nameType\": \"Preferred\",\n" +
            "                        \"firstName\": \"Mary\",\n" +
            "                        \"middleName\": \"R\",\n" +
            "                        \"lastName\": \"Lorch\"\n" +
            "                    }\n" +
            "                ],\n" +
            "                \"gender\": \"F\",\n" +
            "                \"maritalStatus\": \"Unknown\",\n" +
            "                \"dateOfBirth\": \"1947-11-21\",\n" +
            "                \"dateOfDeath\": null\n" +
            "            },\n" +
            "            \"phone\": {\n" +
            "                \"primaryPhone\": \"4332167715\"\n" +
            "            },\n" +
            "            \"email\": {\n" +
            "                \"primaryEmail\": \"riskeduc8@gmail.com\"\n" +
            "            },\n" +
            "            \"userId\": \"AEF\",\n" +
            "            \"partyStatus\": \"Active\",\n" +
            "            \"inactiveFlag\": false,\n" +
            "            \"inactiveDate\": null\n" +
            "        }\n" +
            "    ]\n" +
            "}";

    public static FindCustomerByPolicyResponse transformCustomerByPolicyListStringToObject() {
        FindCustomerByPolicyResponse searchPolicyResponse =
                JSONUtility.convertStringToObject(searchPolicyResponseJson, FindCustomerByPolicyResponse.class);

        return searchPolicyResponse;

    }
}
