package com.pm.api.agencycopilot.utility;

import com.pm.api.agencycopilot.controller.ApplicationStatusController;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Date;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class DateFormatterUtilityTest {
    
    @Test
    void testFormat() {
        String format = "YYYY-MM-dd HH:mm:ss.SSS";
        Assertions.assertNotNull(DateFormatterUtility.format(new Date(), format));
    }

}
