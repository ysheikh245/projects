package com.pm.api.agencycopilot.services;

import com.atiam.applicantperson._2008.ApplicantPersonType;
import com.atiam.insprocommon._2008.SystemCodeTableValueType;
import com.atiam.insprofault._2008.IPFaultListType;
import com.atiam.insprofault._2008.IPFaultType;
import com.atiam.person._2008.NameComponentsType;
import com.atiam.policy._2008.GetPolicyDetailResponseOutputType;
import com.atiam.policy._2008.GetPolicyDetailResponseType;
import com.atiam.policy._2008.PolicyDetailType;
import com.atiam.policy._2008.PolicyStatusType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.services.impl.AsynchronousInvocationServiceHelper;
import com.pm.api.agencycopilot.services.impl.InsproPolicyServiceHandlerImpl;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.ActiveProfiles;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
class InsproPolicyServiceHandlerTest {

    @InjectMocks
    InsproPolicyServiceHandlerImpl insproPolicyServiceHandler;
    @Mock
    private AsynchronousInvocationServiceHelper asynchronousInvocationServiceHelper;
    @Mock
    ThreadPoolTaskExecutor taskExecutor;
    @Mock
    ThreadPoolExecutor threadPoolExecutor;
    @Mock
    BlockingDeque<Runnable> blockingDeque;

    @Mock
    MongoDBCacheHandler mongoDBCacheHandler;
    List<PolicyVO> policyVOS;


    @BeforeEach
    public void setup() throws Exception {
        policyVOS = JsonTransformationUtils.transformApplicationStatusStringToObject().getPolicy();


    }

    private GetPolicyDetailResponseType buildGetPolicyDetailResponseType(boolean isPending) throws DatatypeConfigurationException {
        GetPolicyDetailResponseType getPolicyDetailResponseType = new GetPolicyDetailResponseType();
        GetPolicyDetailResponseOutputType getPolicyDetailResponseOutputType = new GetPolicyDetailResponseOutputType();
        PolicyDetailType policyDetailType = new PolicyDetailType();

        policyDetailType.setPolicyNumber(policyVOS.get(0).getPolicyNumber());
        PolicyStatusType policyStatusType = new PolicyStatusType();
        if (isPending) {
            policyStatusType.setPolicyStatusCode("P01");
            policyStatusType.setPolicyStatusLongName("Pending - Documents Missing");
            policyStatusType.setPolicyStatusShortName("Pending");
            policyDetailType.setPolicyStatus(policyStatusType);
        } else {
            policyStatusType.setPolicyStatusCode("A01");
            policyStatusType.setPolicyStatusLongName("Active - Premium Paying");
            policyStatusType.setPolicyStatusShortName("Active");
            policyDetailType.setPolicyStatus(policyStatusType);
        }


        SystemCodeTableValueType systemCodeTableValueType = new SystemCodeTableValueType();
        systemCodeTableValueType.setCode("AB");
        systemCodeTableValueType.setLongName("AB Group");
        policyDetailType.setBasePlan(systemCodeTableValueType);
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date());
        XMLGregorianCalendar xCal = DatatypeFactory.newInstance()
                .newXMLGregorianCalendar(cal);
        policyDetailType.setApplicationReceivedDate(xCal);
        policyDetailType.setPolicyIssueDate(xCal);

        ApplicantPersonType applicantPersonType = new ApplicantPersonType();
        NameComponentsType nameComponentsType = new NameComponentsType();
        nameComponentsType.setFirstName("TestFirstName");
        nameComponentsType.setLastName("TestLastName");
        applicantPersonType.setNameComponents(nameComponentsType);
        policyDetailType.setOwner(applicantPersonType);

        getPolicyDetailResponseOutputType.setPolicyDetail(policyDetailType);
        getPolicyDetailResponseType.setInfo(getPolicyDetailResponseOutputType);
        return getPolicyDetailResponseType;
    }

    @Test
    void testGetPolicyDetailsFromInspro() throws Exception {
        when(taskExecutor.getActiveCount()).thenReturn(2);
        when(taskExecutor.getPoolSize()).thenReturn(2);
        when(taskExecutor.getThreadPoolExecutor()).thenReturn(threadPoolExecutor);
        when(taskExecutor.getThreadPoolExecutor().getQueue()).thenReturn(blockingDeque);
        when(taskExecutor.getThreadPoolExecutor().getQueue().size()).thenReturn(2);
        PolicyCategoriesRecord policyCategoriesRecord = new PolicyCategoriesRecord();
        policyCategoriesRecord.setCode("A01");
        policyCategoriesRecord.setCategory("Issued");
        when(mongoDBCacheHandler.findApplicationStatusCodes(anyString(), anyBoolean())).thenReturn(policyCategoriesRecord);
        CompletableFuture<GetPolicyDetailResponseType> typeCompletableFuture = new CompletableFuture<>();
        GetPolicyDetailResponseType type = new GetPolicyDetailResponseType();
        typeCompletableFuture.complete(type);
        GetPolicyDetailResponseType getPolicyDetailResponseType = buildGetPolicyDetailResponseType(false);
        when(asynchronousInvocationServiceHelper.invokeInsproSOAPCall(policyVOS.get(0)))
                .thenReturn(CompletableFuture.completedFuture(getPolicyDetailResponseType));
        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setProductCode("C");
        productTypeCategoriesRecord.setCategory("Cancer");
        productTypeCategoriesRecord.setActive(true);
        when(mongoDBCacheHandler.findProductTypeCategory(anyString(), anyBoolean())).thenReturn(productTypeCategoriesRecord);
//        when(asynchronousInsproPolicyServiceHandler.invokeInsproSOAPCall(POLICY_NUMBER)).thenReturn(typeCompletableFuture);
        List<PolicyVO> result =
                insproPolicyServiceHandler.getPolicyDetailsFromInspro(
                        Arrays.asList(policyVOS.get(0)));
//        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPolicyDetailsFromInsproWithIpFaultList() throws Exception {
        when(taskExecutor.getActiveCount()).thenReturn(2);
        when(taskExecutor.getPoolSize()).thenReturn(2);
        when(taskExecutor.getThreadPoolExecutor()).thenReturn(threadPoolExecutor);
        when(taskExecutor.getThreadPoolExecutor().getQueue()).thenReturn(blockingDeque);
        when(taskExecutor.getThreadPoolExecutor().getQueue().size()).thenReturn(2);
        CompletableFuture<GetPolicyDetailResponseType> typeCompletableFuture = new CompletableFuture<>();
        GetPolicyDetailResponseType type = new GetPolicyDetailResponseType();
        typeCompletableFuture.complete(type);
        GetPolicyDetailResponseType getPolicyDetailResponseType = buildGetPolicyDetailResponseType(false);
        IPFaultListType ipFaultListType = new IPFaultListType();
        IPFaultType ipFaultType = new IPFaultType();
        ipFaultType.setFaultReasonText("No Policy Information found in Inspro");
        ipFaultListType.getIPFault().add(ipFaultType);
        getPolicyDetailResponseType.setIPFaultList(ipFaultListType);

        when(asynchronousInvocationServiceHelper.invokeInsproSOAPCall(policyVOS.get(0)))
                .thenReturn(CompletableFuture.completedFuture(getPolicyDetailResponseType));
//        when(asynchronousInsproPolicyServiceHandler.invokeInsproSOAPCall(POLICY_NUMBER)).thenReturn(typeCompletableFuture);
        List<PolicyVO> result =
                insproPolicyServiceHandler.getPolicyDetailsFromInspro(
                        Arrays.asList(policyVOS.get(0)));
//        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPolicyDetailsFromInsproPending() throws Exception {
        when(taskExecutor.getActiveCount()).thenReturn(2);
        when(taskExecutor.getPoolSize()).thenReturn(2);
        when(taskExecutor.getThreadPoolExecutor()).thenReturn(threadPoolExecutor);
        when(taskExecutor.getThreadPoolExecutor().getQueue()).thenReturn(blockingDeque);
        when(taskExecutor.getThreadPoolExecutor().getQueue().size()).thenReturn(2);
        CompletableFuture<GetPolicyDetailResponseType> typeCompletableFuture = new CompletableFuture<>();
        GetPolicyDetailResponseType type = new GetPolicyDetailResponseType();
        typeCompletableFuture.complete(type);


        GetPolicyDetailResponseType getPolicyDetailResponseType = buildGetPolicyDetailResponseType(true);
        when(asynchronousInvocationServiceHelper.invokeInsproSOAPCall(policyVOS.get(3)))
                .thenReturn(CompletableFuture.completedFuture(getPolicyDetailResponseType));
        PolicyCategoriesRecord policyCategoriesRecord = new PolicyCategoriesRecord();
        policyCategoriesRecord.setCode("A01");
        policyCategoriesRecord.setCategory("Issued");
        when(mongoDBCacheHandler.findApplicationStatusCodes(anyString(), anyBoolean())).thenReturn(policyCategoriesRecord);
        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setProductCode("C");
        productTypeCategoriesRecord.setCategory("Cancer");
        productTypeCategoriesRecord.setActive(true);
        when(mongoDBCacheHandler.findProductTypeCategory(anyString(), anyBoolean())).thenReturn(productTypeCategoriesRecord);
//        when(asynchronousInsproPolicyServiceHandler.invokeInsproSOAPCall(POLICY_NUMBER)).thenReturn(typeCompletableFuture);
        List<PolicyVO> result =
                insproPolicyServiceHandler.getPolicyDetailsFromInspro(
                        Arrays.asList(
                                policyVOS.stream()
                                        .filter(policyVO -> policyVO.getPolicyStatus().equalsIgnoreCase("Pending"))
                                        .findFirst().get()));

        //System.out.println("===>" + result.size());
        Assertions.assertNotNull(result);
    }
}
