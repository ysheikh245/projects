package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import com.pm.api.agencycopilot.models.enums.ClaimTypeEnum;
import com.pm.api.agencycopilot.models.external.claims.ClaimsResponse;
import com.pm.api.agencycopilot.models.external.claims.ClaimsResponseItem;
import com.pm.api.agencycopilot.models.external.claims.details.ClaimPayment;
import com.pm.api.agencycopilot.models.external.claims.details.Payee;
import com.pm.api.agencycopilot.models.external.claims.details.Response;
import com.pm.api.agencycopilot.services.impl.ClaimsServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
public class ClaimsServiceHandlerTest {

    private static final String CLAIM_NUMBER = "LAY50770";
    private static final String CLAIMANT_NAME = "HUTCHISON,J";
    private static final String CLAIM_STATUS = "2";

    @InjectMocks
    private ClaimsServiceHandlerImpl claimsServiceHandler;

    @Mock
    RestHelperServiceImpl restHelperService;


    @BeforeEach
    public void init() {
        setField(claimsServiceHandler, "claimsAPIUsername", DEMO);
        setField(claimsServiceHandler, "claimsAPIPassword", DEMO);
        setField(claimsServiceHandler, "claimDetailsAPIEndpoint", API_URL);
        setField(claimsServiceHandler, "claimsByPartyIdAPIEndpoint", API_URL);
        setField(claimsServiceHandler, "claimsAPIClientHeader", DEMO);
        setField(claimsServiceHandler, "claimsAPIClientUserId", DEMO);
        setField(claimsServiceHandler, "restHelperService", restHelperService);
    }

    @Test
    public void testHealthGetClaimDetails() {
        when(restHelperService.invoke(anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<Response>>any()))
                .thenReturn(new ResponseEntity(getHealthClaimDetailsResponse(), HttpStatus.OK));
        Response claimDetailsResponse = claimsServiceHandler.getClaimDetails("LEY54130");
        List<Payee> payees = claimDetailsResponse.getPayees();
        assertNotNull(claimDetailsResponse);
        assertNotNull(payees);
        assertEquals(claimDetailsResponse.getClaimType(), ClaimTypeEnum.HEALTH.toString());
        assertEquals(claimDetailsResponse.getClaimNumber(), CLAIM_NUMBER);
        assertEquals(claimDetailsResponse.getClaimantName(), CLAIMANT_NAME);
        assertEquals(claimDetailsResponse.getClaimStatus(), CLAIM_STATUS);
        assertEquals(payees.get(0).getAddress1(), "PO BOX 860674");
        assertEquals(payees.get(0).getCity(), "MINNEAPOLIS");
        assertEquals(payees.get(0).getZip(), "55486");
        assertEquals(payees.get(0).getName(), "SACRED HEART HEALTH SERVI");
        assertEquals(payees.get(0).getState(), "MN");
        assertEquals(payees.get(0).getSequence(), "1");
        assertEquals(payees.get(0).getPaymentDate(), "2022-06-20");
        assertEquals(payees.get(0).getAmountPaid(), 10.15);
    }

    @Test
    public void testLifeGetClaimDetails() {
        when(restHelperService.invoke(anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<Response>>any()))
                .thenReturn(new ResponseEntity(getLifeClaimDetailsResponse(), HttpStatus.OK));
        Response claimDetailsResponse = claimsServiceHandler.getClaimDetails("2300109561");
        List<ClaimPayment> claimPayments = claimDetailsResponse.getClaimPayments();
        assertNotNull(claimDetailsResponse);
        assertNotNull(claimPayments);
        assertEquals(claimDetailsResponse.getClaimType(), ClaimTypeEnum.LIFE.toString());
        assertEquals(claimDetailsResponse.getClaimNumber(), CLAIM_NUMBER);
        assertEquals(claimDetailsResponse.getClaimantName(), CLAIMANT_NAME);
        assertEquals(claimDetailsResponse.getClaimStatus(), CLAIM_STATUS);
        assertEquals(claimPayments.get(0).getDisbursementDate(), "2020-09-15");
        assertEquals(claimPayments.get(0).getPaidAmount(), "9359.73");
        assertEquals(claimPayments.get(0).getPayeeAddress(), "PO Box 1225");
        assertEquals(claimPayments.get(0).getPayeeCity(), "JONESBORO");
        assertEquals(claimPayments.get(0).getPayeeState(), "AR");
        assertEquals(claimPayments.get(0).getPayeeZip(), "72403");
        assertEquals(claimPayments.get(0).getPayeeName(), "Roller Farmers Union Funeral H");
    }

    @Test
    public void testGetClaimsFromPartyId() {
        lenient().when(restHelperService.invoke(anyString(),
                        any(HttpMethod.class),
                        any(),
                        ArgumentMatchers.<Class<ClaimsResponse>>any()))
                .thenReturn(new ResponseEntity(getClaimItemsResponse(), HttpStatus.OK));
        List<ClaimsResponseItem> claimsResponseItems = claimsServiceHandler.getClaimsFromPartyId("dummyPartyId");
        assertNotNull(claimsResponseItems);
    }

    private ClaimsResponse getClaimItemsResponse() {
        ClaimsResponse claimsResponse = new ClaimsResponse();
        claimsResponse.setResponse(new ArrayList<>());
        return claimsResponse;
    }

    private Response getHealthClaimDetailsResponse() {
        Response response = new Response();
        Payee payee = new Payee();
        List<Payee> payees = new ArrayList<>();
        response.setClaimNumber(CLAIM_NUMBER);
        response.setClaimantName(CLAIMANT_NAME);
        response.setClaimStatus(CLAIM_STATUS);
        response.setClaimType(ClaimTypeEnum.HEALTH.toString());
        payee.setAddress1("PO BOX 860674");
        payee.setName("SACRED HEART HEALTH SERVI");
        payee.setZip("55486");
        payee.setState("MN");
        payee.setCity("MINNEAPOLIS");
        payee.setAmountPaid(10.15);
        payee.setPaymentDate("2022-06-20");
        payee.setSequence("1");
        payees.add(payee);
        response.setPayees(payees);
        return response;
    }

    private Response getLifeClaimDetailsResponse() {
        Response response = new Response();
        ClaimPayment claimPayment = new ClaimPayment();
        List<ClaimPayment> claimPaymentList = new ArrayList<>();
        response.setClaimNumber(CLAIM_NUMBER);
        response.setClaimantName(CLAIMANT_NAME);
        response.setClaimStatus(CLAIM_STATUS);
        response.setClaimType(ClaimTypeEnum.LIFE.toString());
        claimPayment.setDisbursementDate("2020-09-15");
        claimPayment.setPaidAmount("9359.73");
        claimPayment.setPayeeAddress("PO Box 1225");
        claimPayment.setPayeeCity("JONESBORO");
        claimPayment.setPayeeName("Roller Farmers Union Funeral H");
        claimPayment.setPayeeState("AR");
        claimPayment.setPayeeZip("72403");
        claimPaymentList.add(claimPayment);
        response.setClaimPayments(claimPaymentList);
        return response;
    }


}
