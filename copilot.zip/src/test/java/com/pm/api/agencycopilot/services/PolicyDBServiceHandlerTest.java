package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.NPN_2;
import com.pm.api.agencycopilot.models.apis.SortOrderEnum;
import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.impl.PolicyDBServiceHandlerImpl;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import org.hibernate.Query;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.test.context.ActiveProfiles;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class PolicyDBServiceHandlerTest {

    @InjectMocks
    PolicyDBServiceHandlerImpl policyDBServiceHandler;
    @Mock
    EntityManager emInsproExt;
    @Mock
    Query query;

    @Mock
    JdbcTemplate jdbcTemplate;

    //    @Test
    void testGetPoliciesByNPN() {
        List<PolicyVO> resultList = new ArrayList<>();
        PolicyVO policyVO = new PolicyVO();
        policyVO.setPolicyNumber("tet");
        resultList.add(policyVO);
        policyVO = new PolicyVO();
        policyVO.setPolicyNumber("tet1");
        resultList.add(policyVO);

        when(jdbcTemplate.query(anyString(), (ResultSetExtractor<Object>) any()))
                .thenAnswer((invocation -> {
                    ResultSetExtractor<Map<Integer, PolicyVO>> resultSetExtractor =
                            (ResultSetExtractor<Map<Integer, PolicyVO>>) invocation.getArgument(1);

                    ResultSet rs = mock(ResultSet.class);

                    // two times it returns true and third time returns false.
                    when(rs.next()).thenReturn(true, true, false);

                    // Mock ResultSet to return two rows.
                    when(rs.getString(ArgumentMatchers.eq("POLICY_NUMBER")))
                            .thenReturn("TEST-POLICY-NUMBER");
                    when(rs.getString(ArgumentMatchers.eq("SUBMIT_DATE")))
                            .thenReturn("2023-10-10");

                    return resultSetExtractor.extractData(rs);
                }));

        List<PolicyVO> response = policyDBServiceHandler.getPoliciesByNPN(NPN_2, buildFilterCriteriaVo());
        Assertions.assertNotNull(response);
    }

    private FilterCriteriaVO buildFilterCriteriaVo() {
        FilterCriteriaVO filterCriteriaVO = new FilterCriteriaVO();
        filterCriteriaVO.setDays(7);
        filterCriteriaVO.setSortOrder(SortOrderEnum.DESC);
        return filterCriteriaVO;
    }
}