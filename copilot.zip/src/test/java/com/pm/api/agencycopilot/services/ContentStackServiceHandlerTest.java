package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.services.impl.ContentStackServiceHandlerImpl;
import static com.pm.api.agencycopilot.utility.MockResponseFileReader.readMockResponse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
public class ContentStackServiceHandlerTest {

    @InjectMocks
    private ContentStackServiceHandlerImpl contentStackServiceHandler;

    @Mock
    RestTemplate restTemplate;

    @Mock
    private MongoDBCacheHandler mongoDBCacheHandler;


    @BeforeEach
    public void init() {
        ReflectionTestUtils.setField(contentStackServiceHandler, "apiKey", "apiKey");
        ReflectionTestUtils.setField(contentStackServiceHandler, "accessToken", "accessToken");
        ReflectionTestUtils.setField(contentStackServiceHandler, "baseURL", "http://api-baseURL.com");
        ReflectionTestUtils.setField(contentStackServiceHandler, "environment", "test");

    }

    @Test
    public void testValidContentStackResponseFromCache() {
        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setCategory("Life");

        ContentStackProductCategory contentStackProductCategory = new ContentStackProductCategory();
        contentStackProductCategory.setContentStackResponse(readMockResponse("contentStack", "contentStackProductCategory.json"));

        when(mongoDBCacheHandler.findProductTypeCategory(anyString(), anyBoolean())).thenReturn(productTypeCategoriesRecord);
        when(mongoDBCacheHandler.findByProductCategory(anyString())).thenReturn(contentStackProductCategory);

        Response contentStackResponse = contentStackServiceHandler.getAgentWorksheetOptionsResponse("POLICY_STATUS_CODE");
        assertTrue(contentStackResponse != null);
    }

    @Test
    public void testValidContentStackResponseFromContentStack() {
        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setCategory("Life");

        when(mongoDBCacheHandler.findProductTypeCategory(anyString(), anyBoolean())).thenReturn(productTypeCategoriesRecord);
        when(mongoDBCacheHandler.findByProductCategory("Life")).thenReturn(null);
        when(mongoDBCacheHandler.insertContentStackResponseForProductCategory(ArgumentMatchers.any())).thenReturn(new ContentStackProductCategory());

        when(restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenReturn(new ResponseEntity<>(
                readMockResponse("contentStack", "contentStackProductCategory.json"),
                HttpStatus.OK));

        Response contentStackResponse = contentStackServiceHandler.getAgentWorksheetOptionsResponse("POLICY_STATUS_CODE");
        assertTrue(contentStackResponse != null);
    }

    @Test
    public void testExceptionContentStackResponse() {
        /*when(restTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any(),
                ArgumentMatchers.any(Map.class))).thenThrow(new RuntimeException());*/

        ProductTypeCategoriesRecord productTypeCategoriesRecord = new ProductTypeCategoriesRecord();
        productTypeCategoriesRecord.setCategory("Life");

        when(mongoDBCacheHandler.findProductTypeCategory(anyString(), anyBoolean())).thenReturn(productTypeCategoriesRecord);
        when(mongoDBCacheHandler.findByProductCategory("Life")).thenReturn(null);
        when(mongoDBCacheHandler.insertContentStackResponseForProductCategory(ArgumentMatchers.any())).thenReturn(new ContentStackProductCategory());

        when(restTemplate.exchange(
                ArgumentMatchers.any(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<String>>any())).thenThrow(new RuntimeException());

        Response contentStackResponse = contentStackServiceHandler.getAgentWorksheetOptionsResponse("POLICY_STATUS_CODE");
        assertEquals(null, contentStackResponse);
    }
}