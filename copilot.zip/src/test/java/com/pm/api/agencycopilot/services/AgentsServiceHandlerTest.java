package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.NPN_2;
import com.pm.api.agencycopilot.models.external.agents.AgentsAPIResponse;
import com.pm.api.agencycopilot.models.external.agents.Response;
import com.pm.api.agencycopilot.services.impl.AgentsServiceHandlerImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;
import org.springframework.web.client.RestTemplate;


@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class AgentsServiceHandlerTest {
    @InjectMocks
    AgentsServiceHandlerImpl agentsServiceHandler;
    @Mock
    RestTemplate restTemplate;

    private AgentsAPIResponse mockResponse;

    @BeforeEach
    void init() {
        setField(agentsServiceHandler, "agentsAPIUsername", DEMO);
        setField(agentsServiceHandler, "agentsAPIPassword", DEMO);
        setField(agentsServiceHandler, "agentsAPIEndpoint", API_URL);
        setField(agentsServiceHandler, "agentsAPIClientHeader", DEMO);
        setField(agentsServiceHandler, "agentsAPIClientUserId", DEMO);

        mockResponse = new AgentsAPIResponse();
        Response resp = new Response();
        resp.setNpn(NPN_2);
        mockResponse.setResponse(resp);

    }

    @Test
    void testGetAgentsDetail() {

        when(restTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<AgentsAPIResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        AgentsAPIResponse response = agentsServiceHandler.getAgentsDetail(NPN_2);
        Assertions.assertNotNull(response);
        Assertions.assertNotNull(response.getResponse());
        Assertions.assertEquals(NPN_2, response.getResponse().getNpn());
    }


    @Test
    void testGetAgentsDetailWithFail() {
//        setField(agentsServiceHandler, "agentsAPIEndpoint", null);

        when(restTemplate.exchange(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(),
                ArgumentMatchers.<Class<AgentsAPIResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        AgentsAPIResponse response = agentsServiceHandler.getAgentsDetail(NPN_2);
        Assertions.assertNotNull(response);
    }
}