package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.SystemInformation;
import com.pm.api.agencycopilot.services.impl.SystemInformationServiceImpl;
import com.pm.global.environment.EnvironmentUtil;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ActiveProfiles;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class SystemInformationServiceTest {
    @InjectMocks
    SystemInformationServiceImpl systemInformationService;

    @Mock
    EnvironmentUtil environmentUtil;

    @Mock
    Environment environment;


    @Test
    void testGetSystemData() {
        SystemInformation info = systemInformationService.getSystemData();
        assertNotNull(info);
    }
}