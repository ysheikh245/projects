package com.pm.api.agencycopilot.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.PARTY_ID;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.external.customers.AddressListItem;
import com.pm.api.agencycopilot.models.external.customers.CustomerByPolicy;
import com.pm.api.agencycopilot.models.external.customers.CustomerRoleByPolicy;
import com.pm.api.agencycopilot.models.external.customers.Email;
import com.pm.api.agencycopilot.models.external.customers.ExternalReferenceListItem;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerRoleByPolicyResponse;
import com.pm.api.agencycopilot.models.external.customers.Person;
import com.pm.api.agencycopilot.models.external.customers.Phone;
import com.pm.api.agencycopilot.models.external.customers.PolicyListItem;
import com.pm.api.agencycopilot.models.external.customers.PolicyRoleListItem;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.Dependent;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsPerson;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Document;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Policy;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.RiderDetailsItem;
import com.pm.api.agencycopilot.models.external.pmapi2.RiderOffers;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyMessageItem;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyMessage;
import com.pm.api.agencycopilot.models.external.pmapi2.CustomerMessage;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.ReflectionTestUtils.setField;

import static org.springframework.test.util.ReflectionTestUtils.setField;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class PolicyDetailTransformerTest {
    @InjectMocks
    PolicyDetailTransformer transformer;

    @Test
    void testGetCoverageDetailFromRiderDetails() {
        PolicyV2Response policyDetails = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setPolicyNumber(POLICY_NUMBER);
        policy.setRiderDetails(List.of(new RiderDetailsItem()));
        RiderOffers ro = new RiderOffers();
        ro.setBenAmount("3.0");
        ro.setPremium("5.0");
        policy.setRiderOffers(List.of(ro));
        policy.setDiscounts(List.of(new PolicyDiscounts()));
        policy.setRateChanges(List.of(new PolicyRateChange()));
        policy.setBeneficiaryDetails(List.of(new BeneficiaryDetails()));
        policy.setAdditionalCoverages(List.of(new AdditionalCoverage()));
        policyDetails.setPolicies(List.of(policy));


        List<CoverageDetailsVO> voList = transformer.getCoverageDetailFromRiderDetails(policyDetails, POLICY_NUMBER);
        Assertions.assertNotNull(voList);
    }

    @Test
    public void testGetCoverageDetailFromRiderDetails_NullPolicyDetails() {
        //String policyNumber = "POLICY123";
        PolicyV2Response policyDetails = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setPolicyNumber(POLICY_NUMBER);
        policy.setBeneficiaryDetails(List.of(new BeneficiaryDetails()));
        policyDetails.setPolicies(List.of(policy));

        List<CoverageDetailsVO> voList = transformer.getCoverageDetailFromRiderDetails(policyDetails, POLICY_NUMBER);
        Assertions.assertNull(voList);
    }

    @Test
    void testGetAdditionalDetailsCountVO() {
        DependentsV2Reponse dependentsV2Reponse = new DependentsV2Reponse();
        Dependent dependent = new Dependent();
        dependent.setPolicyNumber(POLICY_NUMBER);
        DependentsPerson dependentsPerson = new DependentsPerson();
        dependent.setDependentsPerson(List.of(dependentsPerson));
        dependentsV2Reponse.setDependent(List.of(dependent));

        PolicyV2Response policyDetails = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setPolicyNumber(POLICY_NUMBER);
        policy.setRiderDetails(List.of(new RiderDetailsItem()));
        policy.setRiderOffers(List.of(new RiderOffers()));
        policy.setDiscounts(List.of(new PolicyDiscounts()));
        policy.setRateChanges(List.of(new PolicyRateChange()));
        policy.setBeneficiaryDetails(List.of(new BeneficiaryDetails()));
        policy.setAdditionalCoverages(List.of(new AdditionalCoverage()));
        policyDetails.setPolicies(List.of(policy));

        PolicyInfoV2Response<Role> roleInfoV2Response = new PolicyInfoV2Response<>();
        roleInfoV2Response.setResponse(List.of(new Role()));

        PolicyInfoV2Response<AgentRole> agentRoleInfoV2Response = new PolicyInfoV2Response<>();
        agentRoleInfoV2Response.setResponse(List.of(new AgentRole()));
        DocumentsV2Response<DocumentsResponse> policyDocuments = new DocumentsV2Response<>();
        DocumentsResponse ds = new DocumentsResponse();
        ds.setDocuments(List.of(new Document()));
        policyDocuments.setResponseData(ds);

        PolicyMessageItem policyMessageItem1 = new PolicyMessageItem();
        policyMessageItem1.setMessageCode("121");
        policyMessageItem1.setMessage("Register Complaint");
        policyMessageItem1.setAlertLevel("Medium");
        PolicyMessageItem policyMessageItem2 = new PolicyMessageItem();
        policyMessageItem1.setMessageCode("122");
        policyMessageItem1.setMessage("Register Complaint 2");
        policyMessageItem1.setAlertLevel("Severe");

        PolicyMessage plm1 = new PolicyMessage();
        plm1.setMessages(List.of(policyMessageItem1, policyMessageItem2));
        plm1.setPolicyNumber("123345");
        PolicyMessage plm2 = new PolicyMessage();
        plm2.setMessages(List.of(policyMessageItem1, policyMessageItem2));
        plm2.setPolicyNumber("ABCDEF");
        List<PolicyMessage> policyMessages = Arrays.asList(plm1, plm2);

        CustomerMessage cm1 = new CustomerMessage();
        cm1.setMessageCode("121");
        cm1.setMessage("Register Complaint");
        cm1.setAlertLevel("Medium");
        List<CustomerMessage> customerMessages = Arrays.asList(cm1);

        PolicyAlertResponse policyAlertResponse = new PolicyAlertResponse();
        policyAlertResponse.setPolicyMessages(policyMessages);
        policyAlertResponse.setCustomerMessages(customerMessages);

        DocumentsV2Response<PolicyAlertResponse> policyAlertsResponse = new DocumentsV2Response<>();
        policyAlertsResponse.setResponseData(policyAlertResponse);

        AdditionalDetailsCountVO vo = transformer.getAdditionalDetailsCountVO(
                POLICY_NUMBER,
                dependentsV2Reponse,
                policyDetails,
                roleInfoV2Response,
                agentRoleInfoV2Response,
                policyDocuments,
                policyAlertsResponse);
        Assertions.assertNotNull(vo);
    }

    @Test
    void testTransformPMAPIToCustomersContactDetailWithPolicy() throws JsonProcessingException {
        FindCustomerByPolicyResponse customerDetails = new FindCustomerByPolicyResponse();
        List<CustomerByPolicy> list = new ArrayList<>();
        CustomerByPolicy pp = new CustomerByPolicy();
        setField(pp, "partyId", PARTY_ID);
        setField(pp, "person", new Person());
        setField(pp, "email", new Email());
        setField(pp, "phone", new Phone());
        setField(pp, "addressList", List.of(new AddressListItem()));

        ExternalReferenceListItem item = new ExternalReferenceListItem();

        List<PolicyListItem> policyListItem = new ArrayList<>();
        PolicyListItem policyItem = new PolicyListItem();
        setField(policyItem, "policyNumber", POLICY_NUMBER);
        setField(policyItem, "policyRoleList", List.of(new PolicyRoleListItem()));

        policyListItem.add(policyItem);
        setField(item, "policyList", policyListItem);

        List<ExternalReferenceListItem> externalReferenceList = List.of(item);
        setField(pp, "externalReferenceList", externalReferenceList);

        list.add(pp);
        customerDetails.setResponse(list);
        CustomersVO vo = transformer.transformPMAPIToCustomersContactDetail(customerDetails,
                PARTY_ID,POLICY_NUMBER);
        Assertions.assertNotNull(vo);
    }

    @Test
    void testTransformPMAPIToCustomersContactDetail() throws JsonProcessingException {
        FindCustomerByPolicyResponse customerDetails = new FindCustomerByPolicyResponse();
        List<CustomerByPolicy> list = new ArrayList<>();
        CustomerByPolicy pp = new CustomerByPolicy();
        setField(pp, "partyId", PARTY_ID);
        setField(pp, "person", new Person());
        setField(pp, "email", new Email());
        setField(pp, "phone", new Phone());
        setField(pp, "addressList", List.of(new AddressListItem()));
        setField(pp, "externalReferenceList", List.of(new ExternalReferenceListItem()));

        list.add(pp);
        customerDetails.setResponse(list);
        CustomersVO vo = transformer.transformPMAPIToCustomersContactDetail(customerDetails,
                PARTY_ID, POLICY_NUMBER);
        Assertions.assertNotNull(vo);
    }


    @Test
    void testTransformPMAPIToCustomersDetails() {
        PolicyV2Response policyDetails = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setCurrentMode("SEMIANNUALLY");
        policy.setSemiAnnualPremium(100);
        policy.setPolicyNumber(POLICY_NUMBER);
        policy.setIssueDate(new Date());

        policyDetails.setPolicies(List.of(policy));
        PolicyVO vo = transformer.tranfromPMAPIToPolicyDetail(policyDetails, POLICY_NUMBER);
        Assertions.assertNotNull(vo);

        policy.setCurrentMode("ANNUALLY");
        policyDetails.setPolicies(List.of(policy));
        vo = transformer.tranfromPMAPIToPolicyDetail(policyDetails, POLICY_NUMBER);
        Assertions.assertNotNull(vo);

        policy.setCurrentMode("QUARTERLY");
        policyDetails.setPolicies(List.of(policy));
        vo = transformer.tranfromPMAPIToPolicyDetail(policyDetails, POLICY_NUMBER);
        Assertions.assertNotNull(vo);

        policy.setCurrentMode("MONTHLY");
        policyDetails.setPolicies(List.of(policy));
        vo = transformer.tranfromPMAPIToPolicyDetail(policyDetails, POLICY_NUMBER);
        Assertions.assertNotNull(vo);

        FindCustomerByPolicyResponse customerDetails = new FindCustomerByPolicyResponse();
        List<CustomerByPolicy> list = new ArrayList<>();
        CustomerByPolicy pp = new CustomerByPolicy();
        setField(pp, "partyId", PARTY_ID);
        setField(pp, "person", new Person());
        setField(pp, "email", new Email());
        setField(pp, "phone", new Phone());
        setField(pp, "addressList", List.of(new AddressListItem()));
        ExternalReferenceListItem er = new ExternalReferenceListItem();
        PolicyListItem pli = new PolicyListItem();
        setField(pli, "policyNumber", POLICY_NUMBER);
        setField(pli, "policyRoleList", List.of(new PolicyRoleListItem()));


        setField(er, "policyList", List.of(pli));
        setField(pp, "externalReferenceList", List.of(er));
        list.add(pp);
        customerDetails.setResponse(list);

        FindCustomerRoleByPolicyResponse customerRoles = new FindCustomerRoleByPolicyResponse();
        CustomerRoleByPolicy crbp = new CustomerRoleByPolicy();
        crbp.setRole(DEMO);
        crbp.setCurrentAge("30");
        crbp.setName(DEMO);
        customerRoles.setResponse(List.of(crbp));
        List<CustomersVO> voList =
                transformer.transformPMAPIToCustomersDetails(customerDetails, CustomerDetailsRequestType.SEARCH_BY_POLICY, POLICY_NUMBER);
        Assertions.assertNotNull(voList);
        Assertions.assertFalse(voList.isEmpty());

        voList =
                transformer.transformPMAPIToCustomersDetails(customerDetails,
                        CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS, POLICY_NUMBER);
        Assertions.assertNotNull(voList);
        Assertions.assertFalse(voList.isEmpty());
    }
}