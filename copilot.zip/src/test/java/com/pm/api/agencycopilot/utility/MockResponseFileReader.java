package com.pm.api.agencycopilot.utility;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;

public class MockResponseFileReader {

    public static String readMockResponse(String folder, String fileName) {
        try {
            Path path = Paths.get("./src/test/resources/responses/" + folder + "/" + fileName);
            List<String> contents = Files.readAllLines(path);
            StringBuilder builder = new StringBuilder();
            for (String content : contents) {
                builder.append(content);
            }
            return builder.toString();
        } catch(Exception e) {
            return BLANK;
        }
    }

}
