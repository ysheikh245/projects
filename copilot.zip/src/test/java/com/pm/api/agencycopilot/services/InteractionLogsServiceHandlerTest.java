package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.NPN;
import static com.pm.api.agencycopilot.constants.TestConstants.PARTY_ID;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.models.external.interactionlogs.Cdreason;
import com.pm.api.agencycopilot.models.external.interactionlogs.Cdreasonsubtype;
import com.pm.api.agencycopilot.models.external.interactionlogs.GetInteractionLogItems;
import com.pm.api.agencycopilot.models.external.interactionlogs.GetInteractionLogResponse;
import com.pm.api.agencycopilot.models.external.interactionlogs.InteractionReason;
import com.pm.api.agencycopilot.models.external.interactionlogs.InteractionReasonsSubTypeItem;
import com.pm.api.agencycopilot.services.impl.InteractionLogsServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import com.pm.api.agencycopilot.utility.CustomerPMAPIProperties;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class InteractionLogsServiceHandlerTest {
    @InjectMocks
    InteractionLogsServiceHandlerImpl interactionLogsServiceHandler;

    @Mock
    RestTemplate restTemplate;

    @Mock
    RestHelperServiceImpl restHelperService;

    @Mock
    CustomerPMAPIProperties customerPMAPIProperties;

    @Mock
    MaskedValueLogger maskedValueLogger;


    @BeforeEach
    void init() {

        Mockito.when(customerPMAPIProperties.getCustomersAPIUsername()).thenReturn(DEMO);
//        Mockito.when(interactionLogsProperties.getCustomersAPIPassword()).thenReturn(DEMO);
        Mockito.when(customerPMAPIProperties.getInteractionLogsAPIEndpoint()).thenReturn(API_URL);
//        Mockito.when(interactionLogsProperties.getCustomersAPIClientHeader()).thenReturn(DEMO);
        Mockito.when(customerPMAPIProperties.getCustomersAPIClientUserId()).thenReturn(DEMO);
//        Mockito.when(interactionLogsProperties.getSystemSourceCode()).thenReturn(DEMO);
//        Mockito.when(interactionLogsProperties.getApplicationEventCode()).thenReturn(DEMO);

    }

    @Test
    void testEventOccurred() {

        List<GetInteractionLogItems> interactionLogItems = new ArrayList<>();
        GetInteractionLogItems items = new GetInteractionLogItems();
        items.setPolicyNumber(POLICY_NUMBER);
        InteractionReason reason = new InteractionReason();
        Cdreason cdReason = new Cdreason();
        cdReason.setReasonCd("2200");
        reason.setCdreason(cdReason);
        InteractionReasonsSubTypeItem interactionReasonsSubTypeItem = new InteractionReasonsSubTypeItem();
//        interactionReasonsSubTypeItem.setInteractionReasonSubtypeId(null);
        Cdreasonsubtype cdreasonsubtype = new Cdreasonsubtype();
        cdreasonsubtype.setReasonSubtypeCd("22050");
        interactionReasonsSubTypeItem.setCdreasonsubtype(cdreasonsubtype);
        reason.setInteractionReasonsSubType(Arrays.asList(interactionReasonsSubTypeItem));
        items.setInteractionReasons(List.of(reason));
        interactionLogItems.add(items);
        GetInteractionLogResponse mockResponse = new GetInteractionLogResponse();
        mockResponse.setInteractionLogItems(interactionLogItems);

        Mockito.when(restHelperService.invoke(
                        ArgumentMatchers.anyString(),
                        ArgumentMatchers.any(HttpMethod.class),
                        ArgumentMatchers.any(),
                        ArgumentMatchers.<Class<GetInteractionLogResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));


        boolean eventOccurred = interactionLogsServiceHandler.isEventOccurred(POLICY_NUMBER, PARTY_ID);
        Assertions.assertFalse(eventOccurred);
    }

    @Test
    void testCreateInteractionLogEntry() {

        String reasonNumber = "122";

        when(restTemplate.postForEntity(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<String>>any()))
                .thenReturn(new ResponseEntity<>(DEMO, HttpStatus.OK));

        interactionLogsServiceHandler.createInteractionLogEntry(NPN, DEMO,
                reasonNumber, PARTY_ID, POLICY_NUMBER, DEMO);
        Assertions.assertTrue(true);

    }


}
