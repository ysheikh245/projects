package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.constants.TestConstants;
import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Policy;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.internal.AgentInformationVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.repository.PolicyCategoriesRepository;
import com.pm.api.agencycopilot.repository.PolicyRepository;
import com.pm.api.agencycopilot.services.ApplicationStatusService;
import com.pm.api.agencycopilot.services.PolicyServiceHandler;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class ApplicationStatusControllerTest {

    ObjectMapper objectMapper = new ObjectMapper();
    private MockMvc mvc;
    @InjectMocks
    private ApplicationStatusController controller;
    @Mock
    private ApplicationStatusService applicationStatusService;
    @Mock
    private PolicyServiceHandler policyServiceHandler;
    @Mock
    private PolicyRepository policyRepository;
    @Mock
    PolicyCategoriesRepository policyCategoriesRepository;

    @BeforeEach
    public void setup() {
        mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();
    }

    @Test
    void testProcessApplicationStatus() throws Exception {
        ApplicationStatusResponse applicationStatusResponse = JsonTransformationUtils.transformApplicationStatusStringToObject();
        Mockito.when(applicationStatusService.processApplicationStatus(ArgumentMatchers.any())).thenReturn(applicationStatusResponse);
        ApplicationStatusRequest request = new ApplicationStatusRequest();
        AgentInformationVO agentInformationVO = new AgentInformationVO();
        agentInformationVO.setNpn("dummy");
        request.setAgentInformation(agentInformationVO);
        mvc.perform(MockMvcRequestBuilders
                        .post("/web/application-status")
                        .requestAttr("npnId", "123456789")
                        .content(objectMapper.writeValueAsString(request))
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }

    @Test
    void testProcessApplicationStatusException() throws Exception {
        Mockito.when(applicationStatusService.processApplicationStatus(ArgumentMatchers.any())).thenThrow(
                new AgencyCoPilotException("Unknown Error Occurred", HttpStatus.INTERNAL_SERVER_ERROR)
        );
        ApplicationStatusRequest request = new ApplicationStatusRequest();
        Assertions.assertThrows(AgencyCoPilotException.class,
                () -> controller.processApplicationStatus("Token", new ApplicationStatusRequest(), "123456789"));

    }

    /*@Test
    void testretrieveApplicationStatusByNPN() throws Exception {
        ApplicationStatusResponse applicationStatusResponse = JsonTransformationUtils.transformApplicationStatusStringToObject();
        Map<String, List<PolicyVO>> resultMap = new HashMap<>();
        resultMap.put("policy", applicationStatusResponse.getPolicy());
        Mockito.when(applicationStatusService.retrieveApplicationStatusByNPN(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(resultMap);
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/application-status/1234?pageNo=0&pageSize=12")
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    } */

    /*@Test
    void testretrieveApplicationStatusByNPNNoResult() throws Exception {
        Map<String, List<PolicyVO>> resultMap = new HashMap<>();
        Mockito.when(applicationStatusService.retrieveApplicationStatusByNPN(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt()))
                .thenReturn(resultMap);
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/application-status/1234?pageNo=0&pageSize=12")
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent()).andReturn();
    }*/

    @Test
    void testretrieveApplicationStatusCacheByNPN() throws Exception {
        PolicyCachingStatusRecord policyCachingStatusRecord = JsonTransformationUtils.transformStatusCacheStringToObject();

        Mockito.when(applicationStatusService.retrieveApplicationStatusCacheResults(Mockito.anyString()))
                .thenReturn(policyCachingStatusRecord);
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/application-status/cache-results/1234")
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }

    @Test
    void testretrieveApplicationStatusCacheByNPNNoResult() throws Exception {
        PolicyCachingStatusRecord policyCachingStatusRecord = JsonTransformationUtils.transformStatusCacheStringToObject();

        Mockito.when(applicationStatusService.retrieveApplicationStatusCacheResults(Mockito.anyString()))
                .thenReturn(null);
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/application-status/cache-results/1234")
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isNoContent()).andReturn();
    }


    @Test
    void testGetPMAPIData() throws Exception {
        PolicyV2Response policyDataFromPMAPI = new PolicyV2Response();
        Policy policy = new Policy();
        policy.setPolicyNumber(TestConstants.POLICY_NUMBER);
        policyDataFromPMAPI.setPolicies(List.of(policy));
        PolicyDatabaseRecord record = new PolicyDatabaseRecord();
        Mockito.when(policyServiceHandler.getPolicyDataFromPMAPI(ArgumentMatchers.any()))
                .thenReturn(policyDataFromPMAPI);
        Mockito.when(policyRepository.save(ArgumentMatchers.any()))
                .thenReturn(record);
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/pmapi/" + TestConstants.POLICY_NUMBER)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }

    /*@Test
    void testinsertApplicationStatusCodes() throws Exception {
        Mockito.when(applicationStatusService.insertPolicyCategoriesRecords(Mockito.any()))
                .thenReturn(JsonTransformationUtils.transformPoliciesCategoriesStringToObject());
        List<PolicyCategoriesRecord> policyCategoriesRecordList = new ArrayList<>();
        mvc.perform(MockMvcRequestBuilders
                        .post("/web/application-status/status-code-cache")
                        .content(objectMapper.writeValueAsString(policyCategoriesRecordList))
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }*/


    /*@Test
    void testgetApplicationStatusCodes() throws Exception {
//        Mockito.when(policyCategoriesRepository.findByCodeAndIsActive(Mockito.anyString(), Mockito.anyBoolean()))
//                .thenReturn(JsonTransformationUtils.transformPoliciesCategoriesStringToObject().get(0));
        mvc.perform(MockMvcRequestBuilders
                        .get("/web/application-status/status-code-cache/P12/true")
                        .contentType(MediaType.APPLICATION_JSON)
                )
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }*/
}
