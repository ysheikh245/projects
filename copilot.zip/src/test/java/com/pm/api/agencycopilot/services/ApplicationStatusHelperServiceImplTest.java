package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum;
import com.pm.api.agencycopilot.models.external.case360.Case360WorksheetResponse;
import com.pm.api.agencycopilot.models.external.case360.FieldList;
import com.pm.api.agencycopilot.models.external.case360.FmsRowSetTO;
import com.pm.api.agencycopilot.models.external.case360.FmsRowTO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.services.impl.ApplicationStatusHelperServiceImpl;
import com.pm.api.agencycopilot.services.impl.InsproPolicyServiceHandlerImpl;
import com.pm.api.agencycopilot.utility.ApplicationStatusProperties;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
public class ApplicationStatusHelperServiceImplTest {

    @InjectMocks
    ApplicationStatusHelperServiceImpl applicationStatusHelperService;

    @Mock
    private PolicyDBServiceHandler policyDBServiceHandler;

    @Mock
    private InsproPolicyServiceHandlerImpl insproPolicyServiceHandler;

    @Mock
    private Case360ServiceHandler case360ServiceHandler;

    @Mock
    private InteractionLogsServiceHandler interactionLogsServiceHandler;

    @Mock
    private CustomersServiceHandler customersServiceHandler;

    @Mock
    private ApplicationStatusProperties applicationStatusProperties;

//    @Value("${agency.copilot.background.processing.feature:false}")
//    private String backgroundProcessingFlag;

    @Mock
    MongoDBCacheHandler mongoDBCacheHandler;

    List<PolicyVO> policyVOList = new ArrayList<>();

    @BeforeEach
    public void setup() throws Exception {
        ReflectionTestUtils.setField(applicationStatusHelperService, "backgroundProcessingFlag", "false");

        policyVOList = JsonTransformationUtils.transformApplicationStatusStringToObject().getPolicy();

        lenient().when(insproPolicyServiceHandler.getPolicyDetailsFromInspro(any())).thenReturn(policyVOList);
        lenient().when(customersServiceHandler.findPartyId(anyString())).thenReturn("TST-PART-ID");
        lenient().when(interactionLogsServiceHandler.isEventOccurred(anyString(), anyString())).thenReturn(true, false);
        lenient().when(applicationStatusProperties.getStatusCodeForEvaluatingThankyouEmail()).thenReturn("A01,P12,P03");
        lenient().when(applicationStatusProperties.getCriteriaDaysToEvaluateThankyou()).thenReturn(30);
        lenient().when(mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                anyString(),
                any(),
                anyBoolean(),
                anyBoolean(),
                anyLong())).thenReturn(new PolicyCachingStatusRecord());
        lenient().when(case360ServiceHandler.getRequirementsDocumentList(anyString())).thenReturn(new ArrayList<>());

        Map<String, String> mdcContextMap = new HashMap<>();
        mdcContextMap.put("TRACE_ID", UUID.randomUUID().toString());
        MDC.setContextMap(mdcContextMap);
    }

    private Case360WorksheetResponse buildCase360WorksheetResponse() {
        Case360WorksheetResponse case360WorksheetResponse = new Case360WorksheetResponse();
        List<FmsRowSetTO> fmsRowSetTOList = new ArrayList<>();
        FmsRowSetTO fmsRowSetTO = new FmsRowSetTO();
        List<FmsRowTO> fmsRowTOList = new ArrayList<>();
        FmsRowTO fmsRowTO = new FmsRowTO();
        List<FieldList> fieldListList = new ArrayList<>();
        FieldList fieldList = new FieldList();
        fieldList.setFieldName("UW_REQUIRE_TYPE_LIST");
        fieldListList.add(fieldList);
        fieldList = new FieldList();
        fieldList.setFieldName("UW_REQUIRE_DATE_RECEIEVED");
        fieldListList.add(fieldList);
        fieldList = new FieldList();
        fieldList.setFieldName("UW_REQUIRE_DESC_LIST");
        fieldListList.add(fieldList);
        fmsRowTO.setFieldList(fieldListList);
        fmsRowTOList.add(fmsRowTO);
        fmsRowSetTO.setFmsRowTO(fmsRowTOList);
//        fmsRowSetTO.setFmsRowTO(fmsRowTOList);
        fmsRowSetTOList.add(fmsRowSetTO);

        case360WorksheetResponse.setFmsRowSetTO(fmsRowSetTOList);

        return case360WorksheetResponse;

    }


    @Test
    public void processprocessApplicationStatusForDefaultSearch() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(policyDBServiceHandler.getPoliciesByNPN(anyString(), any()))
                .thenReturn(policyVOList);

        CompletableFuture<Boolean> result = applicationStatusHelperService.processApplicationStatus(applicationStatusRequest, false);
        Boolean res = result.get();
        Assertions.assertTrue(res);
    }

    @Test
    public void processprocessApplicationStatusForDefaultSearchEvaluateThankyou() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(policyDBServiceHandler.getPoliciesByNPN(anyString(), any()))
                .thenReturn(policyVOList);
        CompletableFuture<Boolean> result = applicationStatusHelperService.processApplicationStatus(applicationStatusRequest, false);
        Boolean res = result.get();
        Assertions.assertTrue(res);
    }

    @Test
    public void processprocessApplicationStatusForDefaultSearchNoPolicies() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(policyDBServiceHandler.getPoliciesByNPN(anyString(), any()))
                .thenReturn(new ArrayList<>());
        CompletableFuture<Boolean> result = applicationStatusHelperService.processApplicationStatus(applicationStatusRequest, false);
        Boolean res = result.get();
        Assertions.assertFalse(res);
    }

    @Test
    public void testprocessprocessApplicationStatusForDefaultSearchNoPoliciesIsBackground() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(policyDBServiceHandler.getPoliciesByNPN(anyString(), any()))
                .thenReturn(new ArrayList<>());
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () ->
                applicationStatusHelperService.processApplicationStatus(applicationStatusRequest, true));
    }

    @Test
    public void testgatherPolicyInformationInBackground() throws Exception {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        when(policyDBServiceHandler.getPoliciesByNPN(anyString(), any()))
                .thenReturn(policyVOList);

        applicationStatusHelperService.gatherPolicyInformationInBackground(applicationStatusRequest);
    }

    @Test
    public void testpaginatedApplicationStatusResponseFromMongo() {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        List<PolicyDatabaseRecord> policyDatabaseRecordList = new ArrayList<>();
        PolicyDatabaseRecord policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(0));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(1));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        when(mongoDBCacheHandler.findPoliciesByNpnUsingCriteria(any())).thenReturn(policyDatabaseRecordList);


        ApplicationStatusResponse applicationStatusResponse =
                applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);

        Assertions.assertNotNull(applicationStatusResponse);
        Assertions.assertTrue(applicationStatusResponse.getPolicy().size() > 0);
    }

    @Test
    public void testpaginatedApplicationStatusResponseFromMongoPolicyNumberSearch() {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setPolicyNumber("H730100190");
        List<PolicyDatabaseRecord> policyDatabaseRecordList = new ArrayList<>();
        PolicyDatabaseRecord policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(0));
        policyDatabaseRecord.setPolicyNumber(policyVOList.get(0).getPolicyNumber());
        policyDatabaseRecordList.add(policyDatabaseRecord);
        policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(1));
        policyDatabaseRecord.setPolicyNumber(policyVOList.get(1).getPolicyNumber());
        policyDatabaseRecordList.add(policyDatabaseRecord);
        when(mongoDBCacheHandler.findPoliciesByNpnUsingCriteria(any())).thenReturn(policyDatabaseRecordList);

        ApplicationStatusResponse applicationStatusResponse =
                applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);

        Assertions.assertNotNull(applicationStatusResponse);
        Assertions.assertTrue(applicationStatusResponse.getPolicy().size() > 0);
    }

    @Test
    public void testpaginatedApplicationStatusResponseFromMongoCustomerName() {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        applicationStatusRequest.getFilterCriteria().setCustomerName("Wisconsinlesse");
        List<PolicyDatabaseRecord> policyDatabaseRecordList = new ArrayList<>();
        PolicyDatabaseRecord policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(0));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(1));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        when(mongoDBCacheHandler.findPoliciesByNpnUsingCriteria(any())).thenReturn(policyDatabaseRecordList);


        ApplicationStatusResponse applicationStatusResponse =
                applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);

        Assertions.assertNotNull(applicationStatusResponse);
        Assertions.assertTrue(applicationStatusResponse.getPolicy().size() > 0);
    }

    @Test
    public void testpaginatedApplicationStatusResponseFromMongoStatusAndStartandEndDate() {
        ApplicationStatusRequest applicationStatusRequest = JsonTransformationUtils.buildApplicationStatusRequest();
        List<PolicyStatusCodeEnum> PolicyStatusCodeEnums = new ArrayList<>();
        PolicyStatusCodeEnums.add(PolicyStatusCodeEnum.ISSUED);
        PolicyStatusCodeEnums.add(PolicyStatusCodeEnum.PENDING);
        applicationStatusRequest.getFilterCriteria().setStatus(PolicyStatusCodeEnums);
        applicationStatusRequest.getFilterCriteria().setSearchToDate(LocalDate.now());
        applicationStatusRequest.getFilterCriteria().setSearchFromDate(LocalDate.now().minusDays(10));
        List<PolicyDatabaseRecord> policyDatabaseRecordList = new ArrayList<>();
        PolicyDatabaseRecord policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(0));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        policyDatabaseRecord = new PolicyDatabaseRecord();
        policyDatabaseRecord.setPolicyResponse(policyVOList.get(1));
        policyDatabaseRecordList.add(policyDatabaseRecord);
        when(mongoDBCacheHandler.findPoliciesByNpnUsingCriteria(any())).thenReturn(policyDatabaseRecordList);


        ApplicationStatusResponse applicationStatusResponse =
                applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);

        Assertions.assertNotNull(applicationStatusResponse);
        Assertions.assertTrue(applicationStatusResponse.getPolicy().size() > 0);
    }
}
