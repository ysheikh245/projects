package com.pm.api.agencycopilot.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import org.assertj.core.util.Strings;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class StringUtilityTest {

    @Test
    void objectToStringSuccess() throws JsonProcessingException {
        CustomersVO customerResponseObj = new CustomersVO();
        customerResponseObj.setGender("F");
        customerResponseObj.setPhoneNumber("6058868542");

        String customerResponse = StringUtility.objectToString(customerResponseObj);
        Assertions.assertEquals(customerResponse, "{\"gender\":\"F\",\"phoneNumber\":\"6058868542\"}");
    }

    @Test
    void getAccumulatedValueSuccess() {
        String phone = StringUtility.getAccumulatedValue(BLANK, "+91", "9660824868");
        Assertions.assertEquals(phone, "+919660824868");
    }

    @Test
    void substringSuccess() {
        String substring = StringUtility.substring("Customer", 1, 4);
        Assertions.assertEquals(substring, "ust");
    }

    @Test
    void getValueWithString() {
        String value = StringUtility.getValue("Customer");
        Assertions.assertEquals(value, "Customer");
    }

    @Test
    void getValueWithNullString() {
        String input = null;
        String value = StringUtility.getValue(input);
        Assertions.assertTrue(Strings.isNullOrEmpty(value));
    }
}
