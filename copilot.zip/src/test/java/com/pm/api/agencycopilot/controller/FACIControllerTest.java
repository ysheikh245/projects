package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.BeneficiaryDetailsResponse;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.DiscountsResponse;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.PolicyAdditionalCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.PolicyCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyRateChangeResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.CustomerMessage;
import com.pm.api.agencycopilot.models.external.pmapi2.Dependent;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsPerson;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Document;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyMessage;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyMessageItem;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.DocumentService;
import com.pm.api.agencycopilot.services.FACIService;
import com.pm.api.agencycopilot.utility.DateFormatterUtility;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.mock;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import javax.servlet.http.HttpServletRequest;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class FACIControllerTest {
    ObjectMapper objectMapper = new ObjectMapper();
    private MockMvc mvc;
    @Mock
    private FACIService faciService;
    @InjectMocks
    private FACIController controller;

    @Mock
    private DocumentService documentService;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    public void setup() {
        mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();
    }

    @Test
    void FACICustomerDetailStatus200() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        reqObj.setPolicyNumber("20");

        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();
        Mockito.when(faciService.getPolicyByCustomerDetails(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(customerDetailResponse);
        mvc.perform(MockMvcRequestBuilders
                        .post("/web/faci/customer-detail/")
                        .content(objectMapper.writeValueAsString(reqObj))
                        .contentType(MediaType.APPLICATION_JSON)
                        .requestAttr("npnId", "12345"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }

    @Test
    void FACICustomerDetailSearchByPolicy() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        reqObj.setPolicyNumber("20");
        String request = new ObjectMapper().writeValueAsString(reqObj);

        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();
        Mockito.when(faciService.getPolicyBySalesCustomerDetails(any(), any())).thenReturn(customerDetailResponse);
        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                        .characterEncoding("utf-8")
                        .content(request).contentType(MediaType.APPLICATION_JSON)
                        .requestAttr("npnId", "12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("[{\"partyId\":\"3342593\",\"role\":\"Owner,Insured\",\"gender\":\"F\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"Patricia\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"},{\"partyId\":\"3430690\",\"role\":\"Spouse\",\"gender\":\"M\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"David\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"}]"));

    }

    @Test
    void FACICustomerDetailSearchByCustomerDetails() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        reqObj.setFirstName("David");
        reqObj.setLastName("wicks");
        reqObj.setState("SD");
        String request = new ObjectMapper().writeValueAsString(reqObj);

        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();
        Mockito.when(faciService.getPolicyBySalesCustomerDetails(any(), any())).thenReturn(customerDetailResponse);
        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                        .characterEncoding("utf-8")
                        .content(request).contentType(MediaType.APPLICATION_JSON)
                        .requestAttr("npnId", "12345")
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("[{\"partyId\":\"3342593\",\"role\":\"Owner,Insured\",\"gender\":\"F\",\"personNameList\":[{\"firstName\":\"Patricia\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"},{\"partyId\":\"3430690\",\"role\":\"Spouse\",\"gender\":\"M\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"David\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"}]"));

    }

    @Test
    void FACICustomerDetailSearchByValidZipFiveDigitCustomerDetails() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        reqObj.setFirstName("David");
        reqObj.setLastName("wicks");
        reqObj.setState("SD");
        reqObj.setZip("12345");
        String request = new ObjectMapper().writeValueAsString(reqObj);

        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();
        Mockito.when(faciService.getPolicyBySalesCustomerDetails(any(), any())).thenReturn(customerDetailResponse);
        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                        .characterEncoding("utf-8")
                        .content(request).contentType(MediaType.APPLICATION_JSON)
                        .requestAttr("npnId", "12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("[{\"partyId\":\"3342593\",\"role\":\"Owner,Insured\",\"gender\":\"F\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"Patricia\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"},{\"partyId\":\"3430690\",\"role\":\"Spouse\",\"gender\":\"M\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"David\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"}]"));

    }

    @Test
    void FACICustomerDetailSearchByValidZipNineDigitCustomerDetails() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        reqObj.setFirstName("David");
        reqObj.setLastName("wicks");
        reqObj.setState("SD");
        reqObj.setZip("12345-1234");
        String request = new ObjectMapper().writeValueAsString(reqObj);

        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();
        Mockito.when(faciService.getPolicyBySalesCustomerDetails(any(), any())).thenReturn(customerDetailResponse);
        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                        .characterEncoding("utf-8")
                        .content(request).contentType(MediaType.APPLICATION_JSON)
                        .requestAttr("npnId", "12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().json("[{\"partyId\":\"3342593\",\"role\":\"Owner,Insured\",\"gender\":\"F\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"Patricia\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"},{\"partyId\":\"3430690\",\"role\":\"Spouse\",\"gender\":\"M\",\"personNameList\":[{\"nameType\":\"Preferred\",\"firstName\":\"David\",\"lastName\":\"Wicks\",\"middleName\":\"\"}],\"policyNumber\":\"H100047354\"}]"));

    }

    @Test
    void FACICustomerDetailBadRequest() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setPolicyNumber("20");
        String request = new ObjectMapper().writeValueAsString(reqObj);

        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                .characterEncoding("utf-8")
                .content(request).contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    void FACICustomerDetailInvalidZipCodeBadRequest() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setZip("2345Abc");
        reqObj.setFirstName("Johns");
        reqObj.setLastName("Wicks");
        reqObj.setState("SD");
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        String request = new ObjectMapper().writeValueAsString(reqObj);

        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                .characterEncoding("utf-8")
                .content(request).contentType(MediaType.APPLICATION_JSON)
                .requestAttr("npnId", "12345"));
    }

    @Test
    void FACICustomerDetailInvalidZipCodeCharactersBadRequest() throws Exception {
        PolicyByCustomerDetailsRequest reqObj = new PolicyByCustomerDetailsRequest();
        reqObj.setZip("12345-3@43");
        reqObj.setFirstName("Johns");
        reqObj.setLastName("Wicks");
        reqObj.setState("SD");
        reqObj.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        String request = new ObjectMapper().writeValueAsString(reqObj);

        mvc.perform(MockMvcRequestBuilders.post("/web/faci/customer-detail/")
                .characterEncoding("utf-8")
                .content(request).contentType(MediaType.APPLICATION_JSON)
                .requestAttr("npnId", "12345"));
    }

    @Test
    void FACIGetCustomerContactDetails200() throws Exception {
        CustomersVO customerResponseObj = new CustomersVO();
        PolicyVO policyData = new PolicyVO();
        policyData.setProductName("PET");
        policyData.setPolicyNumber("10");
        customerResponseObj.setPolicies(List.of(policyData));
        List<CustomersVO> customerDetailResponse = JsonTransformationUtils.transformCustomerDetail();

        Mockito.when(faciService.getPMAPIPolicyDetails("10")).thenReturn(policyData);
        Mockito.when(faciService.getCustomerContactDetails("10", "1")).thenReturn(customerResponseObj);
        mvc.perform(MockMvcRequestBuilders.get("/web/faci/customer-detail/10/party/1"))
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    @Test
    void FACIGetCustomerContactDetails() throws Exception {
        CustomersVO customerResponseObj = new CustomersVO();
        PolicyVO policyResponse = new PolicyVO();
        policyResponse.setPolicyNumber("10");
        policyResponse.setProductName("Pet Insurance");

        customerResponseObj.setGender("F");
        customerResponseObj.setPhoneNumber("6058868542");
        customerResponseObj.setSecondaryPhoneNumber("");
        customerResponseObj.setEmailAddress("WICKS@WAT.MIDCO.NET");
        customerResponseObj.setBirthDate("1950-08-09");
        customerResponseObj.setPolicies(List.of(policyResponse));

        Mockito.when(faciService.getPMAPIPolicyDetails("10")).thenReturn(policyResponse);
        Mockito.when(faciService.getCustomerContactDetails("10", "1")).thenReturn(customerResponseObj);
        mvc.perform(MockMvcRequestBuilders.get("/web/faci/customer-detail/10/party/1"))
                .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.content()
                        .json("{\"gender\":\"F\",\"phoneNumber\":\"6058868542\",\"secondaryPhoneNumber\":\"\",\"emailAddress\":\"WICKS@WAT.MIDCO.NET\",\"birthDate\":\"1950-08-09\",\"policies\":[{\"policyNumber\":\"10\",\"productName\":\"Pet Insurance\",\"parties\":[]}]}"));
    }
    @Test
    void testgetPolicyByCustomerDetailsWithNullnpnId() throws Exception {
        Mockito.when(request.getAttribute("npnId")).thenReturn("null");
        Assertions.assertThrows(AgencyCoPilot4xxException.class,
                () -> controller.getPolicyByCustomerDetails( new PolicyByCustomerDetailsRequest(), request),"npnId is null.");

    }

    @Test
    void FACIgetPMAPIPolicyDetailsSuccess() throws Exception {
        PolicyVO policyVO = new PolicyVO();
        policyVO.setIssueDate(new Date());
        policyVO.setProductName("P150 - Individual Dental");
        policyVO.setPolicyStatus("A01");
        policyVO.setParties(new ArrayList<>());
        policyVO.setPolicyEffectiveDate("2022-06-01");
        policyVO.setLastPaymentDate("2023-01-10");
        policyVO.setPaidToDate("2023-02-01");
        policyVO.setCurrentPremium(36.4);

        Mockito.when(faciService.getPMAPIPolicyDetails("12345")).thenReturn(policyVO);
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        PolicyVO responsePolicyVO = mapper.readValue(result.getResponse().getContentAsString(), PolicyVO.class);
        assertEquals(policyVO.getIssueDate(), responsePolicyVO.getIssueDate());
        assertEquals(policyVO.getPolicyStatus(), responsePolicyVO.getPolicyStatus());
    }


    @Test
    void FACIgetPMAPIPolicyDetailsFailure() throws Exception {
        Mockito.when(faciService.getPMAPIPolicyDetails("12345")).thenThrow(new Exception("Policy Not Found"));
        try {
            mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345")).andReturn();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Policy Not Found"));
        }
    }

    @Test
    void FACIgetAdditionalPolicyDetailCountSuccess() throws Exception {
        AdditionalDetailsCountVO additionalDetailsCountVO = new AdditionalDetailsCountVO();

        additionalDetailsCountVO.setRolesCount(1);
        additionalDetailsCountVO.setDependentsCount(0);
        additionalDetailsCountVO.setAgentsOfRecordCount(2);
        additionalDetailsCountVO.setDiscountsCount(0);
        additionalDetailsCountVO.setAdditionalLifeInsuranceRidersCount(0);
        additionalDetailsCountVO.setCoverageDetailsCount(11);
        additionalDetailsCountVO.setBeneficiaryDetailsCount(0);
        additionalDetailsCountVO.setRateChangesCount(2);
        additionalDetailsCountVO.setViewCustomerDocumentsCount(0);

        Mockito.when(faciService.getAdditionalDetailsCountVO("12345")).thenReturn(additionalDetailsCountVO);
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/additional-info/12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        AdditionalDetailsCountVO responseObject = mapper.readValue(result.getResponse().getContentAsString(), AdditionalDetailsCountVO.class);
        assertEquals(responseObject.getRolesCount(), additionalDetailsCountVO.getRolesCount());
        assertEquals(responseObject.getCoverageDetailsCount(), additionalDetailsCountVO.getCoverageDetailsCount());
    }

    @Test
    void FACIgetAdditionalPolicyDetailCountFail() throws Exception {
        Mockito.when(faciService.getAdditionalDetailsCountVO("12345")).thenThrow(new Exception("Policy Not Found"));
        try {
            mvc.perform(MockMvcRequestBuilders.get("/web/faci/additional-info/12345")).andReturn();
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Policy Not Found"));
        }
    }

    @Test
    void FACIgetPolicyRolesSuccess() throws Exception {
        Role role = new Role();

        role.setName("Deborah A Cotton");
        role.setRole("Owner");
        role.setCurrentAge("65");
        role.setIssueAge("64");

        PolicyInfoV2Response<Role> pmapiRolesResponse = new PolicyInfoV2Response<>();
        pmapiRolesResponse.setResponse(List.of(role));
        Mockito.when(faciService.getPolicyRoleInfo("12345")).thenReturn(pmapiRolesResponse);
        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/roles"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        TypeReference<PolicyInfoV2Response<Role>> typeReference = new TypeReference<>() {
        };
        PolicyInfoV2Response<Role> responseObject = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        assertEquals(responseObject.getResponse().get(0).getRole(), role.getRole());
        assertEquals(responseObject.getResponse().get(0).getName(), role.getName());
    }

    @Test
    void FACIgetAgentRolesSuccess() throws Exception {
        AgentRole agentRole = new AgentRole();

        agentRole.setAgentRoleOnPolicyId(13278071);
        agentRole.setAgentStatus("ACTIVE");
        agentRole.setFirstName("James");
        agentRole.setLastName("Reese");
        agentRole.setNationalProducerNumber("2168230");
        agentRole.setPolicyNumber("100244106");
        agentRole.setPolicyRole("Writing");
        agentRole.setSalesforceContactId("003U000001JjH69IAF");
        agentRole.setSplitPercentage(100.0);

        PolicyInfoV2Response<AgentRole> pmapiRolesResponse = new PolicyInfoV2Response<>();
        pmapiRolesResponse.setResponse(List.of(agentRole));
        Mockito.when(faciService.getAgentRoleInfo("12345")).thenReturn(pmapiRolesResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/agent-roles"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        TypeReference<PolicyInfoV2Response<AgentRole>> typeReference = new TypeReference<>() {
        };
        PolicyInfoV2Response<AgentRole> responseObject = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        assertEquals(responseObject.getResponse().get(0).getAgentStatus(), agentRole.getAgentStatus());
        assertEquals(responseObject.getResponse().get(0).getFirstName(), agentRole.getFirstName());
    }

    @Test
    void FACIgetDependentSuccess() throws Exception {
        DependentsPerson dependentsPerson = new DependentsPerson();

        dependentsPerson.setFirstName("Mary");
        dependentsPerson.setMiddleName("R");
        dependentsPerson.setLastName("Lorch");
        dependentsPerson.setDateOfBirth("1947-11-21");
        dependentsPerson.setGender("F");
        dependentsPerson.setIssueAge("72");
        dependentsPerson.setEffectiveDate("2020-08-21");
        dependentsPerson.setStatus("A01");
        dependentsPerson.setStudentInd("N");
        dependentsPerson.setDisabledInd("N");

        DependentsV2Reponse dependentsV2Reponse = new DependentsV2Reponse();
        Dependent dependent = new Dependent();
        dependent.setPolicyNumber("12345");
        dependent.setDependentsPerson(List.of(dependentsPerson));
        dependentsV2Reponse.setDependent(List.of(dependent));

        Mockito.when(faciService.getDependentsInfo("12345")).thenReturn(dependentsV2Reponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/dependents"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();


        ObjectMapper mapper = new ObjectMapper();
        DependentsV2Reponse responseObject = mapper.readValue(result.getResponse().getContentAsString(), DependentsV2Reponse.class);
        assertEquals(responseObject.getDependent().get(0).getDependentsPerson().get(0).getFirstName(),
                dependentsPerson.getFirstName());

        assertEquals(responseObject.getDependent().get(0).getDependentsPerson().get(0).getIssueAge(),
                dependentsPerson.getIssueAge());
    }

    @Test
    void FACIgetPolicyDiscountSuccess() throws Exception {
        PolicyDiscounts discounts = new PolicyDiscounts();

        discounts.setName("Non Tobacco");
        discounts.setAmount(16.54);
        discounts.setEffectiveDate("2022-06-01");
        discounts.setStatus("ACTIVE");

        List<PolicyDiscounts> policyDiscountsList = List.of(discounts);
        DiscountsResponse discountsResponse = new DiscountsResponse();
        discountsResponse.setDiscounts(policyDiscountsList);
        Mockito.when(faciService.getDiscountsInfo("12345")).thenReturn(discountsResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/discounts"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();


        ObjectMapper mapper = new ObjectMapper();
        TypeReference<DiscountsResponse> typeReference = new TypeReference<>() {
        };
        DiscountsResponse discountsAPIResponse = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        List<PolicyDiscounts> responseObject = discountsAPIResponse.getDiscounts();
        assertEquals(responseObject.get(0).getName(),
                discounts.getName());
    }

    @Test
    void FACIgetPolicyRateChangeSuccess() throws Exception {
        PolicyRateChange policyRateChange = new PolicyRateChange();

        policyRateChange.setEffectiveDate("2022-12-01");
        policyRateChange.setPremium(148.83);
        policyRateChange.setMode("Monthly");
        policyRateChange.setArea("F");
        policyRateChange.setState("SD");
        policyRateChange.setLetterDueDate("2022-10-24");
        policyRateChange.setLetterSentDate("2022-10-24");

        List<PolicyRateChange> policyRateChanges = List.of(policyRateChange);

        PolicyRateChangeResponse policyRateChangeResponse = new PolicyRateChangeResponse();
        policyRateChangeResponse.setRateChanges(policyRateChanges);

        Mockito.when(faciService.getRateChangesInfo("12345")).thenReturn(policyRateChangeResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/rate-changes"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
        ObjectMapper mapper = new ObjectMapper();
        TypeReference<PolicyRateChangeResponse> typeReference = new TypeReference<>() {
        };
        PolicyRateChangeResponse policyRateChangeAPIResponse = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        List<PolicyRateChange> responseObject = policyRateChangeAPIResponse.getRateChanges();
        assertEquals(responseObject.get(0).getMode(), policyRateChange.getMode());
        assertEquals(responseObject.get(0).getEffectiveDate(), policyRateChange.getEffectiveDate());
    }

    @Test
    void FACIgetPolicyCoverageDetailsSuccess() throws Exception {
        CoverageDetailsVO coverageDetailsVO = new CoverageDetailsVO();

        coverageDetailsVO.setStatus("T11 - Requested Termination");
        coverageDetailsVO.setCoverageCode("B42600001");
        coverageDetailsVO.setCoverageDesc("Vision");
        coverageDetailsVO.setOffer("");
        coverageDetailsVO.setBenDed(50);
        coverageDetailsVO.setEffectiveDate("2021-08-01");
        coverageDetailsVO.setTerm("2022-08-01");
        coverageDetailsVO.setPremium(6.9);
        coverageDetailsVO.setFirstName("Aaron");
        coverageDetailsVO.setMiddleName("L");
        coverageDetailsVO.setLastName("Hellmann");

        List<CoverageDetailsVO> coverageDetails = List.of(coverageDetailsVO);
        PolicyCoverageDetailsResponse policyCoverageDetailsResponse = new PolicyCoverageDetailsResponse();
        policyCoverageDetailsResponse.setCoverageDetails(coverageDetails);
        Mockito.when(faciService.getPolicyCoverageDetails("12345")).thenReturn(policyCoverageDetailsResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/coverage-details"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        TypeReference<PolicyCoverageDetailsResponse> typeReference = new TypeReference<>() {
        };
        PolicyCoverageDetailsResponse policyCoverageDetailsAPIResponse = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        List<CoverageDetailsVO> responseObject = policyCoverageDetailsAPIResponse.getCoverageDetails();
        assertEquals(responseObject.get(0).getFirstName(), coverageDetailsVO.getFirstName());
    }

    @Test
    void FACIgetPolicyBeneficiaryDetailsSuccess() throws Exception {
        BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();

        beneficiaryDetails.setCompanyCode("PLI");
        beneficiaryDetails.setPolicyNumber("12345");
        beneficiaryDetails.setPersonNumber(2);
        beneficiaryDetails.setAccountNumber(9008182538L);
        beneficiaryDetails.setBeneficiaryRank(1);
        beneficiaryDetails.setStatusCode("A");
        beneficiaryDetails.setStatusReason("01");
        beneficiaryDetails.setBeneficiaryType("C");
        beneficiaryDetails.setSharePercent(50);
        beneficiaryDetails.setLastName("ASHLEY");
        beneficiaryDetails.setFirstName("THAD");
        beneficiaryDetails.setRankDescrip("Primary Beneficiary");
        beneficiaryDetails.setBeneRelationship("Child");
        beneficiaryDetails.setBeneficiaryName("THAD W ASHLEY");

        List<BeneficiaryDetails> beneficiaryDetail = List.of(beneficiaryDetails);
        BeneficiaryDetailsResponse beneficiaryDetailsResponse = new BeneficiaryDetailsResponse();
        beneficiaryDetailsResponse.setBeneficiaryDetails(beneficiaryDetail);
        Mockito.when(faciService.getBeneficiaryDetails("12345")).thenReturn(beneficiaryDetailsResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/beneficiary-detail"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();


        ObjectMapper mapper = new ObjectMapper();

        TypeReference<BeneficiaryDetailsResponse> typeReference = new TypeReference<>() {
        };
        BeneficiaryDetailsResponse beneficiaryDetailsAPIResponse = mapper.readValue(result.getResponse().getContentAsString(), typeReference);

        List<BeneficiaryDetails> responseObject = beneficiaryDetailsAPIResponse.getBeneficiaryDetails();
        assertEquals(responseObject.get(0).getFirstName(), beneficiaryDetails.getFirstName());
        assertEquals(responseObject.get(0).getPolicyNumber(), beneficiaryDetails.getPolicyNumber());
    }

    @Test
    void FACIgetPolicyAdditionalCoverageSuccess() throws Exception {
        AdditionalCoverage additionalCoverage = new AdditionalCoverage();

        additionalCoverage.setPolicyNumber("N830002879");
        additionalCoverage.setCompanyCode("PLI");
        additionalCoverage.setRecordNumber(3);
        additionalCoverage.setPersonNumber(1);
        additionalCoverage.setBaseRiderInd("B");
        additionalCoverage.setStatusCode("T46");
        additionalCoverage.setCoverageCode("L770000P0");
        additionalCoverage.setEffDate("2022-08-11");
        additionalCoverage.setTermDate("2022-08-11");
        additionalCoverage.setBenefitAmt(10000.0f);
        additionalCoverage.setDescrip("Modified Whole Life");
        additionalCoverage.setMonthlyPremium(69.9f);
        additionalCoverage.setQuartPremium(194.7f);
        additionalCoverage.setSemiPremium(389.4f);
        additionalCoverage.setRecurringPremium(64.9f);
        additionalCoverage.setAnnualPremium(778.8f);
        additionalCoverage.setFirstName("Donald");
        additionalCoverage.setMiddleName("J");
        additionalCoverage.setLastName("Rider");
        additionalCoverage.setPaidToDate("2022-08-11");
        additionalCoverage.setStatusLongDescription("T46 - Cancelled During Free Look");

        List<AdditionalCoverage> additionalCoverageList = List.of(additionalCoverage);
        PolicyAdditionalCoverageDetailsResponse policyAdditionalCoverageDetailsResponse = new PolicyAdditionalCoverageDetailsResponse();
        policyAdditionalCoverageDetailsResponse.setAdditionalCoverages(additionalCoverageList);
        Mockito.when(faciService.getAdditionalCoverages("12345")).thenReturn(policyAdditionalCoverageDetailsResponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/policy-detail/12345/additional-coverages"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        TypeReference<PolicyAdditionalCoverageDetailsResponse> typeReference = new TypeReference<>() {
        };
        PolicyAdditionalCoverageDetailsResponse policyAdditionalCoverageDetailsAPIResponse = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        List<AdditionalCoverage> responseObject = policyAdditionalCoverageDetailsAPIResponse.getAdditionalCoverages();
        assertEquals(responseObject.get(0).getFirstName(), additionalCoverage.getFirstName());
        assertEquals(responseObject.get(0).getPolicyNumber(), additionalCoverage.getPolicyNumber());
    }

    @Test
    void FACIgetPolicyDocumentDetailsSuccess() throws Exception {
        Document document = new Document();
        document.setDocumentId("152342648");
        document.setUri("store1?documentId=152342648&version=1&fileName=00922193.pdf");
        document.setFileName("00922193.pdf");
        document.setPolicyNumber("H710433487");
        document.setDocumentLocation("P");
        document.setDocumentSource("SCAN");
        document.setDocumentType("Application");
        document.setVersionNumber(1);
        document.setDocumentScannedDate("2020-06-11");
        document.setCreatedDateTime("2020-06-11T11:19:29");
        document.setReceivedDateTime("2020-06-11T05:10:00");

        DocumentsResponse documentResponse = new DocumentsResponse();
        documentResponse.setSearchType("POLICY_DOCUMENTS");
        documentResponse.setResponseFormat("INDEX");
        documentResponse.setDocuments(List.of(document));

        DocumentsV2Response<DocumentsResponse> pmapiDocumentReponse = new DocumentsV2Response<>();
        pmapiDocumentReponse.setResponseData(documentResponse);
        Mockito.when(faciService.getPolicyDocumentDetails("12345")).thenReturn(pmapiDocumentReponse);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/document-details/12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();

        TypeReference<DocumentsV2Response<DocumentsResponse>> typeReference = new TypeReference<>() {
        };
        DocumentsV2Response<DocumentsResponse> responseObject = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        assertEquals(responseObject.getResponseData().getDocuments().get(0).getDocumentId(), document.getDocumentId());
        assertEquals(responseObject.getResponseData().getDocuments().get(0).getUri(), document.getUri());
    }

    @Test
    void FACIgetPolicyAlertssSuccess() throws Exception {
        CustomerMessage customerMessage = new CustomerMessage();
        customerMessage.setMessageCode("1000");
        customerMessage.setMessage("Register Complaint");
        customerMessage.setAlertLevel("Low");

        PolicyMessageItem policyMessageItem = new PolicyMessageItem();
        policyMessageItem.setMessageCode("1271");
        policyMessageItem.setMessage("Refer General eMem; Benefits may be payable.");
        policyMessageItem.setAlertLevel("Medium");

        PolicyMessage policyMessage = new PolicyMessage();
        policyMessage.setPolicyNumber("12345");
        policyMessage.setMessages(List.of(policyMessageItem));

        PolicyAlertResponse policyAlertResponse = new PolicyAlertResponse();
        policyAlertResponse.setCustomerMessages(List.of(customerMessage));
        policyAlertResponse.setPolicyMessages(List.of(policyMessage));

        DocumentsV2Response<PolicyAlertResponse> policyAlertResponsePMAPIV2Response = new DocumentsV2Response<>();
        policyAlertResponsePMAPIV2Response.setResponseData(policyAlertResponse);
        Mockito.when(faciService.getPolicyAlerts("12345")).thenReturn(policyAlertResponsePMAPIV2Response);

        MvcResult result = mvc.perform(MockMvcRequestBuilders.get("/web/faci/customer-detail/alert/12345"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();

        TypeReference<DocumentsV2Response<PolicyAlertResponse>> typeReference = new TypeReference<>() {
        };
        DocumentsV2Response<PolicyAlertResponse> responseObject = mapper.readValue(result.getResponse().getContentAsString(), typeReference);
        assertEquals(responseObject.getResponseData().getCustomerMessages().get(0).getMessage(), customerMessage.getMessage());
        assertEquals(responseObject.getResponseData().getPolicyMessages().get(0).getMessages().get(0).getMessage(), policyMessageItem.getMessage());
    }

    @Test
    void testDownloadCustomerDocumentSuccess() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        ByteArrayInputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
        Resource mockResource = mock(Resource.class);
        Mockito.when(mockResource.getInputStream()).thenReturn(mockInputStream);

        Mockito.when(documentService.downloadDocument(documentDownloadRequest)).thenReturn(mockResource);

        mvc.perform(MockMvcRequestBuilders.post("/web/faci/documents/download")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(documentDownloadRequest)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_PDF));
    }

    @Test
    void testDownloadCustomerDocumentFailure() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        ByteArrayInputStream mockInputStream = new ByteArrayInputStream(new byte[0]);
        Resource mockResource = mock(Resource.class);
        Mockito.when(mockResource.getInputStream()).thenReturn(mockInputStream);

        Mockito.when(documentService.downloadDocument(documentDownloadRequest))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown error occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        try {
            mvc.perform(MockMvcRequestBuilders.post("/web/faci/documents/download")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(new ObjectMapper().writeValueAsString(documentDownloadRequest)))
                    .andExpect(MockMvcResultMatchers.status().is5xxServerError());
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("AgencyCoPilot5xxException"));
        }
    }
}
