package com.pm.api.agencycopilot.test;

import org.apache.commons.lang3.StringUtils;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.PRODUCT_CATEGORY_CODE_CHARACTERS;

public class Testing {

    public static void main(String[] args) {
        String code = "";
        String substring = StringUtils.substring(code, 0, PRODUCT_CATEGORY_CODE_CHARACTERS);
        System.out.println("****************:" + substring);
    }

}
