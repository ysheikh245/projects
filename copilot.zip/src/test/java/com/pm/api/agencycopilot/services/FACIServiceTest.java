package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.PolicyAdditionalCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.PolicyCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyRateChangeResponse;
import com.pm.api.agencycopilot.models.external.customers.CustomerByPolicy;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.NPNPolicyListCacheRecord;
import com.pm.api.agencycopilot.services.impl.CustomersServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.FACIServiceImpl;
import com.pm.api.agencycopilot.services.impl.PolicyServiceHandlerImpl;
import com.pm.api.agencycopilot.transformer.PolicyDetailTransformer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
class FACIServiceTest {
    @InjectMocks
    FACIServiceImpl faciService;

    @Mock
    CustomersServiceHandlerImpl customersServiceHandler;
    @Mock
    PolicyServiceHandlerImpl policyServiceHandler;

    @Mock
    DocumentsServiceHandler pmapiDocumentsServiceHandler;

    @Mock
    PolicyDetailTransformer policyDetailTransformer;

    @Mock
    CoverageDetailsVO vo;

    @Mock
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Mock
    DocumentService documentService;


    @Test
    void getCustomerDetails() throws Exception {
        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setFirstName("Jhon");
        request.setLastName("Wick");
        request.setState("SD");
        request.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);

        CustomerByPolicy customerByPolicy = new CustomerByPolicy();
        FindCustomerByPolicyResponse response = new FindCustomerByPolicyResponse();
        response.setResponse(List.of(customerByPolicy));

        when(customersServiceHandler.invokeCustomerV2PMAPISearch(any())).thenReturn(response);

        NPNPolicyListCacheRecord npnPolicyListCache = new NPNPolicyListCacheRecord();
        npnPolicyListCache.setNpnId("12345");
        npnPolicyListCache.setPolicies(List.of("ABCD", "CDE"));
        when(mongoDBCacheHandler.findPolicyListByNPN(any())).thenReturn(npnPolicyListCache);

        CustomersVO customersVO = new CustomersVO();
        customersVO.setPolicyNumber("ABCD");
        when(policyDetailTransformer.transformPMAPIToCustomersDetails(
                ArgumentMatchers.any(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any()
                )
        ).thenReturn(List.of(customersVO));
        assertEquals(1, faciService.getPolicyByCustomerDetails(request, "12345").size());
    }


    @Test
    void getAdditionalDetailsCountVO() throws Exception {

        when(policyServiceHandler.getPolicyDataFromPMAPI(
                any(),
                any()
        )).thenReturn(new PolicyV2Response());

        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        mockResponse.setResponseData(new PolicyAlertResponse());
        when(customersServiceHandler.findPartyId(any())).thenReturn("12345");
        when(customersServiceHandler.getPolicyAlerts(any())).thenReturn(mockResponse);
        assertNotNull(faciService.getPolicyAlerts(POLICY_NUMBER));

        when(policyDetailTransformer.getAdditionalDetailsCountVO(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any(),
                ArgumentMatchers.any())
        ).thenReturn(new AdditionalDetailsCountVO());
        assertNotNull(faciService.getAdditionalDetailsCountVO(POLICY_NUMBER));
        DocumentsV2Response<DocumentsResponse> docResp = new DocumentsV2Response<>();
        docResp.setResponseData(new DocumentsResponse());
        when(pmapiDocumentsServiceHandler.getPolicyDocuments(POLICY_NUMBER)).thenReturn(docResp);

        assertNotNull(faciService.getAdditionalDetailsCountVO(POLICY_NUMBER));

        when(policyServiceHandler.getPolicyDetails(POLICY_NUMBER)).thenReturn(new PolicyV2Response());
        when(policyDetailTransformer.tranfromPMAPIToPolicyDetail(any(), any())).thenReturn(new PolicyVO());
        assertNotNull(faciService.getPMAPIPolicyDetails(POLICY_NUMBER));

        PolicyInfoV2Response<Role> roleResp = new PolicyInfoV2Response<>();
        roleResp.setResponse(List.of(new Role()));
        when(policyServiceHandler.getRolesInfo(POLICY_NUMBER)).thenReturn(roleResp);
        assertNotNull(faciService.getPolicyRoleInfo(POLICY_NUMBER));

        PolicyInfoV2Response<AgentRole> agentRoleResp = new PolicyInfoV2Response<>();
        agentRoleResp.setResponse(List.of(new AgentRole()));
        when(policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER)).thenReturn(agentRoleResp);
        assertNotNull(faciService.getAgentRoleInfo(POLICY_NUMBER));

        when(policyServiceHandler.getDependentDetails(POLICY_NUMBER)).thenReturn(new DependentsV2Reponse());
        assertNotNull(faciService.getDependentsInfo(POLICY_NUMBER));

        when(policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER)).thenReturn(List.of(new PolicyDiscounts()));
        assertNotNull(faciService.getDiscountsInfo(POLICY_NUMBER));

        when(policyServiceHandler.getPolicyRateChanges(POLICY_NUMBER)).thenReturn(List.of(new PolicyRateChange()));
        Object rateChangeResult = faciService.getRateChangesInfo(POLICY_NUMBER);
        assertNotNull(rateChangeResult);
        assertTrue(rateChangeResult instanceof PolicyRateChangeResponse);

        when(policyServiceHandler.getPolicyCoverageDetails(POLICY_NUMBER)).thenReturn(List.of(vo));
        Object result = faciService.getPolicyCoverageDetails(POLICY_NUMBER);
        assertNotNull(result);
        assertTrue(result instanceof PolicyCoverageDetailsResponse);
    }

    @Test
    void testGetRateChangesInfoNull() throws Exception {
        when(policyServiceHandler.getPolicyRateChanges(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getRateChangesInfo(POLICY_NUMBER));
    }

    @Test
    public void testGetDependentsInfoNull() throws Exception {
        when(policyServiceHandler.getDependentDetails(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getDependentsInfo(POLICY_NUMBER));
    }

    @Test
    public void testgetPolicyRoleInfoNull() throws Exception {
        PolicyInfoV2Response<Role> roleResp = new PolicyInfoV2Response<>();
        roleResp.setResponse(List.of(new Role()));
        when(policyServiceHandler.getRolesInfo(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPolicyRoleInfo(POLICY_NUMBER));
    }

    @Test
    public void testGetAgentRoleInfoNull() throws Exception {
        PolicyInfoV2Response<AgentRole> agentRoleResp = new PolicyInfoV2Response<>();
        agentRoleResp.setResponse(List.of(new AgentRole()));
        when(policyServiceHandler.getAgentRolesInfo(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getAgentRoleInfo(POLICY_NUMBER));
    }

    @Test
    public void testGetDiscountInfoNull() throws Exception {
        when(policyServiceHandler.getPolicyDiscounts(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getDiscountsInfo(POLICY_NUMBER));
    }

    @Test
    public void testGetPMAPIPolicyDetailsNull() throws Exception {
        when(policyServiceHandler.getPolicyDetails(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPMAPIPolicyDetails(POLICY_NUMBER));
    }

    @Test
    public void testGetPolicyByCustomerDetailsNull() throws Exception {
        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setFirstName("Jhon");
        request.setLastName("Wick");
        request.setState("SD");
        request.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        when(customersServiceHandler.invokeCustomerV2PMAPISearch(any())).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPolicyByCustomerDetails(request, "12345"));
    }

    @Test
    public void testGetCustomerContactDetailsNull() throws Exception {
        when(customersServiceHandler.invokeCustomerV2PMAPIByPolicy(any())).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getCustomerContactDetails("10", "1"));
    }

    @Test
    public void testGetCustomerContactDetailsPoliciesNull() throws Exception {
        CustomerByPolicy customerByPolicy = new CustomerByPolicy();
        FindCustomerByPolicyResponse response = new FindCustomerByPolicyResponse();
        response.setResponse(List.of(customerByPolicy));

        CustomersVO customerResponseObj = new CustomersVO();
        customerResponseObj.setPolicies(List.of());

        when(policyDetailTransformer.transformPMAPIToCustomersContactDetail(
                any(),
                any(),
                any()
        )).thenReturn(customerResponseObj);
        when(customersServiceHandler.invokeCustomerV2PMAPIByPolicy(any())).thenReturn(response);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getCustomerContactDetails("10", "1"));
    }

    @Test
    void getCustomerContactDetails() throws Exception {

        CustomerByPolicy customerByPolicy = new CustomerByPolicy();
        FindCustomerByPolicyResponse response = new FindCustomerByPolicyResponse();
        response.setResponse(List.of(customerByPolicy));
        CustomersVO customerResponseObj = new CustomersVO();
        PolicyVO policyData = new PolicyVO();
        policyData.setProductName("PET");
        policyData.setPolicyNumber("10");
        customerResponseObj.setPolicies(List.of(policyData));
        when(policyServiceHandler.getPolicyDetails("10")).thenReturn(new PolicyV2Response());
        when(policyDetailTransformer.tranfromPMAPIToPolicyDetail(any(), any())).thenReturn(new PolicyVO());
        Mockito.when(faciService.getPMAPIPolicyDetails("10")).thenReturn(policyData);

        when(policyDetailTransformer.transformPMAPIToCustomersContactDetail(
                any(),
                any(),
                any()
        )).thenReturn(customerResponseObj);
        when(customersServiceHandler.invokeCustomerV2PMAPIByPolicy(any())).thenReturn(response);
        assertNotNull(faciService.getCustomerContactDetails("10", "1"));
    }

    @Test
    void testGetPolicyDocumentDetails() throws Exception {
        DocumentsV2Response<DocumentsResponse> mockResponse = new DocumentsV2Response<>();
        mockResponse.setResponseData(new DocumentsResponse());
        when(pmapiDocumentsServiceHandler.getPolicyDocuments(any())).thenReturn(mockResponse);
        assertNotNull(faciService.getPolicyDocumentDetails(POLICY_NUMBER));
    }

    @Test
    public void testGetPolicyDocumentDetailsNull() throws Exception {
        when(pmapiDocumentsServiceHandler.getPolicyDocuments(any())).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPolicyDocumentDetails(POLICY_NUMBER));
    }

    @Test
    void testGetBeneficiaryDetails() throws Exception {
        List<BeneficiaryDetails> list = List.of(new BeneficiaryDetails());
        when(policyServiceHandler.getBeneficiaryDetails(any())).thenReturn(list);
        assertNotNull(faciService.getBeneficiaryDetails(POLICY_NUMBER));
    }

    @Test
    void testGetBeneficiaryDetailsNull() throws Exception {
        when(policyServiceHandler.getBeneficiaryDetails(any())).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getBeneficiaryDetails(POLICY_NUMBER));
    }

    @Test
    void testGetAdditionalCoverages() throws Exception {
        List<AdditionalCoverage> list = List.of(new AdditionalCoverage());
        when(policyServiceHandler.getAdditionalCoverages(any())).thenReturn(list);

        Object result = faciService.getAdditionalCoverages(POLICY_NUMBER);
        assertNotNull(result);
        assertTrue(result instanceof PolicyAdditionalCoverageDetailsResponse);
    }

    @Test
    void testGetCoverageDetailsNull() throws Exception {
        when(policyServiceHandler.getPolicyCoverageDetails(POLICY_NUMBER)).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPolicyCoverageDetails(POLICY_NUMBER));
    }

    @Test
    void testGetAdditionalCoveragesNull() throws Exception {
        when(policyServiceHandler.getAdditionalCoverages(any())).thenReturn(null);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getAdditionalCoverages(POLICY_NUMBER));
    }

    @Test
    void testGetPolicyAlerts() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        mockResponse.setResponseData(new PolicyAlertResponse());
        when(customersServiceHandler.findPartyId(any())).thenReturn("12345");
        when(customersServiceHandler.getPolicyAlerts(any())).thenReturn(mockResponse);
        assertNotNull(faciService.getPolicyAlerts(POLICY_NUMBER));
    }

    @Test
    void testGetPolicyAlertsNullPartyId() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        mockResponse.setResponseData(new PolicyAlertResponse());
        when(customersServiceHandler.findPartyId(any())).thenReturn(StringUtils.EMPTY);
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> faciService.getPolicyAlerts(POLICY_NUMBER));
    }

    @Test
    void testDownloadCustomerDocumentSuccess() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        Resource mockResource = mock(Resource.class);
        when(documentService.downloadDocument(documentDownloadRequest)).thenReturn(mockResource);

        Resource resource = documentService.downloadDocument(documentDownloadRequest);

//        verify(pmapiDocumentsServiceHandler, times(1)).downloadCustomerDocument(faciDocumentDownloadRequest);
        assertEquals(mockResource, resource);
    }

    @Test
    void testDownloadCustomerDocumentFailure() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        when(documentService.downloadDocument(documentDownloadRequest)).thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown error occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            documentService.downloadDocument(documentDownloadRequest);
        });
    }
}
