package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.SystemInformation;
import com.pm.api.agencycopilot.services.impl.MessageServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class MessageServiceTest {
    @InjectMocks
    MessageServiceImpl messageService;

    @Mock
    SystemInformation systemInformation;

    @Test
    void testGetMessage() {

        String message = messageService.getMessage();
        assertNotNull(message);
    }
}