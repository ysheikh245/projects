package com.pm.api.agencycopilot.services;

import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.PARTY_ID;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.external.customers.CustomerByPolicy;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.services.impl.CustomersServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import com.pm.api.agencycopilot.utility.JsonTransformationUtils;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class CustomersServiceHandlerTest {

    @InjectMocks
    CustomersServiceHandlerImpl customersServiceHandler;

    @Mock
    RestTemplate restTemplate;

    @Mock
    RestHelperServiceImpl restHelperService;

    @Mock
    MaskedValueLogger maskedValueLogger;


    @BeforeEach
    void init() {
        setField(customersServiceHandler, "customersAPIUsername", DEMO);
        setField(customersServiceHandler, "customersAPIPassword", DEMO);
        setField(customersServiceHandler, "customersByPolicyAPIEndpoint", API_URL);
        setField(customersServiceHandler, "customersAPIClientHeader", DEMO);
        setField(customersServiceHandler, "customersAPIClientUserId", DEMO);
        setField(customersServiceHandler, "restHelperService", restHelperService);
        setField(customersServiceHandler, "restTemplate", restTemplate);
        setField(customersServiceHandler, "maskedValueLogger", maskedValueLogger);
//        setField(restHelperService, "restTemplate", restTemplate);
    }

    @Test
    void testInvokeCustomerV2PMAPIByPolicy() {
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        FindCustomerByPolicyResponse response =
                customersServiceHandler.invokeCustomerV2PMAPIByPolicy(POLICY_NUMBER);
        Assertions.assertNotNull(response);
    }

    @Test
    void testFindPartyId() {
        FindCustomerByPolicyResponse mockResponse = JsonTransformationUtils.transformCustomerByPolicyListStringToObject();
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        String policyNumber = "H710451816";
        String response = customersServiceHandler.findPartyId(policyNumber);
        Assertions.assertNotNull(response);
    }

    @Test
    void testFindPartyIdFoundInCogen() {
        FindCustomerByPolicyResponse mockResponse = JsonTransformationUtils.transformCustomerByPolicyListStringToObject();
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        String policyNumber = "H710451816";
        String response = customersServiceHandler.findPartyId(POLICY_NUMBER);
        Assertions.assertNotNull(response);
    }

    @Test
    void testFindPartyIdNoPolicies() {
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();
        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);
        mockResponse.setResponse(List.of(policy));

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND));

        String response = customersServiceHandler.findPartyId(POLICY_NUMBER);
        Assertions.assertEquals(StringUtils.EMPTY, response, "Empty string response excepted");
    }


    @Test
    void testGetPolicyAlerts() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        PolicyAlertResponse resp = new PolicyAlertResponse();
        setField(customersServiceHandler, "alertsEndpoint", DEMO);

        setField(customersServiceHandler, "pmapiClientHeader", DEMO);
        setField(customersServiceHandler, "pmapiEndUserId", DEMO);
        setField(customersServiceHandler, "alertsAPIUsername", DEMO);

        mockResponse.setResponseData(resp);

        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        DocumentsV2Response<PolicyAlertResponse> result = customersServiceHandler.getPolicyAlerts(PARTY_ID);
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetPolicyAlertsHttpClientException() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        PolicyAlertResponse resp = new PolicyAlertResponse();
        setField(customersServiceHandler, "alertsEndpoint", DEMO);

        setField(customersServiceHandler, "pmapiClientHeader", DEMO);
        setField(customersServiceHandler, "pmapiEndUserId", DEMO);
        setField(customersServiceHandler, "alertsAPIUsername", DEMO);

        mockResponse.setResponseData(resp);

        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity(HttpStatus.NO_CONTENT));
        DocumentsV2Response<PolicyAlertResponse> result = customersServiceHandler.getPolicyAlerts(PARTY_ID);
        Assertions.assertNull(result);
    }

    @Test
    void testGetPolicyAlertsHttpClientException400() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        PolicyAlertResponse resp = new PolicyAlertResponse();
        setField(customersServiceHandler, "alertsEndpoint", DEMO);

        setField(customersServiceHandler, "pmapiClientHeader", DEMO);
        setField(customersServiceHandler, "pmapiEndUserId", DEMO);
        setField(customersServiceHandler, "alertsAPIUsername", DEMO);

        mockResponse.setResponseData(resp);

        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<PolicyAlertResponse>>() {
                })))
                .thenThrow(new AgencyCoPilot4xxException(new Exception("Downstream service is not available"),
                        HttpStatus.INTERNAL_SERVER_ERROR, ""));
        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            customersServiceHandler.getPolicyAlerts(PARTY_ID);
        });
    }

    @Test
    void testGetPolicyAlertsHttpServerException() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        PolicyAlertResponse resp = new PolicyAlertResponse();
        setField(customersServiceHandler, "alertsEndpoint", DEMO);

        setField(customersServiceHandler, "pmapiClientHeader", DEMO);
        setField(customersServiceHandler, "pmapiEndUserId", DEMO);
        setField(customersServiceHandler, "alertsAPIUsername", DEMO);

        mockResponse.setResponseData(resp);

        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<PolicyAlertResponse>>() {
                })))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"),
                        HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            customersServiceHandler.getPolicyAlerts(PARTY_ID);
        });
    }

    @Test
    void testGetPolicyAlertsRuntimeException() throws Exception {
        DocumentsV2Response<PolicyAlertResponse> mockResponse = new DocumentsV2Response<>();
        PolicyAlertResponse resp = new PolicyAlertResponse();
        setField(customersServiceHandler, "alertsEndpoint", DEMO);

        setField(customersServiceHandler, "pmapiClientHeader", DEMO);
        setField(customersServiceHandler, "pmapiEndUserId", DEMO);
        setField(customersServiceHandler, "alertsAPIUsername", DEMO);

        mockResponse.setResponseData(resp);

        CustomerByPolicy policy = new CustomerByPolicy();
        setField(policy, "partyId", PARTY_ID);

        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<PolicyAlertResponse>>() {
                })))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"),
                        HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            customersServiceHandler.getPolicyAlerts(PARTY_ID);
        });
    }

    @Test
    void testInvokeCustomerV2PMAPISearch() {


        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();
        setField(customersServiceHandler, "customersBySearchApiEndPoint", DEMO);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        FindCustomerByPolicyResponse result =
                customersServiceHandler.invokeCustomerV2PMAPISearch(request);
        Assertions.assertNotNull(result);

        request.setType(CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS);
        result =
                customersServiceHandler.invokeCustomerV2PMAPISearch(request);
        Assertions.assertNotNull(result);
    }

    @Test
    void testInvokeCustomerV2PMAPISearchThrowsHttpClientError() {


        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();
        setField(customersServiceHandler, "customersBySearchApiEndPoint", DEMO);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenReturn(new ResponseEntity(HttpStatus.NO_CONTENT));

        Assertions.assertNull(customersServiceHandler.invokeCustomerV2PMAPISearch(request));

    }

    @Test
    void testInvokeCustomerV2PMAPISearchThrowsHttpServerError() {


        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();
        setField(customersServiceHandler, "customersBySearchApiEndPoint", DEMO);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"),
                        HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            customersServiceHandler.invokeCustomerV2PMAPISearch(request);
        });
    }

    @Test
    void testInvokeCustomerV2PMAPISearchThrowsException() {


        PolicyByCustomerDetailsRequest request = new PolicyByCustomerDetailsRequest();
        request.setType(CustomerDetailsRequestType.SEARCH_BY_POLICY);
        FindCustomerByPolicyResponse mockResponse = new FindCustomerByPolicyResponse();
        setField(customersServiceHandler, "customersBySearchApiEndPoint", DEMO);
        when(restHelperService.invoke(
                anyString(),
                any(HttpMethod.class),
                any(),
                ArgumentMatchers.<Class<FindCustomerByPolicyResponse>>any()))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Downstream service is not available"),
                        HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            customersServiceHandler.invokeCustomerV2PMAPISearch(request);
        });
    }

}
