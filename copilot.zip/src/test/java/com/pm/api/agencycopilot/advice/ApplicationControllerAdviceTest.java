package com.pm.api.agencycopilot.advice;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.errors.ErrorObject;
import java.beans.PropertyEditor;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.PropertyEditorRegistry;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;

@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
public class ApplicationControllerAdviceTest {

    @InjectMocks
    ApplicationControllerAdvice applicationControllerAdvice;

    @Mock
    MethodParameter methodParameter;

    @Mock
    MissingPathVariableException missingPathVariableException;

    @Mock
    HttpRequestMethodNotSupportedException httpRequestMethodNotSupportedException;

    @Test
    public void testHandleException() {
        AgencyCoPilotException agencyCoPilotException = new AgencyCoPilotException(
                new Exception("Agency CoPilot Exception Occured"),
                HttpStatus.INTERNAL_SERVER_ERROR
        );
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handleException(agencyCoPilotException);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, errorResponse.getStatusCode());
    }

    @Test
    public void testhandle5xxException() {
        AgencyCoPilot5xxException agencyCoPilotException = new AgencyCoPilot5xxException(
                new Exception("Agency CoPilot 5xx Exception Occured"),
                HttpStatus.INTERNAL_SERVER_ERROR,
                "/test/error"
        );
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handle5xxException(agencyCoPilotException);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, errorResponse.getStatusCode());
    }

    @Test
    public void testhandle5xxExceptionDetailStackTraceToTrue() {

        ReflectionTestUtils.setField(applicationControllerAdvice,
                "detailedExceptionStackTrace",
                "true");
        AgencyCoPilot5xxException agencyCoPilotException = new AgencyCoPilot5xxException(
                new Exception("Agency CoPilot 5xx Exception Occured"),
                HttpStatus.INTERNAL_SERVER_ERROR,
                "/test/error"
        );
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handle5xxException(agencyCoPilotException);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, errorResponse.getStatusCode());
    }

    @Test
    public void testhandle4xxException() {
        AgencyCoPilot4xxException agencyCoPilot4xxException = new AgencyCoPilot4xxException(
                new Exception("Agency CoPilot 4xx Exception Occured"),
                HttpStatus.BAD_REQUEST,
                "/test/error"
        );
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handle4xxException(agencyCoPilot4xxException);

        Assertions.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());
    }

    @Test
    public void testhandleInvalidFormatException() {
        InvalidFormatException invalidFormatException = new InvalidFormatException(
                "Unable to parse the request value",
                "Testttttttt",
                null
        );
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handleInvalidFormatException(invalidFormatException);

        Assertions.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());
    }

    @Test
    public void testhandleValidationException() {

        MethodArgumentNotValidException methodArgumentNotValidException = new MethodArgumentNotValidException(
                methodParameter,
                buildBindingResult()
        );

        ResponseEntity<List<ErrorObject>> errorResponse = applicationControllerAdvice.handleValidationException(
                methodArgumentNotValidException);

        Assertions.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());
    }

    @Test
    public void testhandleMissingPathVariable() {

        Mockito.when(missingPathVariableException.getMessage()).thenReturn("Required Variable Missing");
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handleMissingPathVariable(missingPathVariableException);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());

    }

    @Test
    public void testhandleHttpRequestMethodNotSupportedException() {
        Mockito.when(httpRequestMethodNotSupportedException.getMessage()).thenReturn("HTTPRequest Method Not Supported");
        ResponseEntity<ErrorObject> errorResponse = applicationControllerAdvice.handleHttpRequestMethodNotSupportedException(httpRequestMethodNotSupportedException);
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatusCode());

    }

    private BindingResult buildBindingResult() {
        FieldError fieldError = new FieldError("TestObj", "TestField", "Cannot be null");
        List<FieldError> fieldErrorList = new ArrayList<>();
        fieldErrorList.add(fieldError);
        BindingResult bindingResult = new BindingResult() {
            @Override
            public Object getTarget() {
                return null;
            }

            @Override
            public Map<String, Object> getModel() {
                return null;
            }

            @Override
            public Object getRawFieldValue(String field) {
                return null;
            }

            @Override
            public PropertyEditor findEditor(String field, Class<?> valueType) {
                return null;
            }

            @Override
            public PropertyEditorRegistry getPropertyEditorRegistry() {
                return null;
            }

            @Override
            public String[] resolveMessageCodes(String errorCode) {
                return new String[0];
            }

            @Override
            public String[] resolveMessageCodes(String errorCode, String field) {
                return new String[0];
            }

            @Override
            public void addError(ObjectError error) {

            }

            @Override
            public String getObjectName() {
                return null;
            }

            @Override
            public void setNestedPath(String nestedPath) {

            }

            @Override
            public String getNestedPath() {
                return null;
            }

            @Override
            public void pushNestedPath(String subPath) {

            }

            @Override
            public void popNestedPath() throws IllegalStateException {

            }

            @Override
            public void reject(String errorCode) {

            }

            @Override
            public void reject(String errorCode, String defaultMessage) {

            }

            @Override
            public void reject(String errorCode, Object[] errorArgs, String defaultMessage) {

            }

            @Override
            public void rejectValue(String field, String errorCode) {

            }

            @Override
            public void rejectValue(String field, String errorCode, String defaultMessage) {

            }

            @Override
            public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage) {

            }

            @Override
            public void addAllErrors(Errors errors) {

            }

            @Override
            public boolean hasErrors() {
                return false;
            }

            @Override
            public int getErrorCount() {
                return 0;
            }

            @Override
            public List<ObjectError> getAllErrors() {
                return null;
            }

            @Override
            public boolean hasGlobalErrors() {
                return false;
            }

            @Override
            public int getGlobalErrorCount() {
                return 0;
            }

            @Override
            public List<ObjectError> getGlobalErrors() {
                return null;
            }

            @Override
            public ObjectError getGlobalError() {
                return null;
            }

            @Override
            public boolean hasFieldErrors() {
                return false;
            }

            @Override
            public int getFieldErrorCount() {
                return 0;
            }

            @Override
            public List<FieldError> getFieldErrors() {
                return fieldErrorList;
            }

            @Override
            public FieldError getFieldError() {
                return null;
            }

            @Override
            public boolean hasFieldErrors(String field) {
                return false;
            }

            @Override
            public int getFieldErrorCount(String field) {
                return 0;
            }

            @Override
            public List<FieldError> getFieldErrors(String field) {
                return null;
            }

            @Override
            public FieldError getFieldError(String field) {
                return null;
            }

            @Override
            public Object getFieldValue(String field) {
                return null;
            }

            @Override
            public Class<?> getFieldType(String field) {
                return null;
            }
        };
        return bindingResult;
    }

}
