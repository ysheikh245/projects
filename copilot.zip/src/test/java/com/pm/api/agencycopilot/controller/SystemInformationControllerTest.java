package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.models.SystemInformation;
import com.pm.api.agencycopilot.services.SystemInformationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
@ActiveProfiles(profiles = "test")
class SystemInformationControllerTest {

    @InjectMocks
    private SystemInformationController controller;
    @Mock
    private SystemInformationService systemInformationService;

    @Test
    void testGetSystemData() throws Exception {
        MockMvc mvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();
        SystemInformation systemInformation = new SystemInformation();
        when(systemInformationService.getSystemData()).thenReturn(systemInformation);
        mvc.perform(MockMvcRequestBuilders.get("/web/data"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
    }

}
