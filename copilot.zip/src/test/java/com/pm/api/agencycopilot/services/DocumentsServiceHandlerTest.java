package com.pm.api.agencycopilot.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.pm.api.agencycopilot.constants.TestConstants.API_URL;
import static com.pm.api.agencycopilot.constants.TestConstants.DEMO;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentSearchCriteria;
import com.pm.api.agencycopilot.models.apis.DocumentSearchCriteriaRequest;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.services.impl.DocumentsServiceHandlerImpl;
import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import static org.mockito.ArgumentMatchers.eq;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class DocumentsServiceHandlerTest {

    @InjectMocks
    DocumentsServiceHandlerImpl documentsServiceHandler;

    @Mock
    RestTemplate restTemplate;

    @Mock
    RestHelperServiceImpl restHelperService;


    @BeforeEach
    void init() throws JsonProcessingException {

        setField(documentsServiceHandler, "documentsAPIUsername", DEMO);
        setField(documentsServiceHandler, "documentsAPIPassword", DEMO);
        setField(documentsServiceHandler, "documentsAPIClientHeader", API_URL);
        setField(documentsServiceHandler, "documentsAPIEndUserId", DEMO);
        setField(documentsServiceHandler, "documentSearchEndPoint", API_URL);
        setField(documentsServiceHandler, "restHelperService", restHelperService);
        setField(documentsServiceHandler, "documentsDownloadAPIEndpoint", "https://portaltest4-nonsso.pmic.com/pmapi/documents/daily/store1?documentId={DOCUMENT_ID}&version={VERSION_NUMBER}&fileName={FILE_NAME}.{FILE_EXT}");

        DocumentSearchCriteriaRequest request = new DocumentSearchCriteriaRequest(DEMO, DEMO, new DocumentSearchCriteria(POLICY_NUMBER, DEMO));

        DocumentSearchCriteria searchCriteria = new DocumentSearchCriteria(POLICY_NUMBER, DEMO);
        request.setSearchCriteria(searchCriteria);
        setField(documentsServiceHandler, "documentSearchPayload", new ObjectMapper().writeValueAsString(request));


    }

    @Test
    void testGetPolicyDocuments() throws Exception {
        DocumentsV2Response<DocumentsResponse> mockResponse = new DocumentsV2Response<>() {
        };
        mockResponse.setResponseData(new DocumentsResponse());

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>() {
                }))).thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        Assertions.assertNotNull(documentsServiceHandler.getPolicyDocuments(POLICY_NUMBER));
    }

    @Test
    void testGetPolicyDocumentsHttpClientError() {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                ArgumentMatchers.<ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>>any())
        ).thenThrow(new AgencyCoPilot4xxException(new Exception("Unauthorized Access"), HttpStatus.BAD_REQUEST, ""));


        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            documentsServiceHandler.getPolicyDocuments(POLICY_NUMBER);
        });
    }

    @Test
    void testGetPolicyDocumentsHttpClientError404() throws Exception {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>() {
                }))).thenReturn(new ResponseEntity<>(HttpStatus.OK));


        Assertions.assertNull(documentsServiceHandler.getPolicyDocuments(POLICY_NUMBER));
    }

    @Test
    void testGetPolicyDocumentsHttpServerError() {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>() {
                })))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown error occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));


        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            documentsServiceHandler.getPolicyDocuments(POLICY_NUMBER);
        });
    }

    @Test
    void testGetPolicyDocumentsRuntimeException() {

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                eq(new ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>() {
                })))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown error occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));


        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            documentsServiceHandler.getPolicyDocuments(POLICY_NUMBER);
        });
    }

    @Test
    void testDownloadCustomerDocumentSuccess() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        byte[] body = "file content".getBytes();
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(body, HttpStatus.OK);

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                ArgumentMatchers.eq(byte[].class)))
                .thenReturn(responseEntity);

        Resource resource = documentsServiceHandler.downloadDocument(documentDownloadRequest);

        Assertions.assertNotNull(resource);
        verify(restHelperService, times(1)).invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                ArgumentMatchers.eq(byte[].class));

        InputStream is = resource.getInputStream();
        byte[] content = IOUtils.toByteArray(is);
        Assertions.assertArrayEquals(body, content);
    }

    @Test
    void testDownloadCustomerDocumentFailure() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        byte[] body = "file content".getBytes();
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(body, HttpStatus.OK);

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                ArgumentMatchers.eq(byte[].class)))
                .thenThrow(new AgencyCoPilot5xxException(new Exception("Unknown error occured"), HttpStatus.INTERNAL_SERVER_ERROR, ""));

        Assertions.assertThrows(AgencyCoPilot5xxException.class, () -> {
            documentsServiceHandler.downloadDocument(documentDownloadRequest);
        });
    }

    @Test
    void testDownloadCustomerDocumentFailureNoContent() throws Exception {
        DocumentDownloadRequest documentDownloadRequest = new DocumentDownloadRequest();
        documentDownloadRequest.setDocumentId("doc123");
        documentDownloadRequest.setVersion("1");
        documentDownloadRequest.setFileName("file");
        documentDownloadRequest.setFileExtension("pdf");

        byte[] body = "".getBytes();
        ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(body, HttpStatus.OK);

        when(restHelperService.invoke(
                ArgumentMatchers.anyString(),
                ArgumentMatchers.any(HttpMethod.class), ArgumentMatchers.any(),
                ArgumentMatchers.eq(byte[].class)))
                .thenReturn(null);

        Assertions.assertThrows(AgencyCoPilot4xxException.class, () -> {
            documentsServiceHandler.downloadDocument(documentDownloadRequest);
        });
    }

}