package com.pm.api.agencycopilot.services;

import com.atiam.insprocommon._2008.SystemCodeTableValueType;
import com.atiam.newbusinessapplication._2008.AppRequirementType;
import com.atiam.newbusinessapplication._2008.GetNewBusinessRequirementHistoryResponseType;
import com.atiam.newbusinessapplication._2008.NewBusinessRequirementHistoryResponseOutputType;
import com.atiam.newbusinessapplicationservice._2008.NewBusinessApplication;
import static com.pm.api.agencycopilot.constants.TestConstants.NPN;
import static com.pm.api.agencycopilot.constants.TestConstants.POLICY_NUMBER;
import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;
import com.pm.api.agencycopilot.models.external.nigo.NIGOResponse;
import com.pm.api.agencycopilot.services.impl.NIGOServiceHandlerImpl;
import com.pm.soap.client.InsproNewBusinessServiceClient;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles(profiles = "test")
class NIGOServiceHandlerTest {

    @InjectMocks
    NIGOServiceHandlerImpl nigoServiceHandler;
    @Mock
    InsproNewBusinessServiceClient insproNewBusinessServiceClient;

    @Mock
    private NewBusinessApplication newBusinessSoap11;


    @Test
    void testInvokeNIGO() throws Exception {

        MessagingAPIRequest messagingAPIRequest = new MessagingAPIRequest();
        messagingAPIRequest.setNpn(NPN);

        GetNewBusinessRequirementHistoryResponseType response = new GetNewBusinessRequirementHistoryResponseType();

        NewBusinessRequirementHistoryResponseOutputType value = new NewBusinessRequirementHistoryResponseOutputType();

        com.atiam.newbusinessapplication._2008.AppRequirementsType appRequirementsType = new com.atiam.newbusinessapplication._2008.AppRequirementsType();
        List<AppRequirementType> appRequirement = new ArrayList<>();
        AppRequirementType apt = new AppRequirementType();
        setField(apt, "requirement", new SystemCodeTableValueType());
        appRequirement.add(apt);

        setField(appRequirementsType, "appRequirement", appRequirement);
        setField(value, "appRequirements", appRequirementsType);


        setField(response, "info", value);
        value.setAppRequirements(appRequirementsType);
        response.setInfo(value);

        when(insproNewBusinessServiceClient.getNewBusinessApplicationService()).thenReturn(newBusinessSoap11);
        when(newBusinessSoap11.getNewBusinessRequirementHistory(any()))
                .thenReturn(response);
        NIGOResponse nigoResponse = nigoServiceHandler.invokeNIGO(List.of(POLICY_NUMBER));
        Assertions.assertNotNull(nigoResponse);
        Assertions.assertNotNull(nigoResponse.getNigoDocuments());
    }

}
