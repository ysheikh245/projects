package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.SystemInformation;

public interface SystemInformationService {

    public SystemInformation getSystemData();
}
