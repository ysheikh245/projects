package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import lombok.Data;

import java.util.List;
@Data
public class DiscountsResponse {
    private List<PolicyDiscounts> discounts;
}
