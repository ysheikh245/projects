package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PolicyRateChange {

    @JsonProperty("effectiveDate")
    private String effectiveDate;

    @JsonProperty("premium")
    private double premium;

    @JsonProperty("mode")
    private String mode;

    @JsonProperty("area")
    private String area;

    @JsonProperty("state")
    private String state;

    @JsonProperty("letterDueDate")
    private String letterDueDate;

    @JsonProperty("controlNumber")
    private String controlNumber;

    @JsonProperty("letterSentDate")
    private String letterSentDate;
}
