package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InteractionReasonsSubTypeItem {

    @JsonProperty("cdreasonsubtype")
    private Cdreasonsubtype cdreasonsubtype;

    @JsonProperty("interactionReasonSubtypeId")
    private int interactionReasonSubtypeId;

}