package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIResponse;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

public interface DocumentService {

    public DocumentsUploadAPIResponse uploadDocument(DocumentsUploadAPIRequest documentsUploadAPIRequest,
                                             MultipartFile uploadedFile) throws Exception ;


    Resource downloadDocument(DocumentDownloadRequest documentDownloadRequest) throws Exception;


}
