package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;

public interface CustomersServiceHandler extends ServiceHandler {

    FindCustomerByPolicyResponse invokeCustomerV2PMAPIByPolicy(String policyNumber);

    String findPartyId(String policyNumber);

    DocumentsV2Response<PolicyAlertResponse> getPolicyAlerts(String partyId)  throws Exception;
    
    FindCustomerByPolicyResponse invokeCustomerV2PMAPISearch(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest);

}
