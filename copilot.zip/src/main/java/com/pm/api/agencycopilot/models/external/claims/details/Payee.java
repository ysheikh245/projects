package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Payee{

	@JsonProperty("zip")
	private String zip;

	@JsonProperty("sequence")
	private String sequence;

	@JsonProperty("city")
	private String city;

	@JsonProperty("address1")
	private String address1;

	@JsonProperty("name")
	private String name;

	@JsonProperty("state")
	private String state;

	@JsonProperty("amountPaid")
	private Double amountPaid;

	@JsonProperty("paymentDate")
	private String paymentDate;

}