package com.pm.api.agencycopilot.models.errors;

import lombok.Data;

import java.util.Calendar;
import java.util.TimeZone;

@Data
public class ErrorObject {
    private String errorMessage;
    private String eventDate;
    private String exceptionStackTrace;

    public String getEventDate() {
        return String.valueOf(Calendar.getInstance().getTime());
    }
}
