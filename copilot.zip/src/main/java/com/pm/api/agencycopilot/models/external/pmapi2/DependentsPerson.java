package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class DependentsPerson {

    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("middleName")
    private String middleName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("issueAge")
    private String issueAge;
    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("status")
    private String status;
    @JsonProperty("studentInd")
    private String studentInd;
    @JsonProperty("disabledInd")
    private String disabledInd;
}
