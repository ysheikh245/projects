package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CsavegbydiscntItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CSavingByDiscnt")
	private String cSavingByDiscnt;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CDiscount")
	private String cDiscount;

	@JsonProperty("CAnnualSavings")
	private String cAnnualSavings;

	public String getEntityType(){
		return entityType;
	}

	public String getGid(){
		return gid;
	}

	public String getCSavingByDiscnt(){
		return cSavingByDiscnt;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCDiscount(){
		return cDiscount;
	}

	public String getCAnnualSavings(){
		return cAnnualSavings;
	}
}