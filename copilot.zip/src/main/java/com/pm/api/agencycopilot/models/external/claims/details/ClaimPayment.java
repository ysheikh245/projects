package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ClaimPayment {

	@JsonProperty("payeeName")
	private String payeeName;

	@JsonProperty("payeeAddress")
	private String payeeAddress;

	@JsonProperty("payeeCity")
	private String payeeCity;

	@JsonProperty("payeeState")
	private String payeeState;

	@JsonProperty("payeeZip")
	private String payeeZip;

	@JsonProperty("paidAmount")
	private String paidAmount;

	@JsonProperty("disbursementDate")
	private String disbursementDate;

}