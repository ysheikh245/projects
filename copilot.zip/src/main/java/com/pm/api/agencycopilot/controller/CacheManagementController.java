package com.pm.api.agencycopilot.controller;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.pm.api.agencycopilot.models.enums.TableEnum;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.AGENCY_COPILOT;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SUCCESS;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class CacheManagementController implements ApplicationController {

    @Value("${spring.data.mongodb.username:}")
    private String username;

    @Value("${spring.data.mongodb.password:}")
    private String password;

    @Value("${spring.data.mongodb.host:}")
    private String host;

    @Value("${spring.data.mongodb.port:}")
    private String port;

    @Autowired
    private Environment environment;

    private final String URI = "mongodb://%s:%s@%s:%s/";
    private final String MESSAGE = "{\"status\": \"{0}\"}";

    private List<String> collectionNames;
    private MongoClient mongoClient;


    @GetMapping("/data/clear-all")
    public ResponseEntity<String> clearData() {
        HttpStatus status;
        String message;

        log.info("CacheManagementController.clearAll() - Started");
        try {
            MongoClient mongoClient = getMongoClient();
            MongoDatabase database = mongoClient.getDatabase(AGENCY_COPILOT);
            for (TableEnum table : TableEnum.values()) {
                String collectionName = table.getCollectionName();
                MongoCollection<Document> collection = database.getCollection(collectionName);
                collection.drop();
            }
            status = HttpStatus.OK;
            message = StringUtils.replace(MESSAGE, "{0}", SUCCESS);
            log.info("CacheManagementController.clearAll() - Completed");
        } catch (Exception e) {
            log.info("CacheManagementController.clearAll() - Failed");
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = StringUtils.replace(MESSAGE, "{0}", ExceptionUtils.getStackTrace(e));
        }
        return ResponseEntity.status(status).body(message);
    }

    @GetMapping("/data/clear/{collectionName}")
    public ResponseEntity<String> clearCollection(@PathVariable("collectionName") String collectionName) {
        HttpStatus status;
        String message;
        log.info("CacheManagementController.clearCollection() - Started");
        try {
            MongoClient mongoClient = getMongoClient();
            MongoDatabase database = mongoClient.getDatabase(AGENCY_COPILOT);
            validateCollectionName(collectionName);
            MongoCollection<Document> collection = database.getCollection(collectionName);
            collection.drop();
            status = HttpStatus.OK;
            message = StringUtils.replace(MESSAGE, "{0}", SUCCESS);
            log.info("CacheManagementController.clearCollection() - Completed");
        } catch (Exception e) {
            log.info("CacheManagementController.clearCollection() - Failed");
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            message = StringUtils.replace(MESSAGE, "{0}", ExceptionUtils.getStackTrace(e));
        }
        return ResponseEntity.status(status).body(message);
    }

    private void validateCollectionName(String collectionNameToEvict) {
        List<String> collectionNames = getCollectionNames();
        if (!collectionNames.contains(collectionNameToEvict)) {
            log.info("CacheManagementController.validateCollectionName() - No collection found {}", collectionNameToEvict);
            throw new RuntimeException("No collection exists within agency-copilot");
        }
    }

    private List<String> getCollectionNames() {
        if (collectionNames == null) {
            collectionNames = new ArrayList<>();
            Stream.of(TableEnum.values()).forEach(value -> collectionNames.add(value.getCollectionName()));
        }
        return collectionNames;
    }

    private MongoClient getMongoClient() {
        if (mongoClient == null) {
            String[] profiles = environment.getActiveProfiles();
            if (Arrays.asList(profiles).contains("local")) {
                log.info("Local Profile used for Mongo Client");
                mongoClient = MongoClients.create();
            } else {
                log.info("Non Local Profile used for Mongo Client");
                String actualURI = String.format(URI, username, password, host, port);
                mongoClient = MongoClients.create(actualURI);
            }
        }
        return mongoClient;
    }
}
