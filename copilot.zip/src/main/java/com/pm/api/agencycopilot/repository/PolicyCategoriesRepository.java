package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyCategoriesRepository extends MongoRepository<PolicyCategoriesRecord, String> {

    PolicyCategoriesRecord findByCodeAndIsActive(String id, boolean isActive);
}
