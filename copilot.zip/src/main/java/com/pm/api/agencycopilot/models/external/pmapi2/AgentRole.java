package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AgentRole {

    @JsonProperty("agentRoleOnPolicyId")
    private int agentRoleOnPolicyId;
    @JsonProperty("agentStatus")
    private String agentStatus;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("nationalProducerNumber")
    private String nationalProducerNumber;
    @JsonProperty("policyNumber")
    private String policyNumber;
    @JsonProperty("policyRole")
    private String policyRole;
    @JsonProperty("salesforceContactId")
    private String salesforceContactId;
    @JsonProperty("splitPercentage")
    private double splitPercentage;

}
