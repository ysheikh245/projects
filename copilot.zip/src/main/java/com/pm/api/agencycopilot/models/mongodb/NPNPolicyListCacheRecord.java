package com.pm.api.agencycopilot.models.mongodb;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "npnPolicyListCache")
@Data
public class NPNPolicyListCacheRecord {

    @Id
    private String npnId;
    private List<String> policies;
    private Date createDate;
}
