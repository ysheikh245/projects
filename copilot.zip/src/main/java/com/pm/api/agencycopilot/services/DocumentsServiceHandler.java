package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIResponse;
import com.pm.api.agencycopilot.models.external.documents.upload.DocumentUploadRequest;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import org.springframework.core.io.Resource;

public interface DocumentsServiceHandler<T> extends ServiceHandler {

    public DocumentsV2Response<DocumentsResponse> getPolicyDocuments(String policyNumber) throws Exception;

    public DocumentsUploadAPIResponse uploadDocuments(DocumentUploadRequest documentUploadRequest);

    public Resource downloadDocument(DocumentDownloadRequest documentDownloadRequest) throws Exception;
}
