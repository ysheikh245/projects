package com.pm.api.agencycopilot.models.external.agents;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PrimaryWorkAddress{

	@JsonProperty("zipPostalCode")
	private String zipPostalCode;

	@JsonProperty("city")
	private String city;

	@JsonProperty("addressType")
	private String addressType;

	@JsonProperty("addressLine1")
	private String addressLine1;

	@JsonProperty("stateProvince")
	private String stateProvince;

	@JsonProperty("addressLine2")
	private String addressLine2;

	public String getZipPostalCode(){
		return zipPostalCode;
	}

	public String getCity(){
		return city;
	}

	public String getAddressType(){
		return addressType;
	}

	public String getAddressLine1(){
		return addressLine1;
	}

	public String getStateProvince(){
		return stateProvince;
	}

	public String getAddressLine2(){
		return addressLine2;
	}
}