package com.pm.api.agencycopilot.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class AgencyCoPilot5xxException extends AgencyCoPilotException{



    public AgencyCoPilot5xxException(Exception exception,
                                     HttpStatus httpStatus,
                                     String apiEndpoint) {
        super(exception, httpStatus, apiEndpoint);
    }
}
