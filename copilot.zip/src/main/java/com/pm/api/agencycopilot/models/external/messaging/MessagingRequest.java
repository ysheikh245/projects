package com.pm.api.agencycopilot.models.external.messaging;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Map;
import lombok.Data;

@Data
public class MessagingRequest {

    @JsonProperty("fromUser")
    private String fromUserName;

    @JsonProperty("toUser")
    private ToUser toUser;

    @JsonProperty("toEmailAddress")
    private String toEmailAddress;

    @JsonProperty("messageCode")
    private String messageCode;

    @JsonProperty("valueMap")
    private Map<String, String> valueMap;

    @JsonProperty("deliveryTypes")
    private String[] deliveryType;

}
