package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.apis.AgentCompensation;
import com.pm.api.agencycopilot.models.apis.AgentCompensations;
import com.pm.api.agencycopilot.models.enums.AgentCompensationFieldNamesEnum;
import com.pm.api.agencycopilot.models.external.compensation.AgentCompensationResponse;
import com.pm.api.agencycopilot.models.external.compensation.FieldList;
import com.pm.api.agencycopilot.models.external.compensation.FmsRowTO;
import com.pm.api.agencycopilot.services.AgentCompensationService;
import com.pm.api.agencycopilot.services.Case360ServiceHandler;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AgentCompensationServiceImpl implements AgentCompensationService {

    @Autowired
    private Case360ServiceHandler case360ServiceHandler;

    @Override
    public AgentCompensations fetchAvailableCompensations(String npn, String beginDate, String endDate) {
        AgentCompensationResponse response = case360ServiceHandler.fetchAvailableCompensations(npn, beginDate, endDate);
        List<AgentCompensation> agentCompensationList = new ArrayList<>();
        AgentCompensations agentCompensations = new AgentCompensations();
        response.getFmsRowSetTO().get(0).getFmsRowTO().forEach(fmsRowTO -> {
            AgentCompensation agentCompensation = new AgentCompensation();
            agentCompensation.setDocumentType(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.PMU_DOC_TYPE));
            agentCompensation.setDocumentId(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.DOCUMENTID));
            agentCompensation.setEndDate(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.PMU_PAYPERIOD_ENDDATE));
            agentCompensation.setDocumentIndexCode(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.PMU_DOC_INDEX_CODE));
            agentCompensation.setVersion(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.VERSIONNUMBER));
            agentCompensation.setFileName(extractFieldsByFieldName(fmsRowTO, AgentCompensationFieldNamesEnum.FILENAME));
            agentCompensationList.add(agentCompensation);
        });
        agentCompensations.setAgentCompensationStatements(agentCompensationList);

        return agentCompensations;
    }

    private String extractFieldsByFieldName(FmsRowTO fmsRowTO, AgentCompensationFieldNamesEnum agentCompensationFieldNamesEnum) {
        Optional<FieldList> fieldList = fmsRowTO.getFieldList()
                .stream()
                .filter(row -> agentCompensationFieldNamesEnum.name().equalsIgnoreCase(row.getFieldName()))
                .findFirst();

        if (fieldList.isPresent()) {
            if (agentCompensationFieldNamesEnum.getDataType().equalsIgnoreCase("STRING")) {
                return fieldList.get().getStringValue();
            } else if (agentCompensationFieldNamesEnum.getDataType().equalsIgnoreCase("BIGDECIMAL")) {
                return fieldList.get().getBigDecimalValue().toString();
            } else if (agentCompensationFieldNamesEnum.getDataType().equalsIgnoreCase("CALENDAR")) {
                return fieldList.get().getCalendarValue();
            } else if (agentCompensationFieldNamesEnum.getDataType().equalsIgnoreCase("INTEGER")) {
                return String.valueOf(fieldList.get().getIntValue());
            }
        }
        return null;
    }

}
