package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
//@JsonRootName("FmsRowSetTO")
public class FmsRowSetTO {

    @JsonProperty("FmsRowTO")
    private List<FmsRowTO> fmsRowTO;

    @JsonProperty("rowCount")
    private int rowCount;


}