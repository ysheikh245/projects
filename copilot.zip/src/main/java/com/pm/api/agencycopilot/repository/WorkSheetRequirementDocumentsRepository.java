package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.mongodb.WorkSheetRequirementDocuments;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkSheetRequirementDocumentsRepository extends MongoRepository<WorkSheetRequirementDocuments, String> {

    //List<Case360DocumentVO> findWorkSheetRequirementDocuments(String policyNumber);

}
