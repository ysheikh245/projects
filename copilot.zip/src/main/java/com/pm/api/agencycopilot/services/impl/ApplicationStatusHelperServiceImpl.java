package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.apis.SortOrderEnum;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.EntriesItem;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyToProductCategory;
import com.pm.api.agencycopilot.models.mongodb.WorkSheetRequirementDocuments;
import com.pm.api.agencycopilot.repository.WorkSheetRequirementDocumentsRepository;
import com.pm.api.agencycopilot.services.Case360ServiceHandler;
import com.pm.api.agencycopilot.services.ContentStackServiceHandler;
import com.pm.api.agencycopilot.services.CustomersServiceHandler;
import com.pm.api.agencycopilot.services.InteractionLogsServiceHandler;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import com.pm.api.agencycopilot.services.PolicyDBServiceHandler;
import com.pm.api.agencycopilot.utility.ApplicationStatusProperties;
import com.pm.api.agencycopilot.utility.DateFormatterUtility;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum.filterActivePolicies;
import static com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum.filterDeclineWithdrawnPolicies;
import static com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum.filterNotTakenPolicies;
import static com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum.filterPendingPolicies;
import static com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum.transformEnumToStringList;
import static com.pm.api.agencycopilot.models.enums.ThankyouStatusEnum.HIDE;
import static com.pm.api.agencycopilot.models.enums.ThankyouStatusEnum.SEND_THANKYOU;
import static com.pm.api.agencycopilot.models.enums.ThankyouStatusEnum.THANKYOU_SENT;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.COMMA;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.CREATED_BY_USER;

@Service
@Slf4j
public class ApplicationStatusHelperServiceImpl {

    @Autowired
    private PolicyDBServiceHandler policyDBServiceHandler;

    @Autowired
    private InsproPolicyServiceHandlerImpl insproPolicyServiceHandler;

    @Autowired
    private Case360ServiceHandler case360ServiceHandler;

    @Autowired
    private InteractionLogsServiceHandler interactionLogsServiceHandler;

    @Autowired
    private CustomersServiceHandler customersServiceHandler;

    @Autowired
    private ApplicationStatusProperties applicationStatusProperties;

    @Value("${agency.copilot.background.processing.feature:false}")
    private String backgroundProcessingFlag;

    @Value("${agency.copilot.worksheet.requirement.exception.count:-1}")
    private int worksheetExceptionCount;

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private WorkSheetRequirementDocumentsRepository workSheetRequirementDocumentsRepository;

    @Autowired
    private ContentStackServiceHandler contentStackServiceHandler;

    @Autowired
    private MaskedValueLogger maskedValueLogger;

    //private String queryParams = "?environment={0}&query={1}"; //"product_type": "Life"

    @Async("applicationStatusTaskExecutor")
    public CompletableFuture<Boolean> processApplicationStatus(ApplicationStatusRequest applicationStatusRequest, boolean isBackground) throws Exception {
        log.info("Entering processApplicationStatus at {}", LocalDateTime.now());
        List<PolicyV2Response> pmapiPolicyResponse = null;
        List<PolicyVO> policies;

        policies = getPolicyNumbersFromDB(applicationStatusRequest.getAgentInformation().getNpn(),
                applicationStatusRequest.getFilterCriteria());
            /*
            - Go to the SOAP client and get data for the policies
            - For each policy, bucket the data in Active, Pending
            - If Active, get interaction log if email was sent?
            - If Pending, go to case 360 and get response
             */
        if (CollectionUtils.isEmpty(policies)) {
            if (isBackground) {
                mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                        applicationStatusRequest.getAgentInformation().getNpn(),
                        LocalDateTime.now(),
                        true,
                        true,
                        0);
                throw new AgencyCoPilot4xxException(String.format("No Results found for the given npn %s", applicationStatusRequest.getAgentInformation().getNpn()),
                        HttpStatus.NOT_FOUND,
                        "");
            } else {
                mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                        applicationStatusRequest.getAgentInformation().getNpn(),
                        LocalDateTime.now(),
                        false,
                        true,
                        0);
                return CompletableFuture.completedFuture(Boolean.FALSE);
            }

        }
        List<PolicyVO> insproPolicyResponses = insproPolicyServiceHandler.getPolicyDetailsFromInspro(policies);

        if (!Boolean.valueOf(backgroundProcessingFlag)) {
            /**
             Since the results are paginated, it would be easier to apply Pagination logic directly on database.
             Hence, if the backgroundProcessingFlag is set to false, we first delete all the data for given NPN
             and store the fresh set of records in database and return the paginated results back to the user.
             **/
            mongoDBCacheHandler.findAndDeletePoliciesByNpn(applicationStatusRequest.getAgentInformation().getNpn());

        }

        PolicyVO[] filteredPolicies = insproPolicyResponses.stream().filter(mappedPolicy ->
                filterActivePolicies(mappedPolicy) ||
                        filterPendingPolicies(mappedPolicy) ||
                        filterDeclineWithdrawnPolicies(mappedPolicy) ||
                        filterNotTakenPolicies(mappedPolicy)
        ).toArray(PolicyVO[]::new);
        log.info("*****Debug*****. FilteredPolicies={}. Data={}", org.apache.commons.collections4.CollectionUtils.size(filteredPolicies), filteredPolicies);

        PolicyVO[] activePolicies = insproPolicyResponses.stream()
                .filter(policyVO -> filterActivePolicies(policyVO)).toArray(PolicyVO[]::new);

        processActivePolicies(activePolicies, applicationStatusRequest);
        log.info("*****Debug*****. activePoliciesCount={}. activePolicies={}", activePolicies.length, Arrays.asList(activePolicies));

        // get the party id
        // for each party id, check interaction logs

        PolicyVO[] pendingPolicies = insproPolicyResponses.stream()
                .filter(policyVO -> filterPendingPolicies(policyVO)).toArray(PolicyVO[]::new);

        processPendingPolicies(pendingPolicies, applicationStatusRequest);
        log.info("*****Debug*****. pendingPoliciesCount={}. pendingPolicies={}", pendingPolicies.length, Arrays.asList(pendingPolicies));

        List<PolicyVO> notIssuedPolicies = insproPolicyResponses.stream()
                .filter(policyVO ->
                        (filterDeclineWithdrawnPolicies(policyVO) ||
                                filterNotTakenPolicies(policyVO))
                ).collect(Collectors.toList());

        processNotIssuedPolicies(notIssuedPolicies, applicationStatusRequest);
        log.info("*****Debug*****. notIssuedPoliciesCount={}. notIssuedPolicies={}", notIssuedPolicies, notIssuedPolicies);

        mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                applicationStatusRequest.getAgentInformation().getNpn(),
                LocalDateTime.now(),
                isBackground,
                true,
                filteredPolicies == null ? 0 : filteredPolicies.length);

        log.info("Exiting processApplicationStatus at {}", LocalDateTime.now());
        return CompletableFuture.completedFuture(Boolean.TRUE);
    }

    public ApplicationStatusResponse paginatedApplicationStatusResponseFromMongo(ApplicationStatusRequest applicationStatusRequest) {
        log.info("Entering paginatedApplicationStatusResponseFromMongo at {}", LocalDateTime.now());
        log.info("Querying database using criteria queries...");
        ApplicationStatusResponse response = new ApplicationStatusResponse();

        Pageable paging = PageRequest.of(
                applicationStatusRequest.getFilterCriteria().getPageNumber(),
                applicationStatusRequest.getFilterCriteria().getPageSize());

        log.info("Executing the database query for npnId={} and filter criteria {} ",
                applicationStatusRequest.getAgentInformation().getNpn(),
                applicationStatusRequest.getFilterCriteria());

        Sort sort = null;
        if (SortOrderEnum.ASC == applicationStatusRequest.getFilterCriteria().getSortOrder()) {
            sort = Sort.by(Sort.Direction.ASC, "policyResponse.submitDate");
        } else {
            sort = Sort.by(Sort.Direction.DESC, "policyResponse.submitDate");
        }
        Query query = new Query()
                .with(paging)
                .with(sort);

        Criteria criteria = Criteria.where("npnId").is(applicationStatusRequest.getAgentInformation().getNpn());
        if (applicationStatusRequest.getFilterCriteria().getCustomerName() != null) {
            log.info("Adding CustomerName to MongoFilterQuery {}", applicationStatusRequest.getFilterCriteria().getCustomerName());
            //The below is the query format in mongocompass that is used to filter by name and case-insensitive.
            // { "policyResponse.parties" : { "$elemMatch" : { "fullName" : {"$regex":"KIM",  "$options":"i" }}}}
            criteria.and("policyResponse.parties")
                    .elemMatch(Criteria.where("fullName")
                            .regex(applicationStatusRequest.getFilterCriteria().getCustomerName(), "i"));
        }

        if (applicationStatusRequest.getFilterCriteria().getPolicyNumber() != null) {
            log.info("Adding PolicyNumber to MongoFilterQuery {}", applicationStatusRequest.getFilterCriteria().getPolicyNumber());
            criteria.and("policyNumber")
                    .is(applicationStatusRequest.getFilterCriteria().getPolicyNumber());
        }
        if (!CollectionUtils.isEmpty(applicationStatusRequest.getFilterCriteria().getStatus())) {
            log.info("Filters applied for Application Status are {}", transformEnumToStringList(applicationStatusRequest.getFilterCriteria().getStatus()));
            criteria.and("policyResponse.policyStatus").in(transformEnumToStringList(applicationStatusRequest.getFilterCriteria().getStatus()));
        }

        if (isFilterApplied(applicationStatusRequest.getFilterCriteria())) {
            //{ "policyResponse.submitDate" : { "$gte" : { "$date" : "2023-04-15T04:00:00Z"}, "$lte" : { "$date" : "2023-04-19T04:00:00Z"}}}
            log.info("Filters applied for submitDate From: {} and To:{}",
                    applicationStatusRequest.getFilterCriteria().getSearchFromDate(),
                    applicationStatusRequest.getFilterCriteria().getSearchToDate());
            criteria.and("policyResponse.submitDate")
                    .gte(applicationStatusRequest.getFilterCriteria().getSearchFromDate())
                    .lte(applicationStatusRequest.getFilterCriteria().getSearchToDate());
        }
        query.addCriteria(criteria);

        List<PolicyDatabaseRecord> policyVOList = mongoDBCacheHandler.findPoliciesByNpnUsingCriteria(query);

        if (policyVOList != null) {
            log.info("Returned {} policies from mongodb cache for npn {}", policyVOList.size(), applicationStatusRequest.getAgentInformation().getNpn());
        }
        response.setPolicy(policyVOList
                .stream()
                .map(PolicyDatabaseRecord::getPolicyResponse)
                .collect(Collectors.toList()));

        log.info("Exiting paginatedApplicationStatusResponseFromMongo at {}", LocalDateTime.now());
        return response;
    }

    @Async("applicationStatusBckGrdTaskExecutor")
    public void gatherPolicyInformationInBackground(ApplicationStatusRequest applicationStatusRequest) throws Exception {
        log.info("Entering gatherPolicyInformationInBackground at {}", LocalDateTime.now());
        fillDefaultValuesIfNeeded(applicationStatusRequest);
        CompletableFuture<Boolean> completableFuture = this.processApplicationStatus(applicationStatusRequest, true);
        Boolean isBackgroundProcessCompleted = completableFuture.get();
        log.info("Initiated the search process for criteria {} in the background.", applicationStatusRequest.getFilterCriteria());
        log.info("Exiting gatherPolicyInformationInBackground at {}", LocalDateTime.now());
    }

    /**
     * Enriches the Pending PolicyVO object with the upload button and the display field criteria
     *
     * @param case360Documents
     * @param contentStackAgentsWorksheetResponse
     */
    public List<Case360DocumentVO> filterEligibleCase360Documents(List<Case360DocumentVO> case360Documents, Response contentStackAgentsWorksheetResponse) {
        log.info("Entering filterEligibleCase360Documents at {}", LocalDateTime.now());
        List<Case360DocumentVO> filteredCase360Documents = new ArrayList<>();
        for (Case360DocumentVO case360Document : case360Documents) {
            if (StringUtils.isEmpty(case360Document.getDateReceived())) { // do not process any further if dateReceived is populated
                String documentTitle = case360Document.getDescription();
                Optional<EntriesItem> entriesItem = contentStackAgentsWorksheetResponse.getEntries().stream().filter(
                        element -> StringUtils.equalsIgnoreCase(element.getDescription(), documentTitle)).findFirst();
                if (entriesItem.isPresent()) {
                    String checklistAction = StringUtils.isNotEmpty(entriesItem.get().getChecklistAction()) ? entriesItem.get().getChecklistAction() : BLANK;
                    String displayField = StringUtils.isNotEmpty(String.valueOf(entriesItem.get().isShowField())) ? String.valueOf(entriesItem.get().isShowField()) : BLANK;
                    case360Document.setUploadButton(checklistAction);
                    case360Document.setDisplayField(displayField);
                    filteredCase360Documents.add(case360Document);
                } else {
                    log.info("Filtering document as description mismatched. Description={}", case360Document.getDescription());
                }
            } else {
                log.info("Filtering document as date received is populated. Description={}. Date Received={}", case360Document.getDescription(), case360Document.getDateReceived());
            }

            /*contentStackAgentsWorksheetResponse.getEntries().forEach(element -> {
                System.out.println("EValuating : " + element.getDescription());
                if(element.getDescription().equalsIgnoreCase(documentTitle)) {
                    System.out.println("Found the document: " + documentTitle);
                    case360Document.setUploadButton(element.getChecklistAction());
                    case360Document.setDisplayField(String.valueOf(element.isShowField()));
                    filteredCase360Documents.add(case360Document);
                }
            });*/
        }
        log.info("Exiting filterEligibleCase360Documents at {}", LocalDateTime.now());
        return filteredCase360Documents;

        /*if(response != null) {
            Optional<EntriesItem> contentStackItem = response.getEntries().stream().filter(element -> StringUtils.equals(element.getDescription(), policyStatusCode)).findFirst();
            if(contentStackItem.isPresent()) {
                EntriesItem entriesItem = contentStackItem.get();
                String checkListAction = entriesItem.getChecklistAction();
                boolean showField = entriesItem.isShowField();
            }
        }*/
    }

    /**
     * Updates the cache for that NPN; Policy Number
     * @param npn
     * @param policyNumber
     * @param updateStatus
     */
    public void updateCacheEntryForActivePolicy(String npn, String policyNumber, String updateStatus) {
        // Updating the cache to reflect more appropriate status of active policies
        try {
            log.info("Attempting updateCacheEntryForActivePolicy - Started. PolicyNumber={}, NPN={}", policyNumber, npn);
            PolicyDatabaseRecord updatedPolicyRecord = mongoDBCacheHandler.updatePolicyRepository(npn, policyNumber, updateStatus);
            if(updatedPolicyRecord == null) {
                log.info("Attempting updateCacheEntryForActivePolicy - Failed. PolicyNumber={}, NPN={}", policyNumber, npn);
            } else {
                log.info("Attempting updateCacheEntryForActivePolicy - Completed. PolicyNumber={}, NPN={}", policyNumber, npn);
            }
        } catch(Exception exception) {
            log.error("ApplicationStatusHelperServiceImpl.updateCacheEntryForActivePolicy - Failed. PolicyNumber={}, NPN={}, Exception={}",
                                                       policyNumber, npn, ExceptionUtils.getStackTrace(exception));
            return;
        }
    }

    private void processNotIssuedPolicies(List<PolicyVO> notIssuedPolicies, ApplicationStatusRequest applicationStatusRequest) {
        log.info("Entering processNotIssuedPolicies at {}. Size={}", LocalDateTime.now(), org.apache.commons.collections4.CollectionUtils.size(notIssuedPolicies));
        notIssuedPolicies.forEach(policyVO -> {
                    log.debug("Inserting the not issue policies with status category {} in mongo cache.", policyVO.getPolicyStatus());
                    log.info("Saving policy to cache {}-{}", policyVO.getPolicyNumber(), "NotIssued");
                    mongoDBCacheHandler.saveToPolicyDocument(policyVO, applicationStatusRequest);
                }
        );
        log.info("Exiting processNotIssuedPolicies at {}. Size={}", LocalDateTime.now(), org.apache.commons.collections4.CollectionUtils.size(notIssuedPolicies));
    }

    private boolean isFilterApplied(FilterCriteriaVO filterCriteriaVO) {
        return (filterCriteriaVO.getSearchToDate() != null && filterCriteriaVO.getSearchFromDate() != null);
    }

    private void processPendingPolicies(PolicyVO[] pendingPolicies, ApplicationStatusRequest applicationStatusRequest) throws Exception {
        log.info("Entering processPendingPolicies at {}. Size={}", LocalDateTime.now(), pendingPolicies.length);
        log.info("Processing {} pending policies", (!CollectionUtils.isEmpty(Arrays.asList(pendingPolicies))) ? pendingPolicies.length : 0);
        ExecutorService executorService = getExecutorService();
        Map<String, String> currentMDCContextMap = MDC.getCopyOfContextMap();
        Map<String, Future> futures = new HashMap();
        for (PolicyVO pendingPolicy : pendingPolicies) {
            // find out whether send thank you was sent; we need partyId
            // once we find partyId, we can use Interaction Logs to determine the thank you status
            String policyNumber = pendingPolicy.getPolicyNumber();
            String policyStatus = pendingPolicy.getPolicyStatusCode();
            futures.put(policyNumber, executorService.submit(() -> {
                MDC.setContextMap(currentMDCContextMap);
                return invokeCase360UWRequirementAPI(policyNumber, policyStatus);
            }));

        }

        for (PolicyVO pendingPolicy : pendingPolicies) {
            try {
                //Case360WorksheetResponse case360WorksheetResponse = (Case360WorksheetResponse) futures.get(pendingPolicy.getPolicyNumber()).get();
                //List<Case360DocumentVO> case360Documents = mapCase360APIResponse(case360WorksheetResponse);

                List<Case360DocumentVO> case360Documents = (List<Case360DocumentVO>) futures.get(pendingPolicy.getPolicyNumber()).get();
                log.info("Filtering results from case360Documents for PolicyNumber={}. ProductCode={}", pendingPolicy.getPolicyNumber(), pendingPolicy.getProductCode());
                String productCode = pendingPolicy.getProductCode();
                if (StringUtils.isNotBlank(productCode)) {
                    Response agentsWorksheetResponse = getDocumentMetaDataFromContentStack(productCode);
                    if (agentsWorksheetResponse != null) {
                        //log.debug("****** Response from Content-Stack Agent Worksheet options: {}***", JSONUtility.convertObjectToString(agentsWorksheetResponse)); //TODO: remove log
                        log.info("Case360Documents - BeforeFiltering, Size={}. Policy={}.", case360Documents.size(), pendingPolicy.getPolicyNumber());
                        List<Case360DocumentVO> filteredCase360Documents = filterEligibleCase360Documents(case360Documents, agentsWorksheetResponse);
                        //log.debug("****** Filtered Case 360 Documents : {}***", JSONUtility.convertObjectToString(filteredCase360Documents)); //TODO: remove log
                        log.info("Case360Documents - AfterFiltering, Size={}. Policy={}.", filteredCase360Documents.size(), pendingPolicy.getPolicyNumber());
                        pendingPolicy.setWorkSheetRequirementCount(filteredCase360Documents.size());
                        persistProcessedCase360Response(pendingPolicy.getPolicyNumber(), filteredCase360Documents); // Cache data in the table until midnight for faster retrieval
                    } else {
                        pendingPolicy.setWorkSheetRequirementCount(worksheetExceptionCount);
                        log.error("Agent Worksheet option query is NULL. Policy={}. ProductCode={}", pendingPolicy.getPolicyNumber(), productCode);
                    }
                }
                log.info("Saving policy to cache {}-{}", pendingPolicy.getPolicyNumber(), "Pending");
                mongoDBCacheHandler.saveToPolicyDocument(pendingPolicy, applicationStatusRequest);
                persistPolicyToProductCategory(pendingPolicy); // this persists policyNumber to Product Category mapping
            } catch (Exception e) {
                log.error("ApplicationStatusServiceImpl.processPendingPolicies(). Exception={}", ExceptionUtils.getStackTrace(e));
                //TODO: Exception handling
            }
        }
        log.info("Exiting processPendingPolicies at {}. Size={}", LocalDateTime.now(), pendingPolicies.length);
    }

    private void processActivePolicies(PolicyVO[] activePolicies, ApplicationStatusRequest applicationStatusRequest) throws Exception {
        log.info("Entering processActivePolicies at {}. Size={}", LocalDateTime.now(), activePolicies.length);
        ExecutorService executorService = getExecutorService();
        Map<String, String> currentMDCContextMap = MDC.getCopyOfContextMap();
        Map<String, Future> futures = new HashMap();
        for (PolicyVO activePolicy : activePolicies) {
            // find out whether send thank you was sent; we need partyId
            // once we find partyId, we can use Interaction Logs to determine the thank you status
            String policyNumber = activePolicy.getPolicyNumber();
            futures.put(policyNumber, executorService.submit(() -> {
                MDC.setContextMap(currentMDCContextMap);
                return invokeCustomersV2PMAPI(policyNumber);
            }));
        }

        for (PolicyVO activePolicy : activePolicies) {
            String partyId = (String) futures.get(activePolicy.getPolicyNumber()).get();
            activePolicy.getParties().get(0).setPartyId(partyId);
        }

        // Evaluate if Thank you was sent
        for (PolicyVO activePolicy : activePolicies) {
            String policyNumber = activePolicy.getPolicyNumber();
            futures.put(policyNumber, executorService.submit(() -> {
                MDC.setContextMap(currentMDCContextMap);
                return evaluateSendThankYouEvent(activePolicy, activePolicy.getParties().get(0).getPartyId());
            }));
        }

        for (PolicyVO activePolicy : activePolicies) {
            try {
                String event = (String) futures.get(activePolicy.getPolicyNumber()).get();
                activePolicy.setThankyouEmailStatus(event);
                log.info("Saving policy to cache {}-{}", activePolicy.getPolicyNumber(), "Active");
                mongoDBCacheHandler.saveToPolicyDocument(activePolicy, applicationStatusRequest);
            } catch (ExecutionException executionException) {
                executionException.printStackTrace();
                log.error("ExecutionException Occurred for policyNumber={}, exceptionMessage={}"
                        , activePolicy.getPolicyNumber()
                        , executionException.getMessage());
            }
        }
        log.info("Exiting processActivePolicies at {}. Size={}", LocalDateTime.now(), activePolicies.length);
    }

    private List<PolicyVO> getPolicyNumbersFromDB(String npn, FilterCriteriaVO filterCriteriaVO) {
        return policyDBServiceHandler.getPoliciesByNPN(npn, filterCriteriaVO);
    }

    private List<Case360DocumentVO> invokeCase360UWRequirementAPI(String policyNumber, String policyStatusCode) throws Exception {
        log.info("Entering invokeCase360UWRequirementAPI at {}. Policy={}", LocalDateTime.now(), policyNumber);
        List<Case360DocumentVO> case360Documents = case360ServiceHandler.getRequirementsDocumentList(policyNumber);
        log.info("Exiting invokeCase360UWRequirementAPI at {}. Policy={}", LocalDateTime.now(), policyNumber);
        return case360Documents;
    }

    @NotNull
    private ExecutorService getExecutorService() {
        return Executors.newFixedThreadPool(10);
    }

    private String invokeCustomersV2PMAPI(String policyNumber) {
        log.info("Entering invokeCustomersV2PMAPI at {}", LocalDateTime.now());
        String partyId = "";
        try {
            partyId = customersServiceHandler.findPartyId(policyNumber);
            log.info("Found partyId for policyNumber {} from pmapiCustomers API", policyNumber);
            maskedValueLogger.info(String.format("Policy Number %s and PartyId from Customers PMAPI %s", policyNumber, partyId), log);
        } catch (Exception exception) {
            log.error("Exception Occurred while invokingCustomersV2PMAPI. policyNumber={} exceptionMessage={}", policyNumber, exception.getMessage());
            return StringUtils.EMPTY;
        }
        log.info("Exiting invokeCustomersV2PMAPI at {}", LocalDateTime.now());
        return partyId;
    }

    private String evaluateSendThankYouEvent(PolicyVO policy, String partyId) throws Exception{
        LocalDate issueDate = DateFormatterUtility.convertUtilDateToLocalDate(policy.getIssueDate());
        if (isStatusCodeEligibleForThankyouEvaluation(policy)) {
            if (LocalDate.now().minusDays(applicationStatusProperties.getCriteriaDaysToEvaluateThankyou()).isBefore(issueDate)) {
                if (interactionLogsServiceHandler.isEventOccurred(policy.getPolicyNumber(), partyId)) {
                    return THANKYOU_SENT.name();
                } else {
                    return SEND_THANKYOU.name();
                }
            } else {
                return HIDE.name();
            }

        } else {
            return HIDE.name();
        }

    }

    private boolean isStatusCodeEligibleForThankyouEvaluation(PolicyVO policy) {
        List<String> statusCodes = Arrays.asList(
                applicationStatusProperties.getStatusCodeForEvaluatingThankyouEmail().split(COMMA));

        if (statusCodes.contains(policy.getPolicyStatusCode())) {
            return true;
        }
        return false;

    }

    private void fillDefaultValuesIfNeeded(ApplicationStatusRequest applicationStatusModel) {
        FilterCriteriaVO defaultFilterCriteria = new FilterCriteriaVO();
        defaultFilterCriteria.setDays(applicationStatusProperties.getDefaultLastMaxXDaysFilter());
        defaultFilterCriteria.setStatus(applicationStatusModel.getFilterCriteria().getStatus());
        LocalDate last7DaysBackDate = LocalDate.now().minusDays(applicationStatusProperties.getDefaultLastXDaysFilter() + 1);
        LocalDate last60DaysBackDate = LocalDate.now().minusDays(applicationStatusProperties.getDefaultLastMaxXDaysFilter());
        defaultFilterCriteria.setSearchFromDate(last60DaysBackDate);
        defaultFilterCriteria.setSearchToDate(last7DaysBackDate);
        defaultFilterCriteria.setSortOrder(applicationStatusModel.getFilterCriteria().getSortOrder());
        defaultFilterCriteria.setPageSize(applicationStatusModel.getFilterCriteria().getPageSize());
        applicationStatusModel.setFilterCriteria(defaultFilterCriteria);
    }

    private Response getDocumentMetaDataFromContentStack(String productCode) {
        return contentStackServiceHandler.getAgentWorksheetOptionsResponse(productCode);
        /*List<Object> documentsMetadata = new ArrayList<>();
        //TODO: invoke the Content Stack and get the document meta-data response
        String productCategory = mongoDBCacheHandler.findProductTypeCategory(policyStatusCode, true).getCategory(); // Life, Dental, MedSupp, Cancer etc.
        String contentStackResponse = mongoDBCacheHandler.findByProductCategory(productCategory).getContentStackResponse();
        if(StringUtils.isEmpty(contentStackResponse)) {
            contentStackResponse = contentStackServiceHandler.getContentStackResponse(apiURL, "product_type=\"" + policyStatusCode + "\"");
        }

        AgentsWorksheetResponse response = (AgentsWorksheetResponse) JSONUtility.convertStringToObject(contentStackResponse);
        return response;*/
    }

    private void persistProcessedCase360Response(String policyNumber, List<Case360DocumentVO> case360Documents) {
        WorkSheetRequirementDocuments workSheetRequirementDocuments = new WorkSheetRequirementDocuments();
        workSheetRequirementDocuments.setPolicyNumber(policyNumber);
        workSheetRequirementDocuments.setProcessedResponse(case360Documents);
        workSheetRequirementDocuments.setCreateDate(Calendar.getInstance().getTime());
        workSheetRequirementDocumentsRepository.save(workSheetRequirementDocuments);
    }

    private void persistPolicyToProductCategory(PolicyVO pendingPolicy) {
        PolicyToProductCategory policyToProductCategory = new PolicyToProductCategory();
        policyToProductCategory.setPolicyNumber(pendingPolicy.getPolicyNumber());
        policyToProductCategory.setFullProductCategory(pendingPolicy.getFullProductCode());
        policyToProductCategory.setProductCategory(pendingPolicy.getProductCode());
        policyToProductCategory.setCreatedDate(LocalDateTime.now());
        policyToProductCategory.setCreatedBy(CREATED_BY_USER);
        policyToProductCategory.setUpdatedDate(LocalDateTime.now());
        policyToProductCategory.setUpdatedBy(CREATED_BY_USER);
        mongoDBCacheHandler.insertPolicyToProductCategory(policyToProductCategory);
    }
}