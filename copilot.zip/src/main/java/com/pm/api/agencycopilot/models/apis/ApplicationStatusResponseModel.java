package com.pm.api.agencycopilot.models.apis;

import lombok.Data;

import java.util.List;

@Data
public class ApplicationStatusResponseModel {

    private List<ApplicationStatusResponse> results;

}
