package com.pm.api.agencycopilot.utility;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class MessagingProperties {

    @Value("${agency.copilot.communication.preferenceType.primary}")
    public String primaryCommunicationPreferenceType;

    @Value("${agency.copilot.communication.preferenceType.secondary}")
    public String secondaryCommunicationPreferenceType;

    @Value("${agency.copilot.messaging.username}")
    private String messagingAPIUserName;

    @Value("${agency.copilot.messaging.password}")
    private String messagingAPIPassword;

    @Value("${agency.copilot.messaging.url}")
    private String messagingAPIURL;
    @Value("${agency.copilot.communication.client-header}")
    private String clientHeader;
    @Value("${agency.copilot.communication.end-user-id}")
    private String endUserId;
    @Value("${agency.copilot.communication.context-id}")
    private String contextId;
    @Value("${agency.copilot.communication.ext-ref-id}")
    private String extRefId;
}
