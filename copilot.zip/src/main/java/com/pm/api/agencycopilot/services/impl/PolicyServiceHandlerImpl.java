package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerRoleByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Policy;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.services.PolicyServiceHandler;
import com.pm.api.agencycopilot.transformer.PolicyDetailTransformer;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class PolicyServiceHandlerImpl implements PolicyServiceHandler {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RestHelperServiceImpl restHelperService;

    @Autowired
    PolicyDetailTransformer policyDetailTransformer;


    @Value("${agency.copilot.pmapi.service.username}")
    private String pmapiAuthUserName;

    @Value("${agency.copilot.pmapi.service.password}")
    private String pmapiAuthPassword;

    @Value("${agency.copilot.pmapi.service.client.header}")
    private String pmapiClientHeader;

    @Value("${agency.copilot.pmapi.service.end.userid}")
    private String pmapiEndUserId;

    @Value("${agency.copilot.pmapi.policy.v2.endpoint}")
    private String pmapiPolicyEndpoint;

    @Value("${agency.copilot.pmapi.policy.v2.roles.endpoint}")
    private String rolesAPIEndPoint;

    @Value("${agency.copilot.pmapi.policy.v2.agent.roles.endpoint}")
    private String agentRolAPIEndPoint;

    @Value("${agency.copilot.pmapi.policy.v2.dependents.endpoint}")
    private String dependentsByPolicyAPIEndpoint;

    @Autowired
    private MaskedValueLogger maskedValueLogger;

    public PolicyV2Response getPolicyDataFromPMAPI(String policyNumber) throws Exception {
        log.info("Entering getPolicyDataFromPMAPI at {}", LocalDateTime.now());
        //List<PMAPIPolicy> pmapiPolicies = new ArrayList();
        List<PolicyV2Response> pmapiPolicies = new ArrayList();
        /*List<Future> futures = new ArrayList();
        ExecutorService executorService = Executors.newFixedThreadPool(10);*/
        PolicyV2Response policyV2Response = invokePMAPIRestCall(policyNumber);
        log.info("Exiting getPolicyDataFromPMAPI at {}", LocalDateTime.now());
        return policyV2Response;

        /*for(String policyNumber : policyNumbers) {
            System.out.println("Printing 1: " + policyNumber);
            futures.add(executorService.submit(() -> invokePMAPIRestCall(policyNumber)));
        }

        System.out.println("Length: " + futures.size());
        for(Future future : futures) {
            System.out.println("Printing 2");
            pmapiPolicies.add((ApplicationStatusPolicyResponse) future.get());
            //pmapiPolicies.add(pmapiPolicy);
        }

        return pmapiPolicies;*/
    }

    public PolicyV2Response getPolicyDataFromPMAPI(String policyNumber, List<String> params) throws Exception {
        return invokePMAPIRestCall(policyNumber, params);
    }

    @Override
    public PolicyV2Response getPolicyDetails(String policyNumber) throws Exception {
        return getPolicyDataFromPMAPI(policyNumber);
    }

    @Override
    public List<PolicyDiscounts> getPolicyDiscounts(String policyNumber) throws Exception {
        log.info("Entering getPolicyDiscounts at {}", LocalDateTime.now());
        PolicyV2Response discountsResponse = invokePMAPIRestCall(policyNumber, Arrays.asList("discounts"));
        if (discountsResponse == null) {
            log.info("Exiting getPolicyDiscounts at {}", LocalDateTime.now());
            return null;
        }
        Policy policy = discountsResponse.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);
        if (policy != null && policy.getDiscounts() != null) {
            log.info("Exiting getPolicyDiscounts at {}", LocalDateTime.now());
            return policy.getDiscounts();
        } else {
            log.info("Exiting getPolicyDiscounts at {}", LocalDateTime.now());
            return null;
        }

    }

    @Override
    public List<PolicyRateChange> getPolicyRateChanges(String policyNumber) throws Exception {
        log.info("Entering getPolicyRateChanges at {}", LocalDateTime.now());
        PolicyV2Response policyRateChangeDetails = invokePMAPIRestCall(policyNumber, Arrays.asList("rateChanges"));
        if (policyRateChangeDetails == null) {
            log.info("Exiting getPolicyRateChanges at {}", LocalDateTime.now());
            return null;
        }
        Policy policy = policyRateChangeDetails.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);
        if (policy != null && policy.getRateChanges() != null) {
            log.info("Exiting getPolicyRateChanges at {}", LocalDateTime.now());
            return policy.getRateChanges();
        } else {
            log.info("Exiting getPolicyRateChanges at {}", LocalDateTime.now());
            return null;
        }
    }

    @Override
    public List<CoverageDetailsVO> getPolicyCoverageDetails(String policyNumber) throws Exception {
        log.info("Entering getPolicyCoverageDetails at {}", LocalDateTime.now());
        PolicyV2Response policyCoverageDetailsResponse = getPolicyDataFromPMAPI(policyNumber, Arrays.asList("discounts", "offers", "rateChanges", "beneficiaryDetails"));
        if (policyCoverageDetailsResponse == null) {
            log.info("Exiting getPolicyCoverageDetails at {}", LocalDateTime.now());
            return null;
        }
        log.info("Exiting getPolicyCoverageDetails at {}", LocalDateTime.now());
        return policyDetailTransformer.getCoverageDetailFromRiderDetails(
                policyCoverageDetailsResponse,
                policyNumber
        );
    }

    @Override
    public PolicyInfoV2Response<Role> getRolesInfo(String policyNumber) throws Exception {
        log.info("Entering getRolesInfo at {}", LocalDateTime.now());
        log.info("Roles API for policyNumber {}", policyNumber);
        LocalDateTime start = LocalDateTime.now();
        PolicyInfoV2Response<Role> policyInfoV2Response = getPolicyRoleInfoFromPmapi(policyNumber);
        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the getRolesInfo is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getRolesInfo at {}", LocalDateTime.now());
        return policyInfoV2Response;

    }

    @Override
    public PolicyInfoV2Response<AgentRole> getAgentRolesInfo(String policyNumber) throws Exception {
        log.info("Entering getAgentRolesInfo at {}", LocalDateTime.now());
        log.info("Agent Roles API for policyNumber {}", policyNumber);
        LocalDateTime start = LocalDateTime.now();
        PolicyInfoV2Response<AgentRole> policyInfoV2Response = getPolicyAgentRoleInfoFromPmapi(policyNumber);
        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the getAgentRolesInfo is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getAgentRolesInfo at {}", LocalDateTime.now());
        return policyInfoV2Response;
    }

    @Override
    public DependentsV2Reponse getDependentDetails(String policyNumber) throws Exception {
        log.info("Entering getDependentDetails at {}", LocalDateTime.now());
        log.info("Dependent Details API for policyNumber {}", policyNumber);
        LocalDateTime start = LocalDateTime.now();
        DependentsV2Reponse dependentsV2Reponse = getPolicyDependentDetails(policyNumber);
        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the getDependentDetails is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getDependentDetails at {}", LocalDateTime.now());
        return dependentsV2Reponse;
    }

    private DependentsV2Reponse getPolicyDependentDetails(String policyNumber) {
        log.info("Entering getPolicyDependentDetails at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);
        String uri = dependentsByPolicyAPIEndpoint.replace("{policyNumber}", policyNumber);
        ResponseEntity<DependentsV2Reponse> response = restHelperService.invoke(uri,
                HttpMethod.GET, request, DependentsV2Reponse.class);
        maskedValueLogger.info(String.format("Dependent API response %s", response.toString()), log);
        log.info("Exiting getPolicyDependentDetails at {}", LocalDateTime.now());
        return response.getBody();
    }

    private PolicyInfoV2Response<Role> getPolicyRoleInfoFromPmapi(String policyNumber) {
        log.info("Entering getPolicyRoleInfoFromPmapi at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);
        String uri = rolesAPIEndPoint.replace("{policyNumber}", policyNumber);
        ResponseEntity<PolicyInfoV2Response> response = restHelperService.invoke(uri,
                HttpMethod.GET, request, PolicyInfoV2Response.class);
        maskedValueLogger.info(String.format("Roles API response %s", response.toString()), log);
        log.info("Exiting getPolicyRoleInfoFromPmapi at {}", LocalDateTime.now());
        return response.getBody();
    }

    private PolicyInfoV2Response<AgentRole> getPolicyAgentRoleInfoFromPmapi(String policyNumber) {
        log.info("Entering getPolicyAgentRoleInfoFromPmapi at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);
        String uri = agentRolAPIEndPoint.replace("{policyNumber}", policyNumber);
        ResponseEntity<PolicyInfoV2Response> response = restHelperService.invoke(uri,
                HttpMethod.GET, request, PolicyInfoV2Response.class);
        maskedValueLogger.info(String.format("Agent Roles API response %s", response.toString()), log);
        log.info("Exiting getPolicyAgentRoleInfoFromPmapi at {}", LocalDateTime.now());
        return response.getBody();
    }

    private PolicyV2Response invokePMAPIRestCall(String policyNumber) {
        log.info("Entering invokePMAPIRestCall at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);

        ResponseEntity<PolicyV2Response> response = restHelperService.invoke(pmapiPolicyEndpoint + policyNumber,
                HttpMethod.GET, request, PolicyV2Response.class);
        log.info("Exiting invokePMAPIRestCall at {}", LocalDateTime.now());
        return response.getBody();
    }

    private PolicyV2Response invokePMAPIRestCall(String policyNumber, List<String> params) {
        log.info("Entering invokePMAPIRestCall at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);

        StringBuilder pmapiPolicyV2URL = new StringBuilder(pmapiPolicyEndpoint + policyNumber);
        if (params.size() > 0) {
            pmapiPolicyV2URL.append("?include=" + String.join(",", params));
        }
        ResponseEntity<PolicyV2Response> response = restHelperService.invoke(pmapiPolicyV2URL.toString(),
                HttpMethod.GET, request, PolicyV2Response.class);
        log.info("Exiting invokePMAPIRestCall at {}", LocalDateTime.now());
        return response.getBody();
    }

    public FindCustomerRoleByPolicyResponse getCustomerRolesFromPMAPI(String policyNumber) {
        log.info("Entering getCustomerRolesFromPMAPI at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(pmapiAuthUserName, pmapiAuthPassword));

        HttpEntity request = new HttpEntity(headers);

        ResponseEntity<FindCustomerRoleByPolicyResponse> response = restTemplate.exchange(pmapiPolicyEndpoint + policyNumber + "/roles",
                HttpMethod.GET, request, FindCustomerRoleByPolicyResponse.class);
        log.info("Exiting getCustomerRolesFromPMAPI at {}", LocalDateTime.now());
        return response.getBody();
    }

    @Override
    public List<BeneficiaryDetails> getBeneficiaryDetails(String policyNumber) throws Exception {
        log.info("Entering getBeneficiaryDetails at {}", LocalDateTime.now());
        PolicyV2Response policyDetails = invokePMAPIRestCall(policyNumber);
        if (policyDetails == null) {
            log.info("Exiting getBeneficiaryDetails at {}", LocalDateTime.now());
            return null;
        }
        Policy policy = policyDetails.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);
        if (policy != null && !CollectionUtils.isEmpty(policy.getBeneficiaryDetails())) {
            log.info("Exiting  at {}", LocalDateTime.now());
            return policy.getBeneficiaryDetails();
        } else {
            log.info("Exiting getBeneficiaryDetails at {}", LocalDateTime.now());
            return null;
        }
    }

    @Override
    public List<AdditionalCoverage> getAdditionalCoverages(String policyNumber) throws Exception {
        try {
            log.info("Entering getAdditionalCoverages at {}", LocalDateTime.now());
            PolicyV2Response policyDetails = invokePMAPIRestCall(policyNumber);
            Policy policy = policyDetails.getPolicies().stream()
                    .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                    .findFirst()
                    .orElse(null);
            if (policy != null && policy.getAdditionalCoverages() != null) {
                log.info("Exiting getAdditionalCoverages at {}", LocalDateTime.now());
                return policy.getAdditionalCoverages();
            } else {
                log.info("Exiting getAdditionalCoverages at {}", LocalDateTime.now());
                return null;
            }
        } catch (Exception e) {
            log.info("Exiting getAdditionalCoverages at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(e, HttpStatus.INTERNAL_SERVER_ERROR, "");
        }
    }
    /*@NotNull
    private String getBasicAuthToken() {
        String auth = pmapiAuthUserName + ":" + pmapiAuthPassword;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }*/

}
