package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;

@Data
public class SearchParams {
    @JsonProperty("firstName")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String firstName;

    @JsonProperty("lastName")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String lastName;

    @JsonProperty("state")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String state;

    @JsonProperty("zipCode")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String zipCode;

    @JsonProperty("policy")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String policy;

    @JsonProperty("dateOfBirth")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "mm/dd/yyyy")
    private Date dateOfBirth;
}
