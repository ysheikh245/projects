package com.pm.api.agencycopilot.utility;

public interface AgencyCoPilotConstants {

    String SPACE = " ";
    String BLANK = "";
    String DASH = "-";
    String EQUALS = "=";
    String COMMA = ",";
    String PENDING = "Pending";
    String NOT_FOUND = "Not Found";
    String ISSUED = "Issued";
    String ACTIVE = "Active";
    String FILTERED = "ToFilter";
    String OWNER = "Owner"; // Roles
    String SUCCESS = "Success";
    String FAILED = "FAILED";

    // Interaction Logs
    String NOTIFY = "NOTIFY";
    String NONE = "NONE";
    String AGENT = "AGENT";
    String OTHER = "OTHER";
    String EDELIVERY = "EDELIVERY";
    String TRUE = "true";

    public static final String AGENCY_COPILOT = "agency-copilot";
    public static int FILTER_MAX_NO_OF_DAYS = 60;
    public static int FILTER_DEFAULT_NO_OF_DAYS = 7;
    String PENDING_STARTS_WITH_P = "P";
    String CREATE_DATE_INDEX_NM = "createDateIndex";
    String INDEX_ON_FIELD_NM = "createDate";

    // Case360 constants
    String UW_REQUIRE_TYPE_LIST = "UW_REQUIRE_TYPE_LIST";
    String UW_REQUIRE_DATE_RECEIVED = "UW_REQUIRE_DATE_RECEIEVED";
    String UW_REQUIRE_DATE_REQ = "UW_REQUIRE_DATE_REQ";
    String UW_REQUIRE_DESC_LIST = "UW_REQUIRE_DESC_LIST";
    String UW_REQUIRE_COMMENTS = "UW_REQUIRE_COMMENTS";
    int DATATYPE_APPLICABLE_FOR_AGENTS = 4;
    String INFORMATIONAL = "I";
    String NEEDS_UPLOAD = "N";

    // Content Stack
    String CURLY_BRACE_START = "{";
    String CURLY_BRACE_END = "}";

    // Product Category
    int PRODUCT_CATEGORY_CODE_CHARACTERS = 4;

    // Database Constants
    String CREATED_BY_USER = "AGENCY_SYSTEM";

    String INSPRO = "Inspro";
    String COGEN = "Cogen";

    String MESSAGING_REASON_NUMBER = "1";

    public static int NPN_POLICY_CACHE_DURATION = 60;
    String POLICY_DATA = "POLICY_DATA";
    String DEPENDENT_DETAILS = "DEPENDENT_DETAILS";
    String ROLE_INFO = "ROLE_INFO";
    String POLICY_DOCUMENTS = "POLICY_DOCUMENTS";
    String AGENT_ROLES_INFO = "AGENT_ROLES_INFO";
    String POLICY_ALERTS = "POLICY_ALERTS";
}
