package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PHBasicPetInformationItem{

	@JsonProperty("CPetIndicator")
	private String cPetIndicator;

	@JsonProperty("CAgeNew")
	private String cAgeNew;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CPhPetDetId")
	private String cPhPetDetId;

	@JsonProperty("CPetNumber")
	private String cPetNumber;

	@JsonProperty("CGender")
	private String cGender;

	@JsonProperty("CSpecies")
	private String cSpecies;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CTotalAnnualDiscounts")
	private String cTotalAnnualDiscounts;

	@JsonProperty("CExpectedLife")
	private String cExpectedLife;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CPetType")
	private String cPetType;

	@JsonProperty("CPetNumberOverride")
	private String cPetNumberOverride;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CName")
	private String cName;

	@JsonProperty("CPetTransEffDate")
	private String cPetTransEffDate;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("CBreedGroup")
	private String cBreedGroup;

	@JsonProperty("CBreed")
	private String cBreed;

	public String getCPetIndicator(){
		return cPetIndicator;
	}

	public String getCAgeNew(){
		return cAgeNew;
	}

	public String getGid(){
		return gid;
	}

	public String getCPhPetDetId(){
		return cPhPetDetId;
	}

	public String getCPetNumber(){
		return cPetNumber;
	}

	public String getCGender(){
		return cGender;
	}

	public String getCSpecies(){
		return cSpecies;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCTotalAnnualDiscounts(){
		return cTotalAnnualDiscounts;
	}

	public String getCExpectedLife(){
		return cExpectedLife;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getCPetType(){
		return cPetType;
	}

	public String getCPetNumberOverride(){
		return cPetNumberOverride;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCName(){
		return cName;
	}

	public String getCPetTransEffDate(){
		return cPetTransEffDate;
	}

	public String getId(){
		return id;
	}

	public String getCBreedGroup(){
		return cBreedGroup;
	}

	public String getCBreed(){
		return cBreed;
	}
}