package com.pm.api.agencycopilot.models.mongodb;

import java.util.Date;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "policyCachingStatus")
@Data
public class PolicyCachingStatusRecord {
    @Id
    private String npnId;
    private PolicySearchStatus defaultPolicySearchProcess;
    private PolicySearchStatus backgroundPolicySearchProcess;
    private Long totalPoliciesFetchedCount;
    private Date createDate;
    private String errorMessage;
}
