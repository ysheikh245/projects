package com.pm.api.agencycopilot.models.external.agents;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class Response {

    @JsonProperty("shortFirstName")
    private String shortFirstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("primaryPhoneNumbers")
    private List<PrimaryPhoneNumbersItem> primaryPhoneNumbers;

    @JsonProperty("secondaryAddress")
    private List<SecondaryAddressItem> secondaryAddress;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("endDate")
    private String endDate;

    @JsonProperty("primaryWorkAddress")
    private PrimaryWorkAddress primaryWorkAddress;

    @JsonProperty("dateOfBirth")
    private String dateOfBirth;

    @JsonProperty("npn")
    private String npn;

    @JsonProperty("titleCode")
    private String titleCode;

    @JsonProperty("secondaryPhoneNumbers")
    private List<SecondaryPhoneNumbersItem> secondaryPhoneNumbers;

    @JsonProperty("middleNames")
    private String middleNames;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("statusDescription")
    private String statusDescription;

    @JsonProperty("licenses")
    private List<Object> licenses;

    @JsonProperty("emailAddresses")
    private List<EmailAddressesItem> emailAddresses;

    @JsonProperty("titleDescription")
    private String titleDescription;

    @JsonProperty("faxNumber")
    private FaxNumber faxNumber;

    @JsonProperty("suffixTitles")
    private String suffixTitles;

    @JsonProperty("maritalStatus")
    private String maritalStatus;

    @JsonProperty("startDate")
    private String startDate;

    @JsonProperty("statusCode")
    private String statusCode;

}
