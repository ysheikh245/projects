package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContactItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("InsuredContact")
	private String insuredContact;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("MasterRecordGid")
	private String masterRecordGid;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("Phone1")
	private String phone1;

	@JsonProperty("ProducerContact")
	private String producerContact;

	public String getEntityType(){
		return entityType;
	}

	public String getInsuredContact(){
		return insuredContact;
	}

	public String getGid(){
		return gid;
	}

	public String getMasterRecordGid(){
		return masterRecordGid;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getPhone1(){
		return phone1;
	}

	public String getProducerContact(){
		return producerContact;
	}
}