package com.pm.api.agencycopilot.test;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.EntriesItem;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;
import com.pm.api.agencycopilot.utility.JSONUtility;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AgentWorksheetResponse {

    public static void main(String[] args) throws Exception {
       /* String fileName = "response-empty.json";
        Path path = Paths.get("C:\\Yusuf\\Code\\NextGenQuote\\agency-copilot\\src\\main\\java\\com\\pm\\api\\agencycopilot\\test\\" + fileName);
        String content = new String(Files.readAllBytes(path));
        //Response response = (Response) JSONUtility.convertStringToObject(content);
        //Map response = (LinkedHashMap) JSONUtility.convertStringToObject(content);
        //Response response = new ObjectMapper().readValue(content, Response.class);
        Response response = JSONUtility.convertStringToObject(content, Response.class);
        System.out.println(response);*/

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MILLISECOND, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.HOUR_OF_DAY, 23);

        long seconds = (calendar.getTime().getTime() - (new Date().getTime())) / 1000;
        System.out.println("Seconds : " + seconds);

        LocalTime midnight = LocalTime.of(23, 59, 59);
        Duration durationSeconds = Duration.between(LocalTime.now(), midnight);
        System.out.println("Duration Midnight " + midnight);
        //System.out.println("Duration Now " + LocalTime.now());
        System.out.println(durationSeconds.getSeconds());

    }

}
