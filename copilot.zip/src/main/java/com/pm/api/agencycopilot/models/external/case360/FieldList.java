package com.pm.api.agencycopilot.models.external.case360;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldList {

	/*@JsonProperty("bigDecimalValue")
	private BigDecimal bigDecimalValue;*/

	@JsonProperty("fieldName")
	private String fieldName;

	@JsonProperty("fieldMetaData")
	private FieldMetaData fieldMetaData;

	@JsonProperty("intValue")
	private int intValue;

	@JsonProperty("dataType")
	private int dataType;

	@JsonProperty("modified")
	private boolean modified;

	@JsonProperty("booleanValue")
	private boolean booleanValue;

	@JsonProperty("readOnly")
	private boolean readOnly;

	@JsonProperty("nullValue")
	private boolean nullValue;

	@JsonProperty("stringValue")
	private String stringValue;

	@JsonProperty("calendarValue")
	private String calendarValue;

}