package com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Response{

	@JsonProperty("entries")
	private List<EntriesItem> entries;

	public List<EntriesItem> getEntries(){
		return entries;
	}
}