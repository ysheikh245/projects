package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Cdlevel2{

	@JsonProperty("level2Cd")
	private String level2Cd;

}