package com.pm.api.agencycopilot.models.external.nigo;

import lombok.Data;

@Data
public class NIGODocument {

    private String code;
    private String shortName;
    private String longName;
    private String openDate;
    private String systemControlled;
    private String holdUpIssue;
    private String comments;

}
