package com.pm.api.agencycopilot.models.enums;

public enum TableEnum {

    CONTENT_STACK_PRODUCT_CATEGORY("contentStackProductCategory"),
    POLICY("policy"),
    POLICY_CACHING_STATUS("policyCachingStatus"),
    //POLICY_CATEGORIES_RECORD("policyCategoriesRecord"),
    POLICY_TO_PRODUCT_CATEGORY("policyToProductCategory"),
    //PRODUCT_TYPE_CATEGORIES_RECORD("productTypeCategoriesRecord"),
    WORKSHEET_REQUIREMENT_DOCUMENTS("workSheetRequirementDocuments"),
    NPN_POLICY_LIST_CACHE("npnPolicyListCache");

    private String collectionName;

    TableEnum(String collectionName) {
        this.collectionName = collectionName;
    }

    public String getCollectionName() {
        return this.collectionName;
    }
}
