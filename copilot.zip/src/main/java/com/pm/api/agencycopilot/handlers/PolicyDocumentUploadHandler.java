package com.pm.api.agencycopilot.handlers;

import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.ActionMetadata;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.CaseMetadata;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.EntriesItem;
import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;
import com.pm.api.agencycopilot.models.external.documents.upload.DocumentUploadRequest;
import com.pm.api.agencycopilot.models.internal.ActionMetadataVO;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.models.mongodb.PolicyToProductCategory;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.services.ContentStackServiceHandler;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import com.pm.api.agencycopilot.utility.JSONUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;

@Component
@Slf4j
public class PolicyDocumentUploadHandler implements  IDocumentUploadHandler {

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private ContentStackServiceHandler contentStackServiceHandler;

    @Override
    public ActionMetadataVO formActionMetadata(DocumentsUploadAPIRequest documentsUploadAPIRequest) {
        log.info("PolicyDocumentUploadHandler.formActionMetadata() ::: Start. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
        ProductTypeCategoriesRecord productCategory = getProductCategory(documentsUploadAPIRequest.getPolicyNumber());//productCategoryForPolicy.get().getProductCategory();
        Response contentStackResponse = null;
        if(productCategory != null) {
            ContentStackProductCategory contentStackProductCategory = mongoDBCacheHandler.findByProductCategory(productCategory.getCategory());
            if (contentStackProductCategory != null) {
                String cachedContentStackResponse = contentStackProductCategory.getContentStackResponse();
                contentStackResponse = JSONUtility.convertStringToObject(cachedContentStackResponse, Response.class);
            } else {
                contentStackResponse = contentStackServiceHandler.getAgentWorksheetOptionsResponse(productCategory.getProductCode());
            }
            if (contentStackResponse != null) {
                Optional<EntriesItem> item = contentStackResponse.getEntries().stream().
                        filter(entry -> equalsIgnoreCase(entry.getDescription(), documentsUploadAPIRequest.getDocumentDescription()))
                        .findFirst();
                if (item.isPresent()) {
                    ActionMetadata actionMetadata = item.get().getActionMetadata();
                    if (actionMetadata != null) {
                        ActionMetadataVO actionMetadataVO = formActionMetadataVO(actionMetadata, documentsUploadAPIRequest.getPolicyNumber());
                        log.info("PolicyDocumentUploadHandler.formActionMetadata() ::: Completed. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
                        return actionMetadataVO;
                    }
                } else {
                    log.info("Value missing or not present in Content-Stack. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
                    //log.info("Need to get confirmation from the business for this use-case");
                    //TODO: ask business what to do if we do not find the action_metadata for the DocumentsUpload PMAPI api
                }
            }
        }
        log.info("PolicyDocumentUploadHandler.formActionMetadata() ::: Failed. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
        return null;
    }

    private ActionMetadataVO formActionMetadataVO(ActionMetadata actionMetadata, String policyNumber) {
        ActionMetadataVO actionMetadataVO = new ActionMetadataVO();
        CaseMetadata caseMetadata = actionMetadata.getCaseMetadata();
        if(caseMetadata != null) {
            actionMetadataVO.setSource(caseMetadata.getSource());
            actionMetadataVO.setDocType(caseMetadata.getDocType());
            actionMetadataVO.setDocIndexCode(caseMetadata.getDocumentIndexCode());
            actionMetadataVO.setPolicyNo(policyNumber);
            actionMetadataVO.setDocumentDesc(caseMetadata.getDocumentDesc());
            actionMetadataVO.setCorrType(caseMetadata.getCorrType());
            actionMetadataVO.setDoc_Type(caseMetadata.getDoc_Type());
            return actionMetadataVO;
        }
        return null;
    }

    private ProductTypeCategoriesRecord getProductCategory(String policyNumber) {
        ProductTypeCategoriesRecord productTypeCategory = null;
        Optional<PolicyToProductCategory> productCategoryForPolicy = mongoDBCacheHandler.findProductCategoryForPolicy(policyNumber);
        if(productCategoryForPolicy.isPresent()) {
            productTypeCategory = mongoDBCacheHandler.findProductTypeCategory(productCategoryForPolicy.get().getProductCategory(), true);
        }
        return productTypeCategory;
    }
}
