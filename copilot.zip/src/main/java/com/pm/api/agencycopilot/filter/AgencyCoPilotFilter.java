package com.pm.api.agencycopilot.filter;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.UUID;

@Component
@Slf4j
public class AgencyCoPilotFilter extends OncePerRequestFilter {

    @Value("${agency.copilot.api.access.token}")
    private String apiToken;

    private final String API = "api";
    private final String WEB = "web";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        log.debug("Entering doFilterInternal at {}", LocalDateTime.now());
        initializeMDCContext();
        String path = request.getServletPath();
        if (StringUtils.contains(path, API) || StringUtils.contains(path, WEB)) {
            if(!StringUtils.contains(path, "data")) {
                addNpnIdFromJwtToken(request);
                proceed(request, response, filterChain);
            } else {
                // do API key validation bare minimum
                String apiKey = request.getHeader("apikey");
                if(StringUtils.equals(apiToken, apiKey)) {
                    proceed(request, response, filterChain);
                } else {
                    throw new RuntimeException("api key is needed to perform the operation");
                    //throw new AgencyCoPilot4xxException("", HttpStatus.BAD_REQUEST, request.getRequestURI()); // not working
                }
            }
        } else {
            //log.debug("AgencyCoPilotFilter.doFilterInternal() : Not Performing API key validation");
            proceed(request, response, filterChain);
        }
        log.debug("Exiting doFilterInternal at {}", LocalDateTime.now());
    }

    private void proceed(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        try {
            filterChain.doFilter(request, response);
        } finally {
            clearMDCContext();
        }
    }

    private void clearMDCContext() {
        log.debug("clearing MDC context...");
        MDC.clear();
    }

    private void initializeMDCContext() {
        UUID traceId = UUID.randomUUID();
        MDC.put("TRACE_ID", traceId.toString());
    }

    private void addNpnIdFromJwtToken(HttpServletRequest request) {
        log.info("Entering addNpnIdFromJwtToken at {}", LocalDateTime.now());
        try {
            Object authenticationPrincipal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (authenticationPrincipal instanceof Jwt) {
                Jwt jwtPrincipal = (Jwt) authenticationPrincipal;
                String npnFromAuthToken = String.valueOf(jwtPrincipal.getClaims().get("pmicnpn"));
                log.info("NPN Retrieved from JWT Token is {}", npnFromAuthToken);
                request.setAttribute("npnId", npnFromAuthToken);
            } else {
                throw new Exception("Unable to read the npn from Jwt Token since the token passed is not and instance of JWT.");
            }
        } catch (Exception e) {
            log.error("AgencyCoPilotFilter.addNpnIdFromJwtToken ::: Failed");
            String errorMessage = String.format("Unable to extract NPN from keycloak auth token. Error message is %s", e.getMessage());
            log.error(errorMessage);
            throw new AgencyCoPilot4xxException(e, HttpStatus.UNAUTHORIZED, "");
        }
        log.info("Exiting addNpnIdFromJwtToken at {}", LocalDateTime.now());
    }
}
