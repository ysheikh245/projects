package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PolicyDiscounts {
    @JsonProperty("name")
    private String name;
    @JsonProperty("amount")
    private double amount;
    @JsonProperty("effectiveDate")
    private String effectiveDate;
    @JsonProperty("status")
    private String status;
}
