package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.AgentCompensations;

public interface AgentCompensationService {

    AgentCompensations fetchAvailableCompensations(String npn, String beginDate, String endDate);
}
