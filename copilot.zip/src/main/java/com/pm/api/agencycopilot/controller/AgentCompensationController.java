package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.AgentCompensations;
import com.pm.api.agencycopilot.services.AgentCompensationService;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class AgentCompensationController implements ApplicationController {

    @Autowired
    AgentCompensationService agentCompensationService;

    @GetMapping(value = "/compensations/list/{beginDate}/{endDate}", produces = MediaType.APPLICATION_JSON_VALUE)
    public AgentCompensations fetchAvailableAgentCompensations(@Valid @DateTimeFormat(pattern = "yyyy-MM-dd") @PathVariable("beginDate") String beginDate,
                                                               @Valid @DateTimeFormat(pattern = "yyyy-MM-dd") @PathVariable("endDate") String endDate,
                                                               @RequestAttribute(name = "npnId") String npnId) {
        AgentCompensations agentCompensations;
        log.info("AgentCompensationController.fetchAvailableAgentCompensations. Started");

        try {
            agentCompensations = agentCompensationService.fetchAvailableCompensations(npnId, beginDate, endDate);
        } catch (Exception e) {
            log.error("AgentCompensationController.fetchAvailableAgentCompensations(). Failed. Exception={}", ExceptionUtils.getStackTrace(e));
            throw new AgencyCoPilotException(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("AgentCompensationController.fetchAvailableAgentCompensations. Completed");
        return agentCompensations;
    }
}
