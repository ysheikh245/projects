package com.pm.api.agencycopilot.utility;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class CustomerPMAPIProperties {

    @Value("${agency.copilot.customers.api.username}")
    private String customersAPIUsername;

    @Value("${agency.copilot.customers.api.password}")
    private String customersAPIPassword;

    @Value("${agency.copilot.customers.api.interaction.logs.url}")
    private String interactionLogsAPIEndpoint;

    @Value("${agency.copilot.customers.api.client.header}")
    private String customersAPIClientHeader;

    @Value("${agency.copilot.customers.api.end.userid}")
    private String customersAPIClientUserId;

    @Value("${agency.copilot.customers.api.system.source.code:COPILOT}")
    private String systemSourceCode;

    @Value("${agency.copilot.customers.api.caller.relationship.code:OWNINS}")
    private String callerRelationshipCode;

    @Value("${agency.copilot.customers.api.action.code:NOACTN}")
    private String actionCode;

    @Value("${agency.copilot.customers.api.interaction.logs.reason.code:2200}")
    private String reasonCodeForInteractionLogs;

    @Value("${agency.copilot.customers.api.interaction.logs.reason.subtype.code:22050}")
    private String reaasonSubTypeCodeForInteractionLogs;
}
