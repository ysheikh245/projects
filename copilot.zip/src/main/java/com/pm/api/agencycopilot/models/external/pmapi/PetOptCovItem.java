package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PetOptCovItem{

	@JsonProperty("CBehavProbLim")
	private String cBehavProbLim;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("PetAllOptCov")
	private List<PetAllOptCovItem> petAllOptCov;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("CIsOverrideOptCov")
	private String cIsOverrideOptCov;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("optCovRating")
	private List<OptCovRatingItem> optCovRating;

	@JsonProperty("COverrideOptCov")
	private String cOverrideOptCov;

	@JsonProperty("CPiCovOptionalCov")
	private String cPiCovOptionalCov;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	public String getCBehavProbLim(){
		return cBehavProbLim;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public List<PetAllOptCovItem> getPetAllOptCov(){
		return petAllOptCov;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getCIsOverrideOptCov(){
		return cIsOverrideOptCov;
	}

	public String getRiskState(){
		return riskState;
	}

	public List<OptCovRatingItem> getOptCovRating(){
		return optCovRating;
	}

	public String getCOverrideOptCov(){
		return cOverrideOptCov;
	}

	public String getCPiCovOptionalCov(){
		return cPiCovOptionalCov;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}
}