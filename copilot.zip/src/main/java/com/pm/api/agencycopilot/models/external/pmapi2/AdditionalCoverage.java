package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AdditionalCoverage {

    @JsonProperty("policyNumber")
    public String policyNumber;

    @JsonProperty("companyCode")
    public String companyCode;

    @JsonProperty("recordNumber")
    public Integer recordNumber;

    @JsonProperty("personNumber")
    public Integer personNumber;

    @JsonProperty("baseRiderInd")
    public String baseRiderInd;

    @JsonProperty("statusCode")
    public String statusCode;

    @JsonProperty("coverageCode")
    public String coverageCode;

    @JsonProperty("effDate")
    public String effDate;

    @JsonProperty("termDate")
    public String termDate;

    @JsonProperty("benefitAmt")
    public Float benefitAmt;

    @JsonProperty("descrip")
    public String descrip;

    @JsonProperty("monthlyPremium")
    public Float monthlyPremium;

    @JsonProperty("quartPremium")
    public Float quartPremium;

    @JsonProperty("semiPremium")
    public Float semiPremium;

    @JsonProperty("recurringPremium")
    public Float recurringPremium;

    @JsonProperty("annualPremium")
    public Float annualPremium;

    @JsonProperty("firstName")
    public String firstName;

    @JsonProperty("middleName")
    public String middleName;

    @JsonProperty("lastName")
    public String lastName;

    @JsonProperty("paidToDate")
    public String paidToDate;

    @JsonProperty("statusLongDescription")
    public String statusLongDescription;
}
