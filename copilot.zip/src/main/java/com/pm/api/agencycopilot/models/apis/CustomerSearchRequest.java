package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pm.api.agencycopilot.models.external.customers.SearchParams;
import lombok.Data;

@Data
public class CustomerSearchRequest {
    @JsonProperty("type")
    private String type;

    @JsonProperty("searchParams")
    private SearchParams searchParams;
}
