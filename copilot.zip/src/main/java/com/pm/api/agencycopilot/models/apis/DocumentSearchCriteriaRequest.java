package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class DocumentSearchCriteriaRequest {
    private String searchType;
    private String responseFormat;
    private DocumentSearchCriteria searchCriteria;

    @JsonCreator
    public DocumentSearchCriteriaRequest(@JsonProperty("searchType") String searchType,
                                         @JsonProperty("responseFormat") String responseFormat,
                                         @JsonProperty("searchCriteria") DocumentSearchCriteria searchCriteria){
        this.searchType = searchType;
        this.responseFormat = responseFormat;
        this.searchCriteria = searchCriteria;

    }
}