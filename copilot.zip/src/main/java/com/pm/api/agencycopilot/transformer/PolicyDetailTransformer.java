package com.pm.api.agencycopilot.transformer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.external.customers.CustomerByPolicy;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.customers.PersonNameListItem;
import com.pm.api.agencycopilot.models.external.customers.PolicyListItem;
import com.pm.api.agencycopilot.models.external.customers.PolicyRoleListItem;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.Dependent;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Policy;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.external.sales.FindSalesCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.sales.SalesPolicyRoleList;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.AddressVO;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.utility.DateFormatterUtility;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class PolicyDetailTransformer {

    public PolicyVO tranfromPMAPIToPolicyDetail(PolicyV2Response policyDetails, String policyNumber) {
        if (policyDetails == null) {
            return new PolicyVO();
        }
        log.info("PMAPI Response of Policy Details {}",policyDetails.toString());
        PolicyVO policyDetail = new PolicyVO();
        Policy policy = policyDetails.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);
        log.info("Final policy Data: {}",policy.toString());
        if (policy != null) {
            policyDetail.setProductName(policy.getProductCode());
            policyDetail.setPolicyStatus(policy.getPolicyStatusLong());
            policyDetail.setPolicyType(policy.getPolicyType());
            policyDetail.setPolicyEffectiveDate(policy.getEffectiveDate());
            policyDetail.setIssueDate(policy.getIssueDate());
            policyDetail.setLastPaymentDate(policy.getLastPaymentDate());
            policyDetail.setPaidToDate(policy.getPaidToDate());
            policyDetail.setCurrentPremium(policy.getCurrentMode()!=null?getCurrentPremium(policy):null);
            policyDetail.setDisplayIssueDate(DateFormatterUtility.format(policy.getIssueDate(),DateFormatterUtility.FORMAT_MMddyyyy));
            log.info("policy Details: {}",policyDetail.toString());
        }
        return policyDetail;
    }

    public AdditionalDetailsCountVO getAdditionalDetailsCountVO(
            String policyNumber,
            DependentsV2Reponse dependentsV2Reponse,
            PolicyV2Response policyDetails,
            PolicyInfoV2Response<Role> roleInfoV2Response,
            PolicyInfoV2Response<AgentRole> agentRoleInfoV2Response,
            DocumentsV2Response<DocumentsResponse> policyDocuments,
            DocumentsV2Response<PolicyAlertResponse> policyAlerts) {
        AdditionalDetailsCountVO additionalDetailsCountVO = new AdditionalDetailsCountVO();

        if (dependentsV2Reponse != null && dependentsV2Reponse.getDependent() != null) {
            Dependent dependent = dependentsV2Reponse.getDependent().stream()
                    .filter(d -> d.getPolicyNumber().equalsIgnoreCase(policyNumber))
                    .findFirst().orElse(null);
            if (dependent != null && !dependent.getDependentsPerson().isEmpty()) {
                additionalDetailsCountVO.setDependentsCount(dependent.getDependentsPerson().size());
            }

        }

        Policy policy = policyDetails.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);

        if (policy != null) {
            if (policy.getRiderDetails() != null && !policy.getRiderDetails().isEmpty()) {
                additionalDetailsCountVO.setCoverageDetailsCount(policy.getRiderDetails().size());
            }
            if (policy.getRiderOffers() != null && !policy.getRiderOffers().isEmpty()) {
                additionalDetailsCountVO.setCoverageDetailsCount(additionalDetailsCountVO.getCoverageDetailsCount() + policy.getRiderOffers().size());
            }
            if (policy.getDiscounts() != null) {
                additionalDetailsCountVO.setDiscountsCount(policy.getDiscounts().size());
            }

            if (policy.getRateChanges() != null) {
                additionalDetailsCountVO.setRateChangesCount(policy.getRateChanges().size());
            }

            if (policy.getBeneficiaryDetails() != null && !policy.getBeneficiaryDetails().isEmpty()) {
                additionalDetailsCountVO.setBeneficiaryDetailsCount(policy.getBeneficiaryDetails().size());
            }

            if (policy.getAdditionalCoverages() != null && !policy.getAdditionalCoverages().isEmpty()) {
                additionalDetailsCountVO.setAdditionalLifeInsuranceRidersCount(policy.getAdditionalCoverages().size());
            }

        }

        if (roleInfoV2Response != null && !CollectionUtils.isEmpty(roleInfoV2Response.getResponse())) {
            List<Role> roles = roleInfoV2Response.getResponse();
            additionalDetailsCountVO.setRolesCount(roles.size());
        }

        if (agentRoleInfoV2Response != null && !CollectionUtils.isEmpty(agentRoleInfoV2Response.getResponse())) {
            List<AgentRole> agentRoles = agentRoleInfoV2Response.getResponse();
            additionalDetailsCountVO.setAgentsOfRecordCount(agentRoles.size());
        }

        if (policyDocuments != null && policyDocuments.getResponseData().getDocuments() != null && !policyDocuments.getResponseData().getDocuments().isEmpty()) {
            additionalDetailsCountVO.setViewCustomerDocumentsCount(policyDocuments.getResponseData().getDocuments().size());
        }

        if (policyAlerts != null) {
            int policyAlertsCount = 0;
            if (policyAlerts.getResponseData().getPolicyMessages() != null) {
                policyAlertsCount += policyAlerts.getResponseData().getPolicyMessages().size();
            }
            if (policyAlerts.getResponseData().getCustomerMessages() != null) {
                policyAlertsCount += policyAlerts.getResponseData().getCustomerMessages().size();
            }
            additionalDetailsCountVO.setPolicyAlertsCount(policyAlertsCount);
        }

        return additionalDetailsCountVO;
    }

    public List<CoverageDetailsVO> getCoverageDetailFromRiderDetails(PolicyV2Response policyDetails, String policyNumber) {
        List<CoverageDetailsVO> coverageDetails = new ArrayList<>();
        Policy policy = policyDetails.getPolicies().stream()
                .filter(p -> p.getPolicyNumber().equalsIgnoreCase(policyNumber))
                .findFirst()
                .orElse(null);

        if (policy != null && policy.getRiderDetails() != null) {
            coverageDetails = policy.getRiderDetails().stream()
                    .map(riderDetailsItem -> new CoverageDetailsVO(
                            riderDetailsItem.getStatusCode(),
                            riderDetailsItem.getRiderCode(),
                            riderDetailsItem.getRiderDescrip(),
                            "",
                            riderDetailsItem.getRiderBenefitAmt(),
                            riderDetailsItem.getRiderEffDate(),
                            riderDetailsItem.getRiderTermDate(),
                            riderDetailsItem.getRecurringPremium(),
                            riderDetailsItem.getFirstName(),
                            riderDetailsItem.getMiddleName(),
                            riderDetailsItem.getLastName()
                    ))
                    .collect(Collectors.toList());
        }

        if (policy != null && policy.getRiderOffers() != null) {
            List<CoverageDetailsVO> riderOfferCoverageDetails = policy.getRiderOffers().stream()
                    .map(riderOffersItem -> new CoverageDetailsVO(
                            "Rider Offer",
                            riderOffersItem.getOfferPlanCode(),
                            riderOffersItem.getFullDescription(),
                            riderOffersItem.getOfferDate(),
                            Double.parseDouble(riderOffersItem.getBenAmount()),
                            riderOffersItem.getRdrEffDt() != null ? riderOffersItem.getRdrEffDt().substring(0, 4) + "-" + riderOffersItem.getRdrEffDt().substring(4, 6) + "-" + riderOffersItem.getRdrEffDt().substring(6) : "",
                            "n/a",
                            Double.parseDouble(riderOffersItem.getPremium()),
                            "",
                            "",
                            ""

                    ))
                    .collect(Collectors.toList());

            if (riderOfferCoverageDetails.size() > 0) {
                coverageDetails.addAll(riderOfferCoverageDetails);
            }
        }
        if(CollectionUtils.isEmpty(coverageDetails)){
            return null;
        }
        return coverageDetails;
    }

    public List<CustomersVO> transformPMAPIToCustomersDetails(FindCustomerByPolicyResponse customerDetails, CustomerDetailsRequestType requestType, String policyNumber) {
        log.info("PMAPI response of customer details {}", customerDetails.toString());
        List<CustomersVO> customers = new ArrayList<>();
        customerDetails.getResponse().forEach((cd) -> {
            List<PolicyListItem> policies = new ArrayList<>();
            if (requestType.equals(CustomerDetailsRequestType.SEARCH_BY_POLICY)) {
                CustomersVO customerDetail = new CustomersVO();
                customerDetail.setGender(cd.getPerson().getGender());
                customerDetail.setPersonNameList(cd.getPerson().getPersonNameList());
                customerDetail.setPartyId(cd.getPartyId());
                cd.getExternalReferenceList().forEach((er) -> {
                    if (er.getPolicyList() != null && er.getPolicyList().size() != 0) {
                        List<PolicyListItem> matchedPolicies = er.getPolicyList().stream().filter((p) -> p.getPolicyNumber().equals(policyNumber)).collect(Collectors.toList());
                        policies.addAll(matchedPolicies);
                    }
                });
                customerDetail.setPolicyNumber(policyNumber);
                customerDetail.setRole(policies.get(0).getPolicyRoleList().stream().map(PolicyRoleListItem::getRole).collect(Collectors.joining(",")));
                customers.add(customerDetail);
            } else {
                List<String> policyNumbers = new ArrayList<>();
                cd.getExternalReferenceList().forEach((er) -> {
                    if (er.getPolicyList() != null && !er.getPolicyList().isEmpty()) {
                        er.getPolicyList().forEach((p) -> {
                            if (!policyNumbers.contains(p.getPolicyNumber())) {
                                CustomersVO customerDetail = new CustomersVO();
                                customerDetail.setGender(cd.getPerson().getGender());
                                customerDetail.setPersonNameList(cd.getPerson().getPersonNameList());
                                customerDetail.setPartyId(cd.getPartyId());
                                customerDetail.setPolicyNumber(p.getPolicyNumber());
                                policyNumbers.add(p.getPolicyNumber());
                                customerDetail.setRole(p.getPolicyRoleList().stream().map(PolicyRoleListItem::getRole).collect(Collectors.joining(",")));
                                customers.add(customerDetail);
                            }
                        });
                    }
                });
            }
        });
        return customers;
    }
    public List<CustomersVO> transformSalesPMAPIToCustomersDetails(FindSalesCustomerByPolicyResponse policyByCustomerDetailsResponse,CustomerDetailsRequestType requestType, String policyNumber){
    	log.info("PMAPI response of customer details for Sales{}", policyByCustomerDetailsResponse.toString());
        List<CustomersVO> customers = new ArrayList<>();
        policyByCustomerDetailsResponse.getResponse().stream().forEach(response->{
        	 List<PersonNameListItem> personNameList=new ArrayList<>();
        	 personNameList.add(new PersonNameListItem("",response.getFirstName(),response.getLastName(),""));
        	 if (requestType.equals(CustomerDetailsRequestType.SEARCH_BY_POLICY)) {
                 response.getPolicies().stream().forEach(policy->{
                 if(policy.getPolicyNumber().contains(policyNumber)) {
                	 CustomersVO customerDetail = new CustomersVO();
                     customerDetail.setGender(response.getGender());
                     customerDetail.setPersonNameList(personNameList);
                     customerDetail.setPartyId(response.getPartyId());
                	 customerDetail.setPolicyNumber(policyNumber);
                     customerDetail.setRole(policy.getPolicyRoleList().stream().map(SalesPolicyRoleList::getRole).collect(Collectors.joining(",")));
                     customers.add(customerDetail);
                	 }
                 });
        	 }
        	 else {
                 response.getPolicies().stream().forEach(policy->{
                	 CustomersVO customerDetail = new CustomersVO();
                     customerDetail.setGender(response.getGender());
                     customerDetail.setPersonNameList(personNameList);
                     customerDetail.setPartyId(response.getPartyId());
                     customerDetail.setPolicyNumber(policy.getPolicyNumber());
                     customerDetail.setRole(policy.getPolicyRoleList().stream().map(SalesPolicyRoleList::getRole).collect(Collectors.joining(",")));
                     customers.add(customerDetail);
                });
        	 }
        });
        return customers;
    }
    public CustomersVO transformPMAPIToCustomersContactDetail(FindCustomerByPolicyResponse customerDetails, String partyId, String policyNumber) throws JsonProcessingException {
        if (customerDetails == null) {
            return new CustomersVO();
        }
        log.info("PMAPI Response of customerDetails for contact Details {}",customerDetails.toString());
        CustomersVO customersContactDetails = new CustomersVO();
        CustomerByPolicy customerDetail = customerDetails.getResponse().stream().filter((cd) ->
                cd.getPartyId().equals(partyId)).findFirst().orElse(null);
        List<PolicyVO> policies = new ArrayList<>();
        if (customerDetail != null) {
            customersContactDetails.setGender(customerDetail.getPerson().getGender());
            customersContactDetails.setPersonNameList(customerDetail.getPerson().getPersonNameList());
            if(null != customerDetail.getEmail()){
                customersContactDetails.setEmailAddress(customerDetail.getEmail().getPrimaryEmail());
            }else{
                customersContactDetails.setEmailAddress("");
            }
            customersContactDetails.setBirthDate(customerDetail.getPerson().getDateOfBirth());
            if(null != customerDetail.getPhone()){
                if(null != customerDetail.getPhone().getPrimaryPhone()){
                    customersContactDetails.setPhoneNumber(customerDetail.getPhone().getPrimaryPhone());
                }else{
                    customersContactDetails.setPhoneNumber("");
                }
                if(null != customerDetail.getPhone().getSecondaryPhone()){
                    customersContactDetails.setSecondaryPhoneNumber(customerDetail.getPhone().getSecondaryPhone());
                }else{
                    customersContactDetails.setSecondaryPhoneNumber("");
                }
            }else{
                log.info("No phone number for customer with policyNumber {}",policyNumber);
                customersContactDetails.setPhoneNumber("");
                customersContactDetails.setSecondaryPhoneNumber("");
            }
            AddressVO addressVO = new AddressVO();
            addressVO.setAddressLine1(customerDetail.getAddressList().get(0).getAddressLine1());
            addressVO.setCity(customerDetail.getAddressList().get(0).getCity());
            addressVO.setState(customerDetail.getAddressList().get(0).getState());
            addressVO.setCountry(customerDetail.getAddressList().get(0).getCountry());
            addressVO.setZipCode(customerDetail.getAddressList().get(0).getZip());
            customersContactDetails.setHomeAddress(addressVO);
            // TODO: setting Temp Address empty for now
            customersContactDetails.setTempAddress(new AddressVO());
            customersContactDetails.setExternalReferenceList(customerDetail.getExternalReferenceList());

            // set policies list
            List<String> policyNumbers = new ArrayList<>();
            customerDetail.getExternalReferenceList().forEach(er -> {
                if (er.getPolicyList() == null) return;
                er.getPolicyList().forEach(p -> {
                    if (!policyNumbers.contains(p.getPolicyNumber())) {
                        PolicyVO policyVO = new PolicyVO();
                        CustomersVO customersVO = new CustomersVO();
                        policyVO.setPolicyStatus(p.getPolicyStatus());
                        policyVO.setPolicyNumber(p.getPolicyNumber());
                        customersVO.setRole(p.getPolicyRoleList().stream().map(PolicyRoleListItem::getRole).collect(Collectors.joining(",")));
                        policyVO.setParties(List.of(customersVO));
                        policies.add(policyVO);
                        policyNumbers.add(p.getPolicyNumber());
                    }
                });
            });

            customersContactDetails.setPolicies(policies);
            return customersContactDetails;
        }
        return customersContactDetails;
    }

    private Object getCurrentPremium(Policy policy) {
        String policyPaymentMode = StringUtils.upperCase(policy.getCurrentMode());
        switch (policyPaymentMode) {
            case "ANNUALLY":
                return policy.getAnnualPremium();
            case "SEMIANNUALLY":
                return policy.getSemiAnnualPremium();
            case "QUARTERLY":
                return policy.getQuarterlyPremium();
            case "MONTHLY":
            	return policy.getMonthyPremium();
            default:
                return null;
        }
    }
}
