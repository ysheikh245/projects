package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.case360.Case360WorksheetResponse;
import com.pm.api.agencycopilot.models.external.compensation.AgentCompensationResponse;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import java.util.List;

public interface Case360ServiceHandler extends ServiceHandler {

    public List<Case360DocumentVO> getRequirementsDocumentList(String policyNumber) throws Exception;

    public List<Case360DocumentVO> getRequirementsDocumentList(Case360WorksheetResponse case360WorksheetResponse) throws Exception;

    AgentCompensationResponse fetchAvailableCompensations(String npn, String beginDate, String endDate);


}
