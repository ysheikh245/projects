package com.pm.api.agencycopilot.configuration;

import com.pm.api.agencycopilot.models.mongodb.NPNPolicyListCacheRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.WorkSheetRequirementDocuments;
import com.pm.api.agencycopilot.utility.AgencyCoPilotConstants;
import com.pm.api.agencycopilot.utility.ApplicationStatusProperties;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;
import javax.annotation.PostConstruct;

import jdk.swing.interop.SwingInterOpUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexInfo;

@Configuration
@DependsOn("mongoTemplate")
@Slf4j
public class MongoDBConfig {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private ApplicationStatusProperties applicationStatusProperties;

    private static final LocalTime MIDNIGHT = LocalTime.of(23, 59, 59);

    @PostConstruct
    public void initIndexes() {
        checkAndCreateIndex(AgencyCoPilotConstants.CREATE_DATE_INDEX_NM, AgencyCoPilotConstants.INDEX_ON_FIELD_NM, PolicyDatabaseRecord.class, getDuration());
        checkAndCreateIndex(AgencyCoPilotConstants.CREATE_DATE_INDEX_NM, AgencyCoPilotConstants.INDEX_ON_FIELD_NM, PolicyCachingStatusRecord.class, getDuration());
        checkAndCreateIndex(AgencyCoPilotConstants.CREATE_DATE_INDEX_NM, AgencyCoPilotConstants.INDEX_ON_FIELD_NM, WorkSheetRequirementDocuments.class, getDuration(360)); //TODO; need to look at this TTL
        checkAndCreateIndex(AgencyCoPilotConstants.CREATE_DATE_INDEX_NM, AgencyCoPilotConstants.INDEX_ON_FIELD_NM, NPNPolicyListCacheRecord.class, getDuration(AgencyCoPilotConstants.NPN_POLICY_CACHE_DURATION));
    }

    private Duration getDuration() {
        return getDuration(applicationStatusProperties.getMongoCacheTTL());
    }

    private Duration getDuration(long minutes) {
        return Duration.ofMinutes(minutes);
    }

    private Duration getEODDuration() {
        Duration fromNowUntilMidnight = Duration.between(LocalTime.now(), MIDNIGHT);
        return Duration.ofSeconds(fromNowUntilMidnight.getSeconds());
    }

    private void checkAndCreateIndex(String indexName, String fieldName, Class clazz, Duration duration) {
        if (isTTLIndexPresent(clazz, indexName)) {
            log.info("Index is present on policy document withName={}, indexName={}. Hence dropping and recreating",
                    clazz.getName(), indexName);
            mongoTemplate.indexOps(clazz)
                    .dropIndex(indexName);
        }
        mongoTemplate.indexOps(clazz)
                .ensureIndex(
                        new Index().on(fieldName, Sort.Direction.ASC)
                                .named(indexName)
                                .expire(duration));
    }

    private boolean isTTLIndexPresent(Class clazz, String indexName) {
        log.info("Verifying if TTL Index is present on {} with name {}", clazz.getName(), indexName);
        Optional<IndexInfo> indexInfo = mongoTemplate.indexOps(clazz)
                .getIndexInfo().stream()
                .filter(index -> index.getName().equalsIgnoreCase(indexName))
                .findFirst();

        return indexInfo.isPresent();
    }
}
