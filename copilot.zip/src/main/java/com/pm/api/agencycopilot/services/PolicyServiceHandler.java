package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import java.util.List;

public interface PolicyServiceHandler extends ServiceHandler {

    PolicyV2Response getPolicyDataFromPMAPI(String policyNumber) throws Exception;

    PolicyV2Response getPolicyDetails(String policyNumber) throws Exception;

    List<PolicyDiscounts> getPolicyDiscounts(String policyNumber) throws Exception;

    List<PolicyRateChange> getPolicyRateChanges(String policyNumber) throws Exception;

    List<CoverageDetailsVO> getPolicyCoverageDetails(String policyNumber) throws Exception;

    PolicyInfoV2Response<Role> getRolesInfo(String policyNumber) throws Exception;

    PolicyInfoV2Response<AgentRole> getAgentRolesInfo(String policyNumber) throws Exception;

    DependentsV2Reponse getDependentDetails(String policyNumber) throws Exception;

    List<BeneficiaryDetails> getBeneficiaryDetails(String policyNumber) throws Exception;

    List<AdditionalCoverage> getAdditionalCoverages(String policyNumber) throws Exception;
}
