package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.services.impl.RestHelperServiceImpl;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class DemoController implements ApplicationController {

    @Autowired
    RestHelperServiceImpl restHelperServiceImpl;

    @GetMapping("/data/greet")
    public ResponseEntity<String> greetUser() {
        DemoRequest demoRequest = new DemoRequest("4c0c56b2-32c2-47d4-8fd7-bdd02e21bbf1", Arrays.asList("request1.key", "another.key", "feature.flag.value"));
        HttpEntity httpEntity = new HttpEntity(demoRequest);
        ResponseEntity<DemoResponse> response = restHelperServiceImpl.invoke("http://localhost:8081/retrieve-value", HttpMethod.POST, httpEntity, DemoResponse.class);
        DemoResponse demoResponse = response.getBody();
        String featureFlagValue = demoResponse.retrievedKeys.get("feature.flag.value");
        if(StringUtils.equalsIgnoreCase(featureFlagValue, "true")) {
            return ResponseEntity.ok().body("New Feature will be executed");
        } else {
            return ResponseEntity.ok().body("New Feature will NOT be executed");
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class DemoRequest {
        private String applicationIdentifier;
        private List<String> keys;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class DemoResponse {
        private String applicationIdentifier;
        private Map<String, String> retrievedKeys = new HashMap<>();
    }

}
