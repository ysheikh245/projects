package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class GetInteractionLogItems {

	@JsonProperty("businessUpdateTs")
	private String businessUpdateTs;

	@JsonProperty("interactionExternalName")
	private InteractionExternalName interactionExternalName;

	@JsonProperty("interactionId")
	private int interactionId;

	@JsonProperty("businessUpdateUser")
	private String businessUpdateUser;

	@JsonProperty("systemUpdateUser")
	private String systemUpdateUser;

	@JsonProperty("notes")
	private String notes;

	@JsonProperty("cdsourceSystem")
	private CdsourceSystem cdsourceSystem;

	@JsonProperty("cdaction")
	private Cdaction cdaction;

	@JsonProperty("interactionReasons")
	private List<InteractionReason> interactionReasons;

	@JsonProperty("cdlevel2")
	private Cdlevel2 cdlevel2;

	@JsonProperty("partyId")
	private int partyId;

	@JsonProperty("policyNumber")
	private String policyNumber;

}