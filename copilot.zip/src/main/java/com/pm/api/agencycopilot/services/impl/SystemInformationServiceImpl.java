package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.SystemInformation;
import com.pm.api.agencycopilot.services.SystemInformationService;
import com.pm.global.environment.EnvironmentUtil;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SystemInformationServiceImpl implements SystemInformationService {

    @Autowired
    EnvironmentUtil environmentUtil;

    @Autowired
    Environment environment;


    public SystemInformation getSystemData() {
        log.info("Entering getSystemData at {}", LocalDateTime.now());
        log.info("SystemInformationServiceImpl.getSystemData() - Start");
        SystemInformation systemInformation = new SystemInformation();
        try {
            systemInformation.setSystemDate(environmentUtil.getSystemDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        } catch (Exception e) {
            log.error("SystemInformationService.getSystemData()", e);
            log.warn("Setting the system date to current");
            systemInformation.setSystemDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
        systemInformation.setVersion(Optional.ofNullable(environment.getProperty("VERSION")).orElse("x.x.x"));
        systemInformation.setGitCommit(Optional.ofNullable(environment.getProperty("GIT_COMMIT")).orElse("commit_not_found"));
        log.info("SystemInformationServiceImpl.getSystemData() - Completed");
        log.info("Exiting getSystemData at {}", LocalDateTime.now());
        return systemInformation;
    }

}
