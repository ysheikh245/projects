package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WorkSheetDetailsResponse {

    private List<Case360DocumentVO> case360Documents;

}
