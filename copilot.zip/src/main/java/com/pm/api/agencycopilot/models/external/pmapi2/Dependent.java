package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class Dependent {
    @JsonProperty("policyNumber")
    private String policyNumber;
    @JsonProperty("dependents")
    private List<DependentsPerson> dependentsPerson;
}
