package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Cdreason {

	@JsonProperty("reasonCd")
	private String reasonCd;

}