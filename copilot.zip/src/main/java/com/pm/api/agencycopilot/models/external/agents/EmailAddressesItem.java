package com.pm.api.agencycopilot.models.external.agents;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmailAddressesItem {

    @JsonProperty("emailAddress")
    private String emailAddress;

    @JsonProperty("priorityLevel")
    private String priorityLevel;

    @JsonProperty("contactPreferenceType")
    private String contactPreferenceType;

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getPriorityLevel() {
        return priorityLevel;
    }

    public String getContactPreferenceType() {
        return contactPreferenceType;
    }
}