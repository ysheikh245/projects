package com.pm.api.agencycopilot.models.enums;

import com.pm.api.agencycopilot.models.internal.PolicyVO;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.ACTIVE;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum PolicyStatusCodeEnum {

    PENDING("Pending"),
    ISSUED("Issued"),
    DECLINE_WITHDRAWN("Decline/Withdrawn"),
    NOT_TAKEN("Not Taken"),
    EXCLUDE("Exclude");

    private String expandedStatus;

    PolicyStatusCodeEnum(String expandedStatus) {
        this.expandedStatus = expandedStatus;
    }

    public String getExpandedStatus() {
        return expandedStatus;
    }


    public static boolean filterActivePolicies(PolicyVO policyVO) {
        if (policyVO != null
                && ISSUED.getExpandedStatus().equalsIgnoreCase(policyVO.getPolicyStatus())) {
            return true;
        }
        return false;
    }

    public static boolean filterPendingPolicies(PolicyVO policyVO) {

        if (policyVO != null &&
                PENDING.getExpandedStatus().equalsIgnoreCase(policyVO.getPolicyStatus())) {
            return true;
        }
        return false;
    }

    public static boolean filterDeclineWithdrawnPolicies(PolicyVO policyVO) {

        if (policyVO != null &&
                DECLINE_WITHDRAWN.getExpandedStatus().equalsIgnoreCase(policyVO.getPolicyStatus())) {
            return true;
        }
        return false;
    }

    public static boolean filterNotTakenPolicies(PolicyVO policyVO) {
        if (policyVO != null &&
                NOT_TAKEN.getExpandedStatus().equalsIgnoreCase(policyVO.getPolicyStatus())) {
            return true;
        }
        return false;
    }

    /**
     * This method is currently not used anywhere but added here as reference for future purpose.
     *
     * @param policyVO
     * @return
     */
    public static boolean filterExcludePolicies(PolicyVO policyVO) {

        if (policyVO != null &&
                EXCLUDE.getExpandedStatus().equalsIgnoreCase(policyVO.getPolicyStatus())) {
            return true;
        }
        return false;
    }

    public static String policyStatusString(String policyStatusCode) {
        if (policyStatusCode == null) {
            return null;
        }
        List<PolicyStatusCodeEnum> policyStatusCodeEnumList = Arrays.asList(PolicyStatusCodeEnum.values())
                .stream()
                .filter((enumLocal) -> enumLocal.name().equalsIgnoreCase(policyStatusCode))
                .collect(Collectors.toList());
        if (policyStatusCodeEnumList.size() == 0) {
            return null;
        }
        return PolicyStatusCodeEnum.valueOf(policyStatusCode).getExpandedStatus();
    }

    public static boolean isActive(String policyStatusCode) {
        if (policyStatusCode == null) {
            return false;
        }
        List<PolicyStatusCodeEnum> policyStatusCodeEnumList = Arrays.asList(PolicyStatusCodeEnum.values())
                .stream()
                .filter((enumLocal) -> enumLocal.name().equalsIgnoreCase(policyStatusCode))
                .collect(Collectors.toList());
        if (policyStatusCodeEnumList.size() == 0) {
            return false;
        }
        return ACTIVE.equals(PolicyStatusCodeEnum.valueOf(policyStatusCode).getExpandedStatus());
    }

    public static boolean isPending(String policyStatusCode) {
        if (policyStatusCode == null) {
            return false;
        }
        List<PolicyStatusCodeEnum> policyStatusCodeEnumList = Arrays.asList(PolicyStatusCodeEnum.values())
                .stream()
                .filter((enumLocal) -> enumLocal.name().equalsIgnoreCase(policyStatusCode))
                .collect(Collectors.toList());
        if (policyStatusCodeEnumList.size() == 0) {
            return false;
        }
        return PENDING.equals(PolicyStatusCodeEnum.valueOf(policyStatusCode).getExpandedStatus());
    }

    public static List<String> transformEnumToStringList(List<PolicyStatusCodeEnum> policyStatusCodeEnumList) {
        return policyStatusCodeEnumList.stream()
                .map(policyStatusCodeEnum -> policyStatusCodeEnum.getExpandedStatus())
                .collect(Collectors.toList());

    }
}
