package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PetAllOptCovItem{

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("COptCovCode")
	private String cOptCovCode;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CPbr")
	private String cPbr;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CRate")
	private String cRate;

	@JsonProperty("COptAnnualPremium")
	private String cOptAnnualPremium;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CPiCovOptTab")
	private String cPiCovOptTab;

	@JsonProperty("CIsCovSelected")
	private String cIsCovSelected;

	@JsonProperty("COptFinalAnnPremium")
	private String cOptFinalAnnPremium;

	@JsonProperty("CSublimit")
	private String cSublimit;

	@JsonProperty("CCoverageOption")
	private String cCoverageOption;

	public String getCCoverage(){
		return cCoverage;
	}

	public String getCOptCovCode(){
		return cOptCovCode;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getCPbr(){
		return cPbr;
	}

	public String getGid(){
		return gid;
	}

	public String getCRate(){
		return cRate;
	}

	public String getCOptAnnualPremium(){
		return cOptAnnualPremium;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCPiCovOptTab(){
		return cPiCovOptTab;
	}

	public String getCIsCovSelected(){
		return cIsCovSelected;
	}

	public String getCOptFinalAnnPremium(){
		return cOptFinalAnnPremium;
	}

	public String getCSublimit(){
		return cSublimit;
	}

	public String getCCoverageOption(){
		return cCoverageOption;
	}
}