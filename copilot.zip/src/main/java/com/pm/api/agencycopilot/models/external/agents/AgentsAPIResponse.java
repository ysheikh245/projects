package com.pm.api.agencycopilot.models.external.agents;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class AgentsAPIResponse {

	@JsonProperty("response")
	private Response response;


}