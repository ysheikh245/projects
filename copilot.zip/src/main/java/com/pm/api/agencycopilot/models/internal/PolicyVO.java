package com.pm.api.agencycopilot.models.internal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lombok.Data;
import lombok.ToString;

@Data
@JsonRootName("policy")
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyVO {

    private String policyNumber;
    private Date issueDate; // issueDate
    private Date submitDate; //applicationDate
    private String displayIssueDate; // this property is intended to be exposed to UI for the display purpose
    private String displaySubmitDate; // this property is intended to be exposed to UI for the display purpose
    private String productName; //productDescription
    private String productCode; //productCategory (trimmed to 4 characters)
    private String fullProductCode; //completeProductCategory - as is from Inspro SOAP call
    private String productCategory;
    private String policyStatus;
    private String policyDisplayText;
    private String policyStatusCode;
    private String policyStatusLongName;
    private String policyType;
    private List<CustomersVO> parties = new ArrayList();
    private Integer workSheetRequirementCount;
    private String thankyouEmailStatus;
    private String policyEffectiveDate;
    private String lastPaymentDate;
    private String paidToDate;
    private Object currentPremium;
    
}
