package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Email{

	@JsonProperty("primaryEmail")
	private String primaryEmail;

	public String getPrimaryEmail(){
		return primaryEmail;
	}
}