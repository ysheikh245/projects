package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;

@Data
public class PolicyByCustomerDetailsRequest {
    public String firstName;

    public String lastName;

    public String state;

    public String zip;

    public String policyNumber;

    @NotNull(message = "type cannot be null")
    public CustomerDetailsRequestType type;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "mm/dd/yyyy")
    public Date dateOfBirth;

    public PolicyByCustomerDetailsRequest() {
    }
}
