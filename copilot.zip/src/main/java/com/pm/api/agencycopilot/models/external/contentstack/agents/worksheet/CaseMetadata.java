package com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CaseMetadata{

	@JsonProperty("documentIndexCode")
	private String documentIndexCode;

	@JsonProperty("documentDesc")
	private String documentDesc;

	@JsonProperty("docType")
	private String docType;

	@JsonProperty("corrType")
	private String corrType;

	@JsonProperty("source")
	private String source;

	@JsonProperty("doc_type")
	private String doc_Type;
}