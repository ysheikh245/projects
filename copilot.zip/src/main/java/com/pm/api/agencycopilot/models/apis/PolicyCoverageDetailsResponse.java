package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import lombok.Data;

import java.util.List;

@Data
public class PolicyCoverageDetailsResponse {
    private List<CoverageDetailsVO>  coverageDetails;
}
