package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AltPayorAddressItem{

	@JsonProperty("SysExposureIsUnits")
	private String sysExposureIsUnits;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("IsAuditExpoProrated")
	private String isAuditExpoProrated;

	@JsonProperty("ZipCode")
	private String zipCode;

	@JsonProperty("StateCode")
	private String stateCode;

	@JsonProperty("City")
	private String city;

	@JsonProperty("ZipExtension")
	private String zipExtension;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("County")
	private String county;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("PolicyPmAltrPayorAdd")
	private String policyPmAltrPayorAdd;

	@JsonProperty("StateDesc")
	private String stateDesc;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("Country")
	private String country;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("AddressType")
	private String addressType;

	@JsonProperty("CountryCode")
	private String countryCode;

	@JsonProperty("Line1")
	private String line1;

	public String getSysExposureIsUnits(){
		return sysExposureIsUnits;
	}

	public String getGid(){
		return gid;
	}

	public String getIsAuditExpoProrated(){
		return isAuditExpoProrated;
	}

	public String getZipCode(){
		return zipCode;
	}

	public String getStateCode(){
		return stateCode;
	}

	public String getCity(){
		return city;
	}

	public String getZipExtension(){
		return zipExtension;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCounty(){
		return county;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getPolicyPmAltrPayorAdd(){
		return policyPmAltrPayorAdd;
	}

	public String getStateDesc(){
		return stateDesc;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCountry(){
		return country;
	}

	public String getId(){
		return id;
	}

	public String getAddressType(){
		return addressType;
	}

	public String getCountryCode(){
		return countryCode;
	}

	public String getLine1(){
		return line1;
	}
}