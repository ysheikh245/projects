package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.PolicyDBServiceHandler;
import com.pm.api.agencycopilot.utility.DateFormatterUtility;

import java.time.LocalDateTime;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SPACE;

@Service
@Slf4j
public class PolicyDBServiceHandlerImpl implements PolicyDBServiceHandler {
    Logger logger = LoggerFactory.getLogger(PolicyDBServiceHandlerImpl.class);

    @Autowired
    JdbcTemplate jdbcTemplate;


    private final int MAX_RESULT = 3;

    /*@Override
    public List<PolicyDAO> getPoliciesByNPN(String id, int pageNumber, int days, List<String> policyStatus, String sortOrder) {

        System.out.println("Filtered policies  " + sortOrder.toUpperCase());
        StringBuilder queryString = new StringBuilder("SELECT DISTINCT SCA.AG_AGENT_NUMBER, PL.POLICY_NUMBER, PL.ISSUE_DATE, PL.APP_RECD_DATE \n");
        queryString.append("FROM SPLIT_COMMISSION_AGENT SCA \n");
        queryString.append("JOIN POLICY PL \n");
        queryString.append("ON SCA.AG_POLICY_NUMBER = PL.POLICY_NUMBER \n");
        queryString.append("WHERE SCA.AG_AGENT_NUMBER = ( \n");
        queryString.append("SELECT DISTINCT SCA.AG_AGENT_NUMBER FROM SPLIT_COMMISSION_AGENT SCA JOIN AGENT_MASTER AG ON SCA.AG_AGENT_NUMBER = AG.AGENT_NUMBER WHERE AG.NATL_PRODUCER_NBR = :npnNumber) \n");
        queryString.append("AND PL.APP_RECD_DATE BETWEEN DATEADD(DAY, :daysCount, GETDATE()) AND GETDATE() \n");
        queryString.append("AND PL.STATUS_CODE IN :policyStatus \n");
        queryString.append("ORDER BY PL.APP_RECD_DATE " + ("DESC".equalsIgnoreCase(sortOrder) ? "DESC" : "ASC"));

        Query query = emInspro.createNativeQuery(queryString.toString());
        query.setParameter("npnNumber", id);
        query.setParameter("policyStatus", policyStatus);
        query.setParameter("daysCount", (-1*days));
        //query.setParameter("orderBy", Sort.Direction.DESC);
        query.setFirstResult(MAX_RESULT * pageNumber);
        query.setMaxResults(MAX_RESULT);

        logger.info("Get Filtered Policy By NPN Query \n" + query.unwrap(org.hibernate.Query.class).getQueryString());

        List<Object[]> resultList = query.getResultList();

        List<PolicyDAO> policies = resultList.stream()
                .map(policy -> new PolicyDAO((String) policy[0], (String) policy[1], (Timestamp) policy[2]))
                .collect(Collectors.toList());
        //policies.forEach(System.out::println);
        return policies;
    }*/

    @Override
    public List<PolicyVO> getPoliciesByNPN(String npn, FilterCriteriaVO filterCriteriaVO) {
        log.info("Entering getPoliciesByNPN at {}", LocalDateTime.now());
        StringBuilder queryString = new StringBuilder("SELECT NBA.POLICY_NUMBER, NBA.SUBMIT_DATE  \n");
        queryString.append("FROM DBO.NEW_BUSINESS_APP NBA \n");
        queryString.append("WHERE (NBA.NPN_1  = '" + npn + "' \n");
        queryString.append("OR NBA.NPN_2  = '" + npn + "' \n");
        queryString.append("OR NBA.NPN_3  = '" + npn + "' \n");
        queryString.append("OR NBA.NPN_4  = '" + npn + "') \n");

        if (filterCriteriaVO != null && filterCriteriaVO.getDays() > 0) {
            queryString.append("AND (NBA.SUBMIT_DATE  >= '" + filterCriteriaVO.getSearchFromDate() + "'\n");
            queryString.append("AND NBA.SUBMIT_DATE <= '" + filterCriteriaVO.getSearchToDate() + "') \n");
            queryString.append("ORDER BY NBA.SUBMIT_DATE " + filterCriteriaVO.getSortOrder().name());
        }

        logger.info("Fetching filtered data from INSPRO DB using {} ", queryString);
        List<PolicyVO> policyVOList = jdbcTemplate.query(queryString.toString(),
                (rs, rowNum) -> {
                    PolicyVO policyVO = new PolicyVO();
                    String policyNumber = StringUtils.trim(rs.getString("POLICY_NUMBER") + "");
                    log.info("Policy Number: '{}'", policyNumber);
                    policyVO.setPolicyNumber(policyNumber);
                    policyVO.setSubmitDate(rs.getDate("SUBMIT_DATE"));
                    return policyVO;
                });
        logger.info("No. of Policies returned from DBO.NEW_BUSINESS_APP table are {} for npnId {}", policyVOList.size(), npn);
        logger.info("Policies : {}", policyVOList);
        log.info("Exiting getPoliciesByNPN at {}", LocalDateTime.now());
        return policyVOList;
    }
}