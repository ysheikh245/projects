package com.pm.api.agencycopilot.models.external.messaging;

public enum MessagingDeliveryEnum {

    EMAIL("EMAIL");

    MessagingDeliveryEnum(String value) {
        this.value = value;
    }

    private String value;

    public String getValue() {
        return this.value;
    }

}
