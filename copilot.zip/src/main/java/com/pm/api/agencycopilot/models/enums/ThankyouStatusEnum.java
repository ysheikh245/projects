package com.pm.api.agencycopilot.models.enums;

public enum ThankyouStatusEnum {

    THANKYOU_SENT, SEND_THANKYOU, HIDE;
}
