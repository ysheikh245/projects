package com.pm.api.agencycopilot.models.apis;

import lombok.Data;

@Data
public class AgentCompensation {

    private String endDate;
    private String documentIndexCode;
    private String documentType;
    private String documentId;
    private String version;
    private String fileName;
    
}
