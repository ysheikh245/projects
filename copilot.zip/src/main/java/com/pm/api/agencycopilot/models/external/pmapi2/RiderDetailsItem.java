package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiderDetailsItem{

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("companyCode")
	private String companyCode;

	@JsonProperty("personNumber")
	private int personNumber;

	@JsonProperty("baseRiderInd")
	private String baseRiderInd;

	@JsonProperty("statusCode")
	private String statusCode;

	@JsonProperty("riderCode")
	private String riderCode;

	@JsonProperty("riderEffDate")
	private String riderEffDate;

	@JsonProperty("riderTermDate")
	private String riderTermDate;

	@JsonProperty("riderBenefitAmt")
	private double riderBenefitAmt;

	@JsonProperty("riderDescrip")
	private String riderDescrip;

	@JsonProperty("monthlyPremium")
	private double monthlyPremium;

	@JsonProperty("quartPremium")
	private double quartPremium;

	@JsonProperty("semiPremium")
	private double semiPremium;

	@JsonProperty("recurringPremium")
	private double recurringPremium;

	@JsonProperty("annualPremium")
	private double annualPremium;

	@JsonProperty("firstName")
	private String firstName;

	@JsonProperty("middleName")
	private String middleName;

	@JsonProperty("lastName")
	private String lastName;

	@JsonProperty("paidToDate")
	private String paidToDate;

	@JsonProperty("riderForm")
	private RiderForm riderForm;

	@JsonProperty("legacy")
	private boolean legacy;

}