package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collection;

public class Phone{

	@JsonProperty("primaryPhone")
	private String primaryPhone;

	@JsonProperty("secondaryPhone")
	private String secondaryPhone;

	public String getPrimaryPhone(){
		return primaryPhone;
	}

	public String getSecondaryPhone(){
		return secondaryPhone;
	}
}