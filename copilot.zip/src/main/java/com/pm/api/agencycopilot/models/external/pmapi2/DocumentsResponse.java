package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class DocumentsResponse {
    @JsonProperty("searchType")
    private String searchType;
    @JsonProperty("responseFormat")
    private String responseFormat;
    @JsonProperty("documents")
    private List<Document> documents;
}
