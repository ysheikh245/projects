package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InteractionExternalName{

	@JsonProperty("interactionId")
	private int interactionId;

	@JsonProperty("cdcallerRelationship")
	private CdcallerRelationship cdcallerRelationship;

	@JsonProperty("callerName")
	private String callerName;

}