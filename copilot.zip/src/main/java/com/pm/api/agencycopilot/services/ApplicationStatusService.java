package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.apis.WorkSheetDetailsResponse;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface ApplicationStatusService {
    ApplicationStatusResponse processApplicationStatus(ApplicationStatusRequest applicationStatusModel);

    Map<String, List<PolicyVO>> retrieveApplicationStatusByNPN(String npn, Integer pageNo, Integer pageSize);

    PolicyCachingStatusRecord retrieveApplicationStatusCacheResults(String npn);

    List<PolicyCategoriesRecord> insertPolicyCategoriesRecords(List<PolicyCategoriesRecord> policyCategoriesRecordList);

    List<ProductTypeCategoriesRecord> insertProductTypeCategoriesRecords(List<ProductTypeCategoriesRecord> policyCategoriesRecordList);

    WorkSheetDetailsResponse getWorkSheetDocumentDetails(String policyNumber);

}
