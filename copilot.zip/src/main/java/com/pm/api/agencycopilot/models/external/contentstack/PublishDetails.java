package com.pm.api.agencycopilot.models.external.contentstack;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PublishDetails{

	@JsonProperty("environment")
	private String environment;

	@JsonProperty("time")
	private String time;

	@JsonProperty("locale")
	private String locale;

	@JsonProperty("user")
	private String user;
}