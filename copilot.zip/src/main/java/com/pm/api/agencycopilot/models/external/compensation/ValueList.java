package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@JsonRootName("valueList")
@Data
public class ValueList {

    @JsonProperty("fieldName")
    private String fieldName;

    @JsonProperty("itemValue")
    private String itemValue;

    @JsonProperty("displayOrder")
    private int displayOrder;

    public String getFieldName() {
        return fieldName;
    }

    public String getItemValue() {
        return itemValue;
    }

    public int getDisplayOrder() {
        return displayOrder;
    }
}