package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ProducerItem{

	@JsonProperty("DisplayProducerCode")
	private String displayProducerCode;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("Address")
	private List<AddressItem> address;

	@JsonProperty("ProducerOfRecord")
	private String producerOfRecord;

	@JsonProperty("LicenseStates")
	private String licenseStates;

	@JsonProperty("PolicyProducer")
	private String policyProducer;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("SurplusLines")
	private String surplusLines;

	@JsonProperty("Name")
	private String name;

	@JsonProperty("Contact")
	private List<ContactItem> contact;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("GoodStanding")
	private String goodStanding;

	@JsonProperty("LicenseNo")
	private String licenseNo;

	@JsonProperty("ExtUpdMisPolicies")
	private String extUpdMisPolicies;

	@JsonProperty("Primary")
	private String primary;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("DistinguishedFieldUw")
	private String distinguishedFieldUw;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("ProducerCode")
	private String producerCode;

	@JsonProperty("DirectBillIndicator")
	private String directBillIndicator;

	public String getDisplayProducerCode(){
		return displayProducerCode;
	}

	public String getGid(){
		return gid;
	}

	public List<AddressItem> getAddress(){
		return address;
	}

	public String getProducerOfRecord(){
		return producerOfRecord;
	}

	public String getLicenseStates(){
		return licenseStates;
	}

	public String getPolicyProducer(){
		return policyProducer;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getSurplusLines(){
		return surplusLines;
	}

	public String getName(){
		return name;
	}

	public List<ContactItem> getContact(){
		return contact;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getGoodStanding(){
		return goodStanding;
	}

	public String getLicenseNo(){
		return licenseNo;
	}

	public String getExtUpdMisPolicies(){
		return extUpdMisPolicies;
	}

	public String getPrimary(){
		return primary;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getDistinguishedFieldUw(){
		return distinguishedFieldUw;
	}

	public String getId(){
		return id;
	}

	public String getProducerCode(){
		return producerCode;
	}

	public String getDirectBillIndicator(){
		return directBillIndicator;
	}
}