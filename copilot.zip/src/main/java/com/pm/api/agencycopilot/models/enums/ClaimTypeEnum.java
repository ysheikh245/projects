package com.pm.api.agencycopilot.models.enums;

public enum ClaimTypeEnum {

    HEALTH, LIFE;
}
