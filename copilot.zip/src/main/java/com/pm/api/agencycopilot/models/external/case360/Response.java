package com.pm.api.agencycopilot.models.external.case360;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Response{

	@JsonProperty("FmsRowSetTO")
	private List<FmsRowSetTO> fmsRowSetTO;

	public List<FmsRowSetTO> getFmsRowSetTO(){
		return fmsRowSetTO;
	}
}