package com.pm.api.agencycopilot.models.external.sales;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SalesPolicyRoleList {
	private String role;
	private String policyDeletes;
}
