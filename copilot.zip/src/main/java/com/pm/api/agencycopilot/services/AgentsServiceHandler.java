package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.agents.AgentsAPIResponse;

public interface AgentsServiceHandler extends ServiceHandler {

    public AgentsAPIResponse getAgentsDetail(String npn);

}
