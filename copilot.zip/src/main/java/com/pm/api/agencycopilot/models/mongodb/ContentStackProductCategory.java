package com.pm.api.agencycopilot.models.mongodb;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "contentStackProductCategory")
@Data
public class ContentStackProductCategory {

    @Id
    private String productCategory;
    private String contentStackResponse;
}
