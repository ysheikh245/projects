package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyStatus{

	@JsonProperty("entityReference")
	private String entityReference;

	@JsonProperty("entityType")
	private String entityType;

	@JsonProperty("statusTimestamp")
	private String statusTimestamp;

	@JsonProperty("status")
	private String status;

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getStatusTimestamp(){
		return statusTimestamp;
	}

	public String getStatus(){
		return status;
	}
}