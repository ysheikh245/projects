package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class LineItemsItem{

	@JsonProperty("claimPaymentStatus")
	private ClaimPaymentStatus claimPaymentStatus;

	@JsonProperty("amountPaid")
	private Object amountPaid;

	@JsonProperty("payRate")
	private Object payRate;

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("contestableIndicator")
	private String contestableIndicator;

	@JsonProperty("kindRider")
	private String kindRider;

	@JsonProperty("lineNumber")
	private String lineNumber;

	@JsonProperty("description")
	private String description;

	@JsonProperty("payee")
	private Payee payee;

	@JsonProperty("lossCode")
	private String lossCode;

	@JsonProperty("benefitPeriodBegin")
	private String benefitPeriodBegin;

	@JsonProperty("benefitPeriodEnd")
	private String benefitPeriodEnd;

	@JsonProperty("paymentDate")
	private String paymentDate;
}