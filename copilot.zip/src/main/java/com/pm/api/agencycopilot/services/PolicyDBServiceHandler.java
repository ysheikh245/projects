package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import java.util.List;

public interface PolicyDBServiceHandler {
    //public List<PolicyDAO> getPoliciesByNPN(String id, int pageNumber, int days, List<String> policyStatus, String sortOrder);

    /**
     * this goes to Ext InsPro
     **/
    public List<PolicyVO> getPoliciesByNPN(String npnId, FilterCriteriaVO filterCriteriaVO);
}
