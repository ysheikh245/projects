package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.models.mongodb.NPNPolicyListCacheRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicySearchStatus;
import com.pm.api.agencycopilot.models.mongodb.PolicyToProductCategory;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.WorkSheetRequirementDocuments;
import com.pm.api.agencycopilot.repository.ContentStackProductCategoryRepository;
import com.pm.api.agencycopilot.repository.NPNPolicyListCacheRepository;
import com.pm.api.agencycopilot.repository.PolicyCachingStatusRepository;
import com.pm.api.agencycopilot.repository.PolicyCategoriesRepository;
import com.pm.api.agencycopilot.repository.PolicyRepository;
import com.pm.api.agencycopilot.repository.PolicyToProductCategoryRepository;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.repository.WorkSheetRequirementDocumentsRepository;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;


@Service
@Slf4j
public class MongoDBCacheHandlerImpl implements MongoDBCacheHandler {

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private PolicyCachingStatusRepository policyCachingStatusRepository;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private PolicyCategoriesRepository policyCategoriesRepository;

    @Autowired
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Autowired
    private ContentStackProductCategoryRepository contentStackProductCategoryRepository;

    @Autowired
    private WorkSheetRequirementDocumentsRepository workSheetRequirementDocumentsRepository;

    @Autowired
    private PolicyToProductCategoryRepository policyToProductCategoryRepository;
    @Autowired
    private NPNPolicyListCacheRepository npnPolicyListCacheRepository;


    @Override
    public void saveToPolicyDocument(PolicyVO policyVO, ApplicationStatusRequest applicationStatusRequest) {
        log.info("Entering saveToPolicyDocument at {}", LocalDateTime.now());
        PolicyDatabaseRecord record = new PolicyDatabaseRecord();
        record.setPolicyNumber(policyVO.getPolicyNumber());
        record.setPolicyResponse(policyVO);
        record.setPolicyStatus(policyVO.getPolicyStatus());
        record.setNpnId(applicationStatusRequest.getAgentInformation().getNpn());
        record.setRank(applicationStatusRequest.getAgentInformation().getLicenseNumber());
        record.setCreateDate(new Date());
        policyRepository.save(record);
    }

    @Override
    public void findAndDeletePoliciesByNpn(String npnId) {
        log.info("Entering findAndDeletePoliciesByNpn at {}", LocalDateTime.now());
        if (policyRepository.existsByNpnId(npnId)) {
            policyRepository.deleteByNpnId(npnId);
        }
    }

    @Override
    public PolicyCachingStatusRecord saveToPolicyCacheStatusDocument(String npnId,
                                                                     LocalDateTime startTime,
                                                                     Date createdDate) {
        log.info("Entering saveToPolicyCacheStatusDocument at {}", LocalDateTime.now());
        PolicyCachingStatusRecord policyCachingStatusRecord = new PolicyCachingStatusRecord();
        policyCachingStatusRecord.setNpnId(npnId);

        PolicySearchStatus policySearchStatus = new PolicySearchStatus();
        policySearchStatus.setSearchCompleted(false);
        policySearchStatus.setStartedAt(startTime);
        policySearchStatus.setEndedAt(null);
        policySearchStatus.setTotalPoliciesFetched(0l);

        policyCachingStatusRecord.setCreateDate(createdDate);
        policyCachingStatusRecord.setDefaultPolicySearchProcess(policySearchStatus);

        PolicySearchStatus backgroundPolicySearchStatus = new PolicySearchStatus();
        backgroundPolicySearchStatus.setSearchCompleted(false);
        backgroundPolicySearchStatus.setStartedAt(null);
        backgroundPolicySearchStatus.setEndedAt(null);
        backgroundPolicySearchStatus.setTotalPoliciesFetched(0l);
        policyCachingStatusRecord.setBackgroundPolicySearchProcess(backgroundPolicySearchStatus);

        policyCachingStatusRecord.setTotalPoliciesFetchedCount(0l);
        log.info("Exiting saveToPolicyCacheStatusDocument at {}", LocalDateTime.now());
        return policyCachingStatusRepository.save(policyCachingStatusRecord);
    }

    @Override
    public PolicyCachingStatusRecord updatePolicyCacheStatusDocument(String npnId,
                                                                     LocalDateTime localDateTime,
                                                                     boolean isBackground,
                                                                     boolean isSearchCompleted,
                                                                     long policiesFetchedCount) {
        log.info("Entering updatePolicyCacheStatusDocument at {}", LocalDateTime.now());
        PolicyCachingStatusRecord policyCachingStatusRecord = policyCachingStatusRepository.findByNpnId(npnId);

        if (isBackground) {
            if (isSearchCompleted) {
                long totalPoliciesFetchedCount = (policyCachingStatusRecord.getDefaultPolicySearchProcess().getTotalPoliciesFetched()
                        + policiesFetchedCount);

                policyCachingStatusRecord.getBackgroundPolicySearchProcess().setEndedAt(localDateTime);
                policyCachingStatusRecord.setTotalPoliciesFetchedCount(totalPoliciesFetchedCount);
            } else {
                policyCachingStatusRecord.getBackgroundPolicySearchProcess().setStartedAt(localDateTime);
            }

            policyCachingStatusRecord.getBackgroundPolicySearchProcess().setSearchCompleted(isSearchCompleted);
            policyCachingStatusRecord.getBackgroundPolicySearchProcess().setTotalPoliciesFetched(policiesFetchedCount);
        } else {
            policyCachingStatusRecord.getDefaultPolicySearchProcess().setEndedAt(localDateTime);
            policyCachingStatusRecord.getDefaultPolicySearchProcess().setSearchCompleted(isSearchCompleted);
            policyCachingStatusRecord.getDefaultPolicySearchProcess().setTotalPoliciesFetched(policiesFetchedCount);
        }
        log.info("Exiting updatePolicyCacheStatusDocument at {}", LocalDateTime.now());
        return policyCachingStatusRepository.save(policyCachingStatusRecord);
    }

    @Override
    public void findAndDeletePolicyCacheResultByNpn(String npnId) {
        log.info("Entering and Exiting findAndDeletePolicyCacheResultByNpn at {}", LocalDateTime.now());
        if (policyCachingStatusRepository.existsById(npnId)) {
            policyCachingStatusRepository.deleteById(npnId);
        }
    }

    @Override
    public PolicyCachingStatusRecord findPolicyCachingStatusByNpnId(String npnId) {
        log.info("Entering and Exiting findPolicyCachingStatusByNpnId at {}", LocalDateTime.now());
        return policyCachingStatusRepository.findByNpnId(npnId);
    }

    @Override
    public List<PolicyDatabaseRecord> findPoliciesByNpnUsingCriteria(Query query) {
        log.info("Entering and Exiting findPoliciesByNpnUsingCriteria at {}", LocalDateTime.now());
        return mongoTemplate.find(query, PolicyDatabaseRecord.class);
    }

    @Override
    public PolicyCategoriesRecord findApplicationStatusCodes(String statusCode, boolean isActive) {
        log.info("Entering and Exiting findApplicationStatusCodes at {}", LocalDateTime.now());
        return policyCategoriesRepository.findByCodeAndIsActive(statusCode, isActive);
    }


    @Override
    public List<PolicyCategoriesRecord> insertPolicyCategoryCodes(List<PolicyCategoriesRecord> policyCategoriesRecords) {
        log.info("Entering and Exiting insertPolicyCategoryCodes at {}", LocalDateTime.now());
        return policyCategoriesRepository.saveAll(policyCategoriesRecords);
    }

    @Override
    public List<ProductTypeCategoriesRecord> insertProductTypeCategories(List<ProductTypeCategoriesRecord> productTypeCategoriesRecords) {
        log.info("Entering and Exiting insertProductTypeCategories at {}", LocalDateTime.now());
        return productTypeCategoriesRepository.saveAll(productTypeCategoriesRecords);
    }

    @Override
    public ProductTypeCategoriesRecord findProductTypeCategory(String productCode, boolean isActive) {
        log.info("Entering and Exiting findProductTypeCategory at {}", LocalDateTime.now());
        return productTypeCategoriesRepository.findByProductCodeAndIsActive(productCode, isActive);
    }

    @Override
    public List<PolicyDatabaseRecord> findPoliciesByNPNId(String npnId, Pageable pageable) {
        log.info("Entering and Exiting findPoliciesByNPNId at {}", LocalDateTime.now());
        return policyRepository.findByNpnId(npnId, pageable);
    }

    @Override
    public List<PolicyDatabaseRecord> findPoliciesByNPNIdAndPolicyNumber(String npnId, String policyNumber, Pageable pageable) {
        log.info("Entering and Exiting findPoliciesByNPNIdAndPolicyNumber at {}", LocalDateTime.now());
        return policyRepository.findByNpnIdAndPolicyNumber(npnId, policyNumber, pageable);
    }

    @Override
    public List<PolicyDatabaseRecord> findPoliciesByNPNIdAndCustomerFullName(String npnId, String customerFullName, Pageable pageable) {
        log.info("Entering and Exiting findPoliciesByNPNIdAndCustomerFullName at {}", LocalDateTime.now());
        return policyRepository.findByNpnIdAndPolicyResponsePartiesFullNameContaining(npnId, customerFullName, pageable);
    }

    @Override
    public ContentStackProductCategory findByProductCategory(String productCategory) {
        log.info("Entering and Exiting findByProductCategory at {}", LocalDateTime.now());
        return contentStackProductCategoryRepository.findByProductCategory(productCategory);
    }

    @Override
    public ContentStackProductCategory insertContentStackResponseForProductCategory(ContentStackProductCategory contentStackProductCategory) {
        log.info("Entering and Exiting insertContentStackResponseForProductCategory at {}", LocalDateTime.now());
        return contentStackProductCategoryRepository.save(contentStackProductCategory);
    }

    @Override
    public List<Case360DocumentVO> getWorkSheetRequirementDocuments(String policyNumber) {
        log.info("Entering and Exiting getWorkSheetRequirementDocuments at {}", LocalDateTime.now());
        Optional<WorkSheetRequirementDocuments> documents = workSheetRequirementDocumentsRepository.findById(policyNumber);
        if (documents.isPresent()) {
            return documents.get().getProcessedResponse();
        } else {
            return new ArrayList<>(); // send blank collection
        }
    }

    @Override
    public PolicyToProductCategory insertPolicyToProductCategory(PolicyToProductCategory policyToProductCategory) {
        log.info("Entering and Exiting insertPolicyToProductCategory at {}", LocalDateTime.now());
        return policyToProductCategoryRepository.save(policyToProductCategory);
    }

    @Override
    public Optional<PolicyToProductCategory> findProductCategoryForPolicy(String policyNumber) {
        log.info("Entering and Exiting findProductCategoryForPolicy at {}", LocalDateTime.now());
        Optional<PolicyToProductCategory> record = policyToProductCategoryRepository.findById(policyNumber);
        return record;
    }

    @Override
    public NPNPolicyListCacheRecord findPolicyListByNPN(String npnId) {
       return npnPolicyListCacheRepository.findByNpnId(npnId);
    }

    @Override
    public NPNPolicyListCacheRecord insertNPNPolicyListCache(String npnId, List<String> policyList) {
        NPNPolicyListCacheRecord record = new NPNPolicyListCacheRecord();
        record.setNpnId(npnId);
        log.info("***DEBUG***. PolicyLisy={}", policyList);
        record.setPolicies(policyList);
        record.setCreateDate(Calendar.getInstance().getTime());
        return npnPolicyListCacheRepository.save(record);
    }

    @Override
    public PolicyDatabaseRecord updatePolicyRepository(String npn, String policyNumber, String status) {
        List<PolicyDatabaseRecord> cachedPolicy = policyRepository.findByNpnIdAndPolicyNumber(npn, policyNumber, null);
        if(!CollectionUtils.isEmpty(cachedPolicy)) {
            PolicyDatabaseRecord policyDatabaseRecord = cachedPolicy.get(0);
            policyDatabaseRecord.getPolicyResponse().setThankyouEmailStatus(status);
            return policyRepository.save(policyDatabaseRecord);
        } else {
            log.info("MongoDBCacheHandlerImpl.updatePolicyRepository(). " +
                      "No records found for NPN={}, PolicyNumber={} while updating cache for active policy",
                      npn, policyNumber);
            return null;
        }
    }
}
