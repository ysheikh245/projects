package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.pm.api.agencycopilot.models.internal.AgentInformationVO;
import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import lombok.Data;

@Data
public class ApplicationStatusRequest {

    //private String token;
    private AgentInformationVO agentInformation;
    private FilterCriteriaVO filterCriteria;

    @JsonIgnore
    private boolean defaultFilter;

}
