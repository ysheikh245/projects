package com.pm.api.agencycopilot.models.internal;

import com.pm.api.agencycopilot.models.external.customers.ExternalReferenceListItem;
import com.pm.api.agencycopilot.models.external.customers.PersonNameListItem;
import java.util.List;
import lombok.Data;

@Data
public class CustomersVO {
    private String fullName;
    private String firstName;
    private String middleName;
    private String lastName;
    private String partyId;
    private String role;
    private String gender;
    private String phoneNumber;
    private String secondaryPhoneNumber;
    private String emailAddress;
    private String birthDate;
    private AddressVO homeAddress;
    private AddressVO tempAddress;
    private List<PersonNameListItem> personNameList;
    private List<ExternalReferenceListItem> externalReferenceList;
    private String policyNumber;
    private List<PolicyVO> policies;
}
