package com.pm.api.agencycopilot.services.impl;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.SalesCustomerSearchRequest;
import com.pm.api.agencycopilot.models.apis.SalesSearchRequest;
import com.pm.api.agencycopilot.models.external.customers.SearchParams;
import com.pm.api.agencycopilot.models.external.sales.FindSalesCustomerByPolicyResponse;
import com.pm.api.agencycopilot.services.SalesCustomerServiceHandler;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SalesCustomerServiceHandlerImpl implements SalesCustomerServiceHandler {

	
	 @Value("${agency.copilot.pmapi.sales.username}")
	 private String pmapiSalesUserName;
	
	 @Value("${agency.copilot.pmapi.sales.password}")
	 private String pmapiSalesPassword;
	 
	@Value("${agency.copilot.pmapi.sales.search.url}")
	private String pmapiSalesSearchURL;
	
	@Value("${agency.copilot.sales.api.client.header}")
	private String pmapiSalesSearchClientHeader;
	
	@Value("${agency.copilot.sales.api.end.userid}")
	private String pmapiSalesSearchClientUserId;
	
    @Autowired
    private RestHelperServiceImpl restHelperService;
    
    
	@Override
	public FindSalesCustomerByPolicyResponse invokeSalesCustomerPMAPIByPolicy(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npn) {
		    log.info("Entering invokeSalesCustomerPMAPIByPolicy at {}", LocalDateTime.now());
	        HttpHeaders headers = getHttpHeaders();
	        
	        HttpEntity request = new HttpEntity(getSalesSearchPayLoad(policyByCustomerDetailsRequest,npn), headers);

	        ResponseEntity<FindSalesCustomerByPolicyResponse> response = restHelperService.invoke(pmapiSalesSearchURL,
	                HttpMethod.POST,
	                request,
	                FindSalesCustomerByPolicyResponse.class);
	        log.info("Exiting invokeCustomerV2PMAPISearch at {}", LocalDateTime.now());
	        if( response.getStatusCode().equals(HttpStatus.OK)) {
	        	return response.getBody();
	        }
	        else 
	        	return null;
	}
	@Override
	public FindSalesCustomerByPolicyResponse invokeSalesCustomerPMAPIByPolicyNumber(String  policyNumber, String npn) {
		log.info("Entering invokeSalesCustomerPMAPIByPolicy at {}", LocalDateTime.now());
        HttpHeaders headers = getHttpHeaders();
        
        HttpEntity request = new HttpEntity(getSalesSearchPayLoadByPolicyNumber(policyNumber,npn), headers);

        ResponseEntity<FindSalesCustomerByPolicyResponse> response = restHelperService.invoke(pmapiSalesSearchURL,
                HttpMethod.POST,
                request,
                FindSalesCustomerByPolicyResponse.class);
        log.info("Exiting invokeCustomerV2PMAPISearch at {}", LocalDateTime.now());
        if( response.getStatusCode().equals(HttpStatus.OK)) {
        	return response.getBody();
        }
        else 
        	return null;
		
	}
	private HttpHeaders getHttpHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.add("client-header", pmapiSalesSearchClientHeader);
	    headers.add("end-user-id", pmapiSalesSearchClientUserId);
	    headers.add("Content-type", "application/json");
	    headers.add("Authorization", getBasicAuthToken(pmapiSalesUserName, pmapiSalesPassword));
		return headers;
	}
	private SalesCustomerSearchRequest getSalesSearchPayLoad(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npn) {
		SalesCustomerSearchRequest requestData = new SalesCustomerSearchRequest();
        requestData.setNpn(npn);
        SalesSearchRequest searchRequest=new SalesSearchRequest();
        SearchParams searchParams = new SearchParams();
        if (policyByCustomerDetailsRequest.getType().equals(CustomerDetailsRequestType.SEARCH_BY_POLICY)) {
        	searchRequest.setType("searchByPolicy");
            searchParams.setPolicy(policyByCustomerDetailsRequest.getPolicyNumber());
        } else {
        	searchRequest.setType("searchByDynamicCriteria");
            searchParams.setFirstName(policyByCustomerDetailsRequest.getFirstName());
            searchParams.setLastName(policyByCustomerDetailsRequest.getLastName());
            searchParams.setState(policyByCustomerDetailsRequest.getState());
            searchParams.setZipCode(policyByCustomerDetailsRequest.getZip());
            searchParams.setDateOfBirth(policyByCustomerDetailsRequest.getDateOfBirth());
        }
        searchRequest.setSearchParams(searchParams);
        requestData.setSearchRequest(searchRequest);
        return requestData;
	}
	private SalesCustomerSearchRequest getSalesSearchPayLoadByPolicyNumber(String policyNumber, String npn) {
		SalesCustomerSearchRequest requestData = new SalesCustomerSearchRequest();
        requestData.setNpn(npn);
        SalesSearchRequest searchRequest=new SalesSearchRequest();
        SearchParams searchParams = new SearchParams();
        searchRequest.setType("searchByPolicy");
        searchParams.setPolicy(policyNumber);
        searchRequest.setSearchParams(searchParams);
        requestData.setSearchRequest(searchRequest);
        return requestData;
	}

}
