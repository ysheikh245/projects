package com.pm.api.agencycopilot.models.external.pmapi2;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PolicyV2Response {

	@JsonProperty("response")
	private List<Policy> policies;

	/*public List<ResponseItem> getResponse(){
		return response;
	}*/
}