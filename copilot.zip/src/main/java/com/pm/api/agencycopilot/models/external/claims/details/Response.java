package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
public class Response{

	@JsonProperty("response")
	private Response response;

	@JsonProperty("diagnosis")
	private List<DiagnosisItem> diagnosis;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	@JsonProperty("medSupDeductible")
	private Object medSupDeductible;

	@JsonProperty("accidentSickness")
	private String accidentSickness;

	@JsonProperty("lineItems")
	private List<LineItemsItem> lineItems;

	@JsonProperty("claimType")
	private String claimType;

	@JsonProperty("lastUpdatedDate")
	private String lastUpdatedDate;

	@JsonProperty("noticeDate")
	private String noticeDate;

	@JsonProperty("claimantName")
	private String claimantName;

	@JsonProperty("checkDigit")
	private String checkDigit;

	@JsonProperty("claimNumber")
	private String claimNumber;

	@JsonProperty("claimStatus")
	private String claimStatus;

	@JsonProperty("age")
	private String age;

	@JsonProperty("payees")
	private List<Payee> payees;

	@JsonProperty("claimPayments")
	private List<ClaimPayment> claimPayments;
}