package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SavingsByDiscTabPetItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CDiscountCode")
	private String cDiscountCode;

	@JsonProperty("CPiSavingByDiscTab")
	private String cPiSavingByDiscTab;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CDiscount")
	private String cDiscount;

	@JsonProperty("CAnnualSavings")
	private String cAnnualSavings;

	@JsonProperty("CDiscRate")
	private String cDiscRate;

	public String getEntityType(){
		return entityType;
	}

	public String getCDiscountCode(){
		return cDiscountCode;
	}

	public String getCPiSavingByDiscTab(){
		return cPiSavingByDiscTab;
	}

	public String getGid(){
		return gid;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCDiscount(){
		return cDiscount;
	}

	public String getCAnnualSavings(){
		return cAnnualSavings;
	}

	public String getCDiscRate(){
		return cDiscRate;
	}
}