package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PMAPIPolicy{

	@JsonProperty("Policy")
	private Policy policy;

	@JsonProperty("PolicyStatus")
	private PolicyStatus policyStatus;

	public Policy getPolicy(){
		return policy;
	}

	public PolicyStatus getPolicyStatus(){
		return policyStatus;
	}
}