package com.pm.api.agencycopilot.controller;

import org.apache.commons.lang3.StringUtils;

public class Test {

    public static void main(String[] args) {

        //final String MESSAGE = "{\"status\": \"{0}\"}";
        final String URI = "mongodb://%s:%s@%s:%s/";

        //System.out.println(StringUtils.replace(MESSAGE, "{0}", "SUCCESS"));
        System.out.println(String.format(URI, "a", "b", "c", "d"));
    }

}
