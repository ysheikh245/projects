package com.pm.api.agencycopilot.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping({ "/web", "/api"} )
public interface ApplicationController {
}
