package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PetRatingItem{

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("CMedBaseRate")
	private String cMedBaseRate;

	@JsonProperty("CSeq")
	private String cSeq;

	@JsonProperty("CPiCovPetRt")
	private String cPiCovPetRt;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CAgeFtr")
	private String cAgeFtr;

	@JsonProperty("CBaseRate")
	private String cBaseRate;

	@JsonProperty("CPetFinalPbrPremium")
	private String cPetFinalPbrPremium;

	@JsonProperty("CRatingFunction")
	private String cRatingFunction;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CCoverageCode")
	private String cCoverageCode;

	@JsonProperty("CAccidentOnlyFtr")
	private String cAccidentOnlyFtr;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("CDeductFtr")
	private String cDeductFtr;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("CBreedFtr")
	private String cBreedFtr;

	@JsonProperty("CRatingFormula")
	private String cRatingFormula;

	@JsonProperty("CPerInciCopay")
	private String cPerInciCopay;

	@JsonProperty("CPetTransEffectDt")
	private String cPetTransEffectDt;

	@JsonProperty("CTrendFactor")
	private String cTrendFactor;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("CCoinsuranceFtr")
	private String cCoinsuranceFtr;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("CAreaFtr")
	private String cAreaFtr;

	public String getCCoverage(){
		return cCoverage;
	}

	public String getCMedBaseRate(){
		return cMedBaseRate;
	}

	public String getCSeq(){
		return cSeq;
	}

	public String getCPiCovPetRt(){
		return cPiCovPetRt;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCAgeFtr(){
		return cAgeFtr;
	}

	public String getCBaseRate(){
		return cBaseRate;
	}

	public String getCPetFinalPbrPremium(){
		return cPetFinalPbrPremium;
	}

	public String getCRatingFunction(){
		return cRatingFunction;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCCoverageCode(){
		return cCoverageCode;
	}

	public String getCAccidentOnlyFtr(){
		return cAccidentOnlyFtr;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getCDeductFtr(){
		return cDeductFtr;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getCBreedFtr(){
		return cBreedFtr;
	}

	public String getCRatingFormula(){
		return cRatingFormula;
	}

	public String getCPerInciCopay(){
		return cPerInciCopay;
	}

	public String getCPetTransEffectDt(){
		return cPetTransEffectDt;
	}

	public String getCTrendFactor(){
		return cTrendFactor;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getCCoinsuranceFtr(){
		return cCoinsuranceFtr;
	}

	public String getRiskState(){
		return riskState;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}

	public String getCAreaFtr(){
		return cAreaFtr;
	}
}