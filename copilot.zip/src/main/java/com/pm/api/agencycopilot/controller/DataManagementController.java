package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.models.external.case360.Case360WorksheetResponse;
import com.pm.api.agencycopilot.models.external.case360.FmsRowSetTO;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.repository.ContentStackProductCategoryRepository;
import com.pm.api.agencycopilot.repository.PolicyCategoriesRepository;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.services.ApplicationStatusService;
import com.pm.api.agencycopilot.services.Case360ServiceHandler;
import com.pm.api.agencycopilot.services.PolicyServiceHandler;
import java.util.List;
import java.util.Map;

import com.pm.api.agencycopilot.utility.JSONUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
//@RequestMapping("/data")
public class DataManagementController implements ApplicationController {

    @Autowired
    private ApplicationStatusService applicationStatusService;

    @Autowired
    private PolicyServiceHandler policyServiceHandler;

    @Autowired
    private PolicyCategoriesRepository policyCategoriesRepository;

    @Autowired
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Autowired
    private ContentStackProductCategoryRepository contentStackProductCategoryRepository;

    @Autowired
    private Case360ServiceHandler case360ServiceHandler;


    @GetMapping("/data/application-status/{npn}")
    public ResponseEntity<Map<String, List<PolicyVO>>> testRretrieveApplicationStatusByNPN(
            @PathVariable("npn") String npn,
            @RequestParam(defaultValue = "#{@applicationStatusProperties.defaultPageNo}") Integer pageNo,
            @RequestParam(defaultValue = "#{@applicationStatusProperties.defaultPageSize}") Integer pageSize) {
        Map<String, List<PolicyVO>> policyVOList = applicationStatusService.retrieveApplicationStatusByNPN(npn, pageNo, pageSize);

        if (!CollectionUtils.isEmpty(policyVOList)) {
            return ResponseEntity.ok().body(policyVOList);
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/data/application-status/policyCategories")
    public ResponseEntity<List<PolicyCategoriesRecord>> insertPolicyCategoriesRecords(
            @RequestBody List<PolicyCategoriesRecord> policyCategoriesRecordsRequest) {

        List<PolicyCategoriesRecord> policyCategoriesRecordList =
                applicationStatusService.insertPolicyCategoriesRecords(policyCategoriesRecordsRequest);

        return new ResponseEntity<List<PolicyCategoriesRecord>>(policyCategoriesRecordList, HttpStatus.OK);

    }

    @GetMapping("/data/application-status/policyCategories/{statusCode}/{isActive}")
    public ResponseEntity<PolicyCategoriesRecord> getPolicyCategoriesFromCache(
            @PathVariable("statusCode") String statusCode, @PathVariable(name = "isActive") boolean isActive) {

        return new ResponseEntity<PolicyCategoriesRecord>(
                policyCategoriesRepository.findByCodeAndIsActive(statusCode, isActive), HttpStatus.OK);

    }

    @GetMapping("/data/application-status/productCategories")
    public ResponseEntity<List<ProductTypeCategoriesRecord>> insertProductTypeCategories(
            @RequestBody List<ProductTypeCategoriesRecord> productTypeCategoriesRecords) {

        List<ProductTypeCategoriesRecord> policyCategoriesRecordList =
                applicationStatusService.insertProductTypeCategoriesRecords(productTypeCategoriesRecords);

        return new ResponseEntity<List<ProductTypeCategoriesRecord>>(policyCategoriesRecordList, HttpStatus.OK);

    }

    @GetMapping("/data/application-status/productCategories/{productCode}/{isActive}")
    public ResponseEntity<ProductTypeCategoriesRecord> fetchProductTypeCategories(
            @PathVariable("productCode") String statusCode, @PathVariable(name = "isActive") boolean isActive,
            @RequestAttribute(name = "npnId") String npnId) {
        return new ResponseEntity<ProductTypeCategoriesRecord>(
                productTypeCategoriesRepository.findByProductCodeAndIsActive(statusCode, isActive), HttpStatus.OK);

    }

    @GetMapping("/data/application-status/contentstack")
    public ResponseEntity<List<ContentStackProductCategory>> testFetchContentStackProductCategory() {
        return new ResponseEntity(contentStackProductCategoryRepository.findAll(), HttpStatus.OK);

    }

    @GetMapping("/data/application-status/worksheet-detail/")
    public List<Case360DocumentVO> testWorksheetRequirementDetails(@RequestBody String requestBody) throws Exception {
        Case360WorksheetResponse case360WorksheetResponse = JSONUtility.convertStringToObject(requestBody, Case360WorksheetResponse.class);
        return case360ServiceHandler.getRequirementsDocumentList(case360WorksheetResponse);
    }
}
