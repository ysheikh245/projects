package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class InteractionReason {

    @JsonProperty("interactionReasonId")
    private int interactionReasonId;

    @JsonProperty("reasonNumber")
    private String reasonNumber;

    @JsonProperty("cdreason")
    private Cdreason cdreason;

    @JsonProperty("interactionReasonsSubType")
    private List<InteractionReasonsSubTypeItem> interactionReasonsSubType;

}