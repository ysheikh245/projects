package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.BeneficiaryDetailsResponse;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.DiscountsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyAdditionalCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.PolicyCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyRateChangeResponse;
import com.pm.api.agencycopilot.models.enums.ClaimTypeEnum;
import com.pm.api.agencycopilot.models.external.claims.ClaimsResponseItem;
import com.pm.api.agencycopilot.models.external.claims.details.ClaimPayment;
import com.pm.api.agencycopilot.models.external.claims.details.LineItemsItem;
import com.pm.api.agencycopilot.models.external.claims.details.Response;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyDiscounts;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyRateChange;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.external.sales.FindSalesCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.internal.*;
import com.pm.api.agencycopilot.models.mongodb.NPNPolicyListCacheRecord;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.ClaimsVO;
import com.pm.api.agencycopilot.models.internal.CoverageDetailsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.ClaimsServiceHandler;
import com.pm.api.agencycopilot.services.DocumentsServiceHandler;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import com.pm.api.agencycopilot.services.PolicyDBServiceHandler;
import com.pm.api.agencycopilot.services.SalesCustomerServiceHandler;
import com.pm.api.agencycopilot.services.FACIService;
import com.pm.api.agencycopilot.transformer.PolicyDetailTransformer;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.AGENT_ROLES_INFO;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.DEPENDENT_DETAILS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.POLICY_ALERTS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.POLICY_DATA;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.POLICY_DOCUMENTS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.ROLE_INFO;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;

import com.pm.api.agencycopilot.utility.ClaimStatusCodeMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;


@Service
@Slf4j
public class FACIServiceImpl implements FACIService {
    @Autowired
    PolicyDetailTransformer policyDetailTransformer;

    @Autowired
    PolicyServiceHandlerImpl policyServiceHandler;

    @Autowired
    DocumentsServiceHandler pmapiDocumentsServiceHandler;

    @Autowired
    CustomersServiceHandlerImpl customersServiceHandler;

    @Autowired
    ClaimsServiceHandler claimsServiceHandler;

    @Autowired
    private PolicyDBServiceHandler policyDBServiceHandler;

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private ClaimStatusCodeMap claimStatusCodeMap;
    
    @Autowired
    private  SalesCustomerServiceHandler salesCustomerServiceHandler;

    @Override
    public AdditionalDetailsCountVO getAdditionalDetailsCountVO(String policyNumber) throws Exception {
        log.info("Entering getAdditionalDetailsCountVO at {}", LocalDateTime.now());
        LocalDateTime start = LocalDateTime.now();
        Map<String, String> currentMDCContextMap = MDC.getCopyOfContextMap();
        Map<String, Future> futures = new HashMap();

        ExecutorService executorService = getExecutorService();
        futures.put(POLICY_DATA, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            return policyServiceHandler.getPolicyDataFromPMAPI(
                    policyNumber,
                    Arrays.asList("discounts", "offers", "rateChanges")
            );
        }));
        futures.put(DEPENDENT_DETAILS, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            return policyServiceHandler.getDependentDetails(policyNumber);
        }));
        futures.put(ROLE_INFO, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            return policyServiceHandler.getRolesInfo(policyNumber);
        }));
        futures.put(POLICY_DOCUMENTS, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            return pmapiDocumentsServiceHandler.getPolicyDocuments(policyNumber);
        }));
        futures.put(AGENT_ROLES_INFO, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            return policyServiceHandler.getAgentRolesInfo(policyNumber);
        }));
        futures.put(POLICY_ALERTS, executorService.submit(() -> {
            MDC.setContextMap(currentMDCContextMap);
            DocumentsV2Response<PolicyAlertResponse> policyAlertResponse = null;
            try {
                policyAlertResponse =
                        getPolicyAlerts(policyNumber);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
            return policyAlertResponse;
        }));

        AdditionalDetailsCountVO additionalDetailsCountVO = policyDetailTransformer.getAdditionalDetailsCountVO(
                policyNumber,
                (DependentsV2Reponse) futures.get(DEPENDENT_DETAILS).get(),
                (PolicyV2Response) futures.get(POLICY_DATA).get(),
                (PolicyInfoV2Response<Role>) futures.get(ROLE_INFO).get(),
                (PolicyInfoV2Response<AgentRole>) futures.get(AGENT_ROLES_INFO).get(),
                (DocumentsV2Response<DocumentsResponse>) futures.get(POLICY_DOCUMENTS).get(),
                (DocumentsV2Response<PolicyAlertResponse>) futures.get(POLICY_ALERTS).get());

        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the request is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getAdditionalDetailsCountVO at {}", LocalDateTime.now());
        return additionalDetailsCountVO;
    }

    @NotNull
    private ExecutorService getExecutorService() {
        return Executors.newFixedThreadPool(10);
    }

    @Override
    public DocumentsV2Response<DocumentsResponse> getPolicyDocumentDetails(String policyNumber) throws Exception {
        log.info("Entering getPolicyDocumentDetails at {}", LocalDateTime.now());
        DocumentsV2Response policyDocumentDetailsResponse = pmapiDocumentsServiceHandler.getPolicyDocuments(policyNumber);
        if (policyDocumentDetailsResponse == null) {
            throw new AgencyCoPilot4xxException(
                    String.format("No Policy Document Details found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getPolicyDocumentDetails at {}", LocalDateTime.now());
        return policyDocumentDetailsResponse;
    }

    @Override
    public PolicyVO getPMAPIPolicyDetails(String policyNumber) throws Exception {
        log.info("Entering getPMAPIPolicyDetails at {}", LocalDateTime.now());
        PolicyV2Response policyDetailsResponse = policyServiceHandler.getPolicyDetails(policyNumber);
        if (policyDetailsResponse == null) {
            throw new AgencyCoPilot4xxException(
                    String.format("No policy details found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getPMAPIPolicyDetails at {}", LocalDateTime.now());
        return policyDetailTransformer.tranfromPMAPIToPolicyDetail(
                policyDetailsResponse,
                policyNumber
        );
    }

    @Override
    public PolicyInfoV2Response<AgentRole> getAgentRoleInfo(String policyNumber) throws Exception {
        log.info("Entering getAgentRoleInfo at {}", LocalDateTime.now());
        PolicyInfoV2Response<AgentRole> agentRoleInfoResponse = policyServiceHandler.getAgentRolesInfo(policyNumber);
        if (agentRoleInfoResponse == null) {
            throw new AgencyCoPilot4xxException(
                    String.format("No Agent role info found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getAgentRoleInfo at {}", LocalDateTime.now());
        return agentRoleInfoResponse;
    }

    @Override
    public PolicyInfoV2Response<Role> getPolicyRoleInfo(String policyNumber) throws Exception {
        log.info("Entering getPolicyRoleInfo at {}", LocalDateTime.now());
        PolicyInfoV2Response<Role> rolePolicyInfoV2Response = policyServiceHandler.getRolesInfo(policyNumber);
        if (rolePolicyInfoV2Response == null) {
            throw new AgencyCoPilot4xxException(
                    String.format("No Policies found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getPolicyRoleInfo at {}", LocalDateTime.now());
        return rolePolicyInfoV2Response;
    }

    @Override
    public DependentsV2Reponse getDependentsInfo(String policyNumber) throws Exception {
        log.info("Entering getDependentsInfo at {}", LocalDateTime.now());
        DependentsV2Reponse dependentsInfoResponse = policyServiceHandler.getDependentDetails(policyNumber);
        if (dependentsInfoResponse == null) {
            throw new AgencyCoPilot4xxException(
                    String.format("No dependents info found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getDependentsInfo at {}", LocalDateTime.now());
        return dependentsInfoResponse;
    }

    @Override
    public DiscountsResponse getDiscountsInfo(String policyNumber) throws Exception {
        log.info("Entering getDiscountsInfo at {}", LocalDateTime.now());
        List<PolicyDiscounts> discountsInfoResponse = policyServiceHandler.getPolicyDiscounts(policyNumber);

        if (discountsInfoResponse == null) {
            log.info("Exiting getDiscountsInfo at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No discounts info found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        DiscountsResponse discountsInfo = new DiscountsResponse();
        discountsInfo.setDiscounts(discountsInfoResponse);
        log.info("Exiting getDiscountsInfo at {}", LocalDateTime.now());
        return discountsInfo;
    }

    @Override
    public PolicyRateChangeResponse getRateChangesInfo(String policyNumber) throws Exception {
        log.info("Entering getRateChangesInfo at {}", LocalDateTime.now());
        List<PolicyRateChange> pmapiPolicyRateChangesResponse = policyServiceHandler.getPolicyRateChanges(policyNumber);
        if (pmapiPolicyRateChangesResponse == null) {
            log.info("Exiting getRateChangesInfo at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No rate changes found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        PolicyRateChangeResponse policyRateChangeResponse = new PolicyRateChangeResponse();
        policyRateChangeResponse.setRateChanges(pmapiPolicyRateChangesResponse);
        log.info("Exiting getRateChangesInfo at {}", LocalDateTime.now());
        return policyRateChangeResponse;
    }

    @Override
    public PolicyCoverageDetailsResponse getPolicyCoverageDetails(String policyNumber) throws Exception {
        log.info("Entering getPolicyCoverageDetails at {}", LocalDateTime.now());
        List<CoverageDetailsVO> policyCoverageDetailsResponse = policyServiceHandler.getPolicyCoverageDetails(policyNumber);
        if (policyCoverageDetailsResponse == null) {
            log.info("Exiting getPolicyCoverageDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No policy coverage details found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        PolicyCoverageDetailsResponse policyCoverageDetails = new PolicyCoverageDetailsResponse();
        policyCoverageDetails.setCoverageDetails(policyCoverageDetailsResponse);
        log.info("Exiting getPolicyCoverageDetails at {}", LocalDateTime.now());
        return policyCoverageDetails;
    }

    /**
     * Retrieves a list of customer details associated with a policy based on the provided criteria.
     *
     * @param policyByCustomerDetailsRequest The request object containing the criteria for retrieving customer details.
     * @return A list of customer value objects (VO) representing the customer details.
     * @throws Exception If an error occurs during the retrieval process.
     */
    @Override
    public List<CustomersVO> getPolicyByCustomerDetails(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npnId) throws Exception {

        FindCustomerByPolicyResponse policyByCustomerDetailsResponse = null;
        HashSet<String> policiesForNPN = null;

        try {
            CompletableFuture<FindCustomerByPolicyResponse> policyByCustomerDetailsFuture = CompletableFuture.supplyAsync(() -> {
                return customersServiceHandler.invokeCustomerV2PMAPISearch(policyByCustomerDetailsRequest);
            });

            CompletableFuture<HashSet<String>> policiesForNPNFuture = CompletableFuture.supplyAsync(() -> {
                return getPolicyNumberListForNPN(npnId);
            });

            policyByCustomerDetailsResponse = policyByCustomerDetailsFuture.get();
            policiesForNPN = policiesForNPNFuture.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new AgencyCoPilot4xxException(
                    String.format("Unknown Error Occured"),
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "");
        }

        if (policyByCustomerDetailsResponse == null) {
            log.info("Exiting getPolicyByCustomerDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No Policies found for given customer details %s", policyByCustomerDetailsRequest.toString()),
                    HttpStatus.NOT_FOUND,
                    "");
        }

        List<CustomersVO> customerResponse =  policyDetailTransformer.transformPMAPIToCustomersDetails(
                policyByCustomerDetailsResponse,
                policyByCustomerDetailsRequest.getType(),
                policyByCustomerDetailsRequest.getPolicyNumber()
        );

        if (!isNPNAndPolicyMatch(customerResponse, policiesForNPN)) {
            if (CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS.equals(policyByCustomerDetailsRequest.getType())) {
                throw new AgencyCoPilot4xxException(
                        String.format("No Policies found for given customer details %s", policyByCustomerDetailsRequest.toString()),
                        HttpStatus.NOT_FOUND,
                        "");
            } else {
                throw new AgencyCoPilot4xxException(
                        String.format("UNAUTHORIZED Access to Given Policy Not allowed %s", policyByCustomerDetailsRequest.toString()),
                        HttpStatus.FORBIDDEN,
                        "");
            }
        }
        return customerResponse;
    }
    
    public List<CustomersVO> getPolicyBySalesCustomerDetails(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npnId) throws Exception{
    	FindSalesCustomerByPolicyResponse policyByCustomerDetailsResponse=salesCustomerServiceHandler.invokeSalesCustomerPMAPIByPolicy(policyByCustomerDetailsRequest, npnId);
    	if(policyByCustomerDetailsResponse==null) {
    		if (CustomerDetailsRequestType.SEARCH_BY_CUSTOMER_DETAILS.equals(policyByCustomerDetailsRequest.getType())) {
                throw new AgencyCoPilot4xxException(
                        String.format("No Policies found for given customer details %s", policyByCustomerDetailsRequest.toString()),
                        HttpStatus.NOT_FOUND,
                        "");
            } else {
                throw new AgencyCoPilot4xxException(
                        String.format("UNAUTHORIZED Access to Given Policy Not allowed %s", policyByCustomerDetailsRequest.toString()),
                        HttpStatus.FORBIDDEN,
                        "");
            }
    	}
    	List<CustomersVO> customerResponse=policyDetailTransformer.transformSalesPMAPIToCustomersDetails(policyByCustomerDetailsResponse,policyByCustomerDetailsRequest.getType(), policyByCustomerDetailsRequest.policyNumber);
    	if(CollectionUtils.isEmpty(customerResponse)){
    		throw new AgencyCoPilot4xxException(
                    String.format("No Policies found for given customer details %s", policyByCustomerDetailsRequest.toString()),
                    HttpStatus.NOT_FOUND,"");
    	}
    	return customerResponse;
    }

    @Override
    public CustomersVO getCustomerContactDetails(String policyNumber, String partyId) throws Exception {
        log.info("Entering getCustomerContactDetails at {}", LocalDateTime.now());
        FindCustomerByPolicyResponse customerContactDetailsResponse = customersServiceHandler.invokeCustomerV2PMAPIByPolicy(policyNumber);
        if (customerContactDetailsResponse == null) {
            log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No Customer Contact Details found for given policyNumber %s and partyId %s", policyNumber, partyId),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        CustomersVO response = policyDetailTransformer.transformPMAPIToCustomersContactDetail(
                customerContactDetailsResponse,
                partyId,
                policyNumber
        );
        if (!CollectionUtils.isEmpty(response.getPolicies())) {
            List<PolicyVO> policies = response.getPolicies().stream().map(p -> {
                try {
                    PolicyVO policyData = getPMAPIPolicyDetails(p.getPolicyNumber());
                    p.setProductName(policyData.getProductName());
                } catch (AgencyCoPilot4xxException e) {
                    log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
                    return null;
                } catch (Exception e) {
                    log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
                    throw new AgencyCoPilot5xxException(e, HttpStatus.INTERNAL_SERVER_ERROR, "");
                }
                log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
                return p;
            }).collect(Collectors.toList());
            response.setPolicies(policies.stream().filter(p -> p != null).collect(Collectors.toList()));
            log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
            return response;
        } else {
            log.info("Exiting getCustomerContactDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No Customer Contact Details found for given policyNumber %s and partyId %s", policyNumber, partyId),
                    HttpStatus.NOT_FOUND,
                    "");
        }
    }

    @Override
    public BeneficiaryDetailsResponse getBeneficiaryDetails(String policyNumber) throws Exception {
        log.info("Entering getBeneficiaryDetails at {}", LocalDateTime.now());
        List<BeneficiaryDetails> beneficiaryDetailsResponse = policyServiceHandler.getBeneficiaryDetails(policyNumber);
        if (beneficiaryDetailsResponse == null || beneficiaryDetailsResponse.isEmpty()) {
            log.info("Exiting getBeneficiaryDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No beneficiary details found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        BeneficiaryDetailsResponse beneficiaryDetailsAPIResponse = new BeneficiaryDetailsResponse();
        beneficiaryDetailsAPIResponse.setBeneficiaryDetails(beneficiaryDetailsResponse);
        log.info("Exiting getBeneficiaryDetails at {}", LocalDateTime.now());
        return beneficiaryDetailsAPIResponse;
    }

    @Override
    public PolicyAdditionalCoverageDetailsResponse getAdditionalCoverages(String policyNumber) throws Exception {
        log.info("Entering getAdditionalCoverages at {}", LocalDateTime.now());
        List<AdditionalCoverage> additionalCoveragesResponse = policyServiceHandler.getAdditionalCoverages(policyNumber);
        if (additionalCoveragesResponse == null || additionalCoveragesResponse.isEmpty()) {
            log.info("Exiting getAdditionalCoverages at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No additional coverages found for given policy number %s", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        PolicyAdditionalCoverageDetailsResponse policyAdditionalCoverageDetailsResponse = new PolicyAdditionalCoverageDetailsResponse();
        policyAdditionalCoverageDetailsResponse.setAdditionalCoverages(additionalCoveragesResponse);
        log.info("Exiting getAdditionalCoverages at {}", LocalDateTime.now());
        return policyAdditionalCoverageDetailsResponse;
    }

    @Override
    public DocumentsV2Response<PolicyAlertResponse> getPolicyAlerts(String policyNumber) throws Exception {
        log.info("Entering getPolicyAlerts at {}", LocalDateTime.now());
        LocalDateTime start = LocalDateTime.now();
        String partyId = customersServiceHandler.findPartyId(policyNumber);
        LocalDateTime endFindPartyId = LocalDateTime.now();
        log.info("Timetaken to complete the findPartyId is {}", Duration.between(start, endFindPartyId).toMillis());

        if (StringUtils.isNotEmpty(partyId)) {
            DocumentsV2Response<PolicyAlertResponse> documentsV2Response = customersServiceHandler.getPolicyAlerts(partyId);
            if (documentsV2Response != null) {
                LocalDateTime end = LocalDateTime.now();
                log.info("Timetaken to complete the getPolicyAlerts is {}", Duration.between(start, end).toMillis());
                log.info("Exiting getPolicyAlerts at {}", LocalDateTime.now());
                return documentsV2Response;
            }
        } else {
            LocalDateTime end = LocalDateTime.now();
            log.info("Timetaken to complete the getPolicyAlerts is {}", Duration.between(start, end).toMillis());
            log.info("Exiting getPolicyAlerts at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("PartyId not found for policy number %s in PMAPI", policyNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the getPolicyAlerts is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getPolicyAlerts at {}", LocalDateTime.now());
        return null;
    }

    @Override
    public List<ClaimsVO> getAllClaimsFromPolicy(String policyNumber, String npnId) {
        log.info("Entering getAllClaimsFromPolicy at {}", LocalDateTime.now());
        FindSalesCustomerByPolicyResponse policyByCustomerDetailsResponse=salesCustomerServiceHandler.invokeSalesCustomerPMAPIByPolicyNumber(policyNumber, npnId);
        if (policyByCustomerDetailsResponse == null) {
            log.info("Exiting policies for npn at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("UNAUTHORIZED Access to Given PolicyNumber %s", policyNumber),
                    HttpStatus.FORBIDDEN,
                    "");
        } 
        else {
        	List<CustomersVO> customerResponse=policyDetailTransformer.transformSalesPMAPIToCustomersDetails(policyByCustomerDetailsResponse,CustomerDetailsRequestType.SEARCH_BY_POLICY, policyNumber);
        	if(CollectionUtils.isEmpty(customerResponse)){
        		throw new AgencyCoPilot4xxException(
                        String.format("No Policies found for given customer details %s", policyNumber),
                        HttpStatus.NOT_FOUND,"");
        	}
        }
        
        List<ClaimsVO> claims = new ArrayList<>();
        String partyId = customersServiceHandler.findPartyId(policyNumber);
        if (StringUtils.isNotBlank(partyId)) {
            List<ClaimsResponseItem> applicableClaims = claimsServiceHandler.getClaimsFromPartyId(partyId);
            if (!CollectionUtils.isEmpty(applicableClaims)) {
                claims.addAll(mapPMAPIClaimsResponse(policyNumber, applicableClaims));
            } else {
                log.info("Exiting getAllClaimsFromPolicy at {}", LocalDateTime.now());
                throw new AgencyCoPilot4xxException(
                        String.format("PartyId not found for policy number %s in PMAPI", policyNumber),
                        HttpStatus.NOT_FOUND,
                        "");
            }
        }

        log.info("Exiting getAllClaimsFromPolicy at {}", LocalDateTime.now());
        return claims;
    }

    private HashSet<String> getPolicyNumberListForNPN(String npnId) {
        HashSet<String> policySet = new HashSet<>();
        List<String> policies = new ArrayList<String>();
        NPNPolicyListCacheRecord npnPolicyListCache = mongoDBCacheHandler.findPolicyListByNPN(npnId); // 7542517
        if (npnPolicyListCache != null && !CollectionUtils.isEmpty(npnPolicyListCache.getPolicies())) {
            policies = npnPolicyListCache.getPolicies();
        } else {
            List<PolicyVO> policyVOList = policyDBServiceHandler.getPoliciesByNPN(npnId, null);
            if (policyVOList.size() > 0) {
                policies = policyVOList.stream().map(policy -> StringUtils.trim(policy.getPolicyNumber())).collect(Collectors.toList());
                log.info("***DEBUG***FACI. PolicyList={}", policies);
                mongoDBCacheHandler.insertNPNPolicyListCache(npnId, policies);
            }
        }

        policySet.addAll( policies );
        return policySet;
    }

    private boolean isNPNAndPolicyMatch(List<CustomersVO> customersVOs, HashSet<String> policySet) {
        if (CollectionUtils.isEmpty(customersVOs)) {
            return false;
        }
        for(CustomersVO customersVO: customersVOs) {
            if(policySet.contains(customersVO.getPolicyNumber())) {
                return true;
            }
        }
        return false;
    }

    public ClaimsVO getClaimDetails(String claimNumber, String claimType) {
        log.info("Entering getClaimDetails at {}", LocalDateTime.now());
        ClaimsVO claim = null;
        Response claimResponse = claimsServiceHandler.getClaimDetails(claimNumber);
        if (claimResponse != null) {
            claim = mapClaimResponse(claimResponse.getResponse(), claimType);
        } else {
            log.info("Exiting getClaimDetails at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("claims not found for claim number %s in PMAPI", claimNumber),
                    HttpStatus.NOT_FOUND,
                    "");
        }
        log.info("Exiting getClaimDetails at {}", LocalDateTime.now());
        return claim;
    }

    private ClaimsVO mapClaimResponse(Response claimResponse, String claimType) {
        log.info("Entering mapClaimResponse at {}", LocalDateTime.now());
        ClaimsVO claim = new ClaimsVO();
        if (claimResponse != null) {

            claim.setClaimNumber(claimResponse.getClaimNumber());
            claim.setClaimantName(claimResponse.getClaimantName());
            claim.setClaimStatus(claimResponse.getClaimStatus());
            claim.setDateOfBirth(claimResponse.getDateOfBirth());
            claim.setClaimType(claimResponse.getClaimType());
            //claim.setGender(claimResponse.getGender());
            //claim.setClaimRcvdDate(claimResponse.getClaimRcvdDate());
            //claim.setBenefitPeriod(claimResponse.getBenefitPeriod());
            //claim.setPayees(getPayeeInformation(claimResponse));
            List<ClaimsVO.Payee> payees = new ArrayList<>();

            if (ClaimTypeEnum.HEALTH == ClaimTypeEnum.valueOf(claimResponse.getClaimType())) {

                List<LineItemsItem> lineItemsWithPayee = claimResponse.getLineItems().stream().
                        filter(lineItemsItem -> lineItemsItem.getPayee() != null &&
                                Double.parseDouble(String.valueOf(lineItemsItem.getAmountPaid())) > 0)
                        .collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(lineItemsWithPayee)) {

                    lineItemsWithPayee.forEach(lineItemsItem -> {
                        ClaimsVO.Payee payee = new ClaimsVO().constructNewPayee();
                        payee.setName(lineItemsItem.getPayee().getName());
                        payee.setAddress1(lineItemsItem.getPayee().getAddress1());
                        payee.setPaymentDate(lineItemsItem.getPayee().getPaymentDate());
                        payee.setCity(lineItemsItem.getPayee().getCity());
                        payee.setState(lineItemsItem.getPayee().getState());
                        payee.setZip(lineItemsItem.getPayee().getZip());
                        payee.setAmountPaid(String.valueOf(lineItemsItem.getPayee().getAmountPaid()));
                        payees.add(payee);
                    });

                }
            } else if (ClaimTypeEnum.LIFE == ClaimTypeEnum.valueOf(claimResponse.getClaimType())) {
                List<ClaimPayment> filteredClaimPayments = claimResponse.getClaimPayments().stream().filter(claimPayment -> Double.parseDouble(claimPayment.getPaidAmount()) > 0).collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(filteredClaimPayments)) {
                    filteredClaimPayments.forEach(claimPayment -> {
                        ClaimsVO.Payee payee = new ClaimsVO().constructNewPayee();
                        payee.setName(claimPayment.getPayeeName());
                        payee.setAddress1(claimPayment.getPayeeAddress());
                        payee.setPaymentDate(claimPayment.getDisbursementDate());
                        payee.setCity(claimPayment.getPayeeCity());
                        payee.setState(claimPayment.getPayeeState());
                        payee.setZip(claimPayment.getPayeeZip());
                        payee.setAmountPaid(String.valueOf(claimPayment.getPaidAmount()));
                        payees.add(payee);
                    });
                }
            }
            if (claimType.equalsIgnoreCase("CLOSED")) {
                claim.setPayees(addPayeesForClosedClaims(claimResponse, payees));
            } else {
                claim.setPayees(payees);
            }
        }
        log.info("Exiting mapClaimResponse at {}", LocalDateTime.now());
        return claim;
    }

    private List<ClaimsVO.Payee> addPayeesForClosedClaims(Response claimResponse, List<ClaimsVO.Payee> payees) {
        List<ClaimsVO.Payee> newPayees = new ArrayList<>();
        List<LineItemsItem> lineItems =  claimResponse.getLineItems();
        if (!CollectionUtils.isEmpty(lineItems)) {
            lineItems.forEach(lineItemsItem -> {
                ClaimsVO.Payee payee = new ClaimsVO().constructNewPayee();
                String codeAndDescription = BLANK;
                if (lineItemsItem.getClaimPaymentStatus().getCode() != null && lineItemsItem.getClaimPaymentStatus().getDescription() != null) {
                    codeAndDescription = lineItemsItem.getClaimPaymentStatus().getCode() + lineItemsItem.getClaimPaymentStatus().getDescription();
                    codeAndDescription = codeAndDescription.toLowerCase().replace(" ", "").replace("-", "");;
                }
                if (lineItemsItem.getPayee() != null) {
                    payee.setName(lineItemsItem.getPayee().getName());
                    payee.setAddress1(lineItemsItem.getPayee().getAddress1());
                    payee.setPaymentDate(lineItemsItem.getPaymentDate());
                    payee.setCity(lineItemsItem.getPayee().getCity());
                    payee.setState(lineItemsItem.getPayee().getState());
                    payee.setZip(lineItemsItem.getPayee().getZip());
                    payee.setAmountPaid(String.valueOf(lineItemsItem.getAmountPaid()));
                    payee.setClaimStatusDescription(claimStatusCodeMap.getDescription(codeAndDescription));
                } else {
                    payee.setName(BLANK);
                    payee.setAddress1(BLANK);
                    payee.setPaymentDate(BLANK);
                    payee.setCity(BLANK);
                    payee.setState(BLANK);
                    payee.setZip(BLANK);
                    payee.setAmountPaid(String.valueOf(lineItemsItem.getAmountPaid()));
                    payee.setClaimStatusDescription(claimStatusCodeMap.getDescription(codeAndDescription));
                }
                newPayees.add(payee);
            });
            payees = newPayees;
        }
        return payees;
    }

    private List<ClaimsVO> mapPMAPIClaimsResponse(String policyNumber, List<ClaimsResponseItem> applicableClaims) {
        log.info("Entering mapPMAPIClaimsResponse at {}", LocalDateTime.now());
        List<ClaimsVO> claims = new ArrayList();

        if (!CollectionUtils.isEmpty(applicableClaims)) {
            List<ClaimsResponseItem> filteredApplicableClaims = applicableClaims.stream()
                    .filter(applicableClaim -> {
                        boolean strictEquality = StringUtils.equals(policyNumber, applicableClaim.getPolicyNumber());
                        boolean strippedEquality = StringUtils.equals(policyNumber.replaceAll("[A-Za-z]", ""), applicableClaim.getPolicyNumber());
                        return strictEquality || strippedEquality;
                    })
                    .collect(Collectors.toList());
            for (ClaimsResponseItem applicableClaim : filteredApplicableClaims) {
                ClaimsVO claim = new ClaimsVO();
                claim.setClaimNumber(applicableClaim.getClaimNumber());
                claim.setPolicyNumber(applicableClaim.getPolicyNumber());
                claim.setBenefitPeriod(applicableClaim.getBenefitPeriod());
                claim.setClaimStatus(applicableClaim.getClaimStatus());
                claims.add(claim);
            }
        }
        log.info("Exiting mapPMAPIClaimsResponse at {}", LocalDateTime.now());
        return claims;
    }
}
