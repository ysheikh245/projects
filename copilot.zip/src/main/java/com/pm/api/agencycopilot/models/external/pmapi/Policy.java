package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Policy{

	@JsonProperty("BookingDate")
	private String bookingDate;

	@JsonProperty("ProductName")
	private String productName;

	@JsonProperty("OldEntityType")
	private String oldEntityType;

	@JsonProperty("TotalFtermFee")
	private String totalFtermFee;

	@JsonProperty("TotalTransFee")
	private String totalTransFee;

	@JsonProperty("RetainBtmFltEndr")
	private String retainBtmFltEndr;

	@JsonProperty("WaivePremium")
	private String waivePremium;

	@JsonProperty("Renewal")
	private String renewal;

	@JsonProperty("TransDisplayName")
	private String transDisplayName;

	@JsonProperty("OnDemandReorder")
	private String onDemandReorder;

	@JsonProperty("CompanyName")
	private String companyName;

	@JsonProperty("TotalAnnualFee")
	private String totalAnnualFee;

	@JsonProperty("PendingCanInd")
	private String pendingCanInd;

	@JsonProperty("RenewalIndicator")
	private String renewalIndicator;

	@JsonProperty("TotalSurchargeFterm")
	private String totalSurchargeFterm;

	@JsonProperty("TransEffectiveDate")
	private String transEffectiveDate;

	@JsonProperty("IsRebind")
	private String isRebind;

	@JsonProperty("OrdCarrReport")
	private String ordCarrReport;

	@JsonProperty("TransactionCode")
	private String transactionCode;

	@JsonProperty("CustomPackVersion")
	private String customPackVersion;

	@JsonProperty("PolicyQuoteIndicator")
	private String policyQuoteIndicator;

	@JsonProperty("TotalTransSurcharge")
	private String totalTransSurcharge;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("BinderFlag")
	private String binderFlag;

	@JsonProperty("NextGenAudited")
	private String nextGenAudited;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("RenewalCounter")
	private String renewalCounter;

	@JsonProperty("NoConflictOnRollfwd")
	private String noConflictOnRollfwd;

	@JsonProperty("BookingUser")
	private String bookingUser;

	@JsonProperty("Insured")
	private List<InsuredItem> insured;

	@JsonProperty("ControlDate")
	private String controlDate;

	@JsonProperty("TransactionAction")
	private String transactionAction;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("LOB_PH")
	private List<LOBPHItem> lOBPH;

	@JsonProperty("TransactionFactor")
	private String transactionFactor;

	@JsonProperty("TotalFtermSurcharge")
	private String totalFtermSurcharge;

	@JsonProperty("Producer")
	private List<ProducerItem> producer;

	@JsonProperty("TotalAnnualSurcharge")
	private String totalAnnualSurcharge;

	@JsonProperty("CAlternatePayor")
	private String cAlternatePayor;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("PrimaryRiskState")
	private String primaryRiskState;

	@JsonProperty("TotalFtermTaxes")
	private String totalFtermTaxes;

	@JsonProperty("TotalFtermColFee")
	private String totalFtermColFee;

	@JsonProperty("DisplayPolicyNumber")
	private String displayPolicyNumber;

	@JsonProperty("TransAccountingMonth")
	private String transAccountingMonth;

	@JsonProperty("AdpPrefill")
	private String adpPrefill;

	@JsonProperty("EndorsementReason")
	private String endorsementReason;

	@JsonProperty("PolTermCode")
	private String polTermCode;

	@JsonProperty("TransAccountingDate")
	private String transAccountingDate;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("ProductVersion")
	private String productVersion;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CompositeRating")
	private String compositeRating;

	@JsonProperty("PolTerm")
	private String polTerm;

	@JsonProperty("TransAccountingYear")
	private String transAccountingYear;

	@JsonProperty("AlternatePayor")
	private List<AlternatePayorItem> alternatePayor;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("OldEntityReference")
	private String oldEntityReference;

	@JsonProperty("BookingStatus")
	private String bookingStatus;

	@JsonProperty("CustomPolicyNumber")
	private String customPolicyNumber;

	@JsonProperty("CustomRevisionNumber")
	private String customRevisionNumber;

	@JsonProperty("MicVersion")
	private String micVersion;

	@JsonProperty("IsComReduct")
	private String isComReduct;

	@JsonProperty("IsSubjectToAudit")
	private String isSubjectToAudit;

	@JsonProperty("PolicyNumber")
	private String policyNumber;

	@JsonProperty("IsRewrite")
	private String isRewrite;

	@JsonProperty("PremiumRounding")
	private String premiumRounding;

	@JsonProperty("ProrataRounding")
	private String prorataRounding;

	@JsonProperty("TotalAnnualColFee")
	private String totalAnnualColFee;

	@JsonProperty("RevisionNumber")
	private String revisionNumber;

	@JsonProperty("OrgEntityReference")
	private String orgEntityReference;

	@JsonProperty("OoseVoidIndicator")
	private String ooseVoidIndicator;

	@JsonProperty("TotalSurcharge")
	private String totalSurcharge;

	@JsonProperty("RatingMode")
	private String ratingMode;

	@JsonProperty("CanWaivePremium")
	private String canWaivePremium;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("ExpirationDate")
	private String expirationDate;

	@JsonProperty("RenewalCounter2")
	private String renewalCounter2;

	@JsonProperty("RateClicked")
	private String rateClicked;

	@JsonProperty("MasterQuote")
	private String masterQuote;

	@JsonProperty("SourceSystem")
	private String sourceSystem;

	@JsonProperty("CompanyCode")
	private String companyCode;

	@JsonProperty("CAdditionalInsured")
	private String cAdditionalInsured;

	@JsonProperty("EffectiveDate")
	private String effectiveDate;

	@JsonProperty("TotalAnnualTax")
	private String totalAnnualTax;

	public String getBookingDate(){
		return bookingDate;
	}

	public String getProductName(){
		return productName;
	}

	public String getOldEntityType(){
		return oldEntityType;
	}

	public String getTotalFtermFee(){
		return totalFtermFee;
	}

	public String getTotalTransFee(){
		return totalTransFee;
	}

	public String getRetainBtmFltEndr(){
		return retainBtmFltEndr;
	}

	public String getWaivePremium(){
		return waivePremium;
	}

	public String getRenewal(){
		return renewal;
	}

	public String getTransDisplayName(){
		return transDisplayName;
	}

	public String getOnDemandReorder(){
		return onDemandReorder;
	}

	public String getCompanyName(){
		return companyName;
	}

	public String getTotalAnnualFee(){
		return totalAnnualFee;
	}

	public String getPendingCanInd(){
		return pendingCanInd;
	}

	public String getRenewalIndicator(){
		return renewalIndicator;
	}

	public String getTotalSurchargeFterm(){
		return totalSurchargeFterm;
	}

	public String getTransEffectiveDate(){
		return transEffectiveDate;
	}

	public String getIsRebind(){
		return isRebind;
	}

	public String getOrdCarrReport(){
		return ordCarrReport;
	}

	public String getTransactionCode(){
		return transactionCode;
	}

	public String getCustomPackVersion(){
		return customPackVersion;
	}

	public String getPolicyQuoteIndicator(){
		return policyQuoteIndicator;
	}

	public String getTotalTransSurcharge(){
		return totalTransSurcharge;
	}

	public String getGid(){
		return gid;
	}

	public String getBinderFlag(){
		return binderFlag;
	}

	public String getNextGenAudited(){
		return nextGenAudited;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getRenewalCounter(){
		return renewalCounter;
	}

	public String getNoConflictOnRollfwd(){
		return noConflictOnRollfwd;
	}

	public String getBookingUser(){
		return bookingUser;
	}

	public List<InsuredItem> getInsured(){
		return insured;
	}

	public String getControlDate(){
		return controlDate;
	}

	public String getTransactionAction(){
		return transactionAction;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public List<LOBPHItem> getLOBPH(){
		return lOBPH;
	}

	public String getTransactionFactor(){
		return transactionFactor;
	}

	public String getTotalFtermSurcharge(){
		return totalFtermSurcharge;
	}

	public List<ProducerItem> getProducer(){
		return producer;
	}

	public String getTotalAnnualSurcharge(){
		return totalAnnualSurcharge;
	}

	public String getCAlternatePayor(){
		return cAlternatePayor;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}

	public String getPrimaryRiskState(){
		return primaryRiskState;
	}

	public String getTotalFtermTaxes(){
		return totalFtermTaxes;
	}

	public String getTotalFtermColFee(){
		return totalFtermColFee;
	}

	public String getDisplayPolicyNumber(){
		return displayPolicyNumber;
	}

	public String getTransAccountingMonth(){
		return transAccountingMonth;
	}

	public String getAdpPrefill(){
		return adpPrefill;
	}

	public String getEndorsementReason(){
		return endorsementReason;
	}

	public String getPolTermCode(){
		return polTermCode;
	}

	public String getTransAccountingDate(){
		return transAccountingDate;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getProductVersion(){
		return productVersion;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCompositeRating(){
		return compositeRating;
	}

	public String getPolTerm(){
		return polTerm;
	}

	public String getTransAccountingYear(){
		return transAccountingYear;
	}

	public List<AlternatePayorItem> getAlternatePayor(){
		return alternatePayor;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getOldEntityReference(){
		return oldEntityReference;
	}

	public String getBookingStatus(){
		return bookingStatus;
	}

	public String getCustomPolicyNumber(){
		return customPolicyNumber;
	}

	public String getCustomRevisionNumber(){
		return customRevisionNumber;
	}

	public String getMicVersion(){
		return micVersion;
	}

	public String getIsComReduct(){
		return isComReduct;
	}

	public String getIsSubjectToAudit(){
		return isSubjectToAudit;
	}

	public String getPolicyNumber(){
		return policyNumber;
	}

	public String getIsRewrite(){
		return isRewrite;
	}

	public String getPremiumRounding(){
		return premiumRounding;
	}

	public String getProrataRounding(){
		return prorataRounding;
	}

	public String getTotalAnnualColFee(){
		return totalAnnualColFee;
	}

	public String getRevisionNumber(){
		return revisionNumber;
	}

	public String getOrgEntityReference(){
		return orgEntityReference;
	}

	public String getOoseVoidIndicator(){
		return ooseVoidIndicator;
	}

	public String getTotalSurcharge(){
		return totalSurcharge;
	}

	public String getRatingMode(){
		return ratingMode;
	}

	public String getCanWaivePremium(){
		return canWaivePremium;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getExpirationDate(){
		return expirationDate;
	}

	public String getRenewalCounter2(){
		return renewalCounter2;
	}

	public String getRateClicked(){
		return rateClicked;
	}

	public String getMasterQuote(){
		return masterQuote;
	}

	public String getSourceSystem(){
		return sourceSystem;
	}

	public String getCompanyCode(){
		return companyCode;
	}

	public String getCAdditionalInsured(){
		return cAdditionalInsured;
	}

	public String getEffectiveDate(){
		return effectiveDate;
	}

	public String getTotalAnnualTax(){
		return totalAnnualTax;
	}
}