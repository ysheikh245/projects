package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;
import com.pm.api.agencycopilot.services.MessagingServiceHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class MessagingController implements ApplicationController {

    @Autowired
    private MessagingServiceHandler messagingServiceHandler;

    @PostMapping("/send-email")
    public ResponseEntity<String> sendEmail(@RequestBody MessagingAPIRequest messagingAPIRequest,
                                            @RequestAttribute(name = "npnId") String npnId) {
        String response = null;
        try {
            messagingAPIRequest.setNpn(npnId);
            response = messagingServiceHandler.sendEmail(messagingAPIRequest);
        } catch(Exception e) {
            log.error("MessagingController.sendEmail() is {}", e);
            throw new AgencyCoPilotException(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(response);
    }

    /*private SendEmailRequest formSendEmailRequest() {
        SendEmailRequest request = new SendEmailRequest();
        return request;
    }*/

}
