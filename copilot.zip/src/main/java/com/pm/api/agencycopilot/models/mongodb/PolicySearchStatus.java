package com.pm.api.agencycopilot.models.mongodb;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class PolicySearchStatus {

    private LocalDateTime startedAt;
    private LocalDateTime endedAt;
    private boolean isSearchCompleted;
    private Long totalPoliciesFetched;
}
