package com.pm.api.agencycopilot.exception;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpStatus;

@Data
@NoArgsConstructor
public class AgencyCoPilotException extends RuntimeException {

    private HttpStatus httpStatus;
    private String exceptionStackTrace;
    private String exceptionShortMessage;
    private String responseMessage;
    private Exception originatingException;
    private String apiEndPoint;

    public AgencyCoPilotException(Exception exception, HttpStatus httpStatus) {
        super(exception);
        this.httpStatus = httpStatus;
        this.exceptionStackTrace = ExceptionUtils.getStackTrace(exception);
    }

    public AgencyCoPilotException(Exception exception, HttpStatus httpStatus, String apiEndPoint) {
        super(exception);
        this.httpStatus = httpStatus;
        this.apiEndPoint = apiEndPoint;
        this.exceptionStackTrace = ExceptionUtils.getStackTrace(exception);
    }

    public AgencyCoPilotException(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
        this.exceptionStackTrace = message;
    }


}
