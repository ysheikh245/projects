package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.external.claims.ClaimsResponse;
import com.pm.api.agencycopilot.models.external.claims.ClaimsResponseItem;
import com.pm.api.agencycopilot.models.external.claims.details.Response;
import com.pm.api.agencycopilot.services.ClaimsServiceHandler;
import java.time.LocalDateTime;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ClaimsServiceHandlerImpl implements ClaimsServiceHandler {

    @Value("${agency.copilot.claims.api.username}")
    private String claimsAPIUsername;

    @Value("${agency.copilot.claims.api.password}")
    private String claimsAPIPassword;

    @Value("${agency.copilot.claims.by.party.id.api.url}")
    private String claimsByPartyIdAPIEndpoint;

    @Value("${agency.copilot.claim.details.api.url}")
    private String claimDetailsAPIEndpoint;

    @Value("${agency.copilot.claims.api.client.header}")
    private String claimsAPIClientHeader;

    @Value("${agency.copilot.claims.api.end.userid}")
    private String claimsAPIClientUserId;

    @Autowired
    private RestHelperServiceImpl restHelperService;


    public List<ClaimsResponseItem> getClaimsFromPartyId(String partyId) {
        log.info("Entering getClaimsFromPartyId at {}", LocalDateTime.now());
        HttpHeaders httpHeaders = getHttpHeaders();
        HttpEntity httpEntity = new HttpEntity(httpHeaders);
        String endPoint = StringUtils.replace(claimsByPartyIdAPIEndpoint, "{partyId}", partyId);
        log.debug("ClaimsServiceHandler. Used={}-{}", claimsAPIUsername, claimsAPIPassword);
        ResponseEntity<ClaimsResponse> claims = restHelperService.invoke(endPoint, HttpMethod.GET, httpEntity, ClaimsResponse.class);
        if (claims.getBody() != null) {
            log.info("Exiting getClaimsFromPartyId at {}", LocalDateTime.now());
            return claims.getBody().getResponse();
        } else {
            log.info("Exiting getClaimsFromPartyId at {}", LocalDateTime.now());
            return null;
        }
    }

    public Response getClaimDetails(String claimNumber) {
        log.info("Entering getClaimDetails at {}", LocalDateTime.now());
        HttpHeaders httpHeaders = getHttpHeaders();
        HttpEntity httpEntity = new HttpEntity(httpHeaders);
        String endPoint = StringUtils.replace(claimDetailsAPIEndpoint, "{claimNumber}", claimNumber);
        ResponseEntity<Response> claims = restHelperService.invoke(endPoint, HttpMethod.GET, httpEntity, Response.class);
        if (claims.getBody() != null) {
            log.info("Exiting getClaimDetails at {}", LocalDateTime.now());
            return claims.getBody();
        } else {
            log.info("Exiting getClaimDetails at {}", LocalDateTime.now());
            return null;
        }
    }

    @NotNull
    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", claimsAPIClientHeader);
        headers.add("end-user-id", claimsAPIClientUserId);
        headers.add("Authorization", getBasicAuthToken(claimsAPIUsername, claimsAPIPassword));
        return headers;
    }

}
