package com.pm.api.agencycopilot.models.enums;

public enum AgentCompensationFieldNamesEnum {

    PMU_NPN_NO("STRING"),
    PMU_PAYPERIOD_ENDDATE("CALENDAR"),
    PMU_DOC_INDEX_CODE("STRING"),
    PMU_DOC_TYPE("STRING"),
    DOCUMENTID("BIGDECIMAL"),

    VERSIONNUMBER("INTEGER"),
    FILENAME("STRING");

    String dataType;

    AgentCompensationFieldNamesEnum(String dataType) {
        this.dataType = dataType;
    }

    public String getDataType() {
        return dataType;
    }
}
