package com.pm.api.agencycopilot.handlers;

import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.internal.ActionMetadataVO;

public interface IDocumentUploadHandler {

    ActionMetadataVO formActionMetadata(DocumentsUploadAPIRequest documentsUploadAPIRequest);

}
