package com.pm.api.agencycopilot.configuration;

import com.pm.security.util.JwtClaims;
import io.jsonwebtoken.Claims;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;

@Configuration
@EnableAsync
@ConfigurationProperties("async-executor")
public class AgencyCoPilotTemplateConfig {

    // private int pool;
    // private int queue;

    // @Autowired
    // JwtProvider provider;

    // @Autowired
    // MDCTaskDecorator taskDecorator;

    @Bean
    public RestTemplate pmapiClient() {
        return new RestTemplate();
    }

    @Bean
    public JwtClaims jwtClaims() {
        return new JwtClaims() {
            public Claims addClaims(Claims claims, List<GrantedAuthority> roles) {
                super.addClaims(claims, roles);

                return claims;
            }
        };
    }

    // @Bean
    // public TaskExecutor executor() {
    //   ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    //   executor.setCorePoolSize(pool);
    //   executor.setMaxPoolSize(pool);
    //   executor.setQueueCapacity(queue);
    //   executor.setTaskDecorator((Runnable runnable) -> {
    //     Runnable decorated = taskDecorator.decorate(runnable);
    //     Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    //     return () -> {
    //       SecurityContextHolder.getContext().setAuthentication(authentication);
    //       decorated.run();
    //     };
    //   });
    //   executor.initialize();
    //   return executor;
    // }

    // public int getPool() {
    //   return pool;
    // }

    // public void setPool(int pool) {
    //   this.pool = pool;
    // }

    // public int getQueue() {
    //   return queue;
    // }

    // public void setQueue(int queue) {
    //   this.queue = queue;
    // }
}