package com.pm.api.agencycopilot.utility;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
@Slf4j
public class MongoClientUtility {

    @Value("${spring.data.mongodb.username:}")
    private String username;

    @Value("${spring.data.mongodb.password:}")
    private String password;

    @Value("${spring.data.mongodb.host:}")
    private String host;

    @Value("${spring.data.mongodb.port:}")
    private String port;

    @Autowired
    private Environment environment;

    private final String URI = "mongodb://%s:%s@%s:%s/";

    private MongoClient mongoClient;

    public MongoClient getMongoClient() {
        if (mongoClient == null) {
            String[] profiles = environment.getActiveProfiles();
            if (Arrays.asList(profiles).contains("local")) {
                log.info("Local Profile used for Mongo Client");
                mongoClient = MongoClients.create();
            } else {
                log.info("Non Local Profile used for Mongo Client");
                String actualURI = String.format(URI, username, password, host, port);
                mongoClient = MongoClients.create(actualURI);
            }
        }
        return mongoClient;
    }

}
