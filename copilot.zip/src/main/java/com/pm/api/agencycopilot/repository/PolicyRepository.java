package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyRepository extends MongoRepository<PolicyDatabaseRecord, String> {

    List<PolicyDatabaseRecord> findByNpnId(String npnId, Pageable pageable);

    boolean existsByNpnId(String npnId);

    void deleteByNpnId(String npnId);

    List<PolicyDatabaseRecord> findByNpnIdAndPolicyNumber(String npnId, String policyNumber, Pageable pageable);

    List<PolicyDatabaseRecord> findByNpnIdAndPolicyResponsePartiesFullNameContaining(String npnId, String customerFullName, Pageable pageable);
}

