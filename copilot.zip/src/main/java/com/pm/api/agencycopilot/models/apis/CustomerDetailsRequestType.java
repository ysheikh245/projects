package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonValue;

public enum CustomerDetailsRequestType {
    SEARCH_BY_POLICY("searchByPolicy"), SEARCH_BY_CUSTOMER_DETAILS("searchByCustomerDetails");

    private String value;
    CustomerDetailsRequestType(String value){
        this.value = value;
    }
    @JsonValue
    public String getValue(){
        return value;
    }
}
