package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.BeneficiaryDetailsResponse;
import com.pm.api.agencycopilot.models.apis.ClaimsResponse;
import com.pm.api.agencycopilot.models.apis.DiscountsResponse;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.PolicyAdditionalCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.PolicyCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyRateChangeResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.ClaimsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.services.DocumentService;
import com.pm.api.agencycopilot.services.FACIService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class FACIController implements ApplicationController {

    @Autowired
    FACIService faciService;

    @Autowired
    DocumentService documentService;

    @GetMapping("/faci/policy-detail/{policyNumber}")
    public ResponseEntity<PolicyVO> getPMAPIPolicyDetails(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getPMAPIPolicyDetails() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyVO> response = ResponseEntity.ok().body(faciService.getPMAPIPolicyDetails(policyNumber));
        log.info("FaciController.getPMAPIPolicyDetails() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/additional-info/{policyNumber}")
    public ResponseEntity<AdditionalDetailsCountVO> getAdditionalPolicyDetailCount(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getAdditionalPolicyDetailCount() -Start. Policy={}", policyNumber);
        ResponseEntity<AdditionalDetailsCountVO> response = ResponseEntity.ok().body(faciService.getAdditionalDetailsCountVO(policyNumber));
        log.info("FaciController.getAdditionalPolicyDetailCount() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/roles")
    public ResponseEntity<PolicyInfoV2Response<Role>> getPolicyRoleInfo(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getPolicyRoleInfo() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyInfoV2Response<Role>> response = ResponseEntity.ok().body(faciService.getPolicyRoleInfo(policyNumber));
        log.info("FaciController.getPolicyRoleInfo() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/agent-roles")
    public ResponseEntity<PolicyInfoV2Response<AgentRole>> getAgentRoleInfo(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getAgentRoleInfo() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyInfoV2Response<AgentRole>> response = ResponseEntity.ok().body(faciService.getAgentRoleInfo(policyNumber));
        log.info("FaciController.getAgentRoleInfo() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/dependents")
    public ResponseEntity<DependentsV2Reponse> getDependentsInfo(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getDependentsInfo() -Start. Policy={}", policyNumber);
        ResponseEntity<DependentsV2Reponse> response = ResponseEntity.ok().body(faciService.getDependentsInfo(policyNumber));
        log.info("FaciController.getDependentsInfo() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/discounts")
    public ResponseEntity<DiscountsResponse> getDiscountsInfo(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getDiscountsInfo() -Start. Policy={}", policyNumber);
        ResponseEntity<DiscountsResponse> response = ResponseEntity.ok().body(faciService.getDiscountsInfo(policyNumber));
        log.info("FaciController.getDiscountsInfo() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/rate-changes")
    public ResponseEntity<PolicyRateChangeResponse> getRateChangesInfo(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getRateChangesInfo() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyRateChangeResponse> response = ResponseEntity.ok().body(faciService.getRateChangesInfo(policyNumber));
        log.info("FaciController.getRateChangesInfo() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/coverage-details")
    public ResponseEntity<PolicyCoverageDetailsResponse> getPolicyCoverageDetails(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getPolicyCoverageDetails() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyCoverageDetailsResponse> response = ResponseEntity.ok().body(faciService.getPolicyCoverageDetails(policyNumber));
        log.info("FaciController.getPolicyCoverageDetails() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/beneficiary-detail")
    public ResponseEntity<BeneficiaryDetailsResponse> getBeneficiaryDetails(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getBeneficiaryDetails() -Start. Policy={}", policyNumber);
        ResponseEntity<BeneficiaryDetailsResponse> response = ResponseEntity.ok().body(faciService.getBeneficiaryDetails(policyNumber));
        log.info("FaciController.getBeneficiaryDetails() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/policy-detail/{policyNumber}/additional-coverages")
    public ResponseEntity<PolicyAdditionalCoverageDetailsResponse> getAdditionalCoverages(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getAdditionalCoverages() -Start. Policy={}", policyNumber);
        ResponseEntity<PolicyAdditionalCoverageDetailsResponse> response = ResponseEntity.ok().body(faciService.getAdditionalCoverages(policyNumber));
        log.info("FaciController.getAdditionalCoverages() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/document-details/{policyNumber}")
    public ResponseEntity<DocumentsV2Response<DocumentsResponse>> getPolicyDocumentDetails(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getPolicyDocumentDetails() -Start. Policy={}", policyNumber);
        ResponseEntity<DocumentsV2Response<DocumentsResponse>> response = ResponseEntity.ok().body(faciService.getPolicyDocumentDetails(policyNumber));
        log.info("FaciController.getPolicyDocumentDetails() -Complete. Policy={}", policyNumber);
        return response;
    }

    @PostMapping("/faci/customer-detail/")
    public ResponseEntity<List<CustomersVO>> getPolicyByCustomerDetails(@Valid @RequestBody PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, HttpServletRequest request) throws Exception {
        log.info("FaciController getCustomerDetails -Start");
        String npnId = String.valueOf(request.getAttribute("npnId"));
        log.info("NPN Retrieved from request Attribute is {}", npnId);
        if ("null".equals(npnId)) {
            throw new AgencyCoPilot4xxException(
                    "npnId is null.",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "");
        }
        List<CustomersVO> response = faciService.getPolicyBySalesCustomerDetails(policyByCustomerDetailsRequest, npnId);
        log.info("FaciController getCustomerDetails -Complete");
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/faci/customer-detail/{policyNumber}/party/{partyId}")
    public ResponseEntity<CustomersVO> getCustomerContactDetails(@PathVariable String policyNumber, @PathVariable String partyId) throws Exception {
        log.info("FaciController.getCustomerContactDetails() -Start. Policy={}", policyNumber);
        CustomersVO response = faciService.getCustomerContactDetails(policyNumber, partyId);
        log.info("FaciController.getCustomerContactDetails() -Complete. Policy={}", policyNumber);
        return ResponseEntity.ok().body(response);
    }

    @PostMapping("/faci/documents/download")
    public ResponseEntity<Resource> downloadCustomerDocument(@Valid @RequestBody DocumentDownloadRequest documentDownloadRequest) throws Exception {
        log.info("FaciController.downloadCustomerDocument() - Start");
        Resource response = documentService.downloadDocument(documentDownloadRequest);
        log.info("FaciController.downloadCustomerDocument() - Complete");
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(response);
    }

    @GetMapping("/faci/customer-detail/alert/{policyNumber}")
    public ResponseEntity<DocumentsV2Response<PolicyAlertResponse>> getPolicyAlerts(@PathVariable String policyNumber) throws Exception {
        log.info("FaciController.getPolicyAlerts() -Start. Policy={}", policyNumber);
        ResponseEntity<DocumentsV2Response<PolicyAlertResponse>> response = ResponseEntity.ok().body(faciService.getPolicyAlerts(policyNumber));
        log.info("FaciController.getPolicyAlerts() -Complete. Policy={}", policyNumber);
        return response;
    }

    @GetMapping("/faci/claims/{policyNumber}")
    public ResponseEntity<ClaimsResponse> getAllClaimsFromPolicy(@PathVariable String policyNumber, HttpServletRequest request) {
        log.info("FaciController.getAllClaimsFromPolicy() -Start. Policy={}", policyNumber);
        String npnId = String.valueOf(request.getAttribute("npnId"));
        log.info("NPN Retrieved from request Attribute is {}", npnId);
        if ("null".equals(npnId)) {
            throw new AgencyCoPilot4xxException(
                    "npnId is null.",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "");
        }
        ClaimsResponse claimsResponse = new ClaimsResponse();
        List<ClaimsVO> claims = faciService.getAllClaimsFromPolicy(policyNumber, npnId);
        claimsResponse.setClaims(claims);
        log.info("FaciController.getAllClaimsFromPolicy() -Stop. Policy={}", policyNumber);
        return ResponseEntity.ok().body(claimsResponse);
    }

    @GetMapping("/faci/claim-details/{claimNumber}/{claimType}")
    public ResponseEntity<ClaimsResponse> getClaimDetails(@PathVariable String claimNumber, @PathVariable String claimType) {
        log.info("FaciController.getClaimDetails() -Start. Claim={}", claimNumber);
        ClaimsResponse claimsResponse = new ClaimsResponse();
        ClaimsVO claim = faciService.getClaimDetails(claimNumber, claimType);
        claimsResponse.setClaim(claim);
        log.info("FaciController.getClaimDetails() -Stop. Claim={}", claimNumber);
        return ResponseEntity.ok().body(claimsResponse);
    }
}
