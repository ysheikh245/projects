package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.utility.DateFormatterUtility;

import java.util.Date;

public class FileName {

    public static void main(String[] args) {
      Date date = new Date("2023-12-20T05:00:00.000+00:00");
        System.out.println(DateFormatterUtility.format(date, DateFormatterUtility.FORMAT_MMddyyyy));
    }

}
