package com.pm.api.agencycopilot.utility;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Data
public class ApplicationStatusProperties {
    @Value("${agency.copilot.mongo.cache.ttl}")
    public Long mongoCacheTTL;

    @Value("${agency.copilot.application.status.default.pageNo}")
    public String defaultPageNo;

    @Value("${agency.copilot.application.status.default.pageSize}")
    public String defaultPageSize;

    @Value("${agency.copilot.application.status.default.filter.lastXDays}")
    public Integer defaultLastXDaysFilter;

    @Value("${agency.copilot.application.status.default.filter.lastMaxXDays}")
    public Integer defaultLastMaxXDaysFilter;

    @Value("${agency.copilot.application.status.background.process.verification.count}")
    public int backgroundProcessVerificationCount;

    @Value("${agency.copilot.background.processing.check.wait.time.ms}")
    public long verifyBkgGrdVerificationRetryMillis;

    @Value("${agency.copilot.application.status.evaluateThankyou.codes}")
    public String statusCodeForEvaluatingThankyouEmail;

    @Value("${agency.copilot.application.status.evaluateThankyou.criteriaEvaluationDays}")
    public int criteriaDaysToEvaluateThankyou;
}
