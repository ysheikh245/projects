package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
@JsonRootName("fieldMetaData")
public class FieldMetaData {

    @JsonProperty("fieldDefinition")
    private FieldDefinition fieldDefinition;

    @JsonProperty("columnDefinition")
    private ColumnDefinition columnDefinition;

}