package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AddressListItem{

	@JsonProperty("zip")
	private String zip;

	@JsonProperty("country")
	private String country;

	@JsonProperty("city")
	private String city;

	@JsonProperty("postalBarCode")
	private String postalBarCode;

	@JsonProperty("carrierCode")
	private String carrierCode;

	@JsonProperty("addressLine1")
	private String addressLine1;

	@JsonProperty("state")
	private String state;

	@JsonProperty("type")
	private String type;

	public String getZip(){
		return zip;
	}

	public String getCountry(){
		return country;
	}

	public String getCity(){
		return city;
	}

	public String getPostalBarCode(){
		return postalBarCode;
	}

	public String getCarrierCode(){
		return carrierCode;
	}

	public String getAddressLine1(){
		return addressLine1;
	}

	public String getState(){
		return state;
	}

	public String getType(){
		return type;
	}
}