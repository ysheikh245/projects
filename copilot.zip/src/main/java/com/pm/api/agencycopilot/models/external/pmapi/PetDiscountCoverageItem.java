package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PetDiscountCoverageItem{

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CFinalAnnDisPremium")
	private String cFinalAnnDisPremium;

	@JsonProperty("CAnnualDiscountPremium")
	private String cAnnualDiscountPremium;

	@JsonProperty("CDisplayCoverage")
	private String cDisplayCoverage;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CDiscountFactor")
	private String cDiscountFactor;

	@JsonProperty("CAnnualPremium")
	private String cAnnualPremium;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CPetDiscountCov")
	private String cPetDiscountCov;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CCoverageCode")
	private String cCoverageCode;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("CSelect")
	private String cSelect;

	@JsonProperty("Id")
	private String id;

	public String getCCoverage(){
		return cCoverage;
	}

	public String getGid(){
		return gid;
	}

	public String getCFinalAnnDisPremium(){
		return cFinalAnnDisPremium;
	}

	public String getCAnnualDiscountPremium(){
		return cAnnualDiscountPremium;
	}

	public String getCDisplayCoverage(){
		return cDisplayCoverage;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCDiscountFactor(){
		return cDiscountFactor;
	}

	public String getCAnnualPremium(){
		return cAnnualPremium;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getCPetDiscountCov(){
		return cPetDiscountCov;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCCoverageCode(){
		return cCoverageCode;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getCSelect(){
		return cSelect;
	}

	public String getId(){
		return id;
	}
}