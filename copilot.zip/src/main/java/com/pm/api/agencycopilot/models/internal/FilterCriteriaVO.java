package com.pm.api.agencycopilot.models.internal;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.pm.api.agencycopilot.models.apis.SortOrderEnum;
import com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import java.time.LocalDate;
import java.util.List;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.FILTER_DEFAULT_NO_OF_DAYS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.FILTER_MAX_NO_OF_DAYS;

@Data
@JsonRootName("filterCriteria")
public class FilterCriteriaVO {

    @Max(value = FILTER_MAX_NO_OF_DAYS, message = "No of days to filter cannot be more than 60 days")

    @Min(value = FILTER_DEFAULT_NO_OF_DAYS, message = "No of days to filter cannot be less than 7 days")
    private int days;

    @NotEmpty(message = "At least one status is required")

    private List<PolicyStatusCodeEnum> status;

    private String policyNumber;

    private String customerName;

    private SortOrderEnum sortOrder;

    private int pageNumber;

    private int pageSize;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate searchFromDate;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate searchToDate;

    public void setPolicyNumber(String policyNumber) {
        if(StringUtils.isBlank(policyNumber)) {
            this.policyNumber = null;
        } else {
            this.policyNumber = policyNumber;
        }
    }
}
