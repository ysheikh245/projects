package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TaxesSurchargesFeesItem{

	@JsonProperty("CAplyEnrollFee")
	private String cAplyEnrollFee;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("CAplyInstalFee")
	private String cAplyInstalFee;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("CPiTaxSuFe")
	private String cPiTaxSuFe;

	@JsonProperty("Id")
	private String id;

	public String getCAplyEnrollFee(){
		return cAplyEnrollFee;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getCAplyInstalFee(){
		return cAplyInstalFee;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getCPiTaxSuFe(){
		return cPiTaxSuFe;
	}

	public String getId(){
		return id;
	}
}