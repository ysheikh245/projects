package com.pm.api.agencycopilot.models.apis;

public enum SortOrderEnum {

    ASC, DESC;
}
