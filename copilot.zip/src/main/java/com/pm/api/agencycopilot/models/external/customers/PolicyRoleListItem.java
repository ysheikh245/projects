package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PolicyRoleListItem{

	@JsonProperty("role")
	private String role;

	public String getRole(){
		return role;
	}
}