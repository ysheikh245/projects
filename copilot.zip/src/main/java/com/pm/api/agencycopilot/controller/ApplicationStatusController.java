package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.apis.WorkSheetDetailsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyV2Response;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.repository.ContentStackProductCategoryRepository;
import com.pm.api.agencycopilot.repository.PolicyCategoriesRepository;
import com.pm.api.agencycopilot.repository.PolicyRepository;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.services.ApplicationStatusService;
import com.pm.api.agencycopilot.services.PolicyServiceHandler;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestAttribute;

@RestController
@Slf4j
public class ApplicationStatusController implements ApplicationController {

    @Autowired
    private ApplicationStatusService applicationStatusService;

    @Autowired
    private PolicyServiceHandler policyServiceHandler;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private PolicyCategoriesRepository policyCategoriesRepository;

    @Autowired
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Autowired
    private ContentStackProductCategoryRepository contentStackProductCategoryRepository;


    @PostMapping("/application-status")
    public ResponseEntity<ApplicationStatusResponse> processApplicationStatus(@RequestHeader(required = false, value = "authorization") String authorizationToken,
                                                                              @RequestBody ApplicationStatusRequest applicationStatusRequest,
                                                                              @RequestAttribute(name = "npnId") String npnId) {
        ApplicationStatusResponse response = null;
        log.debug("Token={}", authorizationToken);
        try {
            applicationStatusRequest.getAgentInformation().setNpn(npnId);
            log.info("NPN Retrieved from request Attribute is {}", npnId);
            response = applicationStatusService.processApplicationStatus(applicationStatusRequest);
            if (response != null && CollectionUtils.isEmpty(response.getPolicy())) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response);
            }
        } catch (Exception e) {
            log.error("Unknown exception occured in ApplicationStatusController.processApplicationStatus() exception message is {}", e.getMessage());
            throw new AgencyCoPilotException(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/pmapi/{policyNumber}")
    public Object getPMAPIData(@PathVariable String policyNumber) throws Exception {
        PolicyV2Response policyDataFromPMAPI = policyServiceHandler.getPolicyDataFromPMAPI(policyNumber);
        PolicyDatabaseRecord record = new PolicyDatabaseRecord();
        record.setPolicyNumber(policyDataFromPMAPI.getPolicies().get(0).getPolicyNumber());
        record.setPolicyStatus(policyDataFromPMAPI.getPolicies().get(0).getPolicyStatus());
        record.setNpnId("NPN-Id1");
        record.setRank("3");
        record.setCreateDate(new Date());
        policyRepository.save(record);
        return policyDataFromPMAPI;
    }

    @GetMapping("/application-status/cache-results/{npn}")
    public ResponseEntity<PolicyCachingStatusRecord> retrieveApplicationCahceByNPNPath(
            @PathVariable("npn") String npn) {
        return retrieveApplicationCacheByNPNToken(npn);
    }

    @GetMapping("/application-status/cache-results/npn")
    public ResponseEntity<PolicyCachingStatusRecord> retrieveApplicationCacheForAnNPN(
            @RequestAttribute(name = "npnId") String npnId) {
        return retrieveApplicationCacheByNPNToken(npnId);
    }

    @GetMapping("/application-status/cache-results/")
    public ResponseEntity<PolicyCachingStatusRecord> retrieveApplicationCacheByNPNToken(
            @RequestAttribute(name = "npnId") String npnId) {
        log.info("NPN Retrieved from request Attribute is {}", npnId);
        PolicyCachingStatusRecord policyCachingStatusRecord = applicationStatusService.retrieveApplicationStatusCacheResults(npnId);

        if (policyCachingStatusRecord != null) {
            return ResponseEntity.ok().body(policyCachingStatusRecord);
        }
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/application-status/worksheet-detail/{policyNumber}")
    public ResponseEntity<WorkSheetDetailsResponse> getWorkSheetDocumentDetails(@PathVariable String policyNumber) {
        log.info("ApplicationStatusController.getWorkSheetDocumentDetails() - Start. Policy={}", policyNumber);
        WorkSheetDetailsResponse workSheetDetailsResponse = applicationStatusService.getWorkSheetDocumentDetails(policyNumber);
        if (!CollectionUtils.isEmpty(workSheetDetailsResponse.getCase360Documents())) {
            log.info("ApplicationStatusController.getWorkSheetDocumentDetails() - Completed. List Not Empty. Policy={}", policyNumber);
            return ResponseEntity.status(HttpStatus.OK).body(workSheetDetailsResponse);
        } else {
            log.info("ApplicationStatusController.getWorkSheetDocumentDetails() - Completed. List Empty. Policy={}", policyNumber);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(workSheetDetailsResponse);
        }
    }
}
