package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CDiScountTabItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CPetTabPiDisct")
	private String cPetTabPiDisct;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CDiscountPercentage")
	private String cDiscountPercentage;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("CSelect")
	private String cSelect;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CAdditionalDiscount")
	private String cAdditionalDiscount;

	@JsonProperty("CDiscount")
	private String cDiscount;

	public String getEntityType(){
		return entityType;
	}

	public String getCPetTabPiDisct(){
		return cPetTabPiDisct;
	}

	public String getGid(){
		return gid;
	}

	public String getCDiscountPercentage(){
		return cDiscountPercentage;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getCSelect(){
		return cSelect;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCAdditionalDiscount(){
		return cAdditionalDiscount;
	}

	public String getCDiscount(){
		return cDiscount;
	}
}