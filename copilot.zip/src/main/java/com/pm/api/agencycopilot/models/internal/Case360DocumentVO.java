package com.pm.api.agencycopilot.models.internal;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Case360DocumentVO {

    //private String code;
    //private String shortName;
    private String description;
    //private String openDate;
    //private String systemControlled;
    //private String holdUpIssue;
    private String comments;
    private String uploadButton;
    private String displayField;
    private String dateRequired;
    private String dateReceived;
}
