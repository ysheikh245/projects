package com.pm.api.agencycopilot.models.external.contentstack;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ContentStackResponse {

	@JsonProperty("entries")
	private List<EntriesItem> entries;

}