package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.models.mongodb.NPNPolicyListCacheRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyToProductCategory;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.query.Query;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface MongoDBCacheHandler {

    void saveToPolicyDocument(PolicyVO policyVO, ApplicationStatusRequest applicationStatusRequest);

    void findAndDeletePoliciesByNpn(String npnId);

    PolicyCachingStatusRecord saveToPolicyCacheStatusDocument(String npnId,
                                                              LocalDateTime startTime,
                                                              Date createdDate);

    List<PolicyDatabaseRecord> findPoliciesByNPNId(String npnId, Pageable pageable);

    List<PolicyDatabaseRecord> findPoliciesByNPNIdAndPolicyNumber(String npnId, String policyNumber, Pageable pageable);

    List<PolicyDatabaseRecord> findPoliciesByNPNIdAndCustomerFullName(String npnId, String customerFullName, Pageable pageable);

    PolicyCachingStatusRecord updatePolicyCacheStatusDocument(String npnId,
                                                              LocalDateTime startTime,
                                                              boolean isBackground,
                                                              boolean isSearchCompleted,
                                                              long policiesFetchedCount);

    void findAndDeletePolicyCacheResultByNpn(String npnId);

    PolicyCachingStatusRecord findPolicyCachingStatusByNpnId(String npnId);

    List<PolicyDatabaseRecord> findPoliciesByNpnUsingCriteria(Query query);

    PolicyCategoriesRecord findApplicationStatusCodes(String statusCode, boolean isActive);

    List<PolicyCategoriesRecord> insertPolicyCategoryCodes(List<PolicyCategoriesRecord> policyCategoriesRecords);

    List<ProductTypeCategoriesRecord> insertProductTypeCategories(List<ProductTypeCategoriesRecord> productTypeCategoriesRecords);

    ProductTypeCategoriesRecord findProductTypeCategory(String productCode, boolean isActive);

    ContentStackProductCategory findByProductCategory(String productCategory);

    ContentStackProductCategory insertContentStackResponseForProductCategory(ContentStackProductCategory contentStackProductCategory);

    List<Case360DocumentVO> getWorkSheetRequirementDocuments(String policyNumber);

    PolicyToProductCategory insertPolicyToProductCategory(PolicyToProductCategory policyToProductCategory);

    Optional<PolicyToProductCategory> findProductCategoryForPolicy(String policyNumber);

    NPNPolicyListCacheRecord findPolicyListByNPN(String npnId);

    NPNPolicyListCacheRecord insertNPNPolicyListCache(String npnId, List<String> policyList);

    PolicyDatabaseRecord updatePolicyRepository(String npn, String policyNumber, String status);
}
