package com.pm.api.agencycopilot.models.external.contentstack;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class EntriesItem{

	@JsonProperty("outlines")
	private Outlines outlines;

	@JsonProperty("brochure")
	private Brochure brochure;

	@JsonProperty("publish_details")
	private PublishDetails publishDetails;

	@JsonProperty("created_at")
	private String createdAt;

	@JsonProperty("ACL")
	private ACL acl;

	@JsonProperty("_in_progress")
	private boolean inProgress;

	@JsonProperty("locale")
	private String locale;

	@JsonProperty("title")
	private String title;

	@JsonProperty("type")
	private String type;

	@JsonProperty("created_by")
	private String createdBy;

	@JsonProperty("tags")
	private List<String> tags;

	@JsonProperty("uid")
	private String uid;

	@JsonProperty("medicare_advantage")
	private MedicareAdvantage medicareAdvantage;

	@JsonProperty("application")
	private Application application;

	@JsonProperty("updated_at")
	private String updatedAt;

	@JsonProperty("updated_by")
	private String updatedBy;

	@JsonProperty("state_code")
	private StateCode stateCode;

	@JsonProperty("_version")
	private int version;
}