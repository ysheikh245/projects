package com.pm.api.agencycopilot.utility;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
@Component
public class ClaimStatusCodeMap {

    private static final Map<String, String> statusDescriptions = new HashMap<>();

    static {

        statusDescriptions.put("10finalpaidmanual", "Claim Paid and/or Applied to Deductible");
        statusDescriptions.put("11finalpaidcomputer", "Claim Paid and/or Applied to Deductible");
        statusDescriptions.put("c20000fullpaid", "Claim Paid and/or Applied to Deductible");
        statusDescriptions.put("10finalpaidcomputer", "Claim Paid and/or Applied to Deductible");

        statusDescriptions.put("30closeddrop", "Claim Closed – No Payment");
        statusDescriptions.put("31closeddrop", "Claim Closed – No Payment");
        statusDescriptions.put("40miscellaneousreject", "Claim Closed – No Payment");

        statusDescriptions.put("57lossdateafterlapse,noreinstatement", "Claim Closed – No active Coverage");
        statusDescriptions.put("58loseduringlapse,beforereinstatement", "Claim Closed – No active Coverage");
        statusDescriptions.put("59lossbeforeissuedate", "Claim Closed – No active Coverage");
        statusDescriptions.put("65policystatusshowscancelled", "Claim Closed – No active Coverage");
        statusDescriptions.put("d01002lossbeforeeffectivedate", "Claim Closed – No active Coverage");
        statusDescriptions.put("d01003lossafterlapse", "Claim Closed – No active Coverage");
        statusDescriptions.put("d001005nopremiumreceived", "Claim Closed – No active Coverage");


    }


    public String getDescription(String statusCode) {
        return statusDescriptions.getOrDefault(statusCode, "Please Call Customer Service");
    }

}
