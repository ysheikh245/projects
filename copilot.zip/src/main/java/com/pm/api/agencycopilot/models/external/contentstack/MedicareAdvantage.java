package com.pm.api.agencycopilot.models.external.contentstack;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class MedicareAdvantage{

	@JsonProperty("publish_details")
	private PublishDetails publishDetails;

	@JsonProperty("created_at")
	private String createdAt;

	@JsonProperty("ACL")
	private ACL aCL;

	@JsonProperty("title")
	private String title;

	@JsonProperty("created_by")
	private String createdBy;

	@JsonProperty("file_size")
	private String fileSize;

	@JsonProperty("url")
	private String url;

	@JsonProperty("tags")
	private List<String> tags;

	@JsonProperty("uid")
	private String uid;

	@JsonProperty("filename")
	private String filename;

	@JsonProperty("content_type")
	private String contentType;

	@JsonProperty("parent_uid")
	private String parentUid;

	@JsonProperty("updated_at")
	private String updatedAt;

	@JsonProperty("is_dir")
	private boolean isDir;

	@JsonProperty("updated_by")
	private String updatedBy;

	@JsonProperty("_version")
	private int version;
}