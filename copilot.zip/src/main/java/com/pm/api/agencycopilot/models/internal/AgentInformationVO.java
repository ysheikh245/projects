package com.pm.api.agencycopilot.models.internal;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.pm.api.agencycopilot.utility.StringUtility;
import lombok.Data;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SPACE;

@Data
@JsonRootName("agentInformation")
public class AgentInformationVO {

    private String npn;
    private String firstName;
    private String lastName;
    private String middleName;
    private String emailAddress;
    private String phone;
    private String licenseNumber;
    private String name;

   /* public String getName() {
        return StringUtility.getAccumulatedValue(SPACE, firstName, middleName, lastName);
    }*/
}
