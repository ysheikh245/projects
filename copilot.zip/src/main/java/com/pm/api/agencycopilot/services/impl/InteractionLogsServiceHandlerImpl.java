package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.external.interactionlogs.Cdaction;
import com.pm.api.agencycopilot.models.external.interactionlogs.CdcallerRelationship;
import com.pm.api.agencycopilot.models.external.interactionlogs.Cdlevel2;
import com.pm.api.agencycopilot.models.external.interactionlogs.Cdreason;
import com.pm.api.agencycopilot.models.external.interactionlogs.Cdreasonsubtype;
import com.pm.api.agencycopilot.models.external.interactionlogs.CdsourceSystem;
import com.pm.api.agencycopilot.models.external.interactionlogs.GetInteractionLogItems;
import com.pm.api.agencycopilot.models.external.interactionlogs.GetInteractionLogResponse;
import com.pm.api.agencycopilot.models.external.interactionlogs.InteractionExternalName;
import com.pm.api.agencycopilot.models.external.interactionlogs.InteractionReason;
import com.pm.api.agencycopilot.models.external.interactionlogs.InteractionReasonsSubTypeItem;
import com.pm.api.agencycopilot.models.external.interactionlogs.PostInteractionLogRequest;
import com.pm.api.agencycopilot.services.InteractionLogsServiceHandler;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.NONE;
import com.pm.api.agencycopilot.utility.CustomerPMAPIProperties;
import com.pm.api.agencycopilot.utility.DateFormatterUtility;
import com.pm.api.agencycopilot.utility.JSONUtility;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class InteractionLogsServiceHandlerImpl implements InteractionLogsServiceHandler {


    @Autowired
    CustomerPMAPIProperties customerPMAPIProperties;

    private String format = "YYYY-MM-dd HH:mm:ss.SSS";


    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RestHelperServiceImpl restHelperService;

    @Autowired
    MaskedValueLogger maskedValueLogger;


    //public boolean isEventOccurred(String partyId, MessagingDeliveryEnum messagingDeliveryEnum) {
    public boolean isEventOccurred(String policyNumber, String partyId) {
        log.info("Entering isEventOccurred at {}", LocalDateTime.now());
        try {
            //String eventName = messagingDeliveryEnum.getValue();
            //invokeGetInteractionLogsAPI(partyId);
            GetInteractionLogResponse response = invokeGetInteractionLogsAPI(partyId);
            if (response == null) {
                log.error("Unable to find the Interaction Logs for Policy Number={}", policyNumber);
                maskedValueLogger.error(String.format("Unable to find the Interaction Logs for Policy Number=%s and PartyId=%s", policyNumber, partyId), log);
                return false;
            }
            //List<GetInteractionLogItems> interactionLogItems = response.getInteractionLogItems();
            //System.out.println(getInteractionLogsAPIResponses.length);
            maskedValueLogger.info(String.format("Found %s InteractionLogItems for policyNumber=%s and partyId=%s",
                    response.getInteractionLogItems().size(),
                    policyNumber,
                    partyId), log);

            log.info("Found {} InteractionLogItems for policyNumber={}", response.getInteractionLogItems().size(), policyNumber);

       /* response.getInteractionLogItems().stream().filter(interaction -> {
            boolean sourceSystemFound = StringUtils.equals(interaction.getCdsourceSystem().getSourceSystemCd(), "");
            interaction.getInteractionReasons().stream().filter(reason -> {
                boolean reasonCode = StringUtils.equals("", reason.getCdreason().getReasonCd());
            });
            return sourceSystemFound && reasonCode;;
        }).findFirst();*/

            for (GetInteractionLogItems item : response.getInteractionLogItems()) {
                //TODO: change this to 5000. This is only for testing as data is not present (Uncomment the below line)
//            String applicationEventCode = interactionLogsProperties.getApplicationEventCode();
                String reasonCodeForInteractionLogs = customerPMAPIProperties.getReasonCodeForInteractionLogs();
                String reasonSubTypeCode = customerPMAPIProperties.getReaasonSubTypeCodeForInteractionLogs();
                log.info("ReasonCodeForInteractionLogs={}, ReasonSubTypeCode={}", reasonCodeForInteractionLogs, reasonSubTypeCode);
                //String system = item.getCdsourceSystem().getSourceSystemCd();
                //String policyNumberInInteractionLogsResponse = item.getPolicyNumber();
                if (StringUtils.equals(item.getPolicyNumber(), policyNumber)) {
                    Optional<InteractionReason> interactionReasonOptional = item.getInteractionReasons().stream().
                            filter(reason -> StringUtils.equals(reasonCodeForInteractionLogs, reason.getCdreason().getReasonCd())).findFirst();
                    if (interactionReasonOptional.isPresent()) {
                        InteractionReason interactionReason = interactionReasonOptional.get();
                        Optional<InteractionReasonsSubTypeItem> interactionReasonsSubTypeItem =
                                interactionReason.getInteractionReasonsSubType().stream()
                                        .filter(reasonSubType -> StringUtils.equalsIgnoreCase(reasonSubTypeCode, reasonSubType.getCdreasonsubtype().getReasonSubtypeCd()))
                                        .findFirst();
                        if (interactionReasonsSubTypeItem.isPresent()) {
                            log.info("Exiting at {}", LocalDateTime.now());
                            return true;
                        } else {
                            log.info("No resonSubTypeCd found for {}. Exiting at {}", reasonSubTypeCode, LocalDateTime.now());
                            return false;
                        }

                    } else {
                        log.info("No interactionReasons reasonCd for {} entry found for Policy={}", reasonCodeForInteractionLogs, policyNumber);
                    }
                } else {
                    log.info("No interaction log entry found for Policy={}", policyNumber);
                }
            }
            log.info("Exiting isEventOccurred at {}", LocalDateTime.now());
            return false;
        } catch(Exception e) {
            log.error("Exception occurred in isEventOccurred for poliy={}. Exception={}", policyNumber, ExceptionUtils.getStackTrace(e));
            return false;
        }

        /*response.getInteractionLogItems().forEach(interaction -> {
            interaction.getInteractionReasons().forEach(reason -> {
                StringUtils.equals("", reason.getCdreason().getReasonCd());
            });
             StringUtils.equals(interaction.getCdsourceSystem().getSourceSystemCd(), "") &&
             StringUtils.equals(interaction.getInteractionReasons());


        });
        return true;*/
    }

    public void createInteractionLogEntry(String npn, String agentName,
                                          String reasonNumber, String partyId, String policyNumber, String notes) {
        log.info("Entering createInteractionLogEntry at {}", LocalDateTime.now());
        HttpHeaders headers = getHttpHeaders();
        PostInteractionLogRequest request = formInteractionLogRequest(npn, agentName, reasonNumber, partyId, policyNumber, notes);
        log.info("Creating interaction logs for npn={}", npn);
        try {
            maskedValueLogger.info(String.format("Interaction Logs Request %s", JSONUtility.convertObjectToString(request)), log);
        } catch (Exception e) {
            log.info("Exiting createInteractionLogEntry at {}", LocalDateTime.now());
            throw new RuntimeException(e);
        }
        HttpEntity httpEntity = new HttpEntity(request, headers);
        String interactionLogsAPIEndpoint = StringUtils.replace(customerPMAPIProperties.getInteractionLogsAPIEndpoint(), "{partyId}", partyId);
        ResponseEntity<String> response = restTemplate.postForEntity(interactionLogsAPIEndpoint, httpEntity, String.class);
        log.info("Exiting createInteractionLogEntry at {}", LocalDateTime.now());
    }

    private PostInteractionLogRequest formInteractionLogRequest(String npn, String agentName,
                                                                String reasonNumber, String partyId, String policyNumber, String notes) {
        log.info("Entering formInteractionLogRequest at {}", LocalDateTime.now());
        PostInteractionLogRequest request = new PostInteractionLogRequest();

        request.setBusinessUpdateTs(DateFormatterUtility.format(Calendar.getInstance().getTime(), format));
        //request.setBusinessUpdateTs("2023-01-10 14:49:10.695");
        request.setBusinessUpdateUser(npn);

        // CDAction
        Cdaction cdaction = new Cdaction();
        cdaction.setActionCd(customerPMAPIProperties.getActionCode());
        request.setCdaction(cdaction);

        // CDLevel2
        Cdlevel2 cdlevel2 = new Cdlevel2();
        cdlevel2.setLevel2Cd(NONE);
        request.setCdlevel2(cdlevel2);

        //CDSourceSystem
        CdsourceSystem cdsourceSystem = new CdsourceSystem();
        //cdsourceSystem.setSourceSystemCd(AGENT);
        cdsourceSystem.setSourceSystemCd(customerPMAPIProperties.getSystemSourceCode());
        request.setCdsourceSystem(cdsourceSystem);

        // InteractionExternalName
        InteractionExternalName interactionExternalName = new InteractionExternalName();
        CdcallerRelationship cdcallerRelationship = new CdcallerRelationship();
        //cdcallerRelationship.setCallerRelationshipCd(OTHER);
        cdcallerRelationship.setCallerRelationshipCd(customerPMAPIProperties.getCallerRelationshipCode());
        interactionExternalName.setCdcallerRelationship(cdcallerRelationship);
        interactionExternalName.setCallerName(agentName); //TODO: agentName or customerName?
        request.setInteractionExternalName(interactionExternalName);

        //List[InteractionReason]
        InteractionReason interactionReason = new InteractionReason();
//        interactionReason.setInteractionReasonId(null);
        Cdreason cdreason = new Cdreason();
        cdreason.setReasonCd(customerPMAPIProperties.getReasonCodeForInteractionLogs());
        interactionReason.setCdreason(cdreason);
        interactionReason.setReasonNumber(reasonNumber);
        InteractionReasonsSubTypeItem interactionReasonsSubTypeItem = new InteractionReasonsSubTypeItem();
//        interactionReasonsSubTypeItem.setInteractionReasonSubtypeId(null);
        Cdreasonsubtype cdreasonsubtype = new Cdreasonsubtype();
        cdreasonsubtype.setReasonSubtypeCd(customerPMAPIProperties.getReaasonSubTypeCodeForInteractionLogs());
        interactionReasonsSubTypeItem.setCdreasonsubtype(cdreasonsubtype);
        interactionReason.setInteractionReasonsSubType(Arrays.asList(interactionReasonsSubTypeItem));
        request.setInteractionReasons(Arrays.asList(interactionReason));

        request.setPartyId(partyId);
        request.setPolicyNumber(policyNumber);
        request.setSystemUpdateUser(npn);
        request.setNotes(notes);
        log.info("Exiting formInteractionLogRequest at {}", LocalDateTime.now());
        return request;

    }

    private GetInteractionLogResponse invokeGetInteractionLogsAPI(String partyId) {
        log.info("Entering invokeGetInteractionLogsAPI at {}", LocalDateTime.now());
        //private String invokeGetInteractionLogsAPI(String partyId) {
        HttpHeaders headers = getHttpHeaders();
        HttpEntity request = new HttpEntity(headers);

        String interactionLogsAPIEndpoint = StringUtils.replace(customerPMAPIProperties.getInteractionLogsAPIEndpoint(), "{partyId}", partyId);
        //ResponseEntity<GetInteractionLogsAPIResponse[]> response = restTemplate.exchange(interactionLogsEndpoint, HttpMethod.GET, request, GetInteractionLogsAPIResponse[].class);
        //return response.getBody();
        //ResponseEntity<String> response = restTemplate.exchange(interactionLogsEndpoint, HttpMethod.GET, request, String.class);
        ResponseEntity<GetInteractionLogResponse> response =
                restHelperService.invoke(interactionLogsAPIEndpoint, HttpMethod.GET, request, GetInteractionLogResponse.class);
        log.info("Exiting invokeGetInteractionLogsAPI at {}", LocalDateTime.now());
        return response.getBody();
    }

    @NotNull
    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", customerPMAPIProperties.getCustomersAPIClientHeader());
        headers.add("end-user-id", customerPMAPIProperties.getCustomersAPIClientUserId());
        headers.add("Authorization", getBasicAuthToken(
                customerPMAPIProperties.getCustomersAPIUsername(),
                customerPMAPIProperties.getCustomersAPIPassword()));
        return headers;
    }
}
