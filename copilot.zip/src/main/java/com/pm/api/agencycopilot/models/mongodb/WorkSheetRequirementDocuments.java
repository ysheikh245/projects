package com.pm.api.agencycopilot.models.mongodb;

import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document("workSheetRequirementDocuments")
@Data
public class WorkSheetRequirementDocuments {

    @Id
    private String policyNumber;
    //private String case360Response;
    private List<Case360DocumentVO> processedResponse;
    private Date createDate;

}
