package com.pm.api.agencycopilot.models.external.case360;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValueListItem{

	@JsonProperty("fieldName")
	private String fieldName;

	@JsonProperty("itemValue")
	private String itemValue;

	@JsonProperty("displayOrder")
	private int displayOrder;

	@JsonProperty("description")
	private String description;

	public String getFieldName(){
		return fieldName;
	}

	public String getItemValue(){
		return itemValue;
	}

	public int getDisplayOrder(){
		return displayOrder;
	}

	public String getDescription(){
		return description;
	}
}