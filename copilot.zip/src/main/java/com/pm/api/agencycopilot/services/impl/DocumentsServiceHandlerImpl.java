package com.pm.api.agencycopilot.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentSearchCriteria;
import com.pm.api.agencycopilot.models.apis.DocumentSearchCriteriaRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIResponse;
import com.pm.api.agencycopilot.models.external.documents.upload.DocumentUploadRequest;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.services.DocumentsServiceHandler;
import com.pm.api.agencycopilot.transformer.PolicyDetailTransformer;
import com.pm.api.agencycopilot.utility.JSONUtility;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Map;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.FAILED;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SUCCESS;

import static com.pm.api.agencycopilot.utility.JSONUtility.convertObjectToString;

@Service
@Slf4j
public class DocumentsServiceHandlerImpl implements DocumentsServiceHandler {

    @Autowired
    PolicyDetailTransformer policyDetailTransformer;

    @Autowired
    RestHelperServiceImpl restHelperService;

    @Value("${agency.copilot.pmapi.document.username}")
    private String documentsAPIUsername;

    @Value("${agency.copilot.pmapi.document.password}")
    private String documentsAPIPassword;

    @Value("${agency.copilot.pmapi.service.client.header}")
    private String documentsAPIClientHeader;

    @Value("${agency.copilot.pmapi.service.end.userid}")
    private String documentsAPIEndUserId;

    @Value("${agency.copilot.pmapi.document.search.endpoint}")
    private String documentSearchEndPoint;

    @Value("${agency.copilot.pmapi.document.search.payload}")
    private String documentSearchPayload;

    @Value("${agency.copilot.documents.upload.api.endpoint}")
    private String documentsUploadAPIEndpoint;

    @Value("${agency.copilot.pmapi.document.download.endpoint}")
    private String documentsDownloadAPIEndpoint;


    @Override
    public DocumentsV2Response<DocumentsResponse> getPolicyDocuments(String policyNumber) throws Exception {
        log.info("Entering getPolicyDocuments at {}", LocalDateTime.now());
        log.info("Policy Document API for policyNumber {}", policyNumber);
        LocalDateTime start = LocalDateTime.now();
        DocumentsV2Response<DocumentsResponse> documentsResponseDocumentsV2Response = invokePMAPIRestCall(policyNumber);
        LocalDateTime end = LocalDateTime.now();
        log.info("Timetaken to complete the getPolicyDocuments is {}", Duration.between(start, end).toMillis());
        log.info("Exiting getPolicyDocuments at {}", LocalDateTime.now());
        return documentsResponseDocumentsV2Response;
    }

    public DocumentsUploadAPIResponse uploadDocuments(DocumentUploadRequest documentUploadRequest) {
        log.info("Entering uploadDocuments at {}", LocalDateTime.now());
        DocumentsUploadAPIResponse documentsUploadAPIResponse = null;
        try {
            HttpHeaders headers = getHttpHeaders();
            HttpEntity request = new HttpEntity(documentUploadRequest, headers);
            //HttpEntity httpEntity = new HttpEntity(request);
            //Object response = restHelperService.invoke(documentsUploadAPIEndpoint, HttpMethod.POST, request, Object.class); //TODO: take care of return type
            //DocumentUploadResponse documentUploadResponse =  JSONUtility.convertStringToObject(response, DocumentUploadResponse.class);

            ResponseEntity<String> stringResponse = restHelperService.invoke(documentsUploadAPIEndpoint, HttpMethod.POST, request, String.class); //TODO: take care of return type
            documentsUploadAPIResponse = formResponse(stringResponse.getBody(), documentUploadRequest);
            log.info("Document Uploaded Successfully: DocumentUploadAPIResponse={}", convertObjectToString(documentsUploadAPIResponse));
            log.debug("Documents PMAPI API Response={}", convertObjectToString(stringResponse));
            log.info("Exiting uploadDocuments at {}", LocalDateTime.now());
            return documentsUploadAPIResponse;
        } catch (Exception e) {
            log.info("Exiting uploadDocuments at {}", LocalDateTime.now());
            documentsUploadAPIResponse = formResponse(null, documentUploadRequest);
            return documentsUploadAPIResponse;
        }
    }

    @Override
    public Resource downloadDocument(DocumentDownloadRequest documentDownloadRequest) throws Exception {
        log.info("Entering downloadDocument at {}", LocalDateTime.now());
        String URI = documentsDownloadAPIEndpoint
                .replace("{DOCUMENT_ID}", documentDownloadRequest.getDocumentId())
                .replace("{VERSION_NUMBER}", documentDownloadRequest.getVersion())
                .replace("{FILE_NAME}", documentDownloadRequest.getFileName())
                .replace("{FILE_EXT}", documentDownloadRequest.getFileExtension());
        HttpHeaders headers = getHttpHeaders();

        HttpEntity request = new HttpEntity(headers);
        ResponseEntity<byte[]> response = restHelperService.invoke(URI,
                HttpMethod.GET, request,
                byte[].class);

        try {
            InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(response.getBody()));
            log.info("Exiting downloadDocument at {}", LocalDateTime.now());
            return resource;
        } catch (Exception e) {
            log.info("Exiting downloadDocument at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(
                    String.format("No document found for DOCUMENT_ID %s, VERSION_NUMBER %s, FILE_NAME %s, and FILE_EXT %s",
                            documentDownloadRequest.getDocumentId(), documentDownloadRequest.getVersion(),
                            documentDownloadRequest.getFileName(), documentDownloadRequest.getFileExtension()
                    ),
                    HttpStatus.NOT_FOUND,
                    "");
        }

    }

    private HttpHeaders getHttpHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("client-header", documentsAPIClientHeader);
        httpHeaders.add("end-user-id", documentsAPIEndUserId);
        httpHeaders.add("Authorization", getBasicAuthToken(documentsAPIUsername, documentsAPIPassword));
        return httpHeaders;
    }

    private DocumentsV2Response<DocumentsResponse> invokePMAPIRestCall(String policyNumber) throws JsonProcessingException {
        log.info("Entering invokePMAPIRestCall at {}", LocalDateTime.now());
        HttpHeaders headers = getHttpHeaders();
        ObjectMapper objectMapper = new ObjectMapper();
        // DocumentSearchCriteriaRequest documentSearchRequest = objectMapper.readValue(documentSearchPayload, DocumentSearchCriteriaRequest.class);
        DocumentSearchCriteriaRequest documentSearchRequest = new DocumentSearchCriteriaRequest(
                "POLICY_DOCUMENTS",
                "INDEX",
                new DocumentSearchCriteria(
                        policyNumber, "SALESFORCE_DOCUMENT"
                )
        );
        documentSearchRequest.getSearchCriteria().setPolicyNumber(policyNumber);

        HttpEntity request = new HttpEntity(documentSearchRequest, headers);

        ResponseEntity<DocumentsV2Response<DocumentsResponse>> response = restHelperService.invoke(documentSearchEndPoint,
                HttpMethod.POST, request,
                new ParameterizedTypeReference<DocumentsV2Response<DocumentsResponse>>() {
                });
        log.info("Exiting invokePMAPIRestCall at {}", LocalDateTime.now());
        return response.getBody();
    }

    private DocumentsUploadAPIResponse formResponse(String apiResponse, DocumentUploadRequest documentUploadRequest) {
        DocumentsUploadAPIResponse documentsUploadAPIResponse = new DocumentsUploadAPIResponse();
        documentsUploadAPIResponse.setPolicyNumber(getPolicyNumber(documentUploadRequest));
        documentsUploadAPIResponse.setDocumentDescription(getDocumentDescription(documentUploadRequest));
        log.info("DocumentsServiceHandlerImpl.formResponse(). Policy={}, apiResponse={}", documentsUploadAPIResponse.getPolicyNumber(), apiResponse);
        if(!StringUtils.isEmpty(apiResponse)) {
            documentsUploadAPIResponse.setPmicNumber(extractPMICNumberFromResponse(apiResponse));
            documentsUploadAPIResponse.setStatus(SUCCESS);
        } else {
            documentsUploadAPIResponse.setPmicNumber(BLANK);
            documentsUploadAPIResponse.setStatus(FAILED);
        }
        return documentsUploadAPIResponse;
    }

    private String extractPMICNumberFromResponse(String stringResponse) {
        Object pmicNumber;
        try {
            pmicNumber = ((Map) ((Map) JSONUtility.convertStringToObject(stringResponse)).get("response")).get("pmicNumber");
        } catch(Exception e) {
            log.error("Exception occurred in extractPMICNumberFromResponse(). Exception={}", ExceptionUtils.getStackTrace(e));
            pmicNumber = FAILED;
        }
        String returnValue = String.valueOf(pmicNumber);
        log.info("String Response={}. PMICNumber={}", stringResponse, returnValue);
        return returnValue;
    }

    private String getPolicyNumber(DocumentUploadRequest documentUploadRequest) {
        if(documentUploadRequest != null && documentUploadRequest.getIndexFields() != null)
            return documentUploadRequest.getIndexFields().getPolicyNumber();
        else
            return BLANK;
    }

    private String getDocumentDescription(DocumentUploadRequest documentUploadRequest) {
        if(documentUploadRequest != null && documentUploadRequest.getIndexFields() != null) {
            return documentUploadRequest.getIndexFields().getDocumentDesc();
        } else {
            return BLANK;
        }
    }


}
