package com.pm.api.agencycopilot.models.external.messaging;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ToUser{

	@JsonProperty("id")
	private String id;

	@JsonProperty("type")
	private String type;
}