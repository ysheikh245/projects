package com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PublishDetails{

	@JsonProperty("environment")
	private String environment;

	@JsonProperty("time")
	private String time;

	@JsonProperty("locale")
	private String locale;

	@JsonProperty("user")
	private String user;

	public String getEnvironment(){
		return environment;
	}

	public String getTime(){
		return time;
	}

	public String getLocale(){
		return locale;
	}

	public String getUser(){
		return user;
	}
}