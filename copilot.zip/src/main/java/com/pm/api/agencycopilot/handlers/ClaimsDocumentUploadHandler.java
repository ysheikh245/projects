package com.pm.api.agencycopilot.handlers;

import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.internal.ActionMetadataVO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ClaimsDocumentUploadHandler implements IDocumentUploadHandler {

//    @Value("${document.upload.faci.claims.docIndexCode:NA}")
//    private String docIndexCode;

    @Value("${document.upload.faci.claims.documentDesc:CoPilot_FACI_Claims}")
    private String documentDesc;

    @Value("${document.upload.faci.claims.docType:CRITICAL}")
    private String docType;

    @Value("${document.upload.faci.claims.corrType:CLAIMS}")
    private String corrType;

    @Value("${document.upload.faci.claims.source:CoPilot}")
    private String source;

    @Value("${document.upload.faci.claims.doc_Type:CRITICAL}")
    private String doc_Type;

    @Value("${document.upload.faci.claims.workflowType:CLAIMS}")
    private String workFlowType;

    @Value("${document.upload.faci.claims.descriptor:CLAIM_ATTRIBUTES_IN}")
    private String descriptor;

    @Override
    public ActionMetadataVO formActionMetadata(DocumentsUploadAPIRequest documentsUploadAPIRequest) {
        ActionMetadataVO actionMetadataVO = new ActionMetadataVO();
        //actionMetadataVO.setDocIndexCode(docIndexCode);
        actionMetadataVO.setDocumentDesc(documentDesc);
        actionMetadataVO.setDocType(docType);
        actionMetadataVO.setCorrType(corrType);
        actionMetadataVO.setSource(source);
        actionMetadataVO.setDoc_Type(doc_Type);
        actionMetadataVO.setWorkFlowType(workFlowType);
        actionMetadataVO.setDescriptor(descriptor);

        // Set document description in the request object - this is not used anywhere; just for consistent response between App Status and FACI
        documentsUploadAPIRequest.setDocumentDescription(documentDesc);

        return actionMetadataVO;
    }
}
