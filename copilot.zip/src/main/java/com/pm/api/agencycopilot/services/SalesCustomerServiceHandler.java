package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.external.sales.FindSalesCustomerByPolicyResponse;

public interface SalesCustomerServiceHandler extends ServiceHandler {
	
	FindSalesCustomerByPolicyResponse invokeSalesCustomerPMAPIByPolicy(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npn);
	FindSalesCustomerByPolicyResponse invokeSalesCustomerPMAPIByPolicyNumber(String policyNumber, String npn);


}
