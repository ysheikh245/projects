package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PetDiscountOffsetItem{

	@JsonProperty("CAnnualOffsetPremium")
	private String cAnnualOffsetPremium;

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("CPetDiscountOffset")
	private String cPetDiscountOffset;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CAnnualSaveByDiscTot")
	private String cAnnualSaveByDiscTot;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CCoverageName")
	private String cCoverageName;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CRate")
	private String cRate;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CCoverageCode")
	private String cCoverageCode;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("Id")
	private String id;

	public String getCAnnualOffsetPremium(){
		return cAnnualOffsetPremium;
	}

	public String getCCoverage(){
		return cCoverage;
	}

	public String getCPetDiscountOffset(){
		return cPetDiscountOffset;
	}

	public String getGid(){
		return gid;
	}

	public String getCAnnualSaveByDiscTot(){
		return cAnnualSaveByDiscTot;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCCoverageName(){
		return cCoverageName;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getCRate(){
		return cRate;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCCoverageCode(){
		return cCoverageCode;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getId(){
		return id;
	}
}