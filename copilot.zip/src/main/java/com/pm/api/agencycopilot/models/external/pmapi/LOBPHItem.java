package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LOBPHItem{

	@JsonProperty("PHBasicPetInformation")
	private List<PHBasicPetInformationItem> pHBasicPetInformation;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("TaxesSurchargesFees")
	private List<TaxesSurchargesFeesItem> taxesSurchargesFees;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("PolicyLobPh")
	private String policyLobPh;

	@JsonProperty("CTotAnnPolDisc")
	private String cTotAnnPolDisc;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("CPolicyDiscount")
	private String cPolicyDiscount;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("PhDiscounts")
	private List<PhDiscountsItem> phDiscounts;

	@JsonProperty("csavingbydiscount")
	private List<CsavingbydiscountItem> csavingbydiscount;

	@JsonProperty("PetInsurancePet")
	private List<PetInsurancePetItem> petInsurancePet;

	public List<PHBasicPetInformationItem> getPHBasicPetInformation(){
		return pHBasicPetInformation;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public List<TaxesSurchargesFeesItem> getTaxesSurchargesFees(){
		return taxesSurchargesFees;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getPolicyLobPh(){
		return policyLobPh;
	}

	public String getCTotAnnPolDisc(){
		return cTotAnnPolDisc;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getCPolicyDiscount(){
		return cPolicyDiscount;
	}

	public String getId(){
		return id;
	}

	public List<PhDiscountsItem> getPhDiscounts(){
		return phDiscounts;
	}

	public List<CsavingbydiscountItem> getCsavingbydiscount(){
		return csavingbydiscount;
	}

	public List<PetInsurancePetItem> getPetInsurancePet(){
		return petInsurancePet;
	}
}