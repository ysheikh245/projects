package com.pm.api.agencycopilot.models.internal;

import lombok.Data;

@Data
public class ActionMetadataVO {
    private String docIndexCode;
    private String documentDesc;
    private String docType;
    private String corrType;
    private String source;
    private String doc_Type;
    private String policyNo;
    private String workFlowType;
    private String descriptor;
}
