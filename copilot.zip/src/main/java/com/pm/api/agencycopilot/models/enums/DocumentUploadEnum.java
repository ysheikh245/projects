package com.pm.api.agencycopilot.models.enums;

public enum DocumentUploadEnum {

    WORKSHEET_REQUIREMENT_POLICY("WORKSHEET_REQUIREMENT_POLICY"),
    FACI_CLAIMS("FACI_CLAIMS");

    private String status;

    DocumentUploadEnum(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

}
