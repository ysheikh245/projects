package com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EntriesItem{

	@JsonProperty("option_value")
	private String optionValue;

	@JsonProperty("publish_details")
	private PublishDetails publishDetails;

	@JsonProperty("show_field")
	private boolean showField;

	@JsonProperty("created_at")
	private String createdAt;

	@JsonProperty("description")
	private String description;

	@JsonProperty("ACL")
	private Object acl;

	@JsonProperty("_in_progress")
	private boolean inProgress;

	@JsonProperty("locale")
	private String locale;

	@JsonProperty("title")
	private String title;

	@JsonProperty("created_by")
	private String createdBy;

	@JsonProperty("tags")
	private List<Object> tags;

	@JsonProperty("uid")
	private String uid;

	@JsonProperty("product_type")
	private String productType;

	@JsonProperty("updated_at")
	private String updatedAt;

	@JsonProperty("action_metadata")
	private ActionMetadata actionMetadata;

	@JsonProperty("checklist_action")
	private String checklistAction;

	@JsonProperty("updated_by")
	private String updatedBy;

	@JsonProperty("_version")
	private int version;
}