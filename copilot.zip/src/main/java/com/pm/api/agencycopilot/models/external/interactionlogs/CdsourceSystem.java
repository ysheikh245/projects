package com.pm.api.agencycopilot.models.external.interactionlogs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CdsourceSystem{

	@JsonProperty("sourceSystemCd")
	private String sourceSystemCd;

}