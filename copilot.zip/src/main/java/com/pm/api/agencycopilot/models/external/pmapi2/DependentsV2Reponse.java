package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class DependentsV2Reponse {

    @JsonProperty("response")
    private List<Dependent> dependent;
}
