package com.pm.api.agencycopilot.models.external.interactionlogs;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PostInteractionLogRequest {

	@JsonProperty("businessUpdateTs")
	private String businessUpdateTs;

	@JsonProperty("interactionExternalName")
	private InteractionExternalName interactionExternalName;

	@JsonProperty("businessUpdateUser")
	private String businessUpdateUser;

	@JsonProperty("systemUpdateUser")
	private String systemUpdateUser;

	@JsonProperty("notes")
	private String notes;

	@JsonProperty("cdsourceSystem")
	private CdsourceSystem cdsourceSystem;

	@JsonProperty("cdaction")
	private Cdaction cdaction;

	@JsonProperty("interactionReasons")
	private List<InteractionReason> interactionReasons;

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("cdlevel2")
	private Cdlevel2 cdlevel2;

	@JsonProperty("partyId")
	private String partyId;

}