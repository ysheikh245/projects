package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyCachingStatusRepository extends MongoRepository<PolicyCachingStatusRecord, String> {

    PolicyCachingStatusRecord findByNpnId(String npnId);
}
