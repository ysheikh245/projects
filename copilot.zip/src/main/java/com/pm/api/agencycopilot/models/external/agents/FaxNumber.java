package com.pm.api.agencycopilot.models.external.agents;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FaxNumber{

	@JsonProperty("areaCode")
	private String areaCode;

	@JsonProperty("priorityLevel")
	private String priorityLevel;

	@JsonProperty("contactPreferenceType")
	private String contactPreferenceType;

	@JsonProperty("electronicTypeCode")
	private String electronicTypeCode;

	@JsonProperty("localPhoneNumber")
	private String localPhoneNumber;

	public String getAreaCode(){
		return areaCode;
	}

	public String getPriorityLevel(){
		return priorityLevel;
	}

	public String getContactPreferenceType(){
		return contactPreferenceType;
	}

	public String getElectronicTypeCode(){
		return electronicTypeCode;
	}

	public String getLocalPhoneNumber(){
		return localPhoneNumber;
	}
}