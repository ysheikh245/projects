package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.SystemInformation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pm.api.agencycopilot.services.MessageService;

import java.util.Calendar;
import java.util.Date;

@Service
@Slf4j
public class MessageServiceImpl implements MessageService {

    @Autowired
    private SystemInformation systemInformation;

    public String getMessage() {
        log.info("MessageServiceImpl.getMessage() - Start");
        systemInformation.setSystemDate("" + new Date(Calendar.getInstance().getTimeInMillis()));
        systemInformation.setVersion("V1");
        log.info("MessageServiceImpl.getMessage() - Complete");
        return "Successfully sending the message: " + systemInformation;

    }
}
