package com.pm.api.agencycopilot.models.mongodb;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

/**
 * This class will be used as a policy to Product Category mapping.
 * This Collection is a non-expiring Collection which will map policyNumber to Product Category mapping
 * For e.g. H123456789 to L036: later this Collection will be used to get the ProductCategory for the Policy
 * and in turn that will take care of several downstream calls
 */
@Data
public class PolicyToProductCategory {

    @Id
    private String policyNumber;
    private String productCategory;
    private String fullProductCategory; // at times we get a longer product category

    @DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private LocalDateTime createdDate;

    private String createdBy;

    @DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private LocalDateTime updatedDate;

    private String updatedBy;

}
