package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.services.MessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@ComponentScan({ "com.pm.*" })
@Slf4j
public class MessageController {

	@Autowired
	private MessageService messageService;

	@GetMapping("/message")
	public ResponseEntity<String> getMessage() throws JsonProcessingException {
		log.info("AgencyCoPilotController.getMessage() -Start");
		String message = messageService.getMessage();
		log.info("AgencyCoPilotController.getMessage() -Complete");
		return ResponseEntity.ok(message);
	}
}