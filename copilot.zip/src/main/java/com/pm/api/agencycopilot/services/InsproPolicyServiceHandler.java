package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.internal.PolicyVO;
import java.util.List;

public interface InsproPolicyServiceHandler {

    public List<PolicyVO> getPolicyDetailsFromInspro(List<PolicyVO> policyNumber) throws Exception;
}
