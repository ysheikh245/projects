package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DiscountCoverageRatingItem{

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("CSeq")
	private String cSeq;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("CFinalAnnDisPremium")
	private String cFinalAnnDisPremium;

	@JsonProperty("CRatingFormula")
	private String cRatingFormula;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("CDiscountCovRating")
	private String cDiscountCovRating;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("CRatingFunction")
	private String cRatingFunction;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CCoverageCode")
	private String cCoverageCode;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	public String getCCoverage(){
		return cCoverage;
	}

	public String getCSeq(){
		return cSeq;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getCFinalAnnDisPremium(){
		return cFinalAnnDisPremium;
	}

	public String getCRatingFormula(){
		return cRatingFormula;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getCDiscountCovRating(){
		return cDiscountCovRating;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getCRatingFunction(){
		return cRatingFunction;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCCoverageCode(){
		return cCoverageCode;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}
}