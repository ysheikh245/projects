package com.pm.api.agencycopilot.utility;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MaskedValueLogger {

    @Value("${agency.copilot.log.masked-values:false}")
    private boolean logMaskedValues;

    public void info(String message, Logger log) {
        if (logMaskedValues) {
            log.info(message);
        }
    }

    public void debug(String message, Logger log) {
        if (logMaskedValues) {
            log.debug(message);
        }
    }

    public void error(String message, Logger log) {
        if (logMaskedValues) {
            log.error(message);
        }
    }
}
