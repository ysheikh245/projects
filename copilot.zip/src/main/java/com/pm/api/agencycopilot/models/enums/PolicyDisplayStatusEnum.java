package com.pm.api.agencycopilot.models.enums;

public enum PolicyDisplayStatusEnum {

    DISPOSED("Disposed"), PENDING("Pending");

    private String status;

    PolicyDisplayStatusEnum(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
