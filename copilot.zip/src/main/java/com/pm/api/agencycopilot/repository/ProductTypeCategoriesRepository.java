package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductTypeCategoriesRepository extends MongoRepository<ProductTypeCategoriesRecord, String> {

    ProductTypeCategoriesRecord findByProductCodeAndIsActive(String id, boolean isActive);
}
