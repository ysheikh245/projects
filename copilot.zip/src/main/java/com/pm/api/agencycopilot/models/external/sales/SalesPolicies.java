package com.pm.api.agencycopilot.models.external.sales;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SalesPolicies {
	
	private String policyNumber;
    private List<SalesPolicyRoleList> policyRoleList;
    private String policyStatus;

}
