package com.pm.api.agencycopilot.services;

public interface InteractionLogsServiceHandler extends ServiceHandler {

    //public InteractionLogs getInteractionLogs(String partyId);

    boolean isEventOccurred(String policyNumber, String partyId);

    void createInteractionLogEntry(String npn, String agentName, String reasonNumber, String partyId, String policyNumber, String notes);

}
