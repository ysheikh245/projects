package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CsavingbydiscountItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CSavingByDiscount")
	private String cSavingByDiscount;

	@JsonProperty("CTotlAnnualSavingDis")
	private String cTotlAnnualSavingDis;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("csavegbydiscnt")
	private List<CsavegbydiscntItem> csavegbydiscnt;

	public String getEntityType(){
		return entityType;
	}

	public String getGid(){
		return gid;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCSavingByDiscount(){
		return cSavingByDiscount;
	}

	public String getCTotlAnnualSavingDis(){
		return cTotlAnnualSavingDis;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public List<CsavegbydiscntItem> getCsavegbydiscnt(){
		return csavegbydiscnt;
	}
}