package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.internal.PolicyVO;
import lombok.Data;

import java.util.List;

@Data
public class ApplicationStatusResponse {

    private List<PolicyVO> policy;

    //private String insuredName;
    //private String policyNumber;
    //private String productDescription;
    //private String role;
    //private String issuedDate; // issueDate or applicationDate,
    //private String applicationDate;
    //private String status; //pending or issued
    //private String nigoCount;
    //private String corelationId; // coming from other system
    //private String partyId;


}
