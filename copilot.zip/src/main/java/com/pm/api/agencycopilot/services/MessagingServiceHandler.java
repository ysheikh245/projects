package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;

public interface MessagingServiceHandler extends ServiceHandler {

    public String sendEmail(MessagingAPIRequest messagingAPIRequest);

}
