package com.pm.api.agencycopilot.services.impl;

import com.atiam.address._2008.AddressType;
import com.atiam.applicantperson._2008.ApplicantPersonType;
import com.atiam.policy._2008.GetPolicyDetailResponseOutputType;
import com.atiam.policy._2008.GetPolicyDetailResponseType;
import com.atiam.policy._2008.PolicyDetailType;
import com.atiam.policy._2008.PolicyStatusType;
import com.pm.api.agencycopilot.models.enums.PolicyStatusCodeEnum;
import com.pm.api.agencycopilot.models.internal.AddressVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.services.InsproPolicyServiceHandler;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import com.pm.api.agencycopilot.utility.AgencyCoPilotConstants;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.DASH;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.OWNER;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.PRODUCT_CATEGORY_CODE_CHARACTERS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SPACE;

import com.pm.api.agencycopilot.utility.DateFormatterUtility;
import com.pm.api.agencycopilot.utility.StringUtility;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

import javax.xml.datatype.XMLGregorianCalendar;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
public class InsproPolicyServiceHandlerImpl implements InsproPolicyServiceHandler {

    @Autowired
    private AsynchronousInvocationServiceHelper asynchronousInvocationServiceHelper;

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    @Qualifier("applicationStatusTaskExecutor")
    private Executor taskExecutor;


    public List<PolicyVO> getPolicyDetailsFromInspro(List<PolicyVO> policies) throws Exception {
        List<CompletableFuture> futures = new ArrayList<>();
        List<PolicyVO> policyResponses = new ArrayList<>();
        for (PolicyVO policy : policies) {
            //log.info("Policy= " + policy + "Started at : " + Calendar.getInstance().getTime());
            log.debug("Active count: " +
                    ((ThreadPoolTaskExecutor) taskExecutor).getActiveCount() +
                    ", Pool size: " + ((ThreadPoolTaskExecutor) taskExecutor).getPoolSize() +
                    ", Queue Size: " + ((ThreadPoolTaskExecutor) taskExecutor).getThreadPoolExecutor().getQueue().size());
            futures.add(asynchronousInvocationServiceHelper.invokeInsproSOAPCall(policy));
            //log.info("Ended at : " + Calendar.getInstance().getTime());
        }

        for (CompletableFuture future : futures) {
            log.debug("Completing the future object. Started at: ");
            GetPolicyDetailResponseType getPolicyDetailResponseType = (GetPolicyDetailResponseType) future.get();
            PolicyVO policyVO = transformPolicyDetailResponseToPolicyVO(getPolicyDetailResponseType);
            if (null != policyVO) {
                policyResponses.add(policyVO);
            }
            log.debug("End the future object. Started at: ");
        }

        log.info("Total Number of policies processed are {}", policyResponses.size());
        log.info("Exiting getPolicyDetailsFromInspro at {}", LocalDateTime.now());
//        policyResponses.stream().forEach(System.out::println);
        return policyResponses;

    }

    private PolicyVO transformPolicyDetailResponseToPolicyVO(GetPolicyDetailResponseType getPolicyDetailResponseType) {
        log.info("Entering transformPolicyDetailResponseToPolicyVO at {}", LocalDateTime.now());
        PolicyVO policyVO = new PolicyVO();
        List<CustomersVO> customers = new ArrayList();
//        try {
//            log.info("Response from inspro soap call is {}", JSONUtility.convertObjectToString(getPolicyDetailResponseType));
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
        if (getPolicyDetailResponseType.getIPFaultList() != null
                && !CollectionUtils.isEmpty(getPolicyDetailResponseType.getIPFaultList().getIPFault())) {
            log.error("Unable to find the policy from Soap Call Reason={}. Hence Ignoring...",
                    getPolicyDetailResponseType.getIPFaultList().getIPFault().stream().findFirst().get().getFaultReasonText());
            log.info("Exiting transformPolicyDetailResponseToPolicyVO at {}", LocalDateTime.now());
            return null;
        }
        GetPolicyDetailResponseOutputType policyDetails = getPolicyDetailResponseType.getInfo();
        if (policyDetails != null) {
            PolicyDetailType policyDetail = policyDetails.getPolicyDetail();
            String policyStatusCode = policyDetail.getPolicyStatus().getPolicyStatusCode();

            policyVO.setPolicyNumber(policyDetail.getPolicyNumber());
            policyVO.setPolicyStatus(buildStatusForGrouping(policyDetail.getPolicyStatus())); // 'ISSUED' or 'ACTIVE' or 'PENDING' etc.
            policyVO.setPolicyDisplayText(buildStatusTextForDisplay(policyDetail.getPolicyStatus())); // long name description
            policyVO.setPolicyStatusLongName(policyDetail.getPolicyStatus().getPolicyStatusLongName());
            policyVO.setProductName(buildProductName(policyDetail));
            String productCodeFromInspro = trimProductCode(policyDetail.getBasePlan().getCode());
            policyVO.setProductCode(productCodeFromInspro);
            policyVO.setFullProductCode(policyDetail.getBasePlan().getCode());
            policyVO.setPolicyStatusCode(policyStatusCode);
            String productCategory = "";
            if (StringUtils.isNotEmpty(productCodeFromInspro)) {
                ProductTypeCategoriesRecord productCategoryRecord = mongoDBCacheHandler.findProductTypeCategory(productCodeFromInspro, true);
                if (productCategoryRecord != null) {
                    productCategory = productCategoryRecord.getCategory();
                } else {
                    log.error("Product category not present in ProductTypeCategoriesRecord for given product code {} and policy {}", productCodeFromInspro, policyDetail.getPolicyNumber());
                }
            } else {
                log.error("Unable to fetch the product category for given product code {} and policy {}", productCodeFromInspro, policyDetail.getPolicyNumber());
            }
            policyVO.setProductCategory(productCategory);
            if (PolicyStatusCodeEnum.filterActivePolicies(policyVO)) {
            	XMLGregorianCalendar policyIssueDate= policyDetail.getPolicyIssueDate();
            	policyVO.setIssueDate(policyIssueDate.toGregorianCalendar().getTime());
                String date = new StringBuilder().append(String.format("%02d", policyIssueDate.getMonth()))
                        .append("/")
                        .append(String.format("%02d", policyIssueDate.getDay()))
                        .append("/")
                        .append(policyIssueDate.getYear()).toString();
                //String date= String.format("%02d", policyIssueDate.getMonth())+ "/" + String.format("%02d", policyIssueDate.getDay()) + "/" + policyIssueDate.getYear();
            	policyVO.setDisplayIssueDate(date);
            	
            }
            policyVO.setSubmitDate(policyDetail.getApplicationReceivedDate().toGregorianCalendar().getTime());
            policyVO.setDisplaySubmitDate(DateFormatterUtility.format(policyVO.getSubmitDate(), DateFormatterUtility.FORMAT_MMddyyyy));
            CustomersVO customer = getPersonInformation(policyDetail);
            customers.add(customer);
            policyVO.setParties(customers);
        }
        log.info("Exiting transformPolicyDetailResponseToPolicyVO at {}", LocalDateTime.now());
        return policyVO;
    }

    private String trimProductCode(String code) {
        return StringUtils.substring(code, 0, PRODUCT_CATEGORY_CODE_CHARACTERS);
    }

    private String buildStatusForGrouping(PolicyStatusType policyStatus) {
        PolicyCategoriesRecord policyCategoriesRecord =
                mongoDBCacheHandler.findApplicationStatusCodes(policyStatus.getPolicyStatusCode(), true);
        return policyCategoriesRecord != null ? policyCategoriesRecord.getCategory() : AgencyCoPilotConstants.NOT_FOUND;
    }

    private String buildStatusTextForDisplay(PolicyStatusType policyStatus) {
        if (null == policyStatus) {
            return BLANK;
        }
        StringBuilder policyStatusTextBuilder = new StringBuilder();
        policyStatusTextBuilder.append(policyStatus.getPolicyStatusCode())
                .append(DASH)
                .append(policyStatus.getPolicyStatusLongName());

        return policyStatusTextBuilder.toString();
    }

    private CustomersVO getPersonInformation(PolicyDetailType policyDetail) {
        log.info("Entering getPersonInformation at {}", LocalDateTime.now());
        CustomersVO person = null;
        if (policyDetail.getOwner() != null) {
            ApplicantPersonType owner = policyDetail.getOwner();
            AddressType primaryAddress = owner.getPrimaryAddress();
            person = new CustomersVO();
            person.setRole(OWNER);

            // Set full name
            if (owner.getNameComponents() != null) {
                person.setFullName(owner.getNameComponents().getFullName());
                person.setFirstName(owner.getNameComponents().getFirstName());
                person.setMiddleName(owner.getNameComponents().getMiddleName());
                person.setLastName(owner.getNameComponents().getLastName());
                person.setEmailAddress(owner.getEmailAddress());
                person.setPartyId(owner.getPersonNumber());
            }
            if (primaryAddress != null) {
                AddressVO addressVO = new AddressVO();
                addressVO.setAddressLine1(primaryAddress.getAddressLine1());
                addressVO.setAddressLine2(primaryAddress.getAddressLine2());
                addressVO.setAddressLine3(primaryAddress.getAddressLine3());
                addressVO.setCity(primaryAddress.getCityName());
                addressVO.setState(primaryAddress.getStateCode());
                addressVO.setCountry(primaryAddress.getCountry().getCountryName());
                addressVO.setZipCode(primaryAddress.getZipCode());
                person.setHomeAddress(addressVO);
            }
        }
        log.info("Exiting getPersonInformation at {}", LocalDateTime.now());
        return person;
    }

    private String buildProductName(PolicyDetailType policyDetail) {
        log.info("Entering buildProductName at {}", LocalDateTime.now());
        StringBuilder product = new StringBuilder(BLANK);

        if (policyDetail.getBasePlan() != null) {
            String code = StringUtility.substring(policyDetail.getBasePlan().getCode(), 0, 4);
            String longName = policyDetail.getBasePlan().getLongName();
            product.append(code).append(SPACE).append(DASH).append(SPACE).append(longName);
        }
        log.info("Exiting buildProductName at {}", LocalDateTime.now());
        return product.toString();

    }
}
