package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ClaimPaymentStatus{

	@JsonProperty("code")
	private String code;

	@JsonProperty("description")
	private String description;

}