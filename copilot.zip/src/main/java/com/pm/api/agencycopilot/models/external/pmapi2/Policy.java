package com.pm.api.agencycopilot.models.external.pmapi2;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Policy {

	@JsonProperty("lastPaymentAmt")
	private Object lastPaymentAmt;

	@JsonProperty("annualPremium")
	private Object annualPremium;

	@JsonProperty("recurringAchPremium")
	private Object recurringAchPremium;

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("recurringCCPremium")
	private Object recurringCCPremium;

	@JsonProperty("discounts")
	private List<PolicyDiscounts> discounts;

	@JsonProperty("rateChanges")
	private List<PolicyRateChange> rateChanges;

	@JsonProperty("riderDetails")
	private List<RiderDetailsItem> riderDetails;

	@JsonProperty("beneficiaryDetails")
	private List<BeneficiaryDetails> beneficiaryDetails;

	@JsonProperty("riderOffers")
	private List<RiderOffers> riderOffers;

	@JsonProperty("adminSystem")
	private String adminSystem;

	@JsonProperty("distributionChannel")
	private String distributionChannel;

	@JsonProperty("companyCode")
	private String companyCode;

	@JsonProperty("billingMethod")
	private String billingMethod;

	@JsonProperty("statusChangeReasonCode")
	private String statusChangeReasonCode;

	@JsonProperty("lastPaymentDescrip")
	private String lastPaymentDescrip;

	@JsonProperty("netPremium")
	private String netPremium;

	@JsonProperty("lastPaymentTransDate")
	private String lastPaymentTransDate;

	@JsonProperty("paymentMethod")
	private String paymentMethod;

	@JsonProperty("migratedInd")
	private boolean migratedInd;

	@JsonProperty("longDescription")
	private String longDescription;

	@JsonProperty("benefitAmount")
	private Object benefitAmount;

	@JsonProperty("issueAge")
	private int issueAge;

	@JsonProperty("lastPaymentRecvdDate")
	private String lastPaymentRecvdDate;

	@JsonProperty("policyStatusLong")
	private String policyStatusLong;

	@JsonProperty("lastPmtStatusCode")
	private String lastPmtStatusCode;

	@JsonProperty("submitDate")
	private String submitDate;

	@JsonProperty("monthyPremium")
	private Object monthyPremium;

	@JsonProperty("policyStatus")
	private String policyStatus;

	@JsonProperty("uBenefits")
	private List<UBenefitsItem> uBenefits;

	@JsonProperty("paidToDate")
	private String paidToDate;

	@JsonProperty("lastPaymentDate")
	private String lastPaymentDate;

	@JsonProperty("requestBillEligible")
	private boolean requestBillEligible;

	@JsonProperty("quarterlyPremium")
	private Object quarterlyPremium;

	@JsonProperty("issueDate")
	private Date issueDate;

	@JsonProperty("showLastPaymentReceived")
	private boolean showLastPaymentReceived;

	@JsonProperty("coverageCode")
	private String coverageCode;

	@JsonProperty("policyKindCode")
	private String policyKindCode;

	@JsonProperty("currentPremiumDue")
	private Object currentPremiumDue;

	@JsonProperty("classCode")
	private String classCode;

	@JsonProperty("lastPaymentType")
	private String lastPaymentType;

	@JsonProperty("familyCode")
	private String familyCode;

	@JsonProperty("issueState")
	private String issueState;

	@JsonProperty("otpRulesFailures")
	private List<OtpRulesFailuresItem> otpRulesFailures;

	@JsonProperty("electronicPaymentAllowed")
	private boolean electronicPaymentAllowed;

	@JsonProperty("currentMode")
	private String currentMode;

	@JsonProperty("schedule")
	private String schedule;

	@JsonProperty("semiAnnualPremium")
	private Object semiAnnualPremium;

	@JsonProperty("productCode")
	private String productCode;

	@JsonProperty("suspendCode")
	private String suspendCode;

	@JsonProperty("policyType")
	private String policyType;

	@JsonProperty("additionalCoverages")
	private List<AdditionalCoverage> additionalCoverages;

	@JsonProperty("effectiveDate")
	private String effectiveDate;

	@JsonProperty("nextPayDueDate")
	private String nextPayDueDate;


}