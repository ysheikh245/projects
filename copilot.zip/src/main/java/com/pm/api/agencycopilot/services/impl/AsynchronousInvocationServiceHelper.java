package com.pm.api.agencycopilot.services.impl;

import com.atiam.policy._2008.GetPolicyDetailRequestType;
import com.atiam.policy._2008.GetPolicyDetailResponseType;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.soap.client.InsproPolicyServiceClient;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AsynchronousInvocationServiceHelper {
    @Autowired
    private InsproPolicyServiceClient insproPolicyServiceClient;


    @Async("applicationStatusTaskExecutor")
    public CompletableFuture<GetPolicyDetailResponseType> invokeInsproSOAPCall(PolicyVO policyVO) {
        log.info("Entering invokeInsproSOAPCall at {}. Policy={}", LocalDateTime.now(), policyVO.getPolicyNumber());
        log.debug("Printing the thread information: " + policyVO);
        GetPolicyDetailRequestType request = new GetPolicyDetailRequestType();
        request.setPolicyNumber(policyVO.getPolicyNumber());
        GetPolicyDetailResponseType policyDetail = insproPolicyServiceClient.getPolicyService().getPolicyDetail(request);
        if (policyDetail != null && policyDetail.getInfo() == null) {
            log.error("Unable to find the policy in INSPRO (policyDetail.getInfo()) for the policyId {} ", request.getPolicyNumber());
        }
        if (policyDetail == null) {
            log.error("Unable to find the policy in INSPRO for the policyId ", request.getPolicyNumber());
        }
        log.info("Exiting invokeInsproSOAPCall at {}. Policy={}", LocalDateTime.now(), policyVO.getPolicyNumber());
        return CompletableFuture.completedFuture(policyDetail);
    }
}
