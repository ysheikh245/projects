package com.pm.api.agencycopilot.utility;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import org.apache.commons.lang3.StringUtils;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trim;

public class StringUtility {

    public static ObjectMapper objectMapper = new ObjectMapper();

    public static String getValue(String input) {
        return (isNotEmpty(trim(input))) ? input : BLANK;
    }

    public static boolean isEmpty(String input) {
        return StringUtils.isEmpty(trim(input));
    }

    public static String getAccumulatedValue(String delimeter, String... input) {
        StringBuilder accumulatedValue = new StringBuilder(BLANK);
        for (int i = 0; i < input.length; i++) {
            boolean empty = isEmpty(input[i]);
            if (!empty) {
                accumulatedValue.append(input[i]);
            }

            if (!empty && i < input.length) {
                accumulatedValue.append(delimeter);
            }
        }
        return accumulatedValue.toString();
    }

    public static String substring(String value, int start, int end) {
        return StringUtils.substring(value, start, end);
    }

    public static String objectToString(Object object) throws JsonProcessingException {
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw e;
        }
    }

    public static String formatPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10) {
            return phoneNumber;
        }
        return String.format("%s-%s-%s",
                phoneNumber.substring(0, 3),
                phoneNumber.substring(3, 6),
                phoneNumber.substring(6, 10));
    }
    /*public static String concatenate(String... values) {
        StringBuilder stringBuilder = new StringBuilder(EMPTY);
        for(int i=0; i<values.length; i++) {
            stringBuilder.append(values[i]);
            if(i)
        }
    }*/

}
