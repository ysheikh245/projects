package com.pm.api.agencycopilot.services.impl;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

public class TestImpl {

    public String readFromFile() {
        String s = null;
        try {
            s = FileUtils.readFileToString(new File("C:\\Yusuf\\H750003344.json"), Charset.defaultCharset());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return s;
    }

}
