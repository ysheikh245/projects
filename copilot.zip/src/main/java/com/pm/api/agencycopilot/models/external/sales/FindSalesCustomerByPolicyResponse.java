package com.pm.api.agencycopilot.models.external.sales;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

@JsonRootName("response")
@Data
public class FindSalesCustomerByPolicyResponse {
	private List<SalesCustomerByPolicy> response;

}
