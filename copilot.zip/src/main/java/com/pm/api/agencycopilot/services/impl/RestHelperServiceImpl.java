package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import java.time.LocalDateTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class RestHelperServiceImpl {

    @Autowired
    private RestTemplate restTemplate;


    public <T> ResponseEntity<T> invoke(String url, HttpMethod httpMethod, HttpEntity requestEntity, ParameterizedTypeReference parameterizedTypeReference) {
        log.info("Entering invoke at {}", LocalDateTime.now());
        log.info("Invoking endpoing with url {} and ParameterizedTypeReference response type {}", url, parameterizedTypeReference);
        try {
            final ResponseEntity<T> responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, parameterizedTypeReference);
            return responseEntity;
        } catch (
                HttpClientErrorException httpClientErrorException) {
            log.error("HttpClientErrorException occured when calling {}, got {}", url, httpClientErrorException.getMessage());
            if (HttpStatus.NOT_FOUND == httpClientErrorException.getStatusCode()) {
                log.info("Exiting invoke at {}", LocalDateTime.now());
                return new ResponseEntity(HttpStatus.OK);
            }
            log.info("Entering invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(httpClientErrorException,
                    httpClientErrorException.getStatusCode(),
                    url);
        } catch (
                HttpServerErrorException httpServerErrorException) {
            log.error("HttpServerErrorException occured when calling {} got {}", url, httpServerErrorException.getMessage());
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(httpServerErrorException,
                    httpServerErrorException.getStatusCode(),
                    url);
        } catch (Exception exception) {
            log.error("Uncaught Exception occured when calling {} got {}", url, exception.getMessage());
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(exception,
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    url);
        }
    }

    public <T> ResponseEntity<T> invoke(String url, HttpMethod httpMethod, HttpEntity requestEntity, Class<T> clazz) {
        log.info("Entering invoke at {}", LocalDateTime.now());
        log.info("...Invoking endpoing with url {} with Class<T> response type {}", url, clazz);
        try {
            final ResponseEntity<T> responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, clazz);
            log.info("Exiting invoke at {}", LocalDateTime.now());
            return responseEntity;
        } catch (
                HttpClientErrorException httpClientErrorException) {
            log.error("HttpClientErrorException occured when calling {} got {}", url, httpClientErrorException.getMessage());
            if (HttpStatus.NOT_FOUND == httpClientErrorException.getStatusCode()) {
                log.info("Exiting invoke at {}", LocalDateTime.now());
                return new ResponseEntity(HttpStatus.NO_CONTENT);
            }
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot4xxException(httpClientErrorException,
                    httpClientErrorException.getStatusCode(),
                    url);
        } catch (
                HttpServerErrorException httpServerErrorException) {
            log.error("HttpServerErrorException occured when calling {} got {}", url, httpServerErrorException.getMessage());
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(httpServerErrorException,
                    httpServerErrorException.getStatusCode(),
                    url);
        } catch (Exception exception) {
            log.error("Uncaught Exception occured when calling {} got {}", url, exception.getMessage());
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(exception,
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    url);
        }


    }
}
