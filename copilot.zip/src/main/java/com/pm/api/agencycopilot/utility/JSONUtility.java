package com.pm.api.agencycopilot.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.apache.commons.lang3.StringUtils;

public class JSONUtility {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    static {
        OBJECT_MAPPER.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
    }

    public static String convertObjectToString(Object object) throws Exception {
        try {
            return OBJECT_MAPPER.writeValueAsString(object);
        } catch(Exception e) {
            return StringUtils.EMPTY;
        }
    }

    public static Object convertStringToObject(String jsonString) {
        try {
            return OBJECT_MAPPER.readValue(jsonString, Object.class);
        } catch (JsonProcessingException e) {
            return null;
        } catch(Exception e) {
            return null;
        }
    }

    public static <T> T convertStringToObject(String jsonString, Class<T> clazz) {
        try {
            return OBJECT_MAPPER.readValue(jsonString, clazz);
        } catch (JsonProcessingException e) {
            return null;
        } catch(Exception e) {
            return null;
        }
    }
}
