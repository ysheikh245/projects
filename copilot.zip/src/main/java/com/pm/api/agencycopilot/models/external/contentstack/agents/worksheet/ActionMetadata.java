package com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ActionMetadata{

	@JsonProperty("caseMetadata")
	private CaseMetadata caseMetadata;

	public CaseMetadata getCaseMetadata(){
		return caseMetadata;
	}
}