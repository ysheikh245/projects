package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.claims.ClaimsResponseItem;
import com.pm.api.agencycopilot.models.external.claims.details.Response;

import java.util.List;

public interface ClaimsServiceHandler extends ServiceHandler {

    List<ClaimsResponseItem> getClaimsFromPartyId(String partyId);

    Response getClaimDetails(String claimNumber);

}
