package com.pm.api.agencycopilot.models.external.customers;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PolicyListItem{

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("policyStatus")
	private String policyStatus;

	@JsonProperty("policyRoleList")
	private List<PolicyRoleListItem> policyRoleList;

	public String getPolicyNumber(){
		return policyNumber;
	}

	public String getPolicyStatus(){
		return policyStatus;
	}

	public List<PolicyRoleListItem> getPolicyRoleList(){
		return policyRoleList;
	}
}