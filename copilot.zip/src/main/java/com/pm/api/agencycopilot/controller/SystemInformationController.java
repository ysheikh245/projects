package com.pm.api.agencycopilot.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.SystemInformation;
import com.pm.api.agencycopilot.services.SystemInformationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class SystemInformationController implements ApplicationController {
    @Autowired
    private SystemInformationService systemInformationService;

    @GetMapping("/data")
    public ResponseEntity getSystemData() {
        log.info("SystemInformationController.getSystemData() -Start");
        SystemInformation systemInformation = systemInformationService.getSystemData();
        log.info("SystemInformationController.getSystemData() -Complete");
        return ResponseEntity.ok(systemInformation);
    }

}
