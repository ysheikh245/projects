package com.pm.api.agencycopilot.exception;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class AgencyCoPilot4xxException extends AgencyCoPilotException {


    public AgencyCoPilot4xxException(Exception exception,
                                     HttpStatus httpStatus,
                                     String apiEndpoint) {
        super(exception, httpStatus, apiEndpoint);
    }

    public AgencyCoPilot4xxException(String message,
                                     HttpStatus httpStatus,
                                     String apiEndpoint) {
        super(new Exception(message), httpStatus, apiEndpoint);
    }
}
