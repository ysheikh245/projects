package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PolicyInfoV2Response<T> {

    @JsonProperty("response")
    private List<T> response;
}
