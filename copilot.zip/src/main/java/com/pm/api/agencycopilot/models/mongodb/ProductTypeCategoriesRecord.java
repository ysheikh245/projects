package com.pm.api.agencycopilot.models.mongodb;

import java.time.LocalDateTime;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class ProductTypeCategoriesRecord {

    @Id
    private String productCode;
    private String category;
    private boolean isActive;
    @DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private LocalDateTime createdDate;
    private String createdBy;
    @DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
    private LocalDateTime updatedDate;
    private String updatedBy;

}
