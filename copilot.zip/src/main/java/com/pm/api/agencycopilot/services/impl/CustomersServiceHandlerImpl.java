package com.pm.api.agencycopilot.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pm.api.agencycopilot.models.apis.CustomerDetailsRequestType;
import com.pm.api.agencycopilot.models.apis.CustomerSearchRequest;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.external.customers.CustomerByPolicy;
import com.pm.api.agencycopilot.models.external.customers.ExternalReferenceListItem;
import com.pm.api.agencycopilot.models.external.customers.FindCustomerByPolicyResponse;
import com.pm.api.agencycopilot.models.external.customers.PolicyListItem;
import com.pm.api.agencycopilot.models.external.customers.PolicyRoleListItem;
import com.pm.api.agencycopilot.models.external.customers.SearchParams;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.services.CustomersServiceHandler;
import com.pm.api.agencycopilot.utility.AgencyCoPilotConstants;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class CustomersServiceHandlerImpl implements CustomersServiceHandler {

    @Value("${agency.copilot.customers.api.username}")
    private String customersAPIUsername;

    @Value("${agency.copilot.customers.api.password}")
    private String customersAPIPassword;

    @Value("${agency.copilot.customers.api.customer.by.policy.url}")
    private String customersByPolicyAPIEndpoint;

    @Value("${agency.copilot.customers.api.client.header}")
    private String customersAPIClientHeader;

    @Value("${agency.copilot.customers.api.search.url}")
    private String customersBySearchApiEndPoint;

    @Value("${agency.copilot.customers.api.end.userid}")
    private String customersAPIClientUserId;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${agency.copilot.pmapi.customers.alerts.endpoint}")
    private String alertsEndpoint;

    @Value("${agency.copilot.pmapi.service.client.header}")
    private String pmapiClientHeader;

    @Value("${agency.copilot.pmapi.service.end.userid}")
    private String pmapiEndUserId;

    @Value("${agency.copilot.pmapi.customers.alerts.username}")
    private String alertsAPIUsername;

    @Value("${agency.copilot.pmapi.customers.alerts.password}")
    private String alertsAPIPassword;

    @Autowired
    private RestHelperServiceImpl restHelperService;

    @Autowired
    private MaskedValueLogger maskedValueLogger;


    @Override
    public FindCustomerByPolicyResponse invokeCustomerV2PMAPIByPolicy(String policyNumber) {
        log.info("Entering invokeCustomerV2PMAPIByPolicy at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", customersAPIClientHeader);
        headers.add("end-user-id", customersAPIClientUserId);
        headers.add("Authorization", getBasicAuthToken(customersAPIUsername, customersAPIPassword));

        HttpEntity request = new HttpEntity(headers);

        ResponseEntity<FindCustomerByPolicyResponse> response =
                restHelperService.invoke(StringUtils.replace(customersByPolicyAPIEndpoint, "{policyNumber}", policyNumber),
                        HttpMethod.GET,
                        request,
                        FindCustomerByPolicyResponse.class);
        log.info("Exiting invokeCustomerV2PMAPIByPolicy at {}", LocalDateTime.now());
        return response.getBody();
    }

    @Override
    public FindCustomerByPolicyResponse invokeCustomerV2PMAPISearch(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest) {
        log.info("Entering invokeCustomerV2PMAPISearch at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", customersAPIClientHeader);
        headers.add("end-user-id", customersAPIClientUserId);
        headers.add("Content-type", "application/json");
        headers.add("Authorization", getBasicAuthToken(customersAPIUsername, customersAPIPassword));

        CustomerSearchRequest requestData = new CustomerSearchRequest();
        SearchParams searchParams = new SearchParams();
        if (policyByCustomerDetailsRequest.getType().equals(CustomerDetailsRequestType.SEARCH_BY_POLICY)) {
            requestData.setType("searchByPolicy");
            searchParams.setPolicy(policyByCustomerDetailsRequest.getPolicyNumber());
        } else {
            requestData.setType("searchByDynamicCriteria");
            searchParams.setFirstName(policyByCustomerDetailsRequest.getFirstName());
            searchParams.setLastName(policyByCustomerDetailsRequest.getLastName());
            searchParams.setState(policyByCustomerDetailsRequest.getState());
            searchParams.setZipCode(policyByCustomerDetailsRequest.getZip());
            searchParams.setDateOfBirth(policyByCustomerDetailsRequest.getDateOfBirth());
        }
        requestData.setSearchParams(searchParams);

        HttpEntity request = new HttpEntity(requestData, headers);

        ResponseEntity<FindCustomerByPolicyResponse> response = restHelperService.invoke(customersBySearchApiEndPoint,
                HttpMethod.POST,
                request,
                FindCustomerByPolicyResponse.class);
        log.info("Exiting invokeCustomerV2PMAPISearch at {}", LocalDateTime.now());
        return response.getBody();
    }

    @Override
    public String findPartyId(String policyNumber) {
        log.info("Entering findPartyId at {}", LocalDateTime.now());
        FindCustomerByPolicyResponse v2PMAPICustomerByPolicy = invokeCustomerV2PMAPIByPolicy(policyNumber);
        if (v2PMAPICustomerByPolicy != null) {
            List<CustomerByPolicy> customersByPolicy = v2PMAPICustomerByPolicy.getResponse();
            maskedValueLogger.debug(String.format("CustomersByPolicy Response %s", customersByPolicy), log);
            String partyId = parseResponseAndFindPartyId(customersByPolicy, AgencyCoPilotConstants.INSPRO, policyNumber, AgencyCoPilotConstants.OWNER);
            if (partyId == null) {
                partyId = parseResponseAndFindPartyId(customersByPolicy, AgencyCoPilotConstants.COGEN, policyNumber, AgencyCoPilotConstants.OWNER);
                if (partyId == null) {
                    partyId = StringUtils.EMPTY;
                }
            }
            log.info("Exiting findPartyId at {}", LocalDateTime.now());
            return partyId;
//            return parseListToFindPartyId(customersByPolicy, policyNumber);
        }
        log.info("Exiting findPartyId at {}", LocalDateTime.now());
        return StringUtils.EMPTY;
    }

    @Override
    public DocumentsV2Response<PolicyAlertResponse> getPolicyAlerts(String partyId) throws Exception {
        return getPolicyAlertFromPMAPI(partyId);
    }

    private String parseResponseAndFindPartyId(List<CustomerByPolicy> customerByPolicyList, String customerIdType, String policyNumber, String roleName) {
        log.info("Entering parseResponseAndFindPartyId at {}", LocalDateTime.now());
        log.info("Parsing Response and finding the partyId for customerIdType {}", customerIdType);
        for (CustomerByPolicy customerByPolicy : customerByPolicyList) {

            List<ExternalReferenceListItem> insproExternalReferencesListItems = customerByPolicy.getExternalReferenceList().stream()
                    .filter(externalReferenceListItem -> externalReferenceListItem.getCustomerIdType().equalsIgnoreCase(customerIdType)
                    ).collect(Collectors.toList());

            for (ExternalReferenceListItem externalReferenceListItem : insproExternalReferencesListItems) {
                List<PolicyListItem> policyListItemList = externalReferenceListItem.getPolicyList().stream()
                        .filter(policyListItem -> policyListItem.getPolicyNumber().equalsIgnoreCase(policyNumber))
                        .collect(Collectors.toList());
                for (PolicyListItem policyListItem : policyListItemList) {
                    List<PolicyRoleListItem> policyRoleListItemList = policyListItem.getPolicyRoleList().stream()
                            .filter(policyRoleListItem -> policyRoleListItem.getRole().equalsIgnoreCase(roleName))
                            .collect(Collectors.toList());
                    log.debug("Filtered roles are {} and size {}", policyRoleListItemList, policyRoleListItemList.size());
                    policyListItemList.forEach(System.out::println);
                    if (CollectionUtils.isNotEmpty(policyRoleListItemList)) {
                        log.info("Exiting parseResponseAndFindPartyId at {}", LocalDateTime.now());
                        maskedValueLogger.info(String.format("Found the party Id for the policy %s, partyId %s, role %s",
                                policyNumber,
                                customerByPolicy.getPartyId(),
                                policyRoleListItemList.get(0).getRole()), log);
                        return customerByPolicy.getPartyId();
                    }

                }
            }
        }
        log.info("Exiting parseResponseAndFindPartyId at {}", LocalDateTime.now());
        return null;
    }

    private DocumentsV2Response<PolicyAlertResponse> getPolicyAlertFromPMAPI(String partyId) throws JsonProcessingException {
        log.info("Entering getPolicyAlertFromPMAPI at {}", LocalDateTime.now());
        log.info("CustomerServiceHandlerImpl.getPolicyAlertFromPMAPI() -PMAPI Alerts Endpoints API Call for partyID: {}", partyId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", pmapiClientHeader);
        headers.add("end-user-id", pmapiEndUserId);
        headers.add("Authorization", getBasicAuthToken(alertsAPIUsername, alertsAPIPassword));

        HttpEntity request = new HttpEntity(headers);

        ResponseEntity<DocumentsV2Response<PolicyAlertResponse>> response = restHelperService.invoke(
                alertsEndpoint.replace("{partyId}", partyId),
                HttpMethod.GET,
                request,
                new ParameterizedTypeReference<DocumentsV2Response<PolicyAlertResponse>>() {
                });
        maskedValueLogger.info(
                String.format("CustomerServiceHandlerImpl.getPolicyAlertFromPMAPI() -PMAPI Alerts Endpoints API Call response. %s ",
                        response.toString()),
                log);
        if (HttpStatus.NOT_FOUND == response.getStatusCode()) {
            log.info("Exiting getPolicyAlertFromPMAPI at {}", LocalDateTime.now());
            return null;
        }
        log.info("Exiting getPolicyAlertFromPMAPI at {}", LocalDateTime.now());
        return response.getBody();
    }

}
