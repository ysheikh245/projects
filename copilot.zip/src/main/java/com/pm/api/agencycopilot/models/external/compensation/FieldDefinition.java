package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class FieldDefinition {

    @JsonProperty("parentName")
    private String parentName;

    @JsonProperty("fieldName")
    private String fieldName;

    @JsonProperty("dataType")
    private int dataType;

    @JsonProperty("length")
    private int length;

    @JsonProperty("scale")
    private int scale;

    @JsonProperty("allowNull")
    private boolean allowNull;

    @JsonProperty("collection")
    private boolean collection;

    @JsonProperty("enumeration")
    private boolean enumeration;

    @JsonProperty("categoryName")
    private String categoryName;

    @JsonProperty("defaultName")
    private String defaultName;

    @JsonProperty("valueList")
    private Object valueList;

    @JsonProperty("pattern")
    private String pattern;

    @JsonProperty("defaultValue")
    private Integer defaultValue;

}