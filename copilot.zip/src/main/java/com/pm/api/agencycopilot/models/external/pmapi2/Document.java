package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Document {
    @JsonProperty("documentId")
    private String documentId;
    @JsonProperty("uri")
    private String uri;
    @JsonProperty("fileName")
    private String fileName;
    @JsonProperty("policyNumber")
    private String policyNumber;
    @JsonProperty("documentLocation")
    private String documentLocation;
    @JsonProperty("documentSource")
    private String documentSource;
    @JsonProperty("documentType")
    private String documentType;
    @JsonProperty("versionNumber")
    private int versionNumber;
    @JsonProperty("documentScannedDate")
    private String documentScannedDate;
    @JsonProperty("createdDateTime")
    private String createdDateTime;
    @JsonProperty("receivedDateTime")
    private String receivedDateTime;
}
