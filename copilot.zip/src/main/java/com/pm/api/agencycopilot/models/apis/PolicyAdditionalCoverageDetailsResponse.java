package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.external.pmapi2.AdditionalCoverage;
import lombok.Data;

import java.util.List;
@Data
public class PolicyAdditionalCoverageDetailsResponse {

    private List<AdditionalCoverage> additionalCoverages;

}
