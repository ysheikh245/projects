package com.pm.api.agencycopilot.models.internal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @NoArgsConstructor
public class CoverageDetailsVO {
    private String status;
    private String coverageCode;
    private String coverageDesc;
    private String offer;
    private double benDed;
    private String effectiveDate;
    private String term;
    private Double premium;
    private String firstName;
    private String middleName;
    private String lastName;
}
