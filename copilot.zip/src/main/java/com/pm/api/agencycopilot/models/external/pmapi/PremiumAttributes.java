package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PremiumAttributes{

	@JsonProperty("BalanceToMinimum")
	private String balanceToMinimum;

	@JsonProperty("AnnualPremium")
	private String annualPremium;

	@JsonProperty("FullTermPremium")
	private String fullTermPremium;

	@JsonProperty("TransPremNotSubToAud")
	private String transPremNotSubToAud;

	@JsonProperty("CommissionablePremium")
	private String commissionablePremium;

	@JsonProperty("WrittenPremium")
	private String writtenPremium;

	@JsonProperty("TransactionPremium")
	private String transactionPremium;

	@JsonProperty("IsSubToFullyCharge")
	private String isSubToFullyCharge;

	@JsonProperty("IsSubToFullyEarn")
	private String isSubToFullyEarn;

	public String getBalanceToMinimum(){
		return balanceToMinimum;
	}

	public String getAnnualPremium(){
		return annualPremium;
	}

	public String getFullTermPremium(){
		return fullTermPremium;
	}

	public String getTransPremNotSubToAud(){
		return transPremNotSubToAud;
	}

	public String getCommissionablePremium(){
		return commissionablePremium;
	}

	public String getWrittenPremium(){
		return writtenPremium;
	}

	public String getTransactionPremium(){
		return transactionPremium;
	}

	public String getIsSubToFullyCharge(){
		return isSubToFullyCharge;
	}

	public String getIsSubToFullyEarn(){
		return isSubToFullyEarn;
	}
}