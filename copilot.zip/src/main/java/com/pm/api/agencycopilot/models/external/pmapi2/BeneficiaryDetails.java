package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BeneficiaryDetails {

    @JsonProperty("companyCode")
    private String companyCode;

    @JsonProperty("policyNumber")
    private String policyNumber;

    @JsonProperty("personNumber")
    private int personNumber;

    @JsonProperty("accountNumber")
    private Long accountNumber;

    @JsonProperty("beneficiaryRank")
    private int beneficiaryRank;

    @JsonProperty("statusCode")
    private String statusCode;

    @JsonProperty("statusReason")
    private String statusReason;

    @JsonProperty("beneficiaryType")
    private String beneficiaryType;

    @JsonProperty("sharePercent")
    private int sharePercent;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("rankDescrip")
    private String rankDescrip;

    @JsonProperty("beneRelationship")
    private String beneRelationship;

    @JsonProperty("beneficiaryName")
    private String beneficiaryName;
}
