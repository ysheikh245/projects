package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomerMessage {
    @JsonProperty("messageCode")
    private String messageCode;

    @JsonProperty("message")
    private String message;

    @JsonProperty("alertLevel")
    private String alertLevel;
}