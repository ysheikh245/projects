package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class DocumentSearchCriteria {
    private String policyNumber;
    private String queryString;

    @JsonCreator
    public DocumentSearchCriteria(@JsonProperty("policyNumber") String policyNumber, @JsonProperty("queryString") String queryString) {
        this.policyNumber = policyNumber;
        this.queryString = queryString;
    }
}
