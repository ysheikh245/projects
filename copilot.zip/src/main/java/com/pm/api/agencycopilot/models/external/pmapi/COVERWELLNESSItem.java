package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class COVERWELLNESSItem{

	@JsonProperty("CCoverage")
	private String cCoverage;

	@JsonProperty("CSeq")
	private String cSeq;

	@JsonProperty("CVaccinesLimit")
	private String cVaccinesLimit;

	@JsonProperty("CWellnessExpirDt")
	private String cWellnessExpirDt;

	@JsonProperty("CExcessWellWaitPerDt")
	private String cExcessWellWaitPerDt;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CRatingFunction")
	private String cRatingFunction;

	@JsonProperty("CTier")
	private String cTier;

	@JsonProperty("CWellnessWaitPeriod")
	private String cWellnessWaitPeriod;

	@JsonProperty("CNeuterTeethCleanLmt")
	private String cNeuterTeethCleanLmt;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CCoverageCode")
	private String cCoverageCode;

	@JsonProperty("CMicroHelthCertLimit")
	private String cMicroHelthCertLimit;

	@JsonProperty("CWellnessPlan")
	private String cWellnessPlan;

	@JsonProperty("CWellnessEffectDt")
	private String cWellnessEffectDt;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CWellnessExamLimit")
	private String cWellnessExamLimit;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("CRatingFormula")
	private String cRatingFormula;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("CTestsLimit")
	private String cTestsLimit;

	@JsonProperty("CCovWell")
	private String cCovWell;

	@JsonProperty("CWellnessPremium")
	private String cWellnessPremium;

	@JsonProperty("CDewormingLimit")
	private String cDewormingLimit;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	public String getCCoverage(){
		return cCoverage;
	}

	public String getCSeq(){
		return cSeq;
	}

	public String getCVaccinesLimit(){
		return cVaccinesLimit;
	}

	public String getCWellnessExpirDt(){
		return cWellnessExpirDt;
	}

	public String getCExcessWellWaitPerDt(){
		return cExcessWellWaitPerDt;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCRatingFunction(){
		return cRatingFunction;
	}

	public String getCTier(){
		return cTier;
	}

	public String getCWellnessWaitPeriod(){
		return cWellnessWaitPeriod;
	}

	public String getCNeuterTeethCleanLmt(){
		return cNeuterTeethCleanLmt;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCCoverageCode(){
		return cCoverageCode;
	}

	public String getCMicroHelthCertLimit(){
		return cMicroHelthCertLimit;
	}

	public String getCWellnessPlan(){
		return cWellnessPlan;
	}

	public String getCWellnessEffectDt(){
		return cWellnessEffectDt;
	}

	public String getGid(){
		return gid;
	}

	public String getCWellnessExamLimit(){
		return cWellnessExamLimit;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getCRatingFormula(){
		return cRatingFormula;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getCTestsLimit(){
		return cTestsLimit;
	}

	public String getCCovWell(){
		return cCovWell;
	}

	public String getCWellnessPremium(){
		return cWellnessPremium;
	}

	public String getCDewormingLimit(){
		return cDewormingLimit;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}
}