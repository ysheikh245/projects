package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CPIPlanItem{

	@JsonProperty("CAnnCovLimitType")
	private String cAnnCovLimitType;

	@JsonProperty("CAnnualDeductible")
	private String cAnnualDeductible;

	@JsonProperty("CAnnCovLmt")
	private String cAnnCovLmt;

	@JsonProperty("CIllnessEffectiveDt")
	private String cIllnessEffectiveDt;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CIllnessExpirDate")
	private String cIllnessExpirDate;

	@JsonProperty("CEffectAnnDed")
	private String cEffectAnnDed;

	@JsonProperty("CPiPlan")
	private String cPiPlan;

	@JsonProperty("CWaiveOrthoWaitPr")
	private String cWaiveOrthoWaitPr;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CExcessIllnessDy")
	private String cExcessIllnessDy;

	@JsonProperty("CIllnessWaitDays")
	private String cIllnessWaitDays;

	@JsonProperty("CExcessWaitDays")
	private String cExcessWaitDays;

	@JsonProperty("CCoinsurance")
	private String cCoinsurance;

	@JsonProperty("CCovType")
	private String cCovType;

	@JsonProperty("CDedReducAmt")
	private String cDedReducAmt;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CExcessOrthoWtPrDy")
	private String cExcessOrthoWtPrDy;

	@JsonProperty("COrthoEffectDt")
	private String cOrthoEffectDt;

	@JsonProperty("CPerIncidentCopay")
	private String cPerIncidentCopay;

	@JsonProperty("CNumTermCount")
	private String cNumTermCount;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CAccAwaitDt")
	private String cAccAwaitDt;

	@JsonProperty("CDedReduction")
	private String cDedReduction;

	@JsonProperty("COrthopedicWaitPrDy")
	private String cOrthopedicWaitPrDy;

	@JsonProperty("CAccWaitPeriod")
	private String cAccWaitPeriod;

	@JsonProperty("CSelectedPetPlan")
	private String cSelectedPetPlan;

	@JsonProperty("CReimbursement")
	private String cReimbursement;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("CAccExpDt")
	private String cAccExpDt;

	@JsonProperty("COrthoExpDate")
	private String cOrthoExpDate;

	public String getCAnnCovLimitType(){
		return cAnnCovLimitType;
	}

	public String getCAnnualDeductible(){
		return cAnnualDeductible;
	}

	public String getCAnnCovLmt(){
		return cAnnCovLmt;
	}

	public String getCIllnessEffectiveDt(){
		return cIllnessEffectiveDt;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCIllnessExpirDate(){
		return cIllnessExpirDate;
	}

	public String getCEffectAnnDed(){
		return cEffectAnnDed;
	}

	public String getCPiPlan(){
		return cPiPlan;
	}

	public String getCWaiveOrthoWaitPr(){
		return cWaiveOrthoWaitPr;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCExcessIllnessDy(){
		return cExcessIllnessDy;
	}

	public String getCIllnessWaitDays(){
		return cIllnessWaitDays;
	}

	public String getCExcessWaitDays(){
		return cExcessWaitDays;
	}

	public String getCCoinsurance(){
		return cCoinsurance;
	}

	public String getCCovType(){
		return cCovType;
	}

	public String getCDedReducAmt(){
		return cDedReducAmt;
	}

	public String getGid(){
		return gid;
	}

	public String getCExcessOrthoWtPrDy(){
		return cExcessOrthoWtPrDy;
	}

	public String getCOrthoEffectDt(){
		return cOrthoEffectDt;
	}

	public String getCPerIncidentCopay(){
		return cPerIncidentCopay;
	}

	public String getCNumTermCount(){
		return cNumTermCount;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getCAccAwaitDt(){
		return cAccAwaitDt;
	}

	public String getCDedReduction(){
		return cDedReduction;
	}

	public String getCOrthopedicWaitPrDy(){
		return cOrthopedicWaitPrDy;
	}

	public String getCAccWaitPeriod(){
		return cAccWaitPeriod;
	}

	public String getCSelectedPetPlan(){
		return cSelectedPetPlan;
	}

	public String getCReimbursement(){
		return cReimbursement;
	}

	public String getId(){
		return id;
	}

	public String getCAccExpDt(){
		return cAccExpDt;
	}

	public String getCOrthoExpDate(){
		return cOrthoExpDate;
	}
}