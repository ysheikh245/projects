package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class PolicyMessage {
    @JsonProperty("policyNumber")
    private String policyNumber;

    @JsonProperty("messages")
    private List<PolicyMessageItem> messages;
}
