package com.pm.api.agencycopilot.models.external.claims;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ClaimsResponseItem {

	@JsonProperty("benefitPeriod")
	private String benefitPeriod;

	@JsonProperty("lastUpdatedDate")
	private String lastUpdatedDate;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("claimRcvdDate")
	private String claimRcvdDate;

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("specialHandling")
	private String specialHandling;

	@JsonProperty("claimantName")
	private String claimantName;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	@JsonProperty("source")
	private String source;

	@JsonProperty("claimNumber")
	private String claimNumber;

	@JsonProperty("claimStatus")
	private String claimStatus;
}