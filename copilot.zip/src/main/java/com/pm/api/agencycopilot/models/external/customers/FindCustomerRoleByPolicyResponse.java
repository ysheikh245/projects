package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

import java.util.List;

@JsonRootName("response")
@Data
public class FindCustomerRoleByPolicyResponse {
    private List<CustomerRoleByPolicy> response;
}
