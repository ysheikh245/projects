package com.pm.api.agencycopilot.models.external.case360;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
//@JsonRootName("FmsRowSetTO")
public class FmsRowSetTO {

	@JsonProperty("FmsRowTO")
	private List<FmsRowTO> fmsRowTO;

	@JsonProperty("rowCount")
	private int rowCount;


}