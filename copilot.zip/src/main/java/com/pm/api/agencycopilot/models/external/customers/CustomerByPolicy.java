package com.pm.api.agencycopilot.models.external.customers;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CustomerByPolicy {

	@JsonProperty("companyCode")
	private String companyCode;

	@JsonProperty("originatingSource")
	private String originatingSource;

	@JsonProperty("partyType")
	private String partyType;

	@JsonProperty("userId")
	private String userId;

	@JsonProperty("partyStatus")
	private String partyStatus;

	@JsonProperty("partyCategory")
	private String partyCategory;

	@JsonProperty("phone")
	private Phone phone;

	@JsonProperty("addressList")
	private List<AddressListItem> addressList;

	@JsonProperty("person")
	private Person person;

	@JsonProperty("inactiveDate")
	private Object inactiveDate;

	@JsonProperty("externalReferenceList")
	private List<ExternalReferenceListItem> externalReferenceList;

	@JsonProperty("inactiveFlag")
	private boolean inactiveFlag;

	@JsonProperty("partyId")
	private String partyId;

	@JsonProperty("email")
	private Email email;

	public String getCompanyCode(){
		return companyCode;
	}

	public String getOriginatingSource(){
		return originatingSource;
	}

	public String getPartyType(){
		return partyType;
	}

	public String getUserId(){
		return userId;
	}

	public String getPartyStatus(){
		return partyStatus;
	}

	public String getPartyCategory(){
		return partyCategory;
	}

	public Phone getPhone(){
		return phone;
	}

	public List<AddressListItem> getAddressList(){
		return addressList;
	}

	public Person getPerson(){
		return person;
	}

	public Object getInactiveDate(){
		return inactiveDate;
	}

	public List<ExternalReferenceListItem> getExternalReferenceList(){
		return externalReferenceList;
	}

	public boolean isInactiveFlag(){
		return inactiveFlag;
	}

	public String getPartyId(){
		return partyId;
	}

	public Email getEmail(){
		return email;
	}
}