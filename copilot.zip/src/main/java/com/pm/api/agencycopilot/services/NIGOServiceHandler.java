package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.nigo.NIGOResponse;

import java.util.List;

public interface NIGOServiceHandler {

    NIGOResponse invokeNIGO(List<String> policyNumber) throws Exception;

}
