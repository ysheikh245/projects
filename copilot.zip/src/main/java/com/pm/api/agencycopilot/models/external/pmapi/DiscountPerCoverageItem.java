package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class DiscountPerCoverageItem{

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("CDiscountPerCoverage")
	private String cDiscountPerCoverage;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("PetDiscountCoverage")
	private List<PetDiscountCoverageItem> petDiscountCoverage;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("DiscountCoverageRating")
	private List<DiscountCoverageRatingItem> discountCoverageRating;

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getCDiscountPerCoverage(){
		return cDiscountPerCoverage;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public List<PetDiscountCoverageItem> getPetDiscountCoverage(){
		return petDiscountCoverage;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public String getId(){
		return id;
	}

	public List<DiscountCoverageRatingItem> getDiscountCoverageRating(){
		return discountCoverageRating;
	}
}