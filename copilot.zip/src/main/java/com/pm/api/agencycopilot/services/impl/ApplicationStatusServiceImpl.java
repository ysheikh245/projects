package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusRequest;
import com.pm.api.agencycopilot.models.apis.ApplicationStatusResponse;
import com.pm.api.agencycopilot.models.apis.WorkSheetDetailsResponse;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.models.internal.FilterCriteriaVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import com.pm.api.agencycopilot.models.mongodb.PolicyCachingStatusRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyCategoriesRecord;
import com.pm.api.agencycopilot.models.mongodb.PolicyDatabaseRecord;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.services.ApplicationStatusService;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import com.pm.api.agencycopilot.utility.ApplicationStatusProperties;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ApplicationStatusServiceImpl implements ApplicationStatusService {

    @Autowired
    private ApplicationStatusHelperServiceImpl applicationStatusHelperService;

    @Autowired
    private AsynchronousInvocationServiceHelper asynchronousInvocationServiceHelper;

    @Value("${agency.copilot.background.processing.feature:false}")
    private String backgroundProcessingFlag;

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private ApplicationStatusProperties applicationStatusProperties;


    @Override
    public ApplicationStatusResponse processApplicationStatus(ApplicationStatusRequest applicationStatusRequest) {
        log.info("Entering processApplicationStatus at {}", LocalDateTime.now());
        try {
            String npnId = applicationStatusRequest.getAgentInformation().getNpn();
            ApplicationStatusResponse applicationStatusResponse = null;
            if (isFilterApplied(applicationStatusRequest.getFilterCriteria())) {
                PolicyCachingStatusRecord policyCachingStatusRecord = mongoDBCacheHandler.findPolicyCachingStatusByNpnId(npnId);
                if (policyCachingStatusRecord != null) {
                    log.info("Application status search data available in cache for npn {} ", applicationStatusRequest.getAgentInformation().getNpn());
                    applicationStatusResponse = verifyProcessAndReturnData(policyCachingStatusRecord, applicationStatusRequest, 0);
                } else {
                    log.info("PolicyCachingStatusRecord doesn't exist or expired, deleting the policies by npnId {} from policies collection", npnId);
                    mongoDBCacheHandler.findAndDeletePoliciesByNpn(npnId);
                    applicationStatusResponse = initiateApplicationStatusSearch(applicationStatusRequest);
                }
            } else {
                log.info("Filter not applied hence deleting all policies for npnId {} if any exists.", npnId);
                mongoDBCacheHandler.findAndDeletePoliciesByNpn(npnId);
                mongoDBCacheHandler.findAndDeletePolicyCacheResultByNpn(npnId);
                log.info("Initiating the application status search as this is the initial search for npn {} ", applicationStatusRequest.getAgentInformation().getNpn());
                applicationStatusResponse = initiateApplicationStatusSearch(applicationStatusRequest);
            }
            log.info("Exiting processApplicationStatus at {}", LocalDateTime.now());
            return applicationStatusResponse;

        } catch (AgencyCoPilot4xxException agencyCoPilot4xxException) {
            log.error("AgencyCoPilot4xxException occurred while processing application status for NPN={} with errorMessage={}"
                    , applicationStatusRequest.getAgentInformation().getNpn()
                    , agencyCoPilot4xxException.getMessage());
            throw agencyCoPilot4xxException;
        } catch (Exception e) {
            log.error("Error occurred while processing application status for NPN={} with errorMessage={}"
                    , applicationStatusRequest.getAgentInformation().getNpn()
                    , e.getMessage());
            throw new AgencyCoPilotException("Internal Error Occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    private ApplicationStatusResponse verifyProcessAndReturnData(PolicyCachingStatusRecord policyCachingStatusRecord,
                                                                 ApplicationStatusRequest applicationStatusRequest,
                                                                 int counter) {
        log.info("Entering verifyProcessAndReturnData at {}", LocalDateTime.now());
        long defaultSearchCount = policyCachingStatusRecord.getDefaultPolicySearchProcess().getTotalPoliciesFetched();
        int startRecordToBeFetched = ((applicationStatusRequest.getFilterCriteria().getPageNumber() + 1) *
                applicationStatusRequest.getFilterCriteria().getPageSize());
        if (startRecordToBeFetched < defaultSearchCount) {
            return applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);
        } else if (policyCachingStatusRecord.getBackgroundPolicySearchProcess() != null
                && policyCachingStatusRecord.getBackgroundPolicySearchProcess().isSearchCompleted()) {
            return applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);
        } else {
            log.info("Background Process is in progress and waiting for {} second", applicationStatusProperties.getVerifyBkgGrdVerificationRetryMillis());
            if (counter > applicationStatusProperties.getBackgroundProcessVerificationCount()) {
                String errorMessage = String.format("Background Process is not completed after %s retries. NpnId=%s, processStartedAt=%s",
                        applicationStatusProperties.getBackgroundProcessVerificationCount(),
                        applicationStatusRequest.getAgentInformation().getNpn(),
                        policyCachingStatusRecord.getBackgroundPolicySearchProcess().getStartedAt());

                throw new AgencyCoPilot4xxException(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR, "");
            }
            waitAndRetry();
            counter++;
            PolicyCachingStatusRecord localPolicyCachingStatusRecord = mongoDBCacheHandler.findPolicyCachingStatusByNpnId(
                    applicationStatusRequest.getAgentInformation().getNpn()
            );
            log.info("Exiting verifyProcessAndReturnData at {}", LocalDateTime.now());
            return verifyProcessAndReturnData(localPolicyCachingStatusRecord, applicationStatusRequest, counter);
        }
    }

    private void waitAndRetry() {
        try {
            Thread.sleep(applicationStatusProperties.getVerifyBkgGrdVerificationRetryMillis());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
//    findPoliciesByNpnUsingCriteria

    private ApplicationStatusResponse initiateApplicationStatusSearch(ApplicationStatusRequest applicationStatusRequest) throws Exception {
        log.info("Entering initiateApplicationStatusSearch at {}", LocalDateTime.now());
        fillDefaultValuesIfNeeded(applicationStatusRequest);
        mongoDBCacheHandler.saveToPolicyCacheStatusDocument(
                applicationStatusRequest.getAgentInformation().getNpn(),
                LocalDateTime.now(),
                new Date()
        );
        CompletableFuture<Boolean> completableFuture = applicationStatusHelperService.processApplicationStatus(applicationStatusRequest, false);
        Boolean isSearchCompleted = completableFuture.get();
        log.info("Search for policies for npn={} is completed successfully {}. Proceeding to fetch the data from Mongo and return to the user.",
                applicationStatusRequest.getAgentInformation().getNpn(),
                isSearchCompleted);

        ApplicationStatusResponse applicationStatusResponse =
                applicationStatusHelperService.paginatedApplicationStatusResponseFromMongo(applicationStatusRequest);

        if (Boolean.valueOf(backgroundProcessingFlag)) {
            mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                    applicationStatusRequest.getAgentInformation().getNpn(),
                    LocalDateTime.now(),
                    true,
                    false,
                    applicationStatusResponse.getPolicy().size());

            applicationStatusHelperService.gatherPolicyInformationInBackground(applicationStatusRequest);

            mongoDBCacheHandler.updatePolicyCacheStatusDocument(
                    applicationStatusRequest.getAgentInformation().getNpn(),
                    LocalDateTime.now(),
                    true,
                    false,
                    0);
        }
        // Process background policy information only when this flag is TRUE
        log.info("Initiated the background search process and return the results for default search page.");
        log.info("Exiting initiateApplicationStatusSearch at {}", LocalDateTime.now());
        return applicationStatusResponse;
//        }
    }

    @Override
    public Map<String, List<PolicyVO>> retrieveApplicationStatusByNPN(String npn, Integer pageNo, Integer pageSize) {
        log.info("Entering retrieveApplicationStatusByNPN at {}", LocalDateTime.now());
        Pageable paging = PageRequest.of(pageNo, pageSize);
        List<PolicyDatabaseRecord> policyDatabaseRecordList = mongoDBCacheHandler.findPoliciesByNPNId(npn, paging);
        List<PolicyVO> policyVOList = new ArrayList<>();
        policyVOList = policyDatabaseRecordList.stream()
                .map(PolicyDatabaseRecord::getPolicyResponse)
                .collect(Collectors.toList());

        Map<String, List<PolicyVO>> retrivedPolicesResponse = new HashMap<>();
        retrivedPolicesResponse.put("policy", policyVOList);
        log.info("No of records retrieved from database are {} and returned to client {}",
                policyDatabaseRecordList.size(),
                policyVOList.size());
        log.info("Exiting retrieveApplicationStatusByNPN at {}", LocalDateTime.now());
        return retrivedPolicesResponse;
    }

    @Override
    public PolicyCachingStatusRecord retrieveApplicationStatusCacheResults(String npn) {
        return mongoDBCacheHandler.findPolicyCachingStatusByNpnId(npn);
    }

    @Override
    public List<PolicyCategoriesRecord> insertPolicyCategoriesRecords(List<PolicyCategoriesRecord> policyCategoriesRecordList) {
        return mongoDBCacheHandler.insertPolicyCategoryCodes(policyCategoriesRecordList);
    }

    @Override
    public List<ProductTypeCategoriesRecord> insertProductTypeCategoriesRecords(List<ProductTypeCategoriesRecord> productTypeCategoriesRecords) {
        return mongoDBCacheHandler.insertProductTypeCategories(productTypeCategoriesRecords);
    }

    @Override
    public WorkSheetDetailsResponse getWorkSheetDocumentDetails(String policyNumber) {
        log.info("Entering getWorkSheetDocumentDetails at {}", LocalDateTime.now());
        WorkSheetDetailsResponse workSheetDetailsResponse = new WorkSheetDetailsResponse();
        List<Case360DocumentVO> case360Documents = mongoDBCacheHandler.getWorkSheetRequirementDocuments(policyNumber);
        if (CollectionUtils.isNotEmpty(case360Documents)) {
            workSheetDetailsResponse.setCase360Documents(case360Documents);
        } else {
            workSheetDetailsResponse.setCase360Documents(new ArrayList<>()); // send blank array
        }
        log.info("Exiting getWorkSheetDocumentDetails at {}", LocalDateTime.now());
        return workSheetDetailsResponse;
    }

    private void fillDefaultValuesIfNeeded(ApplicationStatusRequest applicationStatusModel) {
        FilterCriteriaVO defaultFilterCriteria = new FilterCriteriaVO();
        defaultFilterCriteria.setDays(applicationStatusProperties.getDefaultLastXDaysFilter());
        defaultFilterCriteria.setStatus(applicationStatusModel.getFilterCriteria().getStatus());
        LocalDate today = LocalDate.now();
        defaultFilterCriteria.setSearchFromDate(today.minusDays(applicationStatusProperties.getDefaultLastXDaysFilter()));
        defaultFilterCriteria.setSearchToDate(today);
        defaultFilterCriteria.setSortOrder(applicationStatusModel.getFilterCriteria().getSortOrder());
        defaultFilterCriteria.setPageSize(applicationStatusModel.getFilterCriteria().getPageSize());
        applicationStatusModel.setFilterCriteria(defaultFilterCriteria);
    }

    private boolean isFilterApplied(FilterCriteriaVO filterCriteriaVO) {
        return (filterCriteriaVO.getSearchToDate() != null && filterCriteriaVO.getSearchFromDate() != null);
    }
}
