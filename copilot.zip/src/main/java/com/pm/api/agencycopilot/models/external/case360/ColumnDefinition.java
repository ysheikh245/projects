package com.pm.api.agencycopilot.models.external.case360;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ColumnDefinition{

	@JsonProperty("fieldName")
	private String fieldName;

	@JsonProperty("hidden")
	private boolean hidden;

	@JsonProperty("primaryKeyPart")
	private int primaryKeyPart;

	@JsonProperty("displayName")
	private String displayName;

	@JsonProperty("identity")
	private boolean identity;

	@JsonProperty("tableId")
	private int tableId;

	@JsonProperty("readOnly")
	private boolean readOnly;

	@JsonProperty("conflictLevel")
	private int conflictLevel;

	@JsonProperty("required")
	private boolean required;

	@JsonProperty("cId")
	private int cId;

	@JsonProperty("primary")
	private boolean primary;

	public String getFieldName(){
		return fieldName;
	}

	public boolean isHidden(){
		return hidden;
	}

	public int getPrimaryKeyPart(){
		return primaryKeyPart;
	}

	public String getDisplayName(){
		return displayName;
	}

	public boolean isIdentity(){
		return identity;
	}

	public int getTableId(){
		return tableId;
	}

	public boolean isReadOnly(){
		return readOnly;
	}

	public int getConflictLevel(){
		return conflictLevel;
	}

	public boolean isRequired(){
		return required;
	}

	public int getCId(){
		return cId;
	}

	public boolean isPrimary(){
		return primary;
	}
}