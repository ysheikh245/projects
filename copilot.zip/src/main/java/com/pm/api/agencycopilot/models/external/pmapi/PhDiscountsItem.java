package com.pm.api.agencycopilot.models.external.pmapi;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PhDiscountsItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CDiscountPercent")
	private String cDiscountPercent;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("CSelect")
	private String cSelect;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CSortby")
	private String cSortby;

	@JsonProperty("CAdditionalDiscount")
	private String cAdditionalDiscount;

	@JsonProperty("CDiscount")
	private String cDiscount;

	@JsonProperty("CPiDiscount")
	private String cPiDiscount;

	public String getEntityType(){
		return entityType;
	}

	public String getGid(){
		return gid;
	}

	public String getCDiscountPercent(){
		return cDiscountPercent;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public String getCSelect(){
		return cSelect;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCSortby(){
		return cSortby;
	}

	public String getCAdditionalDiscount(){
		return cAdditionalDiscount;
	}

	public String getCDiscount(){
		return cDiscount;
	}

	public String getCPiDiscount(){
		return cPiDiscount;
	}
}