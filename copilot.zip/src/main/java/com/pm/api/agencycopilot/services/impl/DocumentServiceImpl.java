package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.handlers.ClaimsDocumentUploadHandler;
import com.pm.api.agencycopilot.handlers.IDocumentUploadHandler;
import com.pm.api.agencycopilot.handlers.PolicyDocumentUploadHandler;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIResponse;
import com.pm.api.agencycopilot.models.enums.DocumentUploadEnum;
import com.pm.api.agencycopilot.models.external.documents.upload.DocumentUploadRequest;
import com.pm.api.agencycopilot.models.external.documents.upload.IndexFields;
import com.pm.api.agencycopilot.models.internal.ActionMetadataVO;
import com.pm.api.agencycopilot.services.DocumentService;
import com.pm.api.agencycopilot.services.DocumentsServiceHandler;
import com.pm.api.agencycopilot.utility.JSONUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.Base64;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.FAILED;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.split;

@Service
@Slf4j
public class DocumentServiceImpl implements DocumentService {

//    @Autowired
//    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private DocumentsServiceHandler documentsServiceHandler;

//    @Autowired
//    private ContentStackServiceHandler contentStackServiceHandler;

//    @Autowired
//    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Autowired
    private PolicyDocumentUploadHandler policyDocumentUploadHandler;

    @Autowired
    private ClaimsDocumentUploadHandler claimsDocumentUploadHandler;


    @Override
    public DocumentsUploadAPIResponse uploadDocument(DocumentsUploadAPIRequest documentsUploadAPIRequest,
                                 MultipartFile uploadedFile) throws Exception {
        log.info("Entering uploadDocument at {}", LocalDateTime.now());
        log.info("DocumentService.uploadDocument() ::: Start. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
        IDocumentUploadHandler documentUploadHandler = getDocumentUploadHandler(documentsUploadAPIRequest.getDocumentUploadEnum());
        ActionMetadataVO actionMetaDataVO = documentUploadHandler.formActionMetadata(documentsUploadAPIRequest);
        if (actionMetaDataVO != null) {
            DocumentUploadRequest documentUploadRequest = getDocumentUploadRequest(documentsUploadAPIRequest, actionMetaDataVO, uploadedFile);
            if (documentUploadRequest != null) {
                DocumentsUploadAPIResponse documentsUploadAPIResponse = documentsServiceHandler.uploadDocuments(documentUploadRequest);
                log.info("Exiting uploadDocument at {}", LocalDateTime.now());
                log.info("DocumentService.uploadDocument() ::: Completed. Response={}", JSONUtility.convertObjectToString(documentsUploadAPIResponse));
                return documentsUploadAPIResponse;
            }
        } else {
            log.info("DocumentService.uploadDocument() ::: Failed. ActionMetadataVO is NULL");
        }
        log.info("Entering uploadDocument at {}", LocalDateTime.now());
        log.info("DocumentService.uploadDocument() ::: Failed. PolicyNumber={}", documentsUploadAPIRequest.getPolicyNumber());
        return getDefaultObject();
    }

    @Override
    public Resource downloadDocument(DocumentDownloadRequest documentDownloadRequest) throws Exception {
        return documentsServiceHandler.downloadDocument(documentDownloadRequest);
    }

    private IDocumentUploadHandler getDocumentUploadHandler(DocumentUploadEnum documentUploadEnum) {
        if (documentUploadEnum == DocumentUploadEnum.WORKSHEET_REQUIREMENT_POLICY) {
            return policyDocumentUploadHandler;
        } else if (documentUploadEnum == DocumentUploadEnum.FACI_CLAIMS) {
            return claimsDocumentUploadHandler;
        } else {
            throw new RuntimeException("No Handler Found for generating Action Metadata");
        }
    }


    private DocumentUploadRequest getDocumentUploadRequest(DocumentsUploadAPIRequest documentsUploadAPIRequest,
                                                           ActionMetadataVO actionMetadataVO,
                                                           MultipartFile uploadedFile) {
        log.info("Entering getDocumentUploadRequest at {}", LocalDateTime.now());
        DocumentUploadRequest documentUploadRequest = new DocumentUploadRequest();
        try {
            String originalFilename = uploadedFile.getOriginalFilename();
            String fileName  = FilenameUtils.getBaseName(originalFilename);
            String extension = FilenameUtils.getExtension(originalFilename);
            documentUploadRequest.setFileName(fileName);
            documentUploadRequest.setExtension(extension);
            documentUploadRequest.setContentType(uploadedFile.getContentType());

            IndexFields indexFields = new IndexFields();

            // Common
            indexFields.setSource(actionMetadataVO.getSource());
            indexFields.setDocType(actionMetadataVO.getDocType());
            indexFields.setDocumentDesc(actionMetadataVO.getDocumentDesc());
            indexFields.setCorrType(actionMetadataVO.getCorrType());
            indexFields.setDoc_Type(actionMetadataVO.getDoc_Type());

            // Policy - Application Status
            indexFields.setDocIndexCode(actionMetadataVO.getDocIndexCode());
            indexFields.setPolicyNo(documentsUploadAPIRequest.getPolicyNumber());

            // FACI Claims specific
            indexFields.setWorkflowType(actionMetadataVO.getWorkFlowType());
            indexFields.setDescriptor(actionMetadataVO.getDescriptor());
            indexFields.setPolicyNumber(documentsUploadAPIRequest.getPolicyNumber());

            documentUploadRequest.setIndexFields(indexFields);

            documentUploadRequest.setBytes(Base64.getEncoder().encodeToString(uploadedFile.getBytes())); //TODO; add bytes[] for document upload
        } catch (Exception e) {
            log.error("DocumentServiceImpl.getDocumentUploadRequest() ::: Exception occurred, PolicyNumber={}, Exception={}",
                    documentsUploadAPIRequest.getPolicyNumber(), ExceptionUtils.getStackTrace(e));
            return null;
        }
        log.info("Exiting getDocumentUploadRequest at {}", LocalDateTime.now());
        return documentUploadRequest;
    }

    private DocumentsUploadAPIResponse getDefaultObject() {
        DocumentsUploadAPIResponse documentsUploadAPIResponse = new DocumentsUploadAPIResponse();
        documentsUploadAPIResponse.setDocumentDescription(BLANK);
        documentsUploadAPIResponse.setPmicNumber(BLANK);
        documentsUploadAPIResponse.setStatus(FAILED);
        documentsUploadAPIResponse.setPolicyNumber(BLANK);
        return documentsUploadAPIResponse;
    }

}
