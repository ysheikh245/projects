package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class InsuredItem{

	@JsonProperty("CreateShellAccount")
	private String createShellAccount;

	@JsonProperty("FeinPhoneRequired")
	private String feinPhoneRequired;

	@JsonProperty("CMiddleName")
	private String cMiddleName;

	@JsonProperty("Address")
	private List<AddressItem> address;

	@JsonProperty("OrderCreditScore")
	private String orderCreditScore;

	@JsonProperty("CPhone")
	private String cPhone;

	@JsonProperty("NameType")
	private String nameType;

	@JsonProperty("InsSuffix")
	private String insSuffix;

	@JsonProperty("StatusUpdMisPolicies")
	private String statusUpdMisPolicies;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CFirstName")
	private String cFirstName;

	@JsonProperty("NameTypeStatCode")
	private String nameTypeStatCode;

	@JsonProperty("RetrieveQuoteNumber")
	private String retrieveQuoteNumber;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("PolicyInsured")
	private String policyInsured;

	@JsonProperty("CustomerName")
	private String customerName;

	@JsonProperty("InsDob")
	private String insDob;

	@JsonProperty("MasterCustomerGid")
	private String masterCustomerGid;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("BusinessName")
	private String businessName;

	@JsonProperty("CEmailNew")
	private String cEmailNew;

	@JsonProperty("FirstName")
	private String firstName;

	@JsonProperty("CLastName")
	private String cLastName;

	@JsonProperty("IndRiskSituation")
	private String indRiskSituation;

	@JsonProperty("CopyCustomerDetails")
	private String copyCustomerDetails;

	@JsonProperty("IsDeregulated")
	private String isDeregulated;

	@JsonProperty("RcFailureCancel")
	private String rcFailureCancel;

	@JsonProperty("WrapUpSponsorship")
	private String wrapUpSponsorship;

	@JsonProperty("InsPrefix")
	private String insPrefix;

	@JsonProperty("MiddleName")
	private String middleName;

	@JsonProperty("Contact")
	private List<ContactItem> contact;

	@JsonProperty("CSuffix")
	private String cSuffix;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("QuoteNumber")
	private String quoteNumber;

	@JsonProperty("InsuredSearchComplete")
	private String insuredSearchComplete;

	@JsonProperty("MasterRecordGid")
	private String masterRecordGid;

	@JsonProperty("CAddInsured")
	private String cAddInsured;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("Surname")
	private String surname;

	@JsonProperty("CInsPrefix")
	private String cInsPrefix;

	public String getCreateShellAccount(){
		return createShellAccount;
	}

	public String getFeinPhoneRequired(){
		return feinPhoneRequired;
	}

	public String getCMiddleName(){
		return cMiddleName;
	}

	public List<AddressItem> getAddress(){
		return address;
	}

	public String getOrderCreditScore(){
		return orderCreditScore;
	}

	public String getCPhone(){
		return cPhone;
	}

	public String getNameType(){
		return nameType;
	}

	public String getInsSuffix(){
		return insSuffix;
	}

	public String getStatusUpdMisPolicies(){
		return statusUpdMisPolicies;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCFirstName(){
		return cFirstName;
	}

	public String getNameTypeStatCode(){
		return nameTypeStatCode;
	}

	public String getRetrieveQuoteNumber(){
		return retrieveQuoteNumber;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getPolicyInsured(){
		return policyInsured;
	}

	public String getCustomerName(){
		return customerName;
	}

	public String getInsDob(){
		return insDob;
	}

	public String getMasterCustomerGid(){
		return masterCustomerGid;
	}

	public String getGid(){
		return gid;
	}

	public String getBusinessName(){
		return businessName;
	}

	public String getCEmailNew(){
		return cEmailNew;
	}

	public String getFirstName(){
		return firstName;
	}

	public String getCLastName(){
		return cLastName;
	}

	public String getIndRiskSituation(){
		return indRiskSituation;
	}

	public String getCopyCustomerDetails(){
		return copyCustomerDetails;
	}

	public String getIsDeregulated(){
		return isDeregulated;
	}

	public String getRcFailureCancel(){
		return rcFailureCancel;
	}

	public String getWrapUpSponsorship(){
		return wrapUpSponsorship;
	}

	public String getInsPrefix(){
		return insPrefix;
	}

	public String getMiddleName(){
		return middleName;
	}

	public List<ContactItem> getContact(){
		return contact;
	}

	public String getCSuffix(){
		return cSuffix;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getQuoteNumber(){
		return quoteNumber;
	}

	public String getInsuredSearchComplete(){
		return insuredSearchComplete;
	}

	public String getMasterRecordGid(){
		return masterRecordGid;
	}

	public String getCAddInsured(){
		return cAddInsured;
	}

	public String getId(){
		return id;
	}

	public String getSurname(){
		return surname;
	}

	public String getCInsPrefix(){
		return cInsPrefix;
	}
}