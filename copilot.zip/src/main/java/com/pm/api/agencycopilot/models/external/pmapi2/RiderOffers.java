package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RiderOffers {
    @JsonProperty("companyCode")
    private String companyCode;

    @JsonProperty("policyNumber")
    private String policyNumber;

    @JsonProperty("statusCode")
    private String statusCode;

    @JsonProperty("statusReason")
    private String statusReason;

    @JsonProperty("offerPlanCode")
    private String offerPlanCode;

    @JsonProperty("fullDescription")
    private String fullDescription;

    @JsonProperty("offerSource")
    private String offerSource;

    @JsonProperty("finderNumber")
    private String finderNumber;

    @JsonProperty("offerDate")
    private String offerDate;

    @JsonProperty("scheduleUpgrade")
    private boolean scheduleUpgrade;

    @JsonProperty("offerId")
    private String offerId;

    @JsonProperty("benAmount")
    private String benAmount;

    @JsonProperty("premium")
    private String premium;

    @JsonProperty("monthly")
    private String monthly;

    @JsonProperty("quarterly")
    private String quarterly;

    @JsonProperty("semiannually")
    private String semiannually;

    @JsonProperty("annually")
    private String annually;

    @JsonProperty("rdrEffDt")
    private String rdrEffDt;

    @JsonProperty("otpEligible")
    private boolean otpEligible;
}
