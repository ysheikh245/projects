package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.apis.MessagingAPIRequest;
import com.pm.api.agencycopilot.models.external.agents.EmailAddressesItem;
import com.pm.api.agencycopilot.models.external.agents.PrimaryPhoneNumbersItem;
import com.pm.api.agencycopilot.models.external.agents.Response;
import com.pm.api.agencycopilot.models.external.agents.SecondaryPhoneNumbersItem;
import com.pm.api.agencycopilot.models.external.messaging.MessagingDeliveryEnum;
import com.pm.api.agencycopilot.models.external.messaging.MessagingRequest;
import com.pm.api.agencycopilot.models.external.messaging.ToUser;
import com.pm.api.agencycopilot.models.internal.AgentInformationVO;
import com.pm.api.agencycopilot.models.mongodb.ProductTypeCategoriesRecord;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.services.AgentsServiceHandler;
import com.pm.api.agencycopilot.services.ContentStackServiceHandler;
import com.pm.api.agencycopilot.services.InteractionLogsServiceHandler;
import com.pm.api.agencycopilot.services.MessagingServiceHandler;
import com.pm.api.agencycopilot.utility.AgencyCoPilotConstants;
import com.pm.api.agencycopilot.utility.CustomerPMAPIProperties;
import com.pm.api.agencycopilot.utility.JSONUtility;
import com.pm.api.agencycopilot.utility.MaskedValueLogger;
import com.pm.api.agencycopilot.utility.MessagingProperties;
import com.pm.api.agencycopilot.utility.StringUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.pm.api.agencycopilot.models.enums.ThankyouStatusEnum.THANKYOU_SENT;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SPACE;

@Service
@Slf4j
public class MessagingServicesHandlerImpl implements MessagingServiceHandler {


    @Autowired
    private MessagingProperties messagingProperties;

    @Autowired
    private CustomerPMAPIProperties customerPMAPIProperties;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AgentsServiceHandler agentsServiceHandler;

    @Autowired
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;

    @Autowired
    private ContentStackServiceHandler contentStackServiceHandler;

    @Autowired
    private InteractionLogsServiceHandler interactionLogsServiceHandler;

    @Autowired
    private MaskedValueLogger maskedValueLogger;

    @Autowired
    private ApplicationStatusHelperServiceImpl applicationStatusHelperService;


    @Override
    public String sendEmail(MessagingAPIRequest messagingAPIRequest) {
        String policyNumber = messagingAPIRequest.getPolicyNumber();
        String npn = messagingAPIRequest.getNpn();
        log.info("Sending Email - Started. PolicyNumber={}, NPN={}", policyNumber, npn);
        AgentInformationVO agentInformationVO = invokeAgentsAPI(npn);
        MessagingRequest messagingRequest = getMessagingRequest(messagingAPIRequest, agentInformationVO, MessagingDeliveryEnum.EMAIL.getValue());
        ResponseEntity<String> responseEntity = invokeMessagingAPI(messagingRequest, npn);
        if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
            log.info("Sending Email - Completed. PolicyNumber={}, NPN={}", policyNumber, npn);
            // TODO: Fix the code and remove the try catch.
            try {
                log.info("Creating interaction log entry for PolicyNumber={}, NPN={}", policyNumber, npn);
                interactionLogsServiceHandler.createInteractionLogEntry(
                        messagingAPIRequest.getNpn(),
                        agentInformationVO.getName(),
                        AgencyCoPilotConstants.MESSAGING_REASON_NUMBER,
                        messagingAPIRequest.getPartyId(),
                        messagingAPIRequest.getPolicyNumber(),
                        messagingAPIRequest.getNotes()
                );
                log.info("Interaction log entry successfully completed for PolicyNumber={}, NPN={}", policyNumber, npn);

                try {
                    log.info("UpdateCacheEntryForActivePolicy - Started. PolicyNumber={}, NPN={}", policyNumber, npn);
                    updateCacheEntryForActivePolicy(npn, policyNumber);
                    log.info("UpdateCacheEntryForActivePolicy - Completed. PolicyNumber={}, NPN={}", policyNumber, npn);
                } catch (Exception exception) {
                    log.error("UpdateCacheEntryForActivePolicy() - Failed. Policy={}, NPN={}, Exception={}",
                            policyNumber,  npn, ExceptionUtils.getStackTrace(exception));
                }
            } catch (Throwable t) {
                // Currently getting the below error.
                //Caused by: org.springframework.web.client.HttpServerErrorException$InternalServerError: 500 : [{"errors":[{"code":"CreateInteractionLogException","message":"could not execute statement; SQL [n/a]; constraint [null]; nested exception is org.hibernate.exception.ConstraintViolationException: could not execute statement","resourceName":"/123456/logs","resourceValue":"POST","timestamp":"2023-06-05T08:54:22"}]}]
                log.error("Skipping this error for time being until fix {}", t.getMessage());
                t.printStackTrace();
            }
            log.info("Exiting sendEmail at {}", LocalDateTime.now());
            return responseEntity.getBody();
        } else {
            log.info("Sending Email - Failed. PolicyNumber={}, NPN={}", policyNumber, npn);
        }
        log.info("Exiting sendEmail at {}", LocalDateTime.now());
        return BLANK;
    }

    private void updateCacheEntryForActivePolicy(String npn, String policyNumber) throws Exception {
        log.info("MessagingServicesHandlerImpl.updateCacheEntryForActivePolicy() - Start");
        applicationStatusHelperService.updateCacheEntryForActivePolicy(npn, policyNumber, THANKYOU_SENT.name());
        log.info("MessagingServicesHandlerImpl.updateCacheEntryForActivePolicy() - Completed");
    }

    private AgentInformationVO invokeAgentsAPI(String npn) {
        log.info("Entering sendEmail at {}", LocalDateTime.now());
        Response agentsAPIResponse = agentsServiceHandler.getAgentsDetail(npn).getResponse();
        AgentInformationVO agentInformationVO = new AgentInformationVO();
        //agentInformationVO.setFirstName(agentsAPIResponse.getFirstName());
        //agentInformationVO.setLastName(agentsAPIResponse.getLastName());
        agentInformationVO.setEmailAddress(findSendToEmail(agentsAPIResponse.getEmailAddresses(), npn));

        String name = StringUtility.getAccumulatedValue(SPACE, agentsAPIResponse.getFirstName(),
                agentsAPIResponse.getMiddleNames(), agentsAPIResponse.getLastName());
        agentInformationVO.setName(name);

//        String phone = StringUtility.getAccumulatedValue(BLANK,
//                agentsAPIResponse.getPrimaryPhoneNumbers().get(0).getAreaCode(),
//                agentsAPIResponse.getPrimaryPhoneNumbers().get(0).getLocalPhoneNumber());
        agentInformationVO.setPhone(findPhoneNumber(agentsAPIResponse.getPrimaryPhoneNumbers(), agentsAPIResponse.getSecondaryPhoneNumbers()));
        log.info("Exiting sendEmail at {}", LocalDateTime.now());
        return agentInformationVO;
    }

    private String findPhoneNumber(List<PrimaryPhoneNumbersItem> phoneNumbersItemList, List<SecondaryPhoneNumbersItem> secondaryPhoneNumbersItemList) {
        log.info("Entering findPhoneNumber at {}", LocalDateTime.now());
        String phoneNumber = null;
        Optional<PrimaryPhoneNumbersItem> primaryPhoneNumbersItemOptional = Optional.ofNullable(phoneNumbersItemList.stream()
                .filter(emailAddresses ->
                        emailAddresses.getContactPreferenceType().equalsIgnoreCase(messagingProperties.getPrimaryCommunicationPreferenceType()))
                .findFirst()
                .orElse(null));
        if (primaryPhoneNumbersItemOptional.isPresent()) {
            phoneNumber = StringUtility.formatPhoneNumber(StringUtility.getAccumulatedValue(BLANK,
                    primaryPhoneNumbersItemOptional.get().getAreaCode(),
                    primaryPhoneNumbersItemOptional.get().getLocalPhoneNumber()
            ));
        }
        log.info("Exiting findPhoneNumber at {}", LocalDateTime.now());
        return phoneNumber;
    }

    private String findSendToEmail(List<EmailAddressesItem> emailAddressesItemList, String npn) {
        log.info("Entering findSendToEmail at {}", LocalDateTime.now());
        String sendToEmail = null;
        Optional<EmailAddressesItem> emailAddressesItemOptional = Optional.ofNullable(emailAddressesItemList.stream()
                .filter(emailAddresses ->
                        emailAddresses.getContactPreferenceType().equalsIgnoreCase(messagingProperties.getPrimaryCommunicationPreferenceType()))
                .findFirst()
                .orElse(null));

        if (!emailAddressesItemOptional.isPresent()) {
            log.info("Exiting findSendToEmail at {}", LocalDateTime.now());
            log.error("Unable to find either primary or secondary email from getAgentDetails for Npn={}", npn);
            throw new AgencyCoPilot4xxException("Unable to find either primary or secondary email from getAgentDetails for Npn=" + npn, HttpStatus.BAD_REQUEST, "");
        }
        log.info("Exiting findSendToEmail at {}", LocalDateTime.now());
        return emailAddressesItemOptional.get().getEmailAddress();

    }

    private ResponseEntity<String> invokeMessagingAPI(MessagingRequest messagingRequest, String npn) {
        log.info("Entering invokeMessagingAPI at {}", LocalDateTime.now());
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", messagingProperties.getClientHeader());
        headers.add("end-user-id", messagingProperties.getEndUserId());
        headers.add("context-id", messagingProperties.getContextId());
        headers.add("ext-ref-id", messagingProperties.getExtRefId());
        headers.add("Authorization",
                getBasicAuthToken(messagingProperties.getMessagingAPIUserName(), messagingProperties.getMessagingAPIPassword()));

        HttpEntity httpEntity = new HttpEntity(messagingRequest, headers);
        log.info("Invoking messaging API for NPN={}", npn);
        try {
            maskedValueLogger.info(
                    String.format("Invoking messaging api with request body %s", JSONUtility.convertObjectToString(messagingRequest)),
                    log);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        ResponseEntity<String> response = null;
        try {
            response = restTemplate.postForEntity(messagingProperties.getMessagingAPIURL(), httpEntity, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new AgencyCoPilot5xxException(e, HttpStatus.INTERNAL_SERVER_ERROR, "");
        }
        log.info("Exiting invokeMessagingAPI at {}", LocalDateTime.now());
        return response;
    }

    private MessagingRequest getMessagingRequest(MessagingAPIRequest messagingAPIRequest,
                                                 AgentInformationVO agentInformationVO,
                                                 String messagingType) {
        log.info("Entering getMessagingRequest at {}", LocalDateTime.now());
        MessagingRequest request = new MessagingRequest();

        request.setToEmailAddress(messagingAPIRequest.getRecipientEmailAddress());
        request.setDeliveryType(new String[]{messagingType});
        request.setMessageCode(messagingAPIRequest.getMessageCode());
        request.setFromUserName(agentInformationVO.getName());

        ToUser toUser = new ToUser();
        toUser.setId("");
        toUser.setType("CUSTOMER");

        request.setToUser(toUser);

        Map<String, String> valueMap = new HashMap();
        valueMap.put("SubscriberKey", messagingAPIRequest.getRecipientEmailAddress());
        valueMap.put("ProductType", fetchProductCategory(messagingAPIRequest.getProductCode())); //TODO: evaluate product type from mongo with right dataset.
        valueMap.put("FirstName", messagingAPIRequest.getRecipientFirstName());
        valueMap.put("LastName", messagingAPIRequest.getRecipientLastName());
        valueMap.put("EmailAddress", messagingAPIRequest.getRecipientEmailAddress());
        valueMap.put("State", messagingAPIRequest.getRecipientState());
        valueMap.put("AgentName", agentInformationVO.getName());
        valueMap.put("AgentEmail", agentInformationVO.getEmailAddress());
        valueMap.put("AgentPhone", agentInformationVO.getPhone());
        valueMap.put("AgentPictureURL", fetchAgentPictureUrlFromContentStack(messagingAPIRequest.getNpn()));


        request.setValueMap(valueMap);

        maskedValueLogger.info(String.format("Sending the email from npn=%s with valueMap=%s", messagingAPIRequest.getNpn(), valueMap), log);
        log.info("Exiting getMessagingRequest at {}", LocalDateTime.now());
        return request;
    }

    private String fetchProductCategory(String productCode) {
        log.info("Entering fetchProductCategory at {}", LocalDateTime.now());
        ProductTypeCategoriesRecord productTypeCategoriesRecord = productTypeCategoriesRepository.findByProductCodeAndIsActive(productCode, true);

        if (productTypeCategoriesRecord != null) {
            log.info("Exiting fetchProductCategory at {}", LocalDateTime.now());
            return productTypeCategoriesRecord.getCategory();
        }
        log.info("Exiting fetchProductCategory at {}", LocalDateTime.now());
        return null;
    }

    private String fetchAgentPictureUrlFromContentStack(String npn) {
        log.info("Entering fetchAgentPictureUrlFromContentStack at {}", LocalDateTime.now());
        String apiResponse = contentStackServiceHandler.getAgentProfileResponse(npn);

        if (BLANK.equalsIgnoreCase(apiResponse)) {
            return apiResponse;
        }
        String agentPictureUrl = "";
        try {
            JSONObject jsonObject = new JSONObject(apiResponse);
            JSONArray entriesJsonArray = jsonObject.getJSONArray("entries");
            for (int i = 0; i < entriesJsonArray.length(); i++) {
                JSONObject entryJson = entriesJsonArray.getJSONObject(i);
                if (!entryJson.isNull("agent_image")) {
                    JSONObject agentImageJson = entryJson.getJSONObject("agent_image");
                    agentPictureUrl = agentImageJson.getString("url");
                    break;

                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        log.info("Exiting fetchAgentPictureUrlFromContentStack at {}", LocalDateTime.now());
        return agentPictureUrl;
    }
}
