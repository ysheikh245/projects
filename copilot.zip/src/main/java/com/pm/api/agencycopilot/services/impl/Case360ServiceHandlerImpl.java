package com.pm.api.agencycopilot.services.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.external.case360.Case360WorksheetResponse;
import com.pm.api.agencycopilot.models.external.case360.FieldList;
import com.pm.api.agencycopilot.models.external.case360.FmsRowTO;
import com.pm.api.agencycopilot.models.external.compensation.AgentCompensationResponse;
import com.pm.api.agencycopilot.models.internal.Case360DocumentVO;
import com.pm.api.agencycopilot.services.Case360ServiceHandler;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SPACE;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.UW_REQUIRE_COMMENTS;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.UW_REQUIRE_DATE_RECEIVED;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.UW_REQUIRE_DATE_REQ;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.UW_REQUIRE_DESC_LIST;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class Case360ServiceHandlerImpl implements Case360ServiceHandler {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${agency.copilot.case360.api.username}")
    private String case360userName;

    @Value("${agency.copilot.case360.api.password}")
    private String case360Password;

    @Value("${agency.copilot.case360.api.url}")
    private String case360APIEndpoint;

    @Value("${agency.copilot.case360.api.client.header}}")
    private String case360APIClientHeader;

    @Value("${agency.copilot.customers.api.end.userid}")
    private String case360APIClientUserId;

    @Value("${agency.copilot.case360.received.document.flag:false}")
    private boolean showReceivedDocumentFlag;

    @Value("${agency.copilot.compensation.policy.v2.endpoint}")
    private String compensationEndPointURL;

    @Value("${agency.copilot.compensation.start.time:00:00:00}")
    private String startTime;

    @Value("${agency.copilot.compensation.end.time:11:59:59}")
    private String endTime;

    @Autowired
    private RestHelperServiceImpl restHelperService;

    /**
     * @param policyNumber
     * @return
     */
    public List<Case360DocumentVO> getRequirementsDocumentList(String policyNumber) throws Exception {
        log.info("Entering getRequirementsDocumentList at {}", LocalDateTime.now());
        Case360WorksheetResponse case360WorksheetResponse = invokeCase360API(policyNumber);
        List<Case360DocumentVO> case360Documents = processCase360Response(case360WorksheetResponse);
//        List<Object> contentStackDocumentMetadata = getDocumentMetaDataFromContentStack("");
//        List<Case360DocumentVO> filteredEligibleCase360Documents = filterEligibleCase360Documents(case360Documents, contentStackDocumentMetadata);
//        persistResponses(policyNumber, case360WorksheetResponse, filteredEligibleCase360Documents);
//        return filteredEligibleCase360Documents;
        log.info("Exiting getRequirementsDocumentList at {}", LocalDateTime.now());
        return case360Documents;
    }

    public List<Case360DocumentVO> getRequirementsDocumentList(Case360WorksheetResponse case360WorksheetResponse) throws Exception {
        log.info("Entering getRequirementsDocumentList at {}", LocalDateTime.now());
        List<Case360DocumentVO> case360Documents = processCase360Response(case360WorksheetResponse);
//        List<Object> contentStackDocumentMetadata = getDocumentMetaDataFromContentStack("");
//        List<Case360DocumentVO> filteredEligibleCase360Documents = filterEligibleCase360Documents(case360Documents, contentStackDocumentMetadata);
//        persistResponses(policyNumber, case360WorksheetResponse, filteredEligibleCase360Documents);
//        return filteredEligibleCase360Documents;
        log.info("Exiting getRequirementsDocumentList at {}", LocalDateTime.now());
        return case360Documents;
    }

    private List<Case360DocumentVO> processCase360Response(Case360WorksheetResponse case360WorksheetResponse) {
        log.info("Entering processCase360Response at {}", LocalDateTime.now());
        List<Case360DocumentVO> case360Documents = new ArrayList();
        if (case360WorksheetResponse != null && CollectionUtils.isNotEmpty(case360WorksheetResponse.getFmsRowSetTO())) {
            List<FmsRowTO> elements = case360WorksheetResponse.getFmsRowSetTO().get(0).getFmsRowTO();

            // Iterate through
            if (CollectionUtils.isNotEmpty(elements)) {
                for (FmsRowTO element : elements) {
                    //List<FieldList> fieldsList = element.getFieldList();
                    Case360DocumentVO case360Document = evaluate360ElementInResponse(element);
                    if (case360Document != null) {
                        case360Documents.add(case360Document);
                    }
                }
            }
        }
        log.info("Exiting processCase360Response at {}", LocalDateTime.now());
        return case360Documents;
    }

    // fmsRowToElement is the nth elementItem in the List<FmsRowTO>
    private Case360DocumentVO evaluate360ElementInResponse(FmsRowTO fmsRowToElement) {
        log.info("Entering evaluate360ElementInResponse at {}", LocalDateTime.now());
        Case360DocumentVO case360Document = null;
        if (fmsRowToElement != null) {
            //Optional<FieldList> documentsApplicableForAgents = isDocumentApplicableForAgent(fmsRowToElement);
            if (isDocumentApplicableForAgent(fmsRowToElement) && !isRequiredDocumentReceived(fmsRowToElement)) {
                case360Document = new Case360DocumentVO();
                case360Document.setComments(extractComments(fmsRowToElement));
                case360Document.setDescription(extractDocumentTitle(fmsRowToElement));
                case360Document.setDateReceived(extractDateReceived(fmsRowToElement));
                case360Document.setDateRequired(extractDateRequired(fmsRowToElement));
                /*String documentCategory = documentsApplicableForAgents.get().getStringValue();
                if(StringUtils.equals(documentCategory, INFORMATIONAL) || StringUtils.equals(documentCategory, NEEDS_UPLOAD)) {
                    case360Document = new Case360DocumentVO();
                    case360Document.setComments(extractComments(fmsRowToElement));
                    case360Document.setUploadButton(StringUtils.equalsIgnoreCase(NEEDS_UPLOAD, documentCategory) ? true : false);
                    case360Document.setLongName(extractRequirementDocumentDescription(fmsRowToElement));
                }*/
            }
        }
        log.info("Exiting evaluate360ElementInResponse at {}", LocalDateTime.now());
        return case360Document;
    }

    @NotNull
    private boolean isDocumentApplicableForAgent(FmsRowTO fmsRowToElement) {
        /*Optional<FieldList> documentsApplicableForAgents = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), UW_REQUIRE_TYPE_LIST))
                .findFirst();
                return documentsApplicableForAgents.isPresent();*/
        return fmsRowToElement.getFieldList().stream().anyMatch(field -> StringUtils.equals(field.getFieldName(), "UW_REQUIRE_TYPE_LIST"));

    }

    private String extractDocumentTitle(FmsRowTO fmsRowToElement) {
        log.info("Entering extractDocumentTitle at {}", LocalDateTime.now());
        Optional<FieldList> requirementDocumentDescription = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), UW_REQUIRE_DESC_LIST))
                .findFirst();
        log.info("Exiting extractDocumentTitle at {}", LocalDateTime.now());
        if (requirementDocumentDescription.isPresent()) {
            return StringUtils.isNotEmpty(requirementDocumentDescription.get().getStringValue()) ? requirementDocumentDescription.get().getStringValue() : BLANK;
        }
        return BLANK;
    }

    private String extractDateReceived(FmsRowTO fmsRowToElement) {
        return extractDate(fmsRowToElement, UW_REQUIRE_DATE_RECEIVED);
        /*Optional<FieldList> requirementDocumentDescription = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), UW_REQUIRE_DATE_RECEIVED))
                .findFirst();
        if(requirementDocumentDescription.isPresent()) {
            return requirementDocumentDescription.get().getCalendarValue();
        }
        return BLANK;*/
    }

    private String extractDateRequired(FmsRowTO fmsRowToElement) {
        return extractDate(fmsRowToElement, UW_REQUIRE_DATE_REQ);
        /*Optional<FieldList> requirementDocumentDescription = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), UW_REQUIRE_DATE_REQ))
                .findFirst();
        if(requirementDocumentDescription.isPresent()) {
            return requirementDocumentDescription.get().getCalendarValue();
        }
        return BLANK;*/
    }

    private String extractDate(FmsRowTO fmsRowToElement, String fieldName) {
        log.info("Starting extractDate at {} params fmsRowToElement={}, fieldName{}", LocalDateTime.now(), fmsRowToElement, fieldName);
        Optional<FieldList> requirementDocumentDescription = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), fieldName))
                .findFirst();
        if (requirementDocumentDescription.isPresent()) {
            return StringUtils.isNotEmpty(requirementDocumentDescription.get().getCalendarValue()) ? requirementDocumentDescription.get().getCalendarValue() : BLANK;
        }
        log.info("Exiting extractDate at {} params fmsRowToElement={}, fieldName{}", LocalDateTime.now(), fmsRowToElement, fieldName);
        return BLANK;
    }

    private boolean isRequiredDocumentReceived(FmsRowTO fmsRowToElement) {
        return (showReceivedDocumentFlag) ? (fmsRowToElement.getFieldList().stream().anyMatch(field -> StringUtils.equals(field.getFieldName(), UW_REQUIRE_DATE_RECEIVED))) : false;
    }

    private String extractComments(FmsRowTO fmsRowToElement) {
        log.info("Entering extractComments at {}", LocalDateTime.now());
        Optional<FieldList> comments = fmsRowToElement.getFieldList().stream()
                .filter(fieldList -> StringUtils.equals(fieldList.getFieldName(), UW_REQUIRE_COMMENTS))
                .findFirst();
        log.info("Exiting extractComments at {}", LocalDateTime.now());
        if (comments.isPresent()) {
            return StringUtils.isNotEmpty(comments.get().getStringValue()) ? comments.get().getStringValue() : BLANK;
        }
        return BLANK;
    }

    private Case360WorksheetResponse invokeCase360API(String policyNumber) throws Exception {
        log.info("Entering invokeCase360API at {}", LocalDateTime.now());
        Case360WorksheetResponse case360WorksheetResponse = null;

        try {
            HttpHeaders headers = getHttpHeaders();
            HttpEntity request = new HttpEntity(headers);
            String actualEndPoint = StringUtils.replace(case360APIEndpoint, "{policyNumber}", policyNumber);
            ResponseEntity<String> response = restTemplate.exchange(actualEndPoint, HttpMethod.GET, request, String.class);
            //TODO: consider this moving to RestHelperServiceImpl.invoke() in future
            String resultedResponseAsString = response.getBody();
            case360WorksheetResponse = new ObjectMapper().readValue(resultedResponseAsString, Case360WorksheetResponse.class);
        } catch (Exception e) {
            log.error("Case360ServiceHandlerImpl.invokeCase360API(). PolicyNumber={}, Exception={}", policyNumber, ExceptionUtils.getStackTrace(e));
            //TODO: Exception handling
        }
        log.info("Exiting invokeCase360API at {}", LocalDateTime.now());
        return case360WorksheetResponse;
    }

    @NotNull
    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", case360APIClientHeader);
        headers.add("end-user-id", case360APIClientUserId);
        headers.add("Authorization", getBasicAuthToken(case360userName, case360Password));
        return headers;
    }

    @Override
    public AgentCompensationResponse fetchAvailableCompensations(String npn, String beginDate, String endDate) {
        log.info("Entering fetchAvailableCompensations at {}", LocalDateTime.now());
        AgentCompensationResponse availableCompensationsResponse = null;

        HttpHeaders headers = getHttpHeaders();
        HttpEntity request = new HttpEntity(headers);
        String actualEndPoint = StringUtils.replace(compensationEndPointURL, "{NPN}", npn)
                .replace("{BEGIN_DATE}", beginDate + SPACE + startTime)
                .replace("{END_DATE}", endDate + SPACE + endTime);
        ResponseEntity<String> response = restHelperService.invoke(actualEndPoint, HttpMethod.GET, request, String.class);
        String resultedResponseAsString = response.getBody();
        try {
            ObjectMapper mapper = new ObjectMapper();
            availableCompensationsResponse = mapper.readValue(resultedResponseAsString, AgentCompensationResponse.class);
        } catch (Exception exception) {
            log.error("HttpServerErrorException occured when calling {} got {}", compensationEndPointURL, exception.getMessage());
            log.info("Exiting invoke at {}", LocalDateTime.now());
            throw new AgencyCoPilot5xxException(exception,
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    compensationEndPointURL);
        }

        log.info("Exiting fetchAvailableCompensations at {}", LocalDateTime.now());
        return availableCompensationsResponse;
    }
}
