package com.pm.api.agencycopilot.models.external.documents.upload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IndexFields {

	@JsonProperty("documentDesc")
	private String documentDesc;

	@JsonProperty("docType")
	private String docType;

	@JsonProperty("corrType")
	private String corrType;

	@JsonProperty("docIndexCode")
	private String docIndexCode;

	@JsonProperty("policyNo")
	private String policyNo; // this one is for application-status policy worksheet requirement

	@JsonProperty("source")
	private String source;

	@JsonProperty("doc_type")
	private String doc_Type;

	@JsonProperty("workflowType")
	private String workflowType;

	@JsonProperty("descriptor")
	private String descriptor;

	@JsonProperty("policyNumber")
	private String policyNumber; // this one is for faci-claims
}