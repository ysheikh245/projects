package com.pm.api.agencycopilot.services;

import org.apache.tomcat.util.codec.binary.Base64;

public interface ServiceHandler {

    default String getBasicAuthToken(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }

    /*TODO: ys- need to consider this for common code
       default T invokePMAPIRestCall(String endpoint, String clientHeader,
                                                      String endUserId, String username, String password,
                                                      Class clazz, HttpMethod httpMethod, T type) {
        HttpHeaders headers = getHttpHeaders(clientHeader, endUserId, username, password);
        HttpEntity request = new HttpEntity(headers);
        ResponseEntity<T> response = restTemplate.exchange(endpoint, httpMethod, request, clazz);
        return response.getBody();
    }

    default HttpHeaders getHttpHeaders(String clientHeader, String endUserId, String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header",  clientHeader);
        headers.add("end-user-id", endUserId);
        headers.add("Authorization", getBasicAuthToken(username, password));
        return headers;
    }*/

}
