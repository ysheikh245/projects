package com.pm.api.agencycopilot.models.external.documents.upload;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DocumentUploadRequest {

	@JsonProperty("fileName")
	private String fileName;

	@JsonProperty("extension")
	private String extension;

	@JsonProperty("bytes")
	private String bytes;

	@JsonProperty("contentType")
	private Object contentType;

	@JsonProperty("indexFields")
	private IndexFields indexFields;

}