package com.pm.api.agencycopilot.services.impl;

import com.atiam.insprocommon._2008.SystemCodeTableValueType;
import com.atiam.newbusinessapplication._2008.AppRequirementType;
import com.atiam.newbusinessapplication._2008.GetNewBusinessRequirementHistoryRequestType;
import com.atiam.newbusinessapplication._2008.GetNewBusinessRequirementHistoryResponseType;
import com.pm.api.agencycopilot.models.external.nigo.NIGODocument;
import com.pm.api.agencycopilot.models.external.nigo.NIGOResponse;
import com.pm.api.agencycopilot.services.NIGOServiceHandler;
import com.pm.soap.client.InsproNewBusinessServiceClient;
import java.time.LocalDateTime;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NIGOServiceHandlerImpl implements NIGOServiceHandler {

    @Autowired
    private InsproNewBusinessServiceClient insproNewBusinessServiceClient;

   

    /*public NIGOResponse invokeNIGO() throws Exception {
        return invokeNIGO(new ArrayList<>());
    }*/

    public NIGOResponse invokeNIGO(List<String> policyNumber) throws Exception {
        log.info("Entering invokeNIGO at {}", LocalDateTime.now());
        GetNewBusinessRequirementHistoryRequestType request = new GetNewBusinessRequirementHistoryRequestType();
        request.setPolicyNumber(policyNumber.get(0));
        GetNewBusinessRequirementHistoryResponseType newBusinessRequirementHistory = insproNewBusinessServiceClient.getNewBusinessApplicationService().getNewBusinessRequirementHistory(request);
        NIGOResponse nigoResponse = mapNIGOResponse(newBusinessRequirementHistory);
        log.info("Exiting invokeNIGO at {}", LocalDateTime.now());
        return nigoResponse;
    }

    private NIGOResponse mapNIGOResponse(GetNewBusinessRequirementHistoryResponseType nigoSOAPResponse) {
        log.info("Entering mapNIGOResponse at {}", LocalDateTime.now());
        NIGOResponse nigoResponse = new NIGOResponse();
        if (nigoSOAPResponse != null && nigoSOAPResponse.getInfo() != null
                && nigoSOAPResponse.getInfo().getAppRequirements() != null
                && nigoSOAPResponse.getInfo().getAppRequirements().getAppRequirement() != null) {
            List<AppRequirementType> appRequirements = nigoSOAPResponse.getInfo().getAppRequirements().getAppRequirement();

            for (AppRequirementType appRequirement : appRequirements) {
                if (appRequirement != null) {
                    NIGODocument nigoDocument = new NIGODocument();
                    if (appRequirement.getRequirement() != null) {
                        SystemCodeTableValueType requirement = appRequirement.getRequirement();
                        nigoDocument.setCode(requirement.getCode());
                        nigoDocument.setShortName(requirement.getShortName());
                        nigoDocument.setLongName(requirement.getLongName());
                    }
                    nigoDocument.setHoldUpIssue(appRequirement.getHoldUpIssue());
                    nigoDocument.setSystemControlled(appRequirement.getSystemControlled());
                    nigoDocument.setOpenDate(String.valueOf(appRequirement.getOpenDate()));
                    nigoDocument.setComments(appRequirement.getComments());

                    nigoResponse.getNigoDocuments().add(nigoDocument);
                }
            }
        }
        log.info("Exiting mapNIGOResponse at {}", LocalDateTime.now());
        return nigoResponse;
    }

    /*private NIGOResponse serializeResponse(String nigoResponse) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(new File("C:\\Yusuf\\Code\\agency-copilot - Copy\\src\\main\\java\\com\\pm\\api\\agencycopilot\\test\\nigo.json"), NIGOResponse.class);
    }*/

    /*private String getNIGOResponseLocally() throws Exception {
        String content = FileUtils.readFileToString(new File("C:\\Yusuf\\Code\\agency-copilot - Copy\\src\\main\\java\\com\\pm\\api\\agencycopilot\\test\\nigo.json"), Charset.defaultCharset());
        return content;
    }*/

}
