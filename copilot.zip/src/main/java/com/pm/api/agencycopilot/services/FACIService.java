package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.apis.BeneficiaryDetailsResponse;
import com.pm.api.agencycopilot.models.apis.DiscountsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyAdditionalCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyByCustomerDetailsRequest;
import com.pm.api.agencycopilot.models.apis.PolicyCoverageDetailsResponse;
import com.pm.api.agencycopilot.models.apis.PolicyRateChangeResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.AgentRole;
import com.pm.api.agencycopilot.models.external.pmapi2.DependentsV2Reponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.DocumentsV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyAlertResponse;
import com.pm.api.agencycopilot.models.external.pmapi2.PolicyInfoV2Response;
import com.pm.api.agencycopilot.models.external.pmapi2.Role;
import com.pm.api.agencycopilot.models.internal.AdditionalDetailsCountVO;
import com.pm.api.agencycopilot.models.internal.ClaimsVO;
import com.pm.api.agencycopilot.models.internal.CustomersVO;
import com.pm.api.agencycopilot.models.internal.PolicyVO;
import java.util.List;

public interface FACIService {

    public AdditionalDetailsCountVO getAdditionalDetailsCountVO(String policyNumber) throws Exception;

    public DocumentsV2Response<DocumentsResponse> getPolicyDocumentDetails(String policyNumber) throws Exception;

    PolicyVO getPMAPIPolicyDetails(String policyNumber) throws Exception;

    PolicyInfoV2Response<Role> getPolicyRoleInfo(String policyNumber) throws Exception;

    PolicyInfoV2Response<AgentRole> getAgentRoleInfo(String policyNumber) throws Exception;

    DependentsV2Reponse getDependentsInfo(String policyNumber) throws Exception;

    DiscountsResponse getDiscountsInfo(String policyNumber) throws Exception;

    PolicyRateChangeResponse getRateChangesInfo(String policyNumber) throws Exception;

    PolicyCoverageDetailsResponse getPolicyCoverageDetails(String policyNumber) throws Exception;

    List<CustomersVO> getPolicyByCustomerDetails(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npnId) throws Exception;

    CustomersVO getCustomerContactDetails(String policyNumber, String partyId) throws Exception;

    BeneficiaryDetailsResponse getBeneficiaryDetails(String policyNumber) throws Exception;

    PolicyAdditionalCoverageDetailsResponse getAdditionalCoverages(String policyNumber) throws Exception;

    DocumentsV2Response<PolicyAlertResponse> getPolicyAlerts(String policyNumber) throws Exception;


    List<ClaimsVO> getAllClaimsFromPolicy(String policyNumber, String npnId);

    ClaimsVO getClaimDetails(String claimNumber, String claimType);
    
    List<CustomersVO> getPolicyBySalesCustomerDetails(PolicyByCustomerDetailsRequest policyByCustomerDetailsRequest, String npnId) throws Exception;
}
