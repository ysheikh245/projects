package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

//TODo: Use this class where ever possible
@Data
public class DocumentsV2Response<T> {
    @JsonProperty("response")
    private T responseData;
}
