package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentsUploadAPIResponse {

    private String status;
    private String policyNumber;
    private String documentDescription;
    private String pmicNumber;

}
