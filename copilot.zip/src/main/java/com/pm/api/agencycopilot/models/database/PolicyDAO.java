package com.pm.api.agencycopilot.models.database;

import lombok.*;
import java.sql.Timestamp;

@Data @NoArgsConstructor @AllArgsConstructor
public class PolicyDAO {
    private String agentNumber;
    private String policyNumber;
    private Timestamp issueDate;
}