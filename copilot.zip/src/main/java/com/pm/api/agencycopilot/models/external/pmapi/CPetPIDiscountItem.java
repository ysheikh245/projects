package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CPetPIDiscountItem{

	@JsonProperty("CMaxDiscount")
	private String cMaxDiscount;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("CDiScountTab")
	private List<CDiScountTabItem> cDiScountTab;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CTotalDiscount")
	private String cTotalDiscount;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("CPetPiDiscount")
	private String cPetPiDiscount;

	@JsonProperty("CPolicyDiscount")
	private String cPolicyDiscount;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("CAddiDiscount")
	private String cAddiDiscount;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	public String getCMaxDiscount(){
		return cMaxDiscount;
	}

	public String getEntityType(){
		return entityType;
	}

	public List<CDiScountTabItem> getCDiScountTab(){
		return cDiScountTab;
	}

	public String getGid(){
		return gid;
	}

	public String getCTotalDiscount(){
		return cTotalDiscount;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getCPetPiDiscount(){
		return cPetPiDiscount;
	}

	public String getCPolicyDiscount(){
		return cPolicyDiscount;
	}

	public String getId(){
		return id;
	}

	public String getCAddiDiscount(){
		return cAddiDiscount;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}
}