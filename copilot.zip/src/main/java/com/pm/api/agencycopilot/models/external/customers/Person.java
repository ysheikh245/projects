package com.pm.api.agencycopilot.models.external.customers;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Person{

	@JsonProperty("personNameList")
	private List<PersonNameListItem> personNameList;

	@JsonProperty("gender")
	private String gender;

	@JsonProperty("dateOfDeath")
	private Object dateOfDeath;

	@JsonProperty("dateOfBirth")
	private String dateOfBirth;

	@JsonProperty("maritalStatus")
	private String maritalStatus;

	public List<PersonNameListItem> getPersonNameList(){
		return personNameList;
	}

	public String getGender(){
		return gender;
	}

	public Object getDateOfDeath(){
		return dateOfDeath;
	}

	public String getDateOfBirth(){
		return dateOfBirth;
	}

	public String getMaritalStatus(){
		return maritalStatus;
	}
}