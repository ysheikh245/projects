package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BigDecimalValue {

    @JsonProperty("@xsi.nil")
    private boolean xsiNil;

    public boolean isXsiNil() {
        return xsiNil;
    }
}