package com.pm.api.agencycopilot.models.external.claims.details;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DiagnosisItem{

	@JsonProperty("code")
	private String code;

}