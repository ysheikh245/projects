package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class Response {

    @JsonProperty("FmsRowSetTO")
    private List<FmsRowSetTO> fmsRowSetTO;

    public List<FmsRowSetTO> getFmsRowSetTO() {
        return fmsRowSetTO;
    }
}