package com.pm.api.agencycopilot.models.apis;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pm.api.agencycopilot.models.enums.DocumentUploadEnum;
import lombok.Data;

@Data
public class DocumentsUploadAPIRequest {

        @JsonProperty("policyNumber")
        private String policyNumber;

        @JsonProperty("productCategory")
        private String productCategory;

        @JsonProperty("documentDescription")
        private String documentDescription;

        @JsonProperty("source")
        private DocumentUploadEnum documentUploadEnum;

       /* @JsonProperty("fileName")
        private String fileName;

        @JsonProperty("extension")
        private String extension;*/


}



