package com.pm.api.agencycopilot.models.external.pmapi2;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UBenefitsItem{

	@JsonProperty("policyNumber")
	private String policyNumber;

	@JsonProperty("uBenefitInd")
	private String uBenefitInd;

	@JsonProperty("uBenefitId")
	private String uBenefitId;

	@JsonProperty("effectiveDate")
	private String effectiveDate;

}