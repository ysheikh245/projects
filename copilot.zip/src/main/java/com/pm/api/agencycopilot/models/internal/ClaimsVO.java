package com.pm.api.agencycopilot.models.internal;

import lombok.Data;

import java.util.List;

@Data
public class ClaimsVO {

    private String claimNumber;
    private String policyNumber;
    private String claimStatus;
    private String claimantName;
    private String dateOfBirth;
    private String gender;
    private String claimRcvdDate;
    private String benefitPeriod;
    private String claimType;
    private List<Payee> payees;
    private String claimStatusDescription;
    @Data
    public class Payee {
        private String name;
        private String address1;
        private String city;
        private String state;
        private String zip;
        private String amountPaid;
        private String payRate;
        private String paymentDate;
        private String claimStatusDescription;
    }

    public Payee constructNewPayee() {
        return new Payee();
    }

}
