package com.pm.api.agencycopilot.configuration;

import com.pm.api.agencycopilot.decorator.LoggingTaskDecorator;
import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Value("${agency.copilot.async.config.core-pool.size}")
    Integer corePoolSize;

    @Value("${agency.copilot.async.config.max-pool.size}")
    Integer maxPoolSize;

    @Value("${agency.copilot.async.config.queue.capacity}")
    Integer queueCapacity;

    @Bean(name = "applicationStatusTaskExecutor")
    public Executor applicationStatusTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("applicationStatus-thread-");
        executor.setTaskDecorator(new LoggingTaskDecorator());
        executor.initialize();
        return executor;
    }

    @Bean(name = "applicationStatusBckGrdTaskExecutor")
    public Executor applicationStatusBckGrdTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setThreadNamePrefix("applicationStatusBckGrd-thread-");
        executor.setTaskDecorator(new LoggingTaskDecorator());
        executor.initialize();
        return executor;
    }
}
