package com.pm.api.agencycopilot.models.external.customers;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomerRoleByPolicy {

    @JsonProperty("name")
    private String name;

    @JsonProperty("role")
    private String role;

    @JsonProperty("currentAge")
    private String currentAge;

    @JsonProperty("issueAge")
    private String issueAge;

}
