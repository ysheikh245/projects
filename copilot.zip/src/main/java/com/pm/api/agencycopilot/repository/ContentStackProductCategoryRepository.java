package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ContentStackProductCategoryRepository extends MongoRepository<ContentStackProductCategory, String> {

    ContentStackProductCategory findByProductCategory(String productCategory);

}
