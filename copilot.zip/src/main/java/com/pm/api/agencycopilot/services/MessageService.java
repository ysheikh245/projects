package com.pm.api.agencycopilot.services;

public interface MessageService {
  public String getMessage();
}