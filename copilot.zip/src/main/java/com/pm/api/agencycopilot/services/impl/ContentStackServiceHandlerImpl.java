package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;
import com.pm.api.agencycopilot.models.mongodb.ContentStackProductCategory;
import com.pm.api.agencycopilot.repository.ProductTypeCategoriesRepository;
import com.pm.api.agencycopilot.services.ContentStackServiceHandler;
import com.pm.api.agencycopilot.services.MongoDBCacheHandler;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.BLANK;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.EQUALS;
import com.pm.api.agencycopilot.utility.JSONUtility;
import com.pm.api.agencycopilot.utility.StringUtility;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class ContentStackServiceHandlerImpl implements ContentStackServiceHandler {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${agency.copilot.content.stack.api.key}")
    private String apiKey;

    @Value("${agency.copilot.content.stack.access.token}")
    private String accessToken;

    @Value("${agency.copilot.content.stack.base.url}")
    private String baseURL;

    @Value("${agency.copilot.content.stack.environment}")
    private String environment;

    @Autowired
    private MongoDBCacheHandler mongoDBCacheHandler;

    @Autowired
    private ProductTypeCategoriesRepository productTypeCategoriesRepository;


    public Response getAgentWorksheetOptionsResponse(String productCode) {
        log.info("ContentStackServiceHandlerImpl.getAgentWorksheetOptionsResponse() - Started. Start={}, ProductCode={}", LocalDateTime.now(), productCode);
        String apiURL = "agent_worksheet_options/entries";
        String contentStackResponse;
        Response response = null;
        //String apiKey = "";
        //String accessToken = "";
        //HttpHeaders httpHeaders = getHttpHeaders(apiKey, accessToken);
        try {
            String productCategory = mongoDBCacheHandler.findProductTypeCategory(productCode, true).getCategory(); // Life, Dental, MedSupp, Cancer etc.
            log.info("ContentStackServiceHandlerImpl.getAgentWorksheetOptionsResponse() ::: ProductCategory={}", productCategory);
            String requestParams = "query={\"product_type\":" + "\"" + productCategory + "\"}";
            ContentStackProductCategory contentStackProductCategory = mongoDBCacheHandler.findByProductCategory(productCategory);
            if (contentStackProductCategory != null && StringUtils.isNotEmpty(contentStackProductCategory.getContentStackResponse())) {
                log.info("Returning cached response for ProductCategory={}. ", productCategory);
                contentStackResponse = contentStackProductCategory.getContentStackResponse();
            } else {
                //contentStackResponse =  invokeContentStack(apiURL, httpHeaders, requestParams);
                log.info("Getting response from ContentStack for ProductCategory={}. ", productCategory);
                contentStackResponse = invokeContentStack(apiURL, requestParams);
                cacheContentStackResponse(productCategory, contentStackResponse);
            }
            response = JSONUtility.convertStringToObject(contentStackResponse, Response.class);
        } catch(Exception exception) {
            log.info("ContentStackServiceHandlerImpl.getAgentWorksheetOptionsResponse() - Failed. End={}, ProductCode={}", LocalDateTime.now(), productCode);
            log.error("Exception occurred {}", ExceptionUtils.getStackTrace(exception));
        }
        log.info("ContentStackServiceHandlerImpl.getAgentWorksheetOptionsResponse() - Completed. End={}, ProductCode={}", LocalDateTime.now(), productCode);
        return response;
    }

    public String getAgentProfileResponse(String npn) {
        log.info("Entering getAgentProfileResponse at {}", LocalDateTime.now());
        String apiURL = "agent_profile/entries";
        String requestParams = "query={\"npn\":{\"$regex\":\"^" + npn + "$\"}}";
        String agentProfileResponse = invokeContentStack(apiURL, requestParams);
        log.info("Exiting getAgentProfileResponse at {}", LocalDateTime.now());
        return agentProfileResponse;
    }

    private String invokeContentStack(String apiURL, String... requestParams) {
        log.info("Entering invokeContentStack at {}", LocalDateTime.now());
        try {
            HttpHeaders headers = getHttpHeaders();
            HttpEntity request = new HttpEntity(headers);
            String actualEndPoint = StringUtility.getAccumulatedValue("/", baseURL, apiURL);
            Map<String, String> requestParameters = getRequestParameters(requestParams);
            UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(actualEndPoint);
            requestParameters.entrySet().stream().forEach(
                    entry -> {
                        uriComponentsBuilder.queryParam(entry.getKey(), entry.getValue());
                    }
            );
            URI finalURLWithQueryParams = uriComponentsBuilder.build().toUri();
            log.info("Invoking content stack with uri {}", finalURLWithQueryParams);

            ResponseEntity<String> response = restTemplate.exchange(finalURLWithQueryParams, HttpMethod.GET, request, String.class);
            log.info("Exiting invokeContentStack at {}", LocalDateTime.now());
            return response.getBody();
        } catch (Exception e) {
            log.error("ContentStackServiceHandlerImpl.invokeContentStack(). apiURL={}, Exception={}",
                    apiURL, ExceptionUtils.getStackTrace(e));
            log.info("Exiting invokeContentStack at {}", LocalDateTime.now());
            return BLANK;
        }
    }


    @NotNull
    /**
     * requestParameters be sent as key=value for every request parameter that needs to be sent to Content Stack
     * E.g. http://www.example.com?a=b&c=d&e=f;
     *      will need to be sent as a=b, c=d, e=f as '3' elements in an array while invoking this method
     */
    private Map<String, String> getRequestParameters(String... requestParameters) {
        log.info("Entering getRequestParameters at {}", LocalDateTime.now());
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("environment", environment);
        for (String requestParameter : requestParameters) {
            String[] splitParameter = requestParameter.split(EQUALS);
            requestParams.put(splitParameter[0], splitParameter[1]);
        }
        log.info("Exiting getRequestParameters at {}", LocalDateTime.now());
        return requestParams;
    }

    private void cacheContentStackResponse(String productCategory, String contentStackResponse) {
        log.info("Entering cacheContentStackResponse at {}", LocalDateTime.now());
        ContentStackProductCategory contentStackProductCategory = new ContentStackProductCategory();
        contentStackProductCategory.setProductCategory(productCategory);
        contentStackProductCategory.setContentStackResponse(contentStackResponse);
        mongoDBCacheHandler.insertContentStackResponseForProductCategory(contentStackProductCategory);
        log.info("Exiting cacheContentStackResponse at {}", LocalDateTime.now());
    }

    private HttpHeaders getHttpHeaders(String apiKey, String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("api_key", apiKey);
        headers.add("access_token", accessToken);
        return headers;
    }

    private HttpHeaders getHttpHeaders() {
        log.info("Kee={}, Tokin={}", apiKey, accessToken);
        return getHttpHeaders(apiKey, accessToken);
    }
}