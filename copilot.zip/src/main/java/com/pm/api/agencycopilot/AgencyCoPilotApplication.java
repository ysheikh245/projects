package com.pm.api.agencycopilot;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import com.pm.configuration.BootRunner;

@SpringBootApplication
@ComponentScan("com.pm.*")
@EnableCaching
@PropertySource(ignoreResourceNotFound = true, value = "file:${user.home}/application.properties")
public class AgencyCoPilotApplication {
	public static void main(String[] args) {
		BootRunner.run(AgencyCoPilotApplication.class, args);
	}
}
