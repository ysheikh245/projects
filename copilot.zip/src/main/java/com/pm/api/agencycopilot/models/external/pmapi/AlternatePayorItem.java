package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AlternatePayorItem{

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("CLastName")
	private String cLastName;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("AltPayorAddress")
	private List<AltPayorAddressItem> altPayorAddress;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("CFirstName")
	private String cFirstName;

	@JsonProperty("PolicyPmCPiBillInfo")
	private String policyPmCPiBillInfo;

	public String getEntityType(){
		return entityType;
	}

	public String getGid(){
		return gid;
	}

	public String getCLastName(){
		return cLastName;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public List<AltPayorAddressItem> getAltPayorAddress(){
		return altPayorAddress;
	}

	public String getId(){
		return id;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public String getCFirstName(){
		return cFirstName;
	}

	public String getPolicyPmCPiBillInfo(){
		return policyPmCPiBillInfo;
	}
}