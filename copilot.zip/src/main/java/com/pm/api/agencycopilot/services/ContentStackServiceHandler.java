package com.pm.api.agencycopilot.services;

import com.pm.api.agencycopilot.models.external.contentstack.agents.worksheet.Response;

public interface ContentStackServiceHandler extends ServiceHandler  {

    Response getAgentWorksheetOptionsResponse(String policyStatusCode);

    String getAgentProfileResponse(String npn);
}
