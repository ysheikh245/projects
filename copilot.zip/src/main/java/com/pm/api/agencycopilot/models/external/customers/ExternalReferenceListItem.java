package com.pm.api.agencycopilot.models.external.customers;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ExternalReferenceListItem{

	@JsonProperty("customerId")
	private String customerId;

	@JsonProperty("customerIdType")
	private String customerIdType;

	@JsonProperty("policyList")
	private List<PolicyListItem> policyList;

	public String getCustomerId(){
		return customerId;
	}

	public String getCustomerIdType(){
		return customerIdType;
	}

	public List<PolicyListItem> getPolicyList(){
		return policyList;
	}
}