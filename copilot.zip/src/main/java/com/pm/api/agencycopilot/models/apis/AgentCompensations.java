package com.pm.api.agencycopilot.models.apis;

import java.util.List;
import lombok.Data;

@Data
public class AgentCompensations {

    List<AgentCompensation> agentCompensationStatements;

}
