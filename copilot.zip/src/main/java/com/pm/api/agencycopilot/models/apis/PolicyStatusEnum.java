package com.pm.api.agencycopilot.models.apis;

import java.util.Arrays;
import java.util.List;

public enum PolicyStatusEnum {
    A, P;

    public static List getPolicyStatusLists() {
        return Arrays.asList(PolicyStatusEnum.values());
    }
}
