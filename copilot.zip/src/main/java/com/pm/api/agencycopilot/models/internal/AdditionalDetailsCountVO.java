package com.pm.api.agencycopilot.models.internal;

import lombok.Data;

@Data
public class AdditionalDetailsCountVO {
    int rolesCount;
    int dependentsCount;
    int agentsOfRecordCount;
    int discountsCount;
    int additionalLifeInsuranceRidersCount;
    int coverageDetailsCount;
    int beneficiaryDetailsCount;
    int rateChangesCount;
    int viewCustomerDocumentsCount;
    int policyAlertsCount;
}
