package com.pm.api.agencycopilot.controller;

import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.apis.DocumentDownloadRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIRequest;
import com.pm.api.agencycopilot.models.apis.DocumentsUploadAPIResponse;
import com.pm.api.agencycopilot.services.DocumentService;
import com.pm.api.agencycopilot.utility.JSONUtility;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;

import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.FAILED;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.SUCCESS;

@RestController
@Slf4j
public class DocumentController implements ApplicationController {

    @Autowired
    DocumentService documentService;

    @PostMapping(value = "/documents/upload", consumes = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<DocumentsUploadAPIResponse> uploadDocument(@RequestParam("request") String request,
                                                                     @RequestParam("file") MultipartFile file) {
        log.info("DocumentController.uploadDocument() ::: Start");
        DocumentsUploadAPIResponse documentsUploadAPIResponse = null;
        HttpStatus httpStatus;
        try {
            DocumentsUploadAPIRequest documentsUploadAPIRequest = JSONUtility.convertStringToObject(request, DocumentsUploadAPIRequest.class);
            if (documentsUploadAPIRequest != null) {
                documentsUploadAPIResponse = documentService.uploadDocument(documentsUploadAPIRequest, file);
            }
        } catch(Exception e) {
            log.error("DocumentController.uploadDocument() ::: Failed. Exception={}", ExceptionUtils.getStackTrace(e));
        }
        String status = (documentsUploadAPIResponse != null && StringUtils.equals(documentsUploadAPIResponse.getStatus(), SUCCESS)) ? SUCCESS : FAILED;
        httpStatus = StringUtils.equals(status, SUCCESS) ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(httpStatus).body(documentsUploadAPIResponse);
    }

    @PostMapping("/documents/download")
    public ResponseEntity<Resource> downloadDocument(@Valid @RequestBody DocumentDownloadRequest documentDownloadRequest) {
        log.info("DocumentController.downloadDocument() - Start");
        Resource response;
        try {
            response = documentService.downloadDocument(documentDownloadRequest);
        } catch (Exception e) {
            log.error("DocumentController.downloadDocument() - Failed. Exception={}", ExceptionUtils.getStackTrace(e));
            throw new AgencyCoPilotException(e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        log.info("DocumentController.downloadDocument() - Completed");
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .body(response);
    }
}