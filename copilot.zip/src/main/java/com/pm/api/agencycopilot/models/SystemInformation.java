package com.pm.api.agencycopilot.models;

import lombok.Data;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@Component
@ToString
public class SystemInformation {
    private String systemDate;

    @Value("${application.version}")
    private String version;

    private String gitCommit;
}
