package com.pm.api.agencycopilot.models.apis;

import lombok.Data;

@Data
public class MessagingAPIRequest {

    private String deliveryMode;
    private String messageCode;
    private String recipientFirstName;
    private String recipientLastName;
    private String recipientEmailAddress;
    private String recipientState;
    private String npn;
    private String productCode;
    private String partyId;
    private String policyNumber;
    private String notes;


}
