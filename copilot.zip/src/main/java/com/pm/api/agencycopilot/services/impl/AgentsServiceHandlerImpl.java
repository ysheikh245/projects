package com.pm.api.agencycopilot.services.impl;

import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.models.external.agents.AgentsAPIResponse;
import com.pm.api.agencycopilot.services.AgentsServiceHandler;
import java.time.LocalDateTime;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class AgentsServiceHandlerImpl implements AgentsServiceHandler {


    @Value("${agency.copilot.agents.api.username}")
    private String agentsAPIUsername;
    @Value("${agency.copilot.agents.api.password}")
    private String agentsAPIPassword;

    @Value("${agency.copilot.agents.api.url}")
    private String agentsAPIEndpoint;

    @Value("${agency.copilot.agents.api.client.header}")
    private String agentsAPIClientHeader;

    @Value("${agency.copilot.agents.api.end.userid}")
    private String agentsAPIClientUserId;

    @Autowired
    private RestTemplate restTemplate;


    public AgentsAPIResponse getAgentsDetail(String npn) {
        log.info("Entering getAgentsDetail at {}", LocalDateTime.now());

        HttpHeaders headers = getHttpHeaders();
        HttpEntity request = new HttpEntity(headers);

        //agentsAPIEndpoint = StringUtils.replace(agentsAPIEndpoint, "{npnId}", npn);
        String endPoint = StringUtils.replace(agentsAPIEndpoint, "{npnId}", npn);
        //ResponseEntity<GetInteractionLogsAPIResponse[]> response = restTemplate.exchange(interactionLogsEndpoint, HttpMethod.GET, request, GetInteractionLogsAPIResponse[].class);
        //return response.getBody();
        //ResponseEntity<String> response = restTemplate.exchange(interactionLogsEndpoint, HttpMethod.GET, request, String.class);
        try {
            ResponseEntity<AgentsAPIResponse> response = restTemplate.exchange(endPoint, HttpMethod.GET, request, AgentsAPIResponse.class);
            log.info("Exiting getAgentsDetail at {}", LocalDateTime.now());

            return response.getBody();
        } catch (Exception e) {
            log.error("Exception occurred while calling GET Agent Details API {} for npn {}", e.getMessage(), npn);
            log.info("Exiting getAgentsDetail at {}", LocalDateTime.now());

            throw new AgencyCoPilot5xxException(e, HttpStatus.INTERNAL_SERVER_ERROR, "");
        }
    }

    @NotNull
    private HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("client-header", agentsAPIClientHeader);
        headers.add("end-user-id", agentsAPIClientUserId);
        headers.add("Authorization", getBasicAuthToken(agentsAPIUsername, agentsAPIPassword));
        return headers;
    }

}
