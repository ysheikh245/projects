package com.pm.api.agencycopilot.repository;

import com.pm.api.agencycopilot.models.mongodb.PolicyToProductCategory;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PolicyToProductCategoryRepository extends MongoRepository<PolicyToProductCategory, String> {
}
