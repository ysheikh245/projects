package com.pm.api.agencycopilot.models.external.pmapi;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PetInsurancePetItem{

	@JsonProperty("CPet")
	private String cPet;

	@JsonProperty("COVERWELLNESS")
	private List<Object> cOVERWELLNESS;

	@JsonProperty("CPetNumber")
	private String cPetNumber;

	@JsonProperty("CGender")
	private String cGender;

	@JsonProperty("CSpecies")
	private String cSpecies;

	@JsonProperty("IsCovManuallyRated")
	private String isCovManuallyRated;

	@JsonProperty("SourceSystemId")
	private String sourceSystemId;

	@JsonProperty("PetOptCov")
	private List<PetOptCovItem> petOptCov;

	@JsonProperty("CExpectedLife")
	private String cExpectedLife;

	@JsonProperty("CPrimaryState")
	private String cPrimaryState;

	@JsonProperty("CHasPetYN")
	private String cHasPetYN;

	@JsonProperty("EntityReference")
	private String entityReference;

	@JsonProperty("EntityStatus")
	private String entityStatus;

	@JsonProperty("savingsByDiscPet")
	private List<SavingsByDiscPetItem> savingsByDiscPet;

	@JsonProperty("CBreed")
	private String cBreed;

	@JsonProperty("DiscountOffset")
	private List<DiscountOffsetItem> discountOffset;

	@JsonProperty("CAge")
	private String cAge;

	@JsonProperty("Gid")
	private String gid;

	@JsonProperty("LobCode")
	private String lobCode;

	@JsonProperty("RiskStateStatCode")
	private String riskStateStatCode;

	@JsonProperty("ProductCode")
	private String productCode;

	@JsonProperty("CThreeDigitZip")
	private String cThreeDigitZip;

	@JsonProperty("CPIPlan")
	private List<CPIPlanItem> cPIPlan;

	@JsonProperty("CPetTransEffectDt")
	private String cPetTransEffectDt;

	@JsonProperty("DiscountPerCoverage")
	private List<DiscountPerCoverageItem> discountPerCoverage;

	@JsonProperty("CFiveDigitZip")
	private String cFiveDigitZip;

	@JsonProperty("EntityType")
	private String entityType;

	@JsonProperty("WaivedPremium")
	private String waivedPremium;

	@JsonProperty("CPetType")
	private String cPetType;

	@JsonProperty("RiskState")
	private String riskState;

	@JsonProperty("CDispPetName")
	private String cDispPetName;

	@JsonProperty("CPetNumberOverride")
	private String cPetNumberOverride;

	@JsonProperty("CPetPIDiscount")
	private List<CPetPIDiscountItem> cPetPIDiscount;

	@JsonProperty("PremiumAttributes")
	private PremiumAttributes premiumAttributes;

	@JsonProperty("PetRating")
	private List<PetRatingItem> petRating;

	@JsonProperty("CName")
	private String cName;

	@JsonProperty("Id")
	private String id;

	@JsonProperty("CBreedGroup")
	private String cBreedGroup;

	@JsonProperty("CWellness")
	private String cWellness;

	public String getCPet(){
		return cPet;
	}

	public List<Object> getCOVERWELLNESS(){
		return cOVERWELLNESS;
	}

	public String getCPetNumber(){
		return cPetNumber;
	}

	public String getCGender(){
		return cGender;
	}

	public String getCSpecies(){
		return cSpecies;
	}

	public String getIsCovManuallyRated(){
		return isCovManuallyRated;
	}

	public String getSourceSystemId(){
		return sourceSystemId;
	}

	public List<PetOptCovItem> getPetOptCov(){
		return petOptCov;
	}

	public String getCExpectedLife(){
		return cExpectedLife;
	}

	public String getCPrimaryState(){
		return cPrimaryState;
	}

	public String getCHasPetYN(){
		return cHasPetYN;
	}

	public String getEntityReference(){
		return entityReference;
	}

	public String getEntityStatus(){
		return entityStatus;
	}

	public List<SavingsByDiscPetItem> getSavingsByDiscPet(){
		return savingsByDiscPet;
	}

	public String getCBreed(){
		return cBreed;
	}

	public List<DiscountOffsetItem> getDiscountOffset(){
		return discountOffset;
	}

	public String getCAge(){
		return cAge;
	}

	public String getGid(){
		return gid;
	}

	public String getLobCode(){
		return lobCode;
	}

	public String getRiskStateStatCode(){
		return riskStateStatCode;
	}

	public String getProductCode(){
		return productCode;
	}

	public String getCThreeDigitZip(){
		return cThreeDigitZip;
	}

	public List<CPIPlanItem> getCPIPlan(){
		return cPIPlan;
	}

	public String getCPetTransEffectDt(){
		return cPetTransEffectDt;
	}

	public List<DiscountPerCoverageItem> getDiscountPerCoverage(){
		return discountPerCoverage;
	}

	public String getCFiveDigitZip(){
		return cFiveDigitZip;
	}

	public String getEntityType(){
		return entityType;
	}

	public String getWaivedPremium(){
		return waivedPremium;
	}

	public String getCPetType(){
		return cPetType;
	}

	public String getRiskState(){
		return riskState;
	}

	public String getCDispPetName(){
		return cDispPetName;
	}

	public String getCPetNumberOverride(){
		return cPetNumberOverride;
	}

	public List<CPetPIDiscountItem> getCPetPIDiscount(){
		return cPetPIDiscount;
	}

	public PremiumAttributes getPremiumAttributes(){
		return premiumAttributes;
	}

	public List<PetRatingItem> getPetRating(){
		return petRating;
	}

	public String getCName(){
		return cName;
	}

	public String getId(){
		return id;
	}

	public String getCBreedGroup(){
		return cBreedGroup;
	}

	public String getCWellness(){
		return cWellness;
	}
}