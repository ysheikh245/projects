package com.pm.api.agencycopilot.models.external.case360;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BigDecimalValue{

	@JsonProperty("@xsi.nil")
	private boolean xsiNil;

	public boolean isXsiNil(){
		return xsiNil;
	}
}