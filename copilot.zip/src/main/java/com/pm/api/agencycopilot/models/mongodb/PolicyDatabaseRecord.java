package com.pm.api.agencycopilot.models.mongodb;

import com.pm.api.agencycopilot.models.internal.PolicyVO;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "policy")
@Data
public class PolicyDatabaseRecord {

    //import javax.persistence.Id; - Earlier this was used before making changes for updating email cache for Active Policy
    //@Id
    private String _id;
    private String policyNumber;
    private PolicyVO policyResponse;
    private String policyStatus;
    private String rank;
    //@Id
    private String npnId;
    private Date createDate;

}



