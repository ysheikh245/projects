package com.pm.api.agencycopilot.models.external.contentstack;

import lombok.Data;

@Data
public class ACL {

}