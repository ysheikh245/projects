package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.internal.ClaimsVO;
import lombok.Data;

import java.util.List;

@Data
public class ClaimsResponse {

    private List<ClaimsVO> claims; // the response can contain either list of applicable claims; just the claimNumber

    private ClaimsVO claim;

}
