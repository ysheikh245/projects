package com.pm.api.agencycopilot.decorator;

import java.util.Map;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

public class LoggingTaskDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable task) {
        Map<String, String> currentMDCContextMap = MDC.getCopyOfContextMap();
        return () -> {
            MDC.setContextMap(currentMDCContextMap);
            task.run();

        };
    }

}
