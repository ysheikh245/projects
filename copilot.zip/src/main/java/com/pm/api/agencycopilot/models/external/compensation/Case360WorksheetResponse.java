package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class Case360WorksheetResponse {

    @JsonProperty("FmsRowSetTO")
    private List<FmsRowSetTO> fmsRowSetTO;

}
