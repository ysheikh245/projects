package com.pm.api.agencycopilot.models.external.messaging;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValueMap{

	@JsonProperty("AgentEmail")
	private String agentEmail;

	@JsonProperty("AgentPhone")
	private String agentPhone;

	@JsonProperty("FirstName")
	private String firstName;

	@JsonProperty("State")
	private String state;

	@JsonProperty("CA_LicenseNumber")
	private String cALicenseNumber;

	@JsonProperty("LastName")
	private String lastName;

	@JsonProperty("AgentName")
	private String agentName;

	@JsonProperty("EmailAddress")
	private String emailAddress;

	@JsonProperty("AppointmentDate")
	private String appointmentDate;

	public String getAgentEmail(){
		return agentEmail;
	}

	public String getAgentPhone(){
		return agentPhone;
	}

	public String getFirstName(){
		return firstName;
	}

	public String getState(){
		return state;
	}

	public String getCALicenseNumber(){
		return cALicenseNumber;
	}

	public String getLastName(){
		return lastName;
	}

	public String getAgentName(){
		return agentName;
	}

	public String getEmailAddress(){
		return emailAddress;
	}

	public String getAppointmentDate(){
		return appointmentDate;
	}
}