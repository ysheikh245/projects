package com.pm.api.agencycopilot.models.external.sales;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SalesCustomerByPolicy {
	
	@JsonProperty("partyId")
	private String partyId;
	
	@JsonProperty("firstName")
	private String firstName;
	
	@JsonProperty("lastName")
	private String lastName;
	
	@JsonProperty("dob")
	private String dob; 
	
	@JsonProperty("gender")
	private String gender;
	
	@JsonProperty("addrLine1")
	private String addrLine1;
	
	@JsonProperty("addrLine2")
	private String addrLine2;
	
	@JsonProperty("city")
	private String city;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("zip")
	private String zip; 
	
	@JsonProperty("contactStartDate")
	private String contactStartDate;
	
	@JsonProperty("contactEndDate")
	private String contactEndDate;
	
	@JsonProperty("altAddrLine1")
	private String altAddrLine1;
	
	@JsonProperty("altAddrLine2")
	private String altAddrLine2; 
	
	@JsonProperty("altCity")
	private String altCity;
	
	@JsonProperty("altState")
	private String altState; 
	
	@JsonProperty("altZip")
	private String altZip; 
	
	@JsonProperty("phone1")
	private String phone1; 
	
	@JsonProperty("phone2")
	private String phone2; 
	
	@JsonProperty("age")
	private String age;
	
	@JsonProperty("policies")
	private List<SalesPolicies> policies;

}
