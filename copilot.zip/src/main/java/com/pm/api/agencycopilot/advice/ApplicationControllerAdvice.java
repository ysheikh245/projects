package com.pm.api.agencycopilot.advice;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot4xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilot5xxException;
import com.pm.api.agencycopilot.exception.AgencyCoPilotException;
import com.pm.api.agencycopilot.models.errors.ErrorObject;
import static com.pm.api.agencycopilot.utility.AgencyCoPilotConstants.TRUE;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
@Slf4j
public class ApplicationControllerAdvice {

    @Value("${agency.copilot.detailed.exception.stack.trace:false}")
    private String detailedExceptionStackTrace;

    @NotNull
    private ErrorObject buildErrorObject(Exception exception) {
        log.error("Following Exception Occurred {}", exception);
        ErrorObject errorObject = new ErrorObject();
        errorObject.setErrorMessage(exception.getMessage());

        // attach detailed stack trace in response only for lower environments
        if (StringUtils.equalsIgnoreCase(TRUE, detailedExceptionStackTrace)) {
            errorObject.setExceptionStackTrace(ExceptionUtils.getStackTrace(exception));
        }
        return errorObject;
    }

    @ExceptionHandler
    public ResponseEntity<ErrorObject> handleException(AgencyCoPilotException agencyCoPilotexception) {
        ErrorObject errorObject = buildErrorObject(agencyCoPilotexception);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorObject);
    }

    @ExceptionHandler
    public ResponseEntity<ErrorObject> handle5xxException(AgencyCoPilot5xxException agencyCoPilot5xxException) {
        ErrorObject errorObject = buildErrorObject(agencyCoPilot5xxException);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorObject);
    }

    @ExceptionHandler
    public ResponseEntity<ErrorObject> handle4xxException(AgencyCoPilot4xxException agencyCoPilot4xxException) {
        ErrorObject errorObject = buildErrorObject(agencyCoPilot4xxException);
        if (HttpStatus.NOT_FOUND == agencyCoPilot4xxException.getHttpStatus()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
        }
        return ResponseEntity.status(agencyCoPilot4xxException.getHttpStatus()).body(errorObject);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<List<ErrorObject>> handleValidationException(MethodArgumentNotValidException methodArgumentNotValidException) {

        List<FieldError> errors = methodArgumentNotValidException.getBindingResult().getFieldErrors();

        List<ErrorObject> errorDetails = new ArrayList<>();
        for (FieldError fieldError : errors) {
            ErrorObject errorObject = new ErrorObject();
            errorObject.setErrorMessage(fieldError.getObjectName() + "." + fieldError.getField() + "::" + fieldError.getDefaultMessage());
            errorDetails.add(errorObject);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorDetails);
    }

    @ExceptionHandler(InvalidFormatException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<ErrorObject> handleInvalidFormatException(InvalidFormatException invalidFormatException) {
        ErrorObject errorObject = buildErrorObject(invalidFormatException);
        return new ResponseEntity<>(errorObject, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingPathVariableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected ResponseEntity<ErrorObject> handleMissingPathVariable(MissingPathVariableException missingPathVariableException) {
        ErrorObject errorObject = buildErrorObject(missingPathVariableException);
        String error = missingPathVariableException.getParameter() + " parameter is missing";
        errorObject.setErrorMessage(error);
        return new ResponseEntity<>(errorObject, new HttpHeaders(), HttpStatus.BAD_REQUEST);

    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    protected ResponseEntity<ErrorObject> handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException httpRequestMethodNotSupportedException) {
        ErrorObject errorObject = buildErrorObject(httpRequestMethodNotSupportedException);

        return new ResponseEntity<>(errorObject, new HttpHeaders(), HttpStatus.BAD_REQUEST);

    }

}
