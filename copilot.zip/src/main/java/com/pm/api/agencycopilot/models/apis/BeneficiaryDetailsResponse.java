package com.pm.api.agencycopilot.models.apis;

import com.pm.api.agencycopilot.models.external.pmapi2.BeneficiaryDetails;
import lombok.Data;

import java.util.List;
@Data
public class BeneficiaryDetailsResponse {
    private List<BeneficiaryDetails> beneficiaryDetails;
}
