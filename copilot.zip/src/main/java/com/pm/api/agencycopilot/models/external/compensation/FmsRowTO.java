package com.pm.api.agencycopilot.models.external.compensation;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Data;

@Data
public class FmsRowTO {

    @JsonProperty("fieldCount")
    private int fieldCount;

    @JsonProperty("repositoryId")
    private int repositoryId;

    @JsonProperty("create")
    private boolean create;

    @JsonProperty("tableId")
    private int tableId;

    @JsonProperty("readOnly")
    private boolean readOnly;

    @JsonProperty("relationCount")
    private int relationCount;

    @JsonProperty("fieldList")
    private List<FieldList> fieldList;

    @JsonProperty("rowId")
    private int rowId;

}