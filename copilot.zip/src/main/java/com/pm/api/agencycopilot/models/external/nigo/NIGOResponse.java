package com.pm.api.agencycopilot.models.external.nigo;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class NIGOResponse {

	private List<NIGODocument> nigoDocuments = new ArrayList();

}