#!/bin/sh
~/config-secret-merger.sh /agency-copilot.config /run/secrets/agency-copilot.secret
java -Djava.security.egd=file:/dev/./urandom -jar /app.jar
