# agent-quoting-apis
**The app that laid Appcelerator/Axway to its eternal sleep**


### Clone down the project
> `` git clone https://pmgitlab01p.pmic.com/mobile-apps/agent-quoting-apis.git ``

### Set up the project
within the agent-quoting-apis directory, run 
        `` npm install ``


### To Start the server locally
> `` npm run start:server ``



### Testing the APIs locally
Import the *AgentQuotingAPIs.postman_collection.json* from the *testing* directory.


### Current Axway MBaaS code is found in the following repository
> `` https://pmgitlab01p.pmic.com/mobile-apps/mobile-apis ``




## Yet to do's...
* Implement API Key Security
  * Can we have three keys?
    * Read
    * Delete
    * Update 
* Implement/Deploy via docker
  * The shell is there, but never been tested
* Implement Salesforce APIs
  * checkUserValidity
  * salesforceLogin
  * opportunityQuote
  * opportunityQuoteHistory  
* Implement Other methods
  * checkForUpdates
  * deleteProduct
  * manifestSync
  * updateProduct
  * updateProductManifest
  * environmentVariable
