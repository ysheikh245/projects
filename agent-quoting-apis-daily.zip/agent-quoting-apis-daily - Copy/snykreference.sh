#!/bin/bash 
# Snyk is a platform allowing users to scan, prioritize, and fix security vulnerabilities in code, open source dependencies and container images. 
# The below monitor command will update snyk org agent-quoting-apis.  This will setup a monitor for open source vulnerabilities and license issues. 
# After running this command, log in to the Snyk website and view your projects and to see the monitor.
#   Possible exit codes and their meaning: 
#      0: success, snapshot created 
#      2: failure, try to re-run command 
#      3: failure, no supported projects detected 
# 
# snyk organization id for agent-quoting-apis: 6d8a1ff8-fb41-4b5c-96a0-48148bec6be4 
# snyk monitor command: snyk monitor --org=6d8a1ff8-fb41-4b5c-96a0-48148bec6be4 
# 
# as reference, cm executes the following command to push the image into snyk: 
#     cd $gitworkspace/agent-quoting-apis/ && (snyk container test -d --app-vulns pmdtrlb01p.pm.local/pm/imageName:$tag --file=Dockerfile || true) && snyk container monitor -d --app-vulns pmdtrlb01p.pm.local/pm/imageName:$tag --file=Dockerfile --org=6d8a1ff8-fb41-4b5c-96a0-48148bec6be4 
 
snyk monitor --scan-all-unmanaged --all-sub-projects --org=6d8a1ff8-fb41-4b5c-96a0-48148bec6be4 
snyk monitor --scan-all-unmanaged --all-projects --org=6d8a1ff8-fb41-4b5c-96a0-48148bec6be4 
