const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService"
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);

let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { Constants } from "../../src/server/util";
let productManifestService;
let qmsAreaService;


describe("QmsAreaService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsAreaService")]
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        qmsAreaService = new QmsAreaService() 
    })

    it("getAllQmsAreas with v2 db - Success", async() => {
        sinon.stub(dbServiceV2,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await qmsAreaService.getAllQmsAreas();
        expect(result.length).to.equal(1);
       
    })
})


describe("QmsAreaService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsAreaService")]
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        qmsAreaService = new QmsAreaService() 
    })

    it("getAllQmsAreas - Success", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await qmsAreaService.getAllQmsAreas();
        expect(result.length).to.equal(1);
       
    })

    it("getAllQmsAreas - in Error case should retun null", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        const result = await qmsAreaService.getAllQmsAreas();
        expect(result).to.equal(null);
       
    })

    it("getQmsAreaById", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsAreaService.getQmsAreaById('507f1f77bcf86cd799439011');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsAreaByBusinessTypeState", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                sort: () => ({
                    toArray: () => ({name: 'test'})
                })
            }),
        })
       const result =  await qmsAreaService.getQmsAreaByBusinessTypeState('test', '');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsArea", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsAreaService.getQmsArea('test', '2022-08-02', '');
       expect(result.name).to.equal('test');
       
    })

    it("deleteQmsAreaById - Success Case", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true)
        })

        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(true);
        
        const result = await qmsAreaService.deleteQmsAreaById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsAreaById - Success Case - if updateManifest is false", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(true);
        
        const result = await qmsAreaService.deleteQmsAreaById('507f1f77bcf86cd799439011', {}, false);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsAreaById - Success Case if getQmsAreaById returns null", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(null);
        
        const result = await qmsAreaService.deleteQmsAreaById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsAreaById - Error Case", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(true);
        
        const result = await qmsAreaService.deleteQmsAreaById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(false);
   
    })

    it("updateProductManifest", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(QmsAreaService.prototype, 'getQmsAreaByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2050-08-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {stateRates : []}});
        sinon.stub(QmsAreaService.prototype, 'deleteQmsAreaById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAreaService.updateProductManifest('test', 'test', {}, true);
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest - Effective date is smaller", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(QmsAreaService.prototype, 'getQmsAreaByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2022-07-05'}, {_id: 'testId2', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {stateRates : [{
            state: 'wrongState',
            rates: [],
            areas: []
        }]}});
        sinon.stub(QmsAreaService.prototype, 'deleteQmsAreaById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAreaService.updateProductManifest('test', 'test', 'testState', {});
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest -if modSupp is null", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
        sinon.stub(QmsAreaService.prototype, 'getQmsAreaByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData:null});
        sinon.stub(QmsAreaService.prototype, 'deleteQmsAreaById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAreaService.updateProductManifest('test', 'test', {}, true);
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("addUpdateQmsArea - Add Case", async() => {
        const addModelObj = {
            name: 'test'
        }
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
       

        const getQmsAreapStub = sinon.stub(QmsAreaService.prototype, 'getQmsArea')
        getQmsAreapStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
            findOne: () => (true)
        })
        sinon.stub(QmsAreaService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsAreapStub.onCall(1).returns(addModelObj)
        const result = await qmsAreaService.addUpdateQmsArea({}, {});
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateQmsArea - Add Case - user details is present", async() => {
        const addModelObj = {
            name: 'test'
        }
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService");

        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';

        const getQmsAreapStub = sinon.stub(QmsAreaService.prototype, 'getQmsArea')
        getQmsAreapStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
            findOne: () => (true)
        })
        sinon.stub(QmsAreaService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsAreapStub.onCall(1).returns(addModelObj)
        const result = await qmsAreaService.addUpdateQmsArea({}, userHeaderDetails);
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateMod - Edit Case", async() => {
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService")
        
        const getQmsAreapStub = sinon.stub(QmsAreaService.prototype, 'getQmsArea')
        getQmsAreapStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsAreaService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsAreapStub.onCall(1).returns(existingModelObj)
        const result = await qmsAreaService.addUpdateQmsArea({}, {});
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })

    it("addUpdateMod - Edit Case - userdetail present", async() => {
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
        const { QmsAreaService } = require("../../src/server/service/QmsAreaService")

        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        
        const getQmsAreapStub = sinon.stub(QmsAreaService.prototype, 'getQmsArea')
        getQmsAreapStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsAreaService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsAreapStub.onCall(1).returns(existingModelObj)
        const result = await qmsAreaService.addUpdateQmsArea({}, userHeaderDetails);
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })

    
});








