const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { QmsAreaService }  from '../../src/server/service/QmsAreaService';
const { expect } = chai;
chai.use(chaiHttp);

const qmsAreaService = new QmsAreaService();

let app;
describe("Qms Area Routes", function () {
      beforeEach(() => {
            sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
                  next();
            });
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("GET BY ID - it should return 200 status if  return success", async () => {
            sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsareas/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET BY ID- it should return 200 status if getQmsAreaById return success without data", async () => {
                sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(Promise.resolve(null));
                const response = await chai.request(app).get("/api/qmsareas/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });
        it("GET BY ID- it should return 500 status if getQmsAreaById return error", async () => {
                sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).get("/api/qmsareas/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });

        it("GET BY ID- it should return 400 status if getQmsAreaById return error", async () => {
            sinon.stub(QmsAreaService.prototype,"getQmsAreaById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsareas/123").set('apiKey', "api")
            expect(response).to.have.status(400);
      });
        it("POST - it should return 200 status if addUpdateQmsArea return success", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
            sinon.stub(QmsAreaService.prototype,"addUpdateQmsArea").returns(Promise.resolve(true));
            const response = await chai.request(app).post("/api/qmsareas").set('apiKey', "api").send(payload)
            expect(response).to.have.status(200);
        });
        it("POST - it should return 200 status if addUpdateQmsArea return success without data", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
                sinon.stub(QmsAreaService.prototype,"addUpdateQmsArea").returns(Promise.resolve(null));
                const response = await chai.request(app).post("/api/qmsareas").set('apiKey', "api").send( payload)
                expect(response).to.have.status(200);
        });
        it("POST - it should return 500 status if addUpdateQmsArea return error", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
                sinon.stub(QmsAreaService.prototype,"addUpdateQmsArea").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).post("/api/qmsareas").set('apiKey', "api").send( payload)
                expect(response).to.have.status(500);
        });
        it("POST - it should return 400 status if request body is empty", async () => {
            sinon.stub(QmsAreaService.prototype,"addUpdateQmsArea").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).post("/api/qmsareas").set('apiKey', "api").send( {})
            expect(response).to.have.status(400);
            });

        it("DELETE BY ID - it should return 500 status if deleteQmsAreaById return error", async () => {
                sinon.stub(QmsAreaService.prototype,"deleteQmsAreaById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).delete("/api/qmsareas/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });
        it("DELETE BY ID - it should return 400 status if deleteQmsAreaById return error", async () => {
            sinon.stub(QmsAreaService.prototype,"deleteQmsAreaById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/qmsareas/123").set('apiKey', "api")
            expect(response).to.have.status(400);
    });

        it("DELETE BY ID - it should return 200 status if deleteQmsAreaById return success", async () => {
                sinon.stub(QmsAreaService.prototype,"deleteQmsAreaById").returns(Promise.resolve(true));
                const response = await chai.request(app).delete("/api/qmsareas/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });


      it("GET - it should return 200 status if getAllQmsAreas return success", async () => {
            sinon.stub(QmsAreaService.prototype,"getAllQmsAreas").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsareas").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getAllQmsAreas return success without data", async () => {
            sinon.stub(QmsAreaService.prototype,"getAllQmsAreas").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsareas").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getAllQmsAreas return error", async () => {
            sinon.stub(QmsAreaService.prototype,"getAllQmsAreas").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsareas").set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      

      it("GET - it should return 200 status if getQmsArea return success", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsArea").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsArea return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsArea").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsArea return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsArea").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });



      it("GET - it should return 200 status if getQmsAreaByBusinessTypeState return success", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsAreaByBusinessTypeState").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsAreaByBusinessTypeState return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsAreaByBusinessTypeState").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsAreaByBusinessTypeState return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsAreaService.prototype,"getQmsAreaByBusinessTypeState").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsareas").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });
    


});

