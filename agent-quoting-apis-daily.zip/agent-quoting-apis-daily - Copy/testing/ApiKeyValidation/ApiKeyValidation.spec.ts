const chai = require("chai");
const chaiHttp = require("chai-http");
const httpMocks = require('node-mocks-http');
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { performAPIKeyValidation } from '../../src/server/routes/ApiKeyValidationRoutes';
import { Util }  from '../../src/server/util/Util';
const { expect } = chai;

describe("API key Validaton", function () {
      

      beforeEach(() => {
            sinon.stub(Util.config, 'credentials').returns({apikey: 'testkey'})
      })

      it("it should return 401 with api absent error if apiKey is not present in request header",  () => {
           
            const mockResponse = httpMocks.createResponse();

           performAPIKeyValidation({headers: {apikey: null}}, mockResponse  , null)
           
            const responseData =  mockResponse._getJSONData();
            expect(responseData.error).to.equal('API key is absent in the request header')

      });


      it("it should return INvalid API key error if it si not matching with actual API key",  () => {

            const mockResponse = httpMocks.createResponse();

            performAPIKeyValidation({headers: {apikey: 'WrongAPIKEY'}}, mockResponse  , null)
            
             const responseData =  mockResponse._getJSONData();
             expect(responseData.error).to.equal('Invalid API key')
      });

      it("it should passthrogh if key matches ",  () => {

            const mockResponse = httpMocks.createResponse();
            const nexMock = sinon.spy();

            performAPIKeyValidation({headers: {apikey: 'xPk22k9irftlkLwaRSuHv8FJWx44mjw5'}}, mockResponse  , nexMock)
            sinon.assert.calledOnce(nexMock);

      });
})

export { };
