const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
const { expect } = chai;
chai.use(chaiHttp);
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { Util } from '../../src/server/util/Util';
import { AedService } from "../../src/server/service/AedService";
let productService ;
let aedService;

describe('Product Service constructor test DB V2', () => {

    beforeEach(() => {
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/ProductService")]
        const { ProductService } = require("../../src/server/service/ProductService");
        ProductService['isInitilized'] = false;
        productService = new ProductService();
    })

    afterEach(function () {
        sinon.restore();
    });

    it("get All product", async () => {
        sinon.stub(dbServiceV2, 'getCollection').returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123"
            }])),
        });
        const { ProductService } = require("../../src/server/service/ProductService");
        ProductService['isInitilized'] = true;
        let productService2 = new ProductService();
        const result = await productService.getAllProducts()
        expect(result.length).to.equal(1)
    })

})

describe("-----Testing Product Service-----", function () {
    afterEach(()=> {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/ProductService")]
        const { ProductService } = require("../../src/server/service/ProductService");
        const { AedService } = require('../../src/server/service/AedService');
        productService = new ProductService();
        aedService = new AedService();    
    })

    it("add product", async () => {
        const { ProductService } = require("../../src/server/service/ProductService");

        const getProductStub =  sinon.stub(ProductService.prototype, "getProduct")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getProductStub.onFirstCall().returns(null);
        getProductStub.onSecondCall().returns({
            id:"2As1",
            productCode:"name12"
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"addUpdateProductManifest").returns({})
        const result = await productService.addUpdateProduct({productCode:"name12"}, { "end-user-id":"use12"})
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("name12")
    })

    it("add product with userdetails empty", async () => {
        const { ProductService } = require("../../src/server/service/ProductService");

        const getProductStub =  sinon.stub(ProductService.prototype, "getProduct")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getProductStub.onFirstCall().returns(null);
        getProductStub.onSecondCall().returns({
            id:"2As1",
            productCode:"name12"
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"addUpdateProductManifest").returns({})
        const result = await productService.addUpdateProduct({productCode:"name12"}, {})
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("name12")
    })


    it("update product", async () => {
        const { ProductService } = require("../../src/server/service/ProductService");

        const getProductStub =  sinon.stub(ProductService.prototype, "getProduct")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getProductStub.onFirstCall().returns({
            id:"2As1",
            productCode:"name12"
        })
        getProductStub.onSecondCall().returns({
            id:"2As1",
            productCode:"nam12"
        })
       
        const result = await productService.addUpdateProduct({
            productCode:"name12",
            updatedBy:"ertic",
        }, {
            "end-user-id":"use12"
        })
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("nam12")
    })

    it("update product with userdetails empty", async () => {
        const { ProductService } = require("../../src/server/service/ProductService");

        const getProductStub =  sinon.stub(ProductService.prototype, "getProduct")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getProductStub.onFirstCall().returns({
            id:"2As1",
            productCode:"name12"
        })
        getProductStub.onSecondCall().returns({
            id:"2As1",
            productCode:"nam12"
        })
       
        const result = await productService.addUpdateProduct({
            productCode:"name12",
            updatedBy:"ertic",
        }, {})
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("nam12")
    })



    it("error while add/update product", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await productService.addUpdateProduct({}, {})
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })

    it("get product", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: () => ({
                productCode: "nam123"
            }),
        })
        const result = await productService.getProduct("nam123")
        expect(result.productCode).to.equal("nam123")
    })

    it("get All product", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123"
            }])),
        })
        const result = await productService.getAllProducts()
        expect(result.length).to.equal(1)
    })

    it("error while get all product", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await productService.getAllProducts()
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })



    it("delete product", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({
            medSuppData:{
                adjGroups:[
                          "507f1f77bcf86cd799439011"  
                ],
                stateRates:[{
                    rates:["507f1f77bcf86cd799439012"],
                    areas:["507f1f77bcf86cd799439013"]
                }]
            }
        })

        sinon.stub(ProductManifestService.prototype,"deleteProductManifest")
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
        })

        const result = await productService.deleteProduct("L030")
        expect(result).to.equal(true)
   
    })
    it("delete product with adjacent Groups and State Rates as null", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({
            medSuppData:{
                adjGroups:null,
                stateRates:null
            }
        })

        sinon.stub(ProductManifestService.prototype,"deleteProductManifest")
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
        })

        const result = await productService.deleteProduct("L030")
        expect(result).to.equal(true)
   
    })
    it("delete product with State Rates as null", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({
            medSuppData:{
                adjGroups:[
                          "507f1f77bcf86cd799439011"  
                ],
                stateRates:[{
                    rates:null,
                    areas:null
                }]
            }
        })

        sinon.stub(ProductManifestService.prototype,"deleteProductManifest")
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
        })

        const result = await productService.deleteProduct("L030")
        expect(result).to.equal(true)
   
    })
   
    it("delete product with empty medsupp data", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"deleteProductManifest")
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
        })

        const result = await productService.deleteProduct("L090")
        expect(result).to.equal(true)
   
    })

    it("delete product with empty productmanifest data", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"deleteProductManifest")
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(null)
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
        })

        const result = await productService.deleteProduct("L030")
        expect(result).to.equal(true)
   
    })


    it("delete product throw error", async ()=>{
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")

        try{
        const result = await productService.deleteProduct("L090")
        }
        catch(err){
        expect(err.message).to.equal("unexpected error")
        }
   
    })

    it("Validate request with empty object", async () => {
        const result= await productService.validateRequest({})
        expect(result).to.equal(false)
    });

    it("Validate request without productCode", async () => {
        const result= await productService.validateRequest({"version":"123"})
        expect(result).to.equal(false)
    });


    it("Validate request with valid object", async () => {
        const result= await productService.validateRequest({productCode:"123"})
        expect(result).to.equal(true)
    });

    it("get all product with state code adds state data", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123",
                type: 'Health'
            }])),
        })
        sinon.stub(AedService.prototype, "getAed").returns({
            jsonData: {
                aed: {
                    productDefinition: {
                        allowedChannels: {
                            allowedStates: ['NJ']
                        }
                    }
                }
            }
        });
        const result = await productService.getAllProducts();
        expect(result.length).to.equal(1);
        expect(result[0].states.length).to.equal(1);
        expect(result[0].states[0]).to.equal('NJ');
    })
    
    it("get all product with state code doesn't add state data", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123",
                type: 'Health'
            }])),
        })
        sinon.stub(AedService.prototype, "getAed").returns(null);
        const result = await productService.getAllProducts();
        expect(result.length).to.equal(1);
        expect(result[0].states).to.equal(undefined);
    })

    it("get all product with state code catches error", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123",
                type: 'Health'
            }])),
        })
        sinon.stub(AedService.prototype, "getAed").throws("unexpected error");
        let result;
        try { 
            result = await productService.getAllProducts();
            expect(result[0].states).to.equal(undefined);
        } catch(err) {
            expect(err.message).to.equal('random error');
        }
    })

})


