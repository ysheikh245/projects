const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { ProductService } = require("../../src/server/service/ProductService")
const { expect } = chai;
chai.use(chaiHttp);

let app;

const mockdata=
{
    "_id": "23ae132111b02d0014ccd777",
    "productCode": "L730",
    "version": "2011-11-11",
    "effectiveDate": "2011-01-09 00:00:00.000",
    "type": "Health",
    "name": "Health Insurance",
    "kindCode": "123",
    "active": true,
    "deleteFlag": false,
}


describe("-----Testing Product Routes/get Product by productCode Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(()=> {
        sinon.restore();
    });

    it("get Product by productCode success", async () => {
        const productCode = "L730"
        sinon.stub(ProductService.prototype, "getProduct").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).get(`/api/product/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal(productCode);
        expect(response.body.results).to.be.instanceof(Array);

    });

    it("get Product by productCode success with null return", async () => {
        const productCode = "23as"
        sinon.stub(ProductService.prototype, "getProduct").returns(Promise.resolve
            (null))
        const response = await chai.request(app).get(`/api/product/${productCode}`)
            .set('apiKey', "api")
            expect(response).to.have.status(200);
            expect(response.body.results).to.be.instanceof(Array);
            expect(response.body.results.length).to.equal(0);
    });

    it("get Product by productCode 500 error", async () => {
        const productCode = "23as"
        sinon.stub(ProductService.prototype, "getProduct").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get(`/api/product/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing Product Routes/get Product -----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get Product success", async () => {
        sinon.stub(ProductService.prototype, "getAllProducts").returns(Promise.resolve
            ([mockdata]))
        const response = await chai.request(app).get("/api/product")
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal("L730");
        expect(response.body.results).to.be.instanceof(Array); 
    });

    it("get Product 500 error", async () => {
        sinon.stub(ProductService.prototype, "getAllProducts").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get("/api/product")
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing Product Routes/Post Product Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("Post product success", async () => {
        sinon.stub(ProductService.prototype, "addUpdateProduct").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).post("/api/product")
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(200);
        expect(response.body.results).to.be.instanceof(Object);  
        expect(response.body.results.productCode).to.equal("L730");
    });

    it("Post product  500 error", async () => {
        const productCode = "23as"
        sinon.stub(ProductService.prototype, "addUpdateProduct").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).post("/api/product")
            .set('apiKey', "api")
            .send({productCode})
        expect(response).to.have.status(500);
    });

    it("Post product 400 data missing error", async () => {
        const response = await chai.request(app).post(`/api/product`)
            .set('apiKey', "api")
         expect(response).to.have.status(400);
    });

})

describe("-----Testing Product Routes/Put/update Product Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("update product success", async () => {
        const productCode = "L730"
        sinon.stub(ProductService.prototype, "addUpdateProduct").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).put(`/api/product/${productCode}`)
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(200);
        expect(response.body.results).to.be.instanceof(Object);  
        expect(response.body.results.productCode).to.equal("L730");
    });

    it("update product  500 error", async () => {
        const productCode = "L730"
        sinon.stub(ProductService.prototype, "addUpdateProduct").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).put(`/api/product/${productCode}`)
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(500);
    });

    it("update product 400 data missing error", async () => {
        const productCode = "L730"
        const response = await chai.request(app).put(`/api/product/${productCode}`)
            .set('apiKey', "api")
         expect(response).to.have.status(400);
    });

})

describe("-----Testing Product Routes/delete product-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("deleteProduct success", async () => {
        const productCode = "23as"
        sinon.stub(ProductService.prototype, "deleteProduct").returns(Promise.resolve(true))
        const response = await chai.request(app).delete(`/api/product/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
    });

    it("deleteProduct 500 error", async () => {
        const productCode = "23as"
        sinon.stub(ProductService.prototype, "deleteProduct").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).delete(`/api/product/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})