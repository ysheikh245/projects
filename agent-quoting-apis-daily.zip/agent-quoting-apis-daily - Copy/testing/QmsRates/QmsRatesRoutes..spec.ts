const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { QmsRatesService }  from '../../src/server/service/QmsRatesService';
const { expect } = chai;
chai.use(chaiHttp);

const qmsRatesService = new QmsRatesService();

let app;
describe("Qms Rates Routes", function () {
      beforeEach(() => {
            sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
                  next();
            });
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("GET BY ID - it should return 200 status if  return success", async () => {
            sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsrates/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
        it("GET BY ID- it should return 200 status if getQmsRatesById return success without data", async () => {
                sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(Promise.resolve(null));
                const response = await chai.request(app).get("/api/qmsrates/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });
        it("GET BY ID- it should return 500 status if getQmsRatesById return error", async () => {
                sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).get("/api/qmsrates/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });
        it("GET BY ID- it should return 400 status if getQmsRatesById return error", async () => {
            sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsrates/123").set('apiKey', "api")
            expect(response).to.have.status(400);
    });

        it("POST - it should return 200 status if addUpdateQmsRates return success", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
            sinon.stub(QmsRatesService.prototype,"addUpdateQmsRates").returns(Promise.resolve(true));
            const response = await chai.request(app).post("/api/qmsrates").set('apiKey', "api").send( payload)
            expect(response).to.have.status(200);
        });
        it("POST - it should return 200 status if addUpdateQmsRates return success without data", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
                sinon.stub(QmsRatesService.prototype,"addUpdateQmsRates").returns(Promise.resolve(null));
                const response = await chai.request(app).post("/api/qmsrates").set('apiKey', "api").send(payload)
                expect(response).to.have.status(200);
        });
        it("POST - it should return 500 status if addUpdateQmsRates return error", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "state":"IA",
                  "records" : []
            }
                sinon.stub(QmsRatesService.prototype,"addUpdateQmsRates").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).post("/api/qmsrates").set('apiKey', "api").send( payload)
                expect(response).to.have.status(500);
        });

        it("POST - it should return 400 status if request body is empty", async () => {
            sinon.stub(QmsRatesService.prototype,"addUpdateQmsRates").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).post("/api/qmsrates").set('apiKey', "api").send( {})
            expect(response).to.have.status(400);
    });

        it("DELETE BY ID - it should return 500 status if deleteQmsRatesById return error", async () => {
                sinon.stub(QmsRatesService.prototype,"deleteQmsRatesById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).delete("/api/qmsrates/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });
        it("DELETE BY ID - it should return 400 status if deleteQmsRatesById return error", async () => {
            sinon.stub(QmsRatesService.prototype,"deleteQmsRatesById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/qmsrates/123").set('apiKey', "api")
            expect(response).to.have.status(400);
    });

        it("DELETE BY ID - it should return 200 status if deleteQmsRatesById return success", async () => {
                sinon.stub(QmsRatesService.prototype,"deleteQmsRatesById").returns(Promise.resolve(true));
                const response = await chai.request(app).delete("/api/qmsrates/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });


      it("GET - it should return 200 status if getAllQmsRates return success", async () => {
            sinon.stub(QmsRatesService.prototype,"getAllQmsRates").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsrates").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getAllQmsRates return success without data", async () => {
            sinon.stub(QmsRatesService.prototype,"getAllQmsRates").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsrates").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getAllQmsRates return error", async () => {
            sinon.stub(QmsRatesService.prototype,"getAllQmsRates").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsrates").set('apiKey', "api")
            expect(response).to.have.status(500);
      });
      

    
      it("GET - it should return 200 status if getQmsRates return success", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRates").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsRates return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRates").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsRates return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-03-02",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRates").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });



      it("GET - it should return 200 status if getQmsRatesByBusinessTypeState return success", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRatesByBusinessTypeState").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsRatesByBusinessTypeState return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRatesByBusinessTypeState").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsRatesByBusinessTypeState return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "state": "IA"
            }
            sinon.stub(QmsRatesService.prototype,"getQmsRatesByBusinessTypeState").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsrates").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });


});

 
