const chai = require("chai");
const sinon = require("sinon");
sinon.restore();
const chaiHttp = require("chai-http");
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
import { Util } from '../../src/server/util/Util';
// import { ProductManifestService } from '../../src/server/service/ProductManifestService';
const { expect } = chai;
chai.use(chaiHttp);

let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
// const {  QmsRatesService, } = require("../../src/server/service/QmsRatesService");
// import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
import { Constants } from "../../src/server/util";
let qmsRatesService; 

describe("QmsRatesService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsRatesService")]
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        QmsRatesService['isInitilized'] = false;
        qmsRatesService = new QmsRatesService() 
    })

    it("getAllQmsRates V2 - Success", async () => {
        sinon.stub(dbServiceV2, 'getCollection').returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            })
        });
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        QmsRatesService['isInitilized'] = true;
        let qmsRatesService2 = new QmsRatesService();
        const result = await qmsRatesService2.getAllQmsRates();
        expect(result.length).to.equal(1);
    });
})

describe("QmsRatesService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsRatesService")]
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        qmsRatesService = new QmsRatesService() 
    })


    it("getAllQmsRates - Success", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await qmsRatesService.getAllQmsRates();
        expect(result.length).to.equal(1);
       
    })

    it("getAllQmsRates - in Error case should retun null", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        const result = await qmsRatesService.getAllQmsRates();
        expect(result).to.equal(null);
       
    })

    it("getQmsRatesById", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsRatesService.getQmsRatesById('507f1f77bcf86cd799439011');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsRatesByBusinessTypeState", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                sort: () => ({
                    toArray: () => ({name: 'test'})
                })
            }),
        })
       const result =  await qmsRatesService.getQmsRatesByBusinessTypeState('test', '');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsRates", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsRatesService.getQmsRates('test', '2022-08-02', '');
       expect(result.name).to.equal('test');
       
    })

    it("deleteQmsRatesById - Success Case", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true),
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(true);
        
        const result = await qmsRatesService.deleteQmsRatesById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })

    it("deleteQmsRatesById - Success Case - if updateManifest is false", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true),
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(true);
        
        const result = await qmsRatesService.deleteQmsRatesById('507f1f77bcf86cd799439011', {}, false);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsRatesById - Success Case if getQmsRatesById returns null", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true),
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(null);
        
        const result = await qmsRatesService.deleteQmsRatesById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsRatesById - Error Case", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsRatesService.prototype,"getQmsRatesById").returns(true);
        
        const result = await qmsRatesService.deleteQmsRatesById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(false);
   
    })

    it("updateProductManifest", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(QmsRatesService.prototype, 'getQmsRatesByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2050-08-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {stateRates : []}});
        sinon.stub(QmsRatesService.prototype, 'deleteQmsRatesById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsRatesService.updateProductManifest('test', 'test', {}, true);
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest - Effective date is smaller", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(QmsRatesService.prototype, 'getQmsRatesByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2022-07-05'}, {_id: 'testId2', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {stateRates : [{
            state: 'wrongState',
            rates: [],
            areas: []
        }]}});
        sinon.stub(QmsRatesService.prototype, 'deleteQmsRatesById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsRatesService.updateProductManifest('test', 'test', 'testState', {});
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest -if modSupp is null", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        sinon.stub(QmsRatesService.prototype, 'getQmsRatesByBusinessTypeState').returns([{_id: 'testId', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData:null});
        sinon.stub(QmsRatesService.prototype, 'deleteQmsRatesById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsRatesService.updateProductManifest('test', 'test', {}, true);
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("addUpdateQmsRates - Add Case", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        const addModelObj = {
            name: 'test'
        }
        const getQmsRatesStub = sinon.stub(QmsRatesService.prototype, 'getQmsRates')
        getQmsRatesStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(QmsRatesService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsRatesStub.onCall(1).returns(addModelObj)
        const result = await qmsRatesService.addUpdateQmsRates({}, {});
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateQmsRates - Add Case - user details is present", async() => {
        const addModelObj = {
           
            name: 'test'
        }
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");

        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';

        const getQmsRatesStub = sinon.stub(QmsRatesService.prototype, 'getQmsRates')
        getQmsRatesStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(QmsRatesService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsRatesStub.onCall(1).returns(addModelObj)
        const result = await qmsRatesService.addUpdateQmsRates({}, userHeaderDetails);
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateQmsRates - Edit Case", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        
        const getQmsRatesStub = sinon.stub(QmsRatesService.prototype, 'getQmsRates')
        getQmsRatesStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsRatesService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsRatesStub.onCall(1).returns(existingModelObj)
        const result = await qmsRatesService.addUpdateQmsRates({}, userHeaderDetails);
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })

    it("addUpdateQmsRates - Edit Case - if userHeaderDeatisl not present", async() => {
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const { QmsRatesService } = require("../../src/server/service/QmsRatesService");
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
       
        
        const getQmsRatesStub = sinon.stub(QmsRatesService.prototype, 'getQmsRates')
        getQmsRatesStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsRatesService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsRatesStub.onCall(1).returns(existingModelObj)
        const result = await qmsRatesService.addUpdateQmsRates({}, {});
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })

    
});








