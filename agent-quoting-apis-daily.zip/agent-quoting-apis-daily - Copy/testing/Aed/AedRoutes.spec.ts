const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';

const { expect } = chai;
chai.use(chaiHttp);

import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { AedService } = require("../../src/server/service/AedService")

let app;
const mockdataforproduct =
{
    "_id": "44a4a61c12fcd13b12ca123e",
    "productCode": "P924",
    "version": "2022",
    "effectiveDate": "2021-12-28 00:00:00.000",
    "jsonData": {
        "aed": {
            "viewDefinition": {
                "viewSection": [
                    {}]
            }
        }
    }
}
const mockdataforaed =
    [{
        "_id": "44a4a61c12fcd13b12ca123e",
        "productCode": "P924",
        "version": "2022",
        "effectiveDate": "2021-12-28 00:00:00.000",
        "jsonData": {
            "aed": {
                "viewDefinition": {
                    "viewSection": [
                        {}]
                }
            }
        }
    },
    {
        "_id": "44a4a61c12fcd13b12ca908a",
        "productCode": "P927",
        "version": "2022",
        "effectiveDate": "2021-12-28 00:00:00.000",
        "jsonData": {
            "aed": {
                "viewDefinition": {
                    "viewSection": [
                        {}]
                }
            }
        }
    }]

describe("-----Testing AedRoutes/get Aed by productCode Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get Aed by product code success", async () => {
        const productCode = "P924"
        sinon.stub(AedService.prototype, "getAed").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).get(`/api/aed/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200)
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal(productCode);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Aed by product code success with empty return", async () => {
        const productCode = "P924"
        sinon.stub(AedService.prototype, "getAed").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/aed/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200)
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Aed by product 500 error", async () => {
        const productCode = "P924"
        sinon.stub(AedService.prototype, "getAed").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get(`/api/aed/${productCode}`).set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})


describe("-----Testing AedRoutes/get Aed by ID Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get Aed by ID success", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(AedService.prototype, "getAedById").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).get(`/api/aed/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0]._id).to.equal(id);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Aed by ID success with empty array", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(AedService.prototype, "getAedById").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/aed/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Aed by ID 500 error", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(AedService.prototype, "getAedById").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get(`/api/aed/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });

    it("get Aed by ID fail with invalid id", async () => {
        const id = "44a4a61c12fcd13b"
        const response = await chai.request(app).get(`/api/aed/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
        expect(response.body.message).to.include("Invalid object id")
    });
})


describe("-----Testing AedRoutes/get all Aed's Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get all Aed success", async () => {
        sinon.stub(AedService.prototype, "getAllAeds").returns(Promise.resolve(mockdataforaed))
        const response = await chai.request(app).get("/api/aed")
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(2);
        expect(response.body.results[0].productCode).to.equal('P924');
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get all Aed 500 error", async () => {
        sinon.stub(AedService.prototype, "getAllAeds").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get("/api/aed")
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing AedRoutes/Post Aed Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("add/update Aed success", async () => {
        sinon.stub(AedService.prototype, "addUpdateAed").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).post(`/api/aed`)
            .set('apiKey', "api")
            .send(mockdataforproduct)
        expect(response).to.have.status(200);
        expect(response.body.results.productCode).to.equal('P924');
        expect(response.body.results).to.be.instanceof(Object);
    });

    it("add/update Aed  500 error", async () => {
        const productCode = "23as"
        sinon.stub(AedService.prototype, "addUpdateAed").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).post(`/api/aed`)
            .set('apiKey', "api")
            .send({ productCode })
        expect(response).to.have.status(500);
    });

    it("add/update Aed  400 data missing error", async () => {
        const response = await chai.request(app).post(`/api/aed`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
    });

})

describe("-----Testing AedRoutes/delete Aed Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("delete Aed success", async () => {
        const productCode = "P924"
        sinon.stub(AedService.prototype, "deleteAed").returns(Promise.resolve(undefined))
        const response = await chai.request(app).delete(`/api/aed/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
    });

    it("get Aed by product 500 error", async () => {
        const productCode = "P924"
        sinon.stub(AedService.prototype, "deleteAed").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).delete(`/api/aed/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})