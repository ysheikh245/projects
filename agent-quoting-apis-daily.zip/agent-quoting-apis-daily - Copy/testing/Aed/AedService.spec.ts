import chai from "chai";
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
const { expect } = chai;
chai.use(chaiHttp);
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
const { GenericModelService } = require("../../src/server/service/GenericModelService");
const { AedService } = require("../../src/server/service/AedService");
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const aedService = new AedService()

const mockdataforproduct =
{
    "_id": "44a4a61c12fcd13b12ca123e",
    "productCode": "P924",
    "version": "2022",
    "effectiveDate": "2021-12-28 00:00:00.000",
    "jsonData": {
        "aed": {
            "viewDefinition": {
                "viewSection": [
                    {}]
            }
        }
    }
}

describe("-----Testing AedService-----", function () {
    afterEach(function () {
        sinon.restore();
    });

    it("get Aed", async () => {
        const productCode = "P924"
        const modelObjectStub = sinon.stub(GenericModelService.prototype, "getModelObject")
        modelObjectStub.withArgs("aed", productCode).returns(mockdataforproduct)
        const result = await aedService.getAed(productCode)
        expect(result.productCode).to.equal(productCode)
    });


    it("add/Update Aed", async () => {
        sinon.stub(GenericModelService.prototype, "addUpdateModel").returns(mockdataforproduct)
        const result = await aedService.addUpdateAed(mockdataforproduct)
        expect(result.productCode).to.equal("P924")
    });

    it("get All Aeds", async () => {
        const allModelStub = sinon.stub(GenericModelService.prototype, "getAllModels")
        allModelStub.withArgs("aed").returns([mockdataforproduct])
        const result = await aedService.getAllAeds()
        expect(result.length).to.equal(1)
        expect(result[0].productCode).to.equal("P924")
    });

    it("get Aed by Id", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        const modelByIdStub = sinon.stub(GenericModelService.prototype, "getModelById")
        modelByIdStub.withArgs("aed", id).returns(mockdataforproduct)
        const result = await aedService.getAedById(id)
        expect(result._id).to.equal(id)
    });

    it("delete Aed", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "deleteModel").returns(true)
        const result = await aedService.deleteAed(productCode)
        expect(result).to.equal(undefined)
    });

    it("updateProductManifestReferenceId Aed", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({ productCode })
        const result = await aedService.updateProductManifestReferenceId(productCode)
        expect(result.productCode).to.equal(productCode)
    });

    it("Validate request with empty object", async () => {
        const result = await aedService.validateRequest({})
        expect(result).to.equal(false)
    });

    it("Validate request without productCode", async () => {
        const result = await aedService.validateRequest({ "version": "123" })
        expect(result).to.equal(false)
    });

    it("Validate request with valid object", async () => {
        const result = await aedService.validateRequest({ productCode: "123" })
        expect(result).to.equal(true)
    });


})