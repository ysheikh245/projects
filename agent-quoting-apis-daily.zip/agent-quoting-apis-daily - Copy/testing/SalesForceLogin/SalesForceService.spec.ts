const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo');
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { SalesforceService } = require("../../src/server/service/SalesforceService");
import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
const { SalesForceHelper } = require("../../src/server/salesforce/SalesForceHelper")
import { Constants } from "../../src/server/util";
const { expect } = chai;
chai.use(chaiHttp);

const Salesforce = new SalesforceService();

let app;
describe("-----Testing Salesforce Login Service-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(()=>{
        sinon.restore();
    });

    it("it should return error if validate request returns false", async () => {

        const result = Salesforce.validateRequest("", "")
        expect(result).to.equal(false);

    });

    it("it should return error if validate request returns true", async () => {

        const result = Salesforce.validateRequest("abc", "123")
        expect(result).to.equal(true);

    });

    it("it should return error if validate request returns false", async () => {

        const result = Salesforce.validateRequest("", "123")
        expect(result).to.equal(false);

    });

    it("it should return error if validate request returns false", async () => {

        const result = Salesforce.validateRequest("abc", "")
        expect(result).to.equal(false);

    });

    it("it should return a connection error", async () => {

        const stub = sinon.stub(SalesForceConnectionService, "getSpecificSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_LOGIN_CONFIG_KEY).throws(new Error("Error in connection"))
        try {
            await Salesforce.getSpecificSalesForceConnection("abc", "123")
        }
        catch (error) {
            expect(error.message).to.equal("Error in connection")
        }

    });

    it("it should return a connection", async () => {
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(SalesForceConnectionService, "getSpecificSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_LOGIN_CONFIG_KEY, "abc", "123").returns([m2])
        const result = await Salesforce.getSpecificSalesForceConnection("abc", "123")
        expect(result).to.include(m2)
    });

    it("isUserActive throws error", async () => {
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_IS_ACTIVE_COLUMN).throws(new Error("Error in Query"))
        try {
            await Salesforce.isUserActive(m2, "123")
        }
        catch (error) {
            expect(error.message).to.equal("Error in Query")
        }

    });

    it("isUserActive gives an output true", async () => {
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_IS_ACTIVE_COLUMN).returns({
            totalSize: 1,
            done: true,
            records: [{ IsActive: true }]
        })
        const result = await Salesforce.isUserActive(m2, "123")
        expect(result).to.equal(true);

    });

    it("isUserActive gives an output false", async () => {
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_IS_ACTIVE_COLUMN).returns({
            totalSize: 1
        })
        const result = await Salesforce.isUserActive(m2, "123")
        expect(result).to.equal(false);

    });

    it("getuserRecord should return an error", async () => {
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_QUERY_FIELDS).throws(new Error("Error in Query"))
        try {
            await Salesforce.getUserRecord(m2, "123")
        }
        catch (error) {
            expect(error.message).to.equal("Error in Query")
        }
    });

    it("getuserRecord should give records", async () => {
        var rec = { IsActive: true, name: true, phno: 817 }
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true,
            records: [rec]
        })
        const result = await Salesforce.getUserRecord(m2, "123")
        expect(result).to.equal(rec)
    });

    it("getuserRecord should give null when records is null", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true
        })
        const result = await Salesforce.getUserRecord(m2, "123")
        expect(result).to.equal(null)
    });

    it("getuserRecord should give records when userquery is null", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryUserTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_USER_QUERY_FIELDS).returns(null)
        const result = await Salesforce.getUserRecord(m2, "123")
        expect(result).to.equal(null)
    });

    it("getUserContactrecord should return null when no records", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryContactTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_CONTACT_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true
        })
        const result = await Salesforce.getUserContactRecord(m2, "123")
        expect(result).to.equal(null)

    });

    it("getUserContactrecord should return null when userqueryrecords is null", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryContactTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_CONTACT_QUERY_FIELDS).returns(null)
        const result = await Salesforce.getUserContactRecord(m2, "123")
        expect(result).to.equal(null)

    });

    it("getUserContactrecord should return Error", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryContactTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_CONTACT_QUERY_FIELDS).throws(new Error("Error in Query Contact table"))
        try {
            await Salesforce.getUserContactRecord(m2, "123")
        }
        catch (error) {
            expect(error.message).to.equal("Error in Query Contact table")
        }

    });

    it("getUserContactrecord should return records", async () => {
        var rec = { IsActive: true, name: true, phno: 817 }
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryContactTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_CONTACT_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true,
            records: [rec]
        })
        const result = await Salesforce.getUserContactRecord(m2, "123")
        expect(result).to.equal(rec);

    });

    it("getUserrAccountrecord should return records", async () => {
        var rec = { IsActive: true, name: true, phno: 817 }
        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryAccountTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_ACCOUNT_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true,
            records: [rec]
        })
        const result = await Salesforce.getUserAccountRecord(m2, "123")
        expect(result).to.equal(rec);

    });

    it("getUserContactrecord should return Error", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryAccountTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_ACCOUNT_QUERY_FIELDS).throws(new Error("Error in Query Account table"))
        try {
            await Salesforce.getUserAccountRecord(m2, "123")
        }
        catch (error) {
            expect(error.message).to.equal("Error in Query Account table")
        }

    });

    it("getUserContactrecord should return null when no records", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryAccountTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_ACCOUNT_QUERY_FIELDS).returns({
            totalSize: 1,
            done: true
        })
        const result = await Salesforce.getUserAccountRecord(m2, "123")
        expect(result).to.equal(null)

    });

    it("getUserAccountrecord should return null when userqueryrecords is null", async () => {

        var m2 = { "name": "pmic", "email": "pmic@gmail.com" };
        const stub = sinon.stub(Salesforce, "queryAccountTable")
        stub.withArgs(m2, "123", Constants.SALES_FORCE_ACCOUNT_QUERY_FIELDS).returns(null)
        const result = await Salesforce.getUserAccountRecord(m2, "123")
        expect(result).to.equal(null)

    });

    it("queryUserTable should return result", async () => {

        let connection = {
            query: () => ({
                id: "2234"
            })
        };
        const result = await Salesforce.queryUserTable(connection, "2234", "id")
        expect(result.id).to.equal("2234")
    });

    it("queryContactTable should return null when userqueryrecords is null", async () => {
        let connection = {
            query: () => ({
                id: "2234",
                number: "234567"
            })
        };
        const result = await Salesforce.queryContactTable(connection, "2234", "id, number")
        expect(result.number).to.equal("234567")
    });

    it("queryAccountTable should return null when userqueryrecords is null", async () => {
        let connection = {
            query: () => ({
                id: "2234",
                balance: "234567"
            })
        };
        const result = await Salesforce.queryAccountTable(connection, "2234", "id,balance")
        expect(result.balance).to.equal("234567")
    });
    it("getUserDetailedRecord", async () => {
        const salesForceHelper = new SalesForceHelper()
        let detailedConsolidatedRecord = {}
        let userConsolidatedRecord = {
            userRecord: {
                FirstName: "fri"
            },
            contactRecord: {
                MailingAddress: {
                    state:"FL"
                },
                LastName:"nmo"
            },
            divisionOfficeRecord: {
                Name:"TX"
            },
            Address: {
                city:"dal"
            }
        }
      
       
      const consolidatedRecord=  await Salesforce.getDetailedUserRecord("tri",userConsolidatedRecord)

        expect(consolidatedRecord["firstName"]).to.equal("fri")
        expect(consolidatedRecord["lastName"]).to.equal("nmo")
        expect(consolidatedRecord["city"]).to.equal("dal")
        expect(consolidatedRecord["userType"]).to.equal("EMPLOYEE")
        });

});



