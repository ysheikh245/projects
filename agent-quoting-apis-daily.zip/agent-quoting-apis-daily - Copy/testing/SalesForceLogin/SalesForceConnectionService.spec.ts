const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo');
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
import jsforce from 'jsforce'
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing Salesforce Connection Service-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(()=>{
        sinon.restore();
    });

    describe("SalesforceConnectionService", () => {

        it("getSalesforceConnection", async () => {
            sinon.stub(jsforce, "Connection").callsFake(() => ({
                login: () => { },
                query: () => { }
            }))

            const connection2 = await SalesForceConnectionService.getSalesForceConnection("salesforceLogin")
            expect(connection2.query).to.exist
            const connection3 = await SalesForceConnectionService.getSalesForceConnection("salesforceLogin", true)
            expect(connection3.query).to.exist
            const connection1 = await SalesForceConnectionService.getSalesForceConnection("salesforceLogin")
            expect(connection1.query).to.exist
        })

        it("getSecificSalesforceConnection", async () => {
            sinon.stub(jsforce, "Connection").callsFake(() => ({
                login: () => { },
                query: () => { }
            }))

            const connection = await SalesForceConnectionService.getSpecificSalesForceConnection("salesforceBatch", "name", "pass")
            expect(connection.query).to.exist
        })

    })

});