const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo');
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});

import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { SalesforceService } = require("../../src/server/service/SalesforceService");
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing Salesforce Login Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(()=>{
        sinon.restore();
    });

    it("it should return error if validate request returns false", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(false)
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")

        expect(response).to.have.status(400);
        expect(response.text).to.include('Bad request: username and password are required');
    });

    it("it should return error if userInfoId doesn't exist", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{}
                        }
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api").send({username: 'testUser'})

        expect(response).to.have.status(401);
        expect(response.text).to.include('Un-authorized User');
    });
    
    it("login successful when getUserdataflag is false and userValidity is valid", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "isUserActive").returns(true)
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api").send({username: 'tesuser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
    });

    it("login successful when getUserdataflag is false and userValidity is invalid", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "isUserActive").returns(false)
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api").send({username: 'test'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('INVALID');
    });

    it("login successful when getUserdataflag is true and No contactID in userRecord", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true
        })
        sinon.stub(SalesforceService.prototype, "getDetailedUserRecord").returns({
            userType:"AGENT"
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
    });

    it("login successful with user account records empty object", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true,
            ContactId:"231s"
        })
        sinon.stub(SalesforceService.prototype, "getUserContactRecord").returns({
            AccountId:"3eac1"
        })
        sinon.stub(SalesforceService.prototype, "getUserAccountRecord").returns({
         
        })
        sinon.stub(SalesforceService.prototype, "getDetailedUserRecord").returns({
            userType:"AGENT",
            ContactId:"231s",
            AccountId:"3eac1"
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
        expect(response.body.userRecord.ContactId).to.equal('231s');
    });

    it("login successful when getUserdataflag is true with extracting contact and account records", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true,
            ContactId:"231s"
        })
        sinon.stub(SalesforceService.prototype, "getUserContactRecord").returns({
            AccountId:"3eac1"
        })
        sinon.stub(SalesforceService.prototype, "getUserAccountRecord").returns({
         Parent:"#$4"
        })
        sinon.stub(SalesforceService.prototype, "getDetailedUserRecord").returns({
            userType:"AGENT",
            ContactId:"231s",
            AccountId:"3eac1"
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
        expect(response.body.userRecord.ContactId).to.equal('231s');
    });

    it("login successful with account records null", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true,
            ContactId:"231s"
        })
        sinon.stub(SalesforceService.prototype, "getUserContactRecord").returns({
            AccountId:"3eac1"
        })
        sinon.stub(SalesforceService.prototype, "getUserAccountRecord").returns(null)
        sinon.stub(SalesforceService.prototype, "getDetailedUserRecord").returns({
            userType:"AGENT",
            ContactId:"231s",
            AccountId:"3eac1"
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
        expect(response.body.userRecord.ContactId).to.equal('231s');
    });


    it("login successful after user record is found even though there are errors later", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true,
            ContactId:"231s"
        })
        sinon.stub(SalesforceService.prototype, "getUserContactRecord").throws("contact record fetch error")
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
    });

    it("login successful with user contact record null", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").returns({
            IsActive: true,
            ContactId:"231s"
        })
        sinon.stub(SalesforceService.prototype, "getUserContactRecord").returns(null)
        sinon.stub(SalesforceService.prototype, "getDetailedUserRecord").returns({
            userType:"AGENT",
            ContactId:"231s",
        })
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(200);
        expect(response.body.validity).to.equal('VALID');
    });

    it("login failed", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").callsFake(()=>{
                        return {
                            userInfo:{
                                id:"22aa12"
                            }
                        }
        })
        sinon.stub(SalesforceService.prototype, "getUserRecord").throws("user record fetch error")
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true'})

        expect(response).to.have.status(500);
    });

    it("login failed ->Invalid login", async () => {
        sinon.stub(SalesforceService.prototype, "validateRequest").returns(true)
        sinon.stub(SalesforceService.prototype, "getSpecificSalesForceConnection").throws(new Error("INVALID_LOGIN"))
        const response = await chai.request(app).post("/api/login")
            .set('apiKey', "api")
            .send({getUserData:'true',username:'testUser'})

        expect(response).to.have.status(401);
    });
});
