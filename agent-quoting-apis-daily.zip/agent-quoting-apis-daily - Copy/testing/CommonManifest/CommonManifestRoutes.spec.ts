const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { expect } = chai;
chai.use(chaiHttp);
let app;
const { CommonManifestService } = require("../../src/server/service/CommonManifestService");


describe("-----Testing CommonManifest Route---------", function () {
  beforeEach(() => {
    sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
      next();
    });
    app = require("../../src/server/index.ts");
  })
  afterEach(() => {
    sinon.restore();
  });

  it("200 Code", async () => {
    let mockdata = 
    {
      "modId": "62fd2c3d3b34e111116fcad2",
    };
    sinon.stub(CommonManifestService.prototype, "getAllCommonManifests").returns(Promise.resolve([mockdata]));
    const response = await chai.request(app).get('/api/commonmanifest').set('apiKey', "api");
    expect(response).to.have.status(200);
    expect(response.body.results).to.be.instanceof(Array);
    expect(response.body.results[0].modId).to.equal(mockdata.modId);    
  });

  it("500 Error", async function () {
    sinon.stub(CommonManifestService.prototype, "getAllCommonManifests").rejects("deleteCommonManifest..........Error");
    const response = await chai.request(app).get('/api/commonmanifest').set('apiKey', "api");
    expect(response).to.have.status(500);
  });
});


