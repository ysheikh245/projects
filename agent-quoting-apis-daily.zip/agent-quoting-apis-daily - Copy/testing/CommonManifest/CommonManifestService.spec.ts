const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
let commonManifestService ;

describe("-----Testing CommonManifest Service-----", function () {
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/CommonManifestService")]
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        commonManifestService = new CommonManifestService()        
    })
    afterEach(()=>{
        sinon.restore();
    })

    it("add/update common manifest", async () => {
        const findOneStub = sinon.stub()
        sinon.stub(dbServiceV2, "getCollection").returns({
            findOne: findOneStub,
            insertOne: () => { },
            updateOne: () => { }
        })
        findOneStub.onFirstCall().returns(null);
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        sinon.stub(CommonManifestService.prototype, "getCommonManifest").returns({
            id: "2As1",
            updatedBy: "name12"
        })      
        const result = await commonManifestService.addUpdateCommonManifest({}, {
            "end-user-id":"use12"
        })
        expect(result.id).to.equal("2As1")
        expect(result.updatedBy).to.equal("name12")

        findOneStub.onSecondCall().returns({})
        const updateResult = await commonManifestService.addUpdateCommonManifest({}, {
            "end-user-id":"use12"
        })
        expect(updateResult.id).to.equal("2As1")
        expect(updateResult.updatedBy).to.equal("name12")
    })
})
describe("-----Testing CommonManifest Service-----", function () {
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/CommonManifestService")]
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        commonManifestService = new CommonManifestService()        
    })
    afterEach(()=>{
        sinon.restore();
    })

    it("add/update common manifest", async () => {
        const findOneStub = sinon.stub()
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: findOneStub,
            insertOne: () => { },
            updateOne: () => { }
        })
        findOneStub.onFirstCall().returns(null);
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        sinon.stub(CommonManifestService.prototype, "getCommonManifest").returns({
            id: "2As1",
            updatedBy: "name12"
        })      
        const result = await commonManifestService.addUpdateCommonManifest({}, {
            "end-user-id":"use12"
        })
        expect(result.id).to.equal("2As1")
        expect(result.updatedBy).to.equal("name12")

        findOneStub.onSecondCall().returns({})
        const updateResult = await commonManifestService.addUpdateCommonManifest({}, {
            "end-user-id":"use12"
        })
        expect(updateResult.id).to.equal("2As1")
        expect(updateResult.updatedBy).to.equal("name12")
    })

    it("add/update common manifest with userdetails empty", async () => {
        const findOneStub = sinon.stub()
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: findOneStub,
            insertOne: () => { },
            updateOne: () => { }
        })
        findOneStub.onFirstCall().returns(null);
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        sinon.stub(CommonManifestService.prototype, "getCommonManifest").returns({
            id: "2As1",
            updatedBy: "name12"
        })      
        const result = await commonManifestService.addUpdateCommonManifest({}, {})
        expect(result.id).to.equal("2As1")
        expect(result.updatedBy).to.equal("name12")

        findOneStub.onSecondCall().returns({})
        const updateResult = await commonManifestService.addUpdateCommonManifest({}, {})
        expect(updateResult.id).to.equal("2As1")
        expect(updateResult.updatedBy).to.equal("name12")
    })

    it("error while add/update common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await commonManifestService.addUpdateCommonManifest({}, {})
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
    })

    it("get common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: () => ({
                updatedBy: "nam123"
            }),
        })
        const result = await commonManifestService.getCommonManifest()
        expect(result.updatedBy).to.equal("nam123")
    })

    it("error=> get common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await commonManifestService.getCommonManifest()
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
    })

    it("get all common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () => (sinon.mongo.documentArray([{
                updatedBy: "nam123"
            }])),
        })
        const result = await commonManifestService.getAllCommonManifests()
        expect(result[0].updatedBy).to.equal("nam123")
    })


    it("error=> get all common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await commonManifestService.getAllCommonManifests()
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
    })

    it("delete common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => { }
        })
        const result = await commonManifestService.deleteCommonManifest()
        expect(result).to.equal(true)
    })

    it("error=> delete common manifest", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await commonManifestService.deleteCommonManifest()
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
    })

})
