const chai = require("chai");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { CheckForUpdateService } = require("../../src/server/service/CheckForUpdateService");
const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
const { ProductService } = require("../../src/server/service/ProductService");
const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
const { QmsAreaService } = require("../../src/server/service/QmsAreaService");
const { QmsRatesService } = require("../../src/server/service/QmsRatesService");



import { AppManifest } from "../../src/server/models/AppManifest";
import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
import { Constants } from "../../src/server/util";

const { expect } = chai;

const checkForUpdateService = new CheckForUpdateService();

describe("-----Testing checkForUpdates Service-----", function () {

    afterEach(function () {
        sinon.restore();
    });

    it("validate request should fail if appmanifest or products doesn't exist", () => {
        let result = checkForUpdateService.validateRequest()
        expect(result).to.equal(undefined);
        result = checkForUpdateService.validateRequest({})
        expect(result).to.equal(undefined);

    })

    it("validate request should pass if appmanifest is valid object", () => {
        const result = checkForUpdateService.validateRequest({ products: [] })
        expect(result).to.be.an('array')
    })

    it("filter duplicate products", () => {
        const result = checkForUpdateService.filterDuplicateProducts([{
            productCode: 221
        }, {
            productCode: 221
        }])
        expect(result.length).to.equal(1)
    })

    it("find common manifest", async () => {
        sinon.stub(CommonManifestService.prototype, "getAllCommonManifests").returns([{ id: "21w" }, { id: "65t" }])
        const result = await checkForUpdateService.findCommonManifest()
        expect(result.length).to.equal(2)
    })

    it("update common manifest", async () => {
        const appManifest1 = { mod: null }
        await checkForUpdateService.updateCommonManifest(appManifest1, [{ modId: "321" }])
        expect(appManifest1.mod?.["serverId"]).to.equal("321")

        const appManifest2 = { mod: { serverId: "12" } }
        await checkForUpdateService.updateCommonManifest(appManifest2, [{ modId: "321" }])
        expect(appManifest2.mod.serverId).to.equal("321")

        const appManifest3 = { mod: { serverId: "12" } }
        await checkForUpdateService.updateCommonManifest(appManifest3, [])
        expect(appManifest3.mod.serverId).to.equal("12")

    })

    it("find all products", async () => {
        sinon.stub(ProductService.prototype, "getAllProducts").returns([{ productCode: "56" }, { productCode: "87" }])
        const result = await checkForUpdateService.findAllProducts()
        expect(result.length).to.equal(2)
    })

    it("update product manifest", async () => {
        sinon.stub(ProductManifestService.prototype, "getAllProductManifests").returns([{
            productCode: "L030",
            aedId: "aed1",
            ratesId: "rate1",
            cashValueId: "cash1",
        }])
        sinon.stub(CheckForUpdateService.prototype, "processQMSData").returns([])
        let result = await checkForUpdateService.updateProductManifest(
            [{ productCode: "appMan1" }],
            [
                {
                    productCode: "L030"
                }
            ])
        expect(result.length).to.equal(2)
        expect(result[1].productCode).to.equal("L030")
        expect(result[1].aed.localId).to.equal('')

        result = await checkForUpdateService.updateProductManifest(
            [
                {
                    productCode: "L030",
                    aed: {
                        serverId: "aeds"
                    },
                    rate: {
                        serverId: "rates"
                    },
                    plan: {
                        serverId: "plans"
                    },
                    cashValue: {
                        serverId: "cashvalues"
                    },
                    nonforfeitureRPU: {
                        serverId: "RPUs"
                    },
                    nonforfeitureETI: {
                        serverId: "ETIs"
                    }
                }
            ],
            [{
                productCode: "L030"
            }]
        )
        expect(result[0].aed.serverId).to.equal("aed1")

        result = await checkForUpdateService.updateProductManifest(
            [{ productCode: "appMan1" }],
            [
                {
                    productCode: "L031"
                }
            ])
        expect(result.length).to.equal(2)
        expect(result[1].productCode).to.equal("L031")
        expect(result[1].aed).to.equal(undefined)

        result = await checkForUpdateService.updateProductManifest(
            [{ productCode: "appMan1" }],
            [
                {
                    productCode: "appMan1"
                }
            ])
        expect(result.length).to.equal(1)
    })

    it("process QMS data", async () => {
     const groupsStub=   sinon.stub(QmsAdjustmentGroupService.prototype, "getAllQmsAdjustmentGroups")
     groupsStub.onFirstCall().returns([{"_id":"id"}])
     groupsStub.onSecondCall().returns(null)
     groupsStub.onThirdCall().throws("unexpected error")
        sinon.stub(QmsAreaService.prototype, "getAllQmsAreas").returns([{ state: "s1" , _id:"id"},{state:"s1"}])
        sinon.stub(QmsRatesService.prototype, "getAllQmsRates").returns([{ state: "r1",_id:"id" },{state:"r1"}])

        let result = await checkForUpdateService.processQMSData(false, "dummy")
        expect(result.adjGroups[0]).to.equal("id")

        result = await checkForUpdateService.processQMSData(false, "dummy")
        expect(result.adjGroups.length).to.equal(0)

        try{
             result = await checkForUpdateService.processQMSData(false, "dummy")
           
        }catch(err){
            expect(err.message).to.include("unexpected error")
        }        
    })

    it("find States", () => {
        const result = checkForUpdateService.findStates()
        expect(result.length).to.equal(0)
    })

    it("update state manifest", () => {

        const appManifest = {
            states: [{ code: "ups1" }]
        }

        checkForUpdateService.updateStateManifest(
            appManifest,
            [
                {
                    code: "ups1"
                }
            ]
        )
        expect(appManifest.states.length).to.equal(1)

        const appManifest1 = {
            states: []
        }
    
        checkForUpdateService.updateStateManifest(
            appManifest1,
            [
                {
                    code: "ups2"
                }
            ]
        )
        expect(appManifest1.states.length).to.equal(1)
    
        const appManifest2 = {
            states: [{ code: "ups1" }]
        }
    
        checkForUpdateService.updateStateManifest(
            appManifest2,
            [
                {
                    code: "ups2"
                }
            ]
        )
        expect(appManifest2.states.length).to.equal(2)

        const appManifest3 = {
            states: [{ code: "ups1" }]
        }
    
        checkForUpdateService.updateStateManifest(
            appManifest3,
            []
        )
        expect(appManifest3.states.length).to.equal(1)
    
    
    })

  })