const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { CheckForUpdateService, } = require("../../src/server/service/CheckForUpdateService");
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing CheckForUpdate Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });


    it("Invalid request", async () => {
        sinon.stub(CheckForUpdateService.prototype, "validateRequest").returns(false)
        const response = await chai.request(app).post("/api/checkForUpdates")
            .set('apiKey', "ppp")
        expect(response).to.have.status(400);
        expect(response.text).to.include("The appManifest.products parameter was null or empty");

    });

    it("CheckForUpdate request successful", async () => {
        sinon.stub(CheckForUpdateService.prototype, "validateRequest").callsFake(() => {
            return true;
        });
        sinon.stub(CheckForUpdateService.prototype, "filterDuplicateProducts")
            .returns([]);
        sinon.stub(CheckForUpdateService.prototype, "findCommonManifest")
            .returns([]);

        sinon.stub(CheckForUpdateService.prototype, "updateCommonManifest")
            .returns([]);

            sinon.stub(CheckForUpdateService.prototype, "findStates")
            .returns([]);
            sinon.stub(CheckForUpdateService.prototype, "updateStateManifest")
            .returns([]);


        sinon.stub(CheckForUpdateService.prototype, "findAllProducts")
            .returns([]);

        sinon.stub(CheckForUpdateService.prototype, "updateProductManifest")
            .returns([]);

        const response = await chai.request(app).post("/api/checkForUpdates")
            .set('apiKey', "app")
            .send({ "appManifest": { products: [] } });
        expect(response).to.have.status(200);
        expect(response.text).to.include("appManifest");
    });

    it("check for update unexpected error", async () => {
        sinon.stub(CheckForUpdateService.prototype, "validateRequest")
            .returns(true);
        sinon.stub(CheckForUpdateService.prototype, "filterDuplicateProducts")
            .throws("unexpected error");

        const response = await chai.request(app).post("/api/checkForUpdates")
            .set('apiKey', "ppp")
            .send({ "appManifest": { products: [] } });

        expect(response).to.have.status(500);
        expect(response.text).to.include("unexpected error");

    })

});

export { };
