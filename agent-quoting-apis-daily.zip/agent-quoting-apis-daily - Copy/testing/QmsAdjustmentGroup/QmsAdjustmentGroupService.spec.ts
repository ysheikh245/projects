const chai = require("chai");
const sinon = require("sinon");
const chaiHttp = require("chai-http");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);

let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { Constants } from "../../src/server/util";
let qmsAdjustmentGroupService ;

describe("QmsAdjustmentGroupService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsAdjustmentGroupService")]
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        qmsAdjustmentGroupService = new QmsAdjustmentGroupService() 
    })

    it("getAllQmsAdjustmentGroups with db v2- Success", async() => {
        sinon.stub(dbServiceV2,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await qmsAdjustmentGroupService.getAllQmsAdjustmentGroups();
        expect(result.length).to.equal(1);
       
    })
})

describe("QmsAdjustmentGroupService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/ProductManifestService")]
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/QmsAdjustmentGroupService")]
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        qmsAdjustmentGroupService = new QmsAdjustmentGroupService() 
    })

    it("getAllQmsAdjustmentGroups - Success", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await qmsAdjustmentGroupService.getAllQmsAdjustmentGroups();
        expect(result.length).to.equal(1);
       
    })

    it("getAllQmsAdjustmentGroups - in Error case should retun null", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        const result = await qmsAdjustmentGroupService.getAllQmsAdjustmentGroups();
        expect(result).to.equal(null);
       
    })

    it("getQmsAdjustmentGroupById", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsAdjustmentGroupService.getQmsAdjustmentGroupById('507f1f77bcf86cd799439011');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsAdjustmentGroupByBusinessType", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                sort: () => ({
                    toArray: () => ({name: 'test'})
                })
            }),
        })
       const result =  await qmsAdjustmentGroupService.getQmsAdjustmentGroupByBusinessType('test');
       expect(result.name).to.equal('test');
       
    })

    it("getQmsAdjustmentGroup", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                name:"test"
            }),
        })
       const result =  await qmsAdjustmentGroupService.getQmsAdjustmentGroup('test', '2022-08-02');
       expect(result.name).to.equal('test');
       
    })

    it("deleteQmsAdjustmentGroupById - Success Case", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true)
        })
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(true);
        
        const result = await qmsAdjustmentGroupService.deleteQmsAdjustmentGroupById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })

    it("deleteQmsAdjustmentGroupById - Success Case - updateManifest is false", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true),
        })
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(true);
        
        const result = await qmsAdjustmentGroupService.deleteQmsAdjustmentGroupById('507f1f77bcf86cd799439011', {}, false);
        expect(result).to.equal(true);
   
    })

    it("deleteQmsAdjustmentGroupById - Success Case if getAdjustmentbygroupId returns null", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
            findOne: () => (true)
        })
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(null);
        
        const result = await qmsAdjustmentGroupService.deleteQmsAdjustmentGroupById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(true);
   
    })
    it("deleteQmsAdjustmentGroupById - Error Case", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(DbService.prototype,"getCollection").throws('unexpected error')
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"updateProductManifest").returns(true);
        sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(true);
        
        const result = await qmsAdjustmentGroupService.deleteQmsAdjustmentGroupById('507f1f77bcf86cd799439011', {}, true);
        expect(result).to.equal(false);
   
    })

    it("updateProductManifest", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroupByBusinessType').returns([{_id: 'testId', effectiveDate: '2050-08-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {adjGroups : []}});
        sinon.stub(QmsAdjustmentGroupService.prototype, 'deleteQmsAdjustmentGroupById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAdjustmentGroupService.updateProductManifest('test', 'test', {});
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest - Effective date is smaller", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroupByBusinessType').returns([{_id: 'testId', effectiveDate: '2022-07-05'}, {_id: 'testId2', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData: {adjGroups : []}});
        sinon.stub(QmsAdjustmentGroupService.prototype, 'deleteQmsAdjustmentGroupById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAdjustmentGroupService.updateProductManifest('test', 'test', {});
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("updateProductManifest -if modSupp is null", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroupByBusinessType').returns([{_id: 'testId', effectiveDate: '2022-07-05'}, {_id: 'testId2', effectiveDate: '2022-07-05'}])
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({medSuppData:null});
        sinon.stub(QmsAdjustmentGroupService.prototype, 'deleteQmsAdjustmentGroupById').returns(true);
        const addUpdateProductManifestStub =  sinon.stub(ProductManifestService.prototype, 'addUpdateProductManifest')
        addUpdateProductManifestStub.returns(true);
        const result = await qmsAdjustmentGroupService.updateProductManifest('test', 'test', {});
        sinon.assert.calledOnce(addUpdateProductManifestStub);
       
    })

    it("addUpdateQmsAdjustmentGroup - Add Case", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const addModelObj = {
            name: 'test'
        }

       

        const getQmsAdjustmentGroupStub = sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroup')
        getQmsAdjustmentGroupStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(QmsAdjustmentGroupService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsAdjustmentGroupStub.onCall(1).returns(addModelObj)
        const result = await qmsAdjustmentGroupService.addUpdateQmsAdjustmentGroup({}, {});
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateQmsAdjustmentGroup - Add Case - user detailis present", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const addModelObj = {
            name: 'test'
        }

        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        
        const getQmsAdjustmentGroupStub = sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroup')
        getQmsAdjustmentGroupStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(QmsAdjustmentGroupService.prototype , 'updateProductManifest').returns(addModelObj)
        getQmsAdjustmentGroupStub.onCall(1).returns(addModelObj)
        const result = await qmsAdjustmentGroupService.addUpdateQmsAdjustmentGroup({}, userHeaderDetails);
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateMod - Edit Case", async() => {
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }

        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        
        const getQmsAdjustmentGroupStub = sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroup')
        getQmsAdjustmentGroupStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsAdjustmentGroupService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsAdjustmentGroupStub.onCall(1).returns(existingModelObj)
        const result = await qmsAdjustmentGroupService.addUpdateQmsAdjustmentGroup({}, userHeaderDetails);
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })


    it("addUpdateMod - Edit Case - User details not present", async() => {
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }

        
        const { QmsAdjustmentGroupService } = require("../../src/server/service/QmsAdjustmentGroupService");
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        const getQmsAdjustmentGroupStub = sinon.stub(QmsAdjustmentGroupService.prototype, 'getQmsAdjustmentGroup')
        getQmsAdjustmentGroupStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        sinon.stub(QmsAdjustmentGroupService.prototype , 'updateProductManifest').returns(existingModelObj)
        getQmsAdjustmentGroupStub.onCall(1).returns(existingModelObj)
        const result = await qmsAdjustmentGroupService.addUpdateQmsAdjustmentGroup({}, {});
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })


    // it("addUpdateMod - Error", async() => {
    //     sinon.stub(ModService.prototype, 'getMod').throws("unexpected error")
       

    //     try {
    //         await modService.addUpdateMod({}, {});
    //     }
    //     catch (err) {
    //         expect(err.message).to.equal('unexpected error')
    //     }
       
       
    // })

    
});








