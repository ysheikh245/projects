const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { QmsAdjustmentGroupService }  from '../../src/server/service/QmsAdjustmentGroupService';
import { query } from 'express';
const { expect } = chai;
chai.use(chaiHttp);

const qmsAdjustmentGroupService = new QmsAdjustmentGroupService();

let app;
describe("Qms Adjustment Group Routes", function () {
      beforeEach(() => {
            sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
                  next();
            });
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("GET BY ID - it should return 200 status if  return success", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
    it("GET BY ID- it should return 200 status if getQmsAdjustmentGroupById return success without data", async () => {
                sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(Promise.resolve(null));
                const response = await chai.request(app).get("/api/qmsadjustmentgroup/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });
        it("GET BY ID- it should return 500 status if getQmsAdjustmentGroupById return error", async () => {
                sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).get("/api/qmsadjustmentgroup/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });
        it("GET BY ID- it should return 400 status if getQmsAdjustmentGroupById return error", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup/123").set('apiKey', "api")
            expect(response).to.have.status(400);
      });
        it("POST - it should return 200 status if addUpdateQmsAdjustmentGroup return success a", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "records" : []
            }
            sinon.stub(QmsAdjustmentGroupService.prototype,"addUpdateQmsAdjustmentGroup").returns(Promise.resolve(true));
            const response = await chai.request(app).post("/api/qmsadjustmentgroup").set('apiKey', "api").send(payload)
            expect(response).to.have.status(200);
    });
        it("POST - it should return 200 status if addUpdateQmsAdjustmentGroup return success without data", async () => {
                  const payload = {
                        "businessType": "Life Standard - 2020",
                        "effectiveDate": "2022-02-02",
                        "records" : []
                  }
                sinon.stub(QmsAdjustmentGroupService.prototype,"addUpdateQmsAdjustmentGroup").returns(Promise.resolve(null));
                const response = await chai.request(app).post("/api/qmsadjustmentgroup").set('apiKey', "api").send( payload)
                expect(response).to.have.status(200);
        });
        it("POST - it should return 500 status if addUpdateQmsAdjustmentGroup return error", async () => {
            const payload = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02",
                  "records" : []
            }
                sinon.stub(QmsAdjustmentGroupService.prototype,"addUpdateQmsAdjustmentGroup").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).post("/api/qmsadjustmentgroup").set('apiKey', "api").send(payload)
                expect(response).to.have.status(500);
        });
        it("POST - it should return 400 status if request body is empty", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"addUpdateQmsAdjustmentGroup").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).post("/api/qmsadjustmentgroup").set('apiKey', "api").send( {})
            expect(response).to.have.status(400);
    });

    it("POST - it should return 200 status if addUpdateQmsAdjustmentGroup return success and businessType is not 'Life Standard - 2020'", async () => {
      const payload = {
            "businessType": "Life Standard - 2021",
            "effectiveDate": "2022-02-02",
            "records" : []
      }
      sinon.stub(QmsAdjustmentGroupService.prototype,"addUpdateQmsAdjustmentGroup").returns(Promise.resolve(true));
      const response = await chai.request(app).post("/api/qmsadjustmentgroup").set('apiKey', "api").send(payload)
      expect(response).to.have.status(200);
});
        it("DELETE BY ID - it should return 500 status if deleteQmsAdjustmentGroupById return error", async () => {
                sinon.stub(QmsAdjustmentGroupService.prototype,"deleteQmsAdjustmentGroupById").returns(Promise.reject('Test Error'));
                const response = await chai.request(app).delete("/api/qmsadjustmentgroup/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(500);
        });

        it("DELETE BY ID - it should return 400 status if deleteQmsAdjustmentGroupById return error", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"deleteQmsAdjustmentGroupById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/qmsadjustmentgroup/123").set('apiKey', "api")
            expect(response).to.have.status(400);
    });

        it("DELETE BY ID - it should return 200 status if deleteQmsAdjustmentGroupById return success", async () => {
                sinon.stub(QmsAdjustmentGroupService.prototype,"deleteQmsAdjustmentGroupById").returns(Promise.resolve(true));
                const response = await chai.request(app).delete("/api/qmsadjustmentgroup/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
                expect(response).to.have.status(200);
        });


      it("GET - it should return 200 status if getQmsAdjustmentGroup return success", async () => {
            // const query = {"businessType":"00","effectiveDate":"00"}
           const query = {
            "businessType": "Life Standard - 2020",
            "effectiveDate": "2022-02-02"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroup").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsAdjustmentGroup return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroup").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsAdjustmentGroup return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020",
                  "effectiveDate": "2022-02-02"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroup").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      it("GET - it should return 200 status if getQmsAdjustmentGroupByBusinessType return success", async () => {
            // const query = {"businessType":"00","effectiveDate":"00"}
           const query = {
            "businessType": "Life Standard - 2020"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupByBusinessType").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getQmsAdjustmentGroupByBusinessType return success without data", async () => {
            const query = {
                  "businessType": "Life Standard - 2020"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupByBusinessType").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getQmsAdjustmentGroupByBusinessType return error", async () => {
            const query = {
                  "businessType": "Life Standard - 2020"}
            sinon.stub(QmsAdjustmentGroupService.prototype,"getQmsAdjustmentGroupByBusinessType").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").query(query).set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      it("GET - it should return 200 status if getAllQmsAdjustmentGroups return success", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"getAllQmsAdjustmentGroups").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getAllQmsAdjustmentGroups return success without data", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"getAllQmsAdjustmentGroups").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getAllQmsAdjustmentGroups return error", async () => {
            sinon.stub(QmsAdjustmentGroupService.prototype,"getAllQmsAdjustmentGroups").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/qmsadjustmentgroup").set('apiKey', "api")
            expect(response).to.have.status(500);
      });
    


});













