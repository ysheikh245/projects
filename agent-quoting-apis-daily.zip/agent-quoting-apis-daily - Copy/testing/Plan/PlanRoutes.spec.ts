const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { PlanService } = require("../../src/server/service/PlanService")
const { expect } = chai;
chai.use(chaiHttp);

let app;
const mockdataforproduct =
{
    "_id": "44a4a61c12fcd13b12ca123e",
    "productCode": "P924",
    "version": "2022",
    "effectiveDate": "2021-12-28 00:00:00.000",
    "jsonData": {
        "plan": {
            "viewDefinition": {
                "viewSection": [
                    {}]
            }
        }
    }
}
const mockdataforplan =
    [{
        "_id": "44a4a61c12fcd13b12ca123e",
        "productCode": "P924",
        "version": "2022",
        "effectiveDate": "2021-12-28 00:00:00.000",
        "jsonData": {
            "plan": {
                "viewDefinition": {
                    "viewSection": [
                        {}]
                }
            }
        }
    },
    {
        "_id": "44a4a61c12fcd13b12ca908a",
        "productCode": "P927",
        "version": "2022",
        "effectiveDate": "2021-12-28 00:00:00.000",
        "jsonData": {
            "plan": {
                "viewDefinition": {
                    "viewSection": [
                        {}]
                }
            }
        }
    }]

describe("-----Testing PlanRoutes/get plan by productCode Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get Plan by product code success", async () => {
        const productCode = "P924"
        sinon.stub(PlanService.prototype, "getPlan").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).get(`/api/plan/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200)
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal(productCode);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Plan by product code success with empty return", async () => {
        const productCode = "P924"
        sinon.stub(PlanService.prototype, "getPlan").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/plan/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200)
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Plan by product 500 error", async () => {
        const productCode = "P924"
        sinon.stub(PlanService.prototype, "getPlan").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get(`/api/plan/${productCode}`).set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})


describe("-----Testing PlanRoutes/get Plan by ID Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get plan by ID success", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(PlanService.prototype, "getPlanById").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).get(`/api/plan/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0]._id).to.equal(id);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Plan by ID success with empty array", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(PlanService.prototype, "getPlanById").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/plan/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Plan by ID 500 error", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(PlanService.prototype, "getPlanById").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get(`/api/plan/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });

    it("get Plan by ID fail with invalid id", async () => {
        const id = "44a4a61c12fcd13b"
        const response = await chai.request(app).get(`/api/plan/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
        expect(response.body.message).to.include("Invalid object id")
    });
})


describe("-----Testing PlanRoutes/get all Plan's Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get all Plan success", async () => {
        sinon.stub(PlanService.prototype, "getAllPlans").returns(Promise.resolve(mockdataforplan))
        const response = await chai.request(app).get("/api/plan")
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(2);
        expect(response.body.results[0].productCode).to.equal('P924');
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get all Plan 500 error", async () => {
        sinon.stub(PlanService.prototype, "getAllPlans").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get("/api/plan")
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing PlanRoutes/Post Plan Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("add/update Plan success", async () => {
        sinon.stub(PlanService.prototype, "addUpdatePlan").returns(Promise.resolve(mockdataforproduct))
        const response = await chai.request(app).post(`/api/plan`)
            .set('apiKey', "api")
            .send(mockdataforproduct)
        expect(response).to.have.status(200);
        expect(response.body.results.productCode).to.equal('P924');
        expect(response.body.results).to.be.instanceof(Object);
    });

    it("add/update Plan 500 error", async () => {
        const productCode = "23as"
        sinon.stub(PlanService.prototype, "addUpdatePlan").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).post(`/api/plan`)
            .set('apiKey', "api")
            .send({ productCode })
        expect(response).to.have.status(500);
    });

    it("add/update Plan 400 data missing error", async () => {
        const response = await chai.request(app).post(`/api/plan`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
    });

})

describe("-----Testing PlanRoutes/delete Plan Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("delete Plan success", async () => {
        const productCode = "P924"
        sinon.stub(PlanService.prototype, "deletePlan").returns(Promise.resolve(undefined))
        const response = await chai.request(app).delete(`/api/plan/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
    });

    it("delete Plan by product 500 error", async () => {
        const productCode = "P924"
        sinon.stub(PlanService.prototype, "deletePlan").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).delete(`/api/plan/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})