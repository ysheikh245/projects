const chai = require('chai');
const chaiHttp = require('chai-http');
const sinon = require('sinon');
sinon.restore();
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { Util } from '../../src/server/util/Util';

const { expect } = chai;
chai.use(chaiHttp);

import { Constants } from '../../src/server/util';
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { RateService }  from '../../src/server/service/RateService';
import { GenericModelService } from '../../src/server/service/GenericModelService';
const rateService = new RateService();
const mockedAllRatesData = [
    {
        '_id': '62b4e69a12fcd13b18df2986',
        'productCode': 'P176',
        'version': '2022-06-09 12:33:06.344',
        'effectiveDate': '2021-12-28 00:00:00.000',
        'jsonData': {
            'premiumRateMaster': [
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0018000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '018'
                },
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0019000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '019'
                }
            ]
        }
    },
    {
        '_id': '62b4e69a12fcd13b18df2986',
        'productCode': 'P176',
        'version': '2022-06-09 12:33:06.344',
        'effectiveDate': '2021-12-28 00:00:00.000',
        'jsonData': {
            'premiumRateMaster': [
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0018000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '018'
                },
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0019000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '019'
                }
            ]
        }
    }
];

describe('RateService', function () {

    afterEach(function () {
        sinon.restore();
    });

    it('getAllRates() gives back all rate info', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'getAllModels').returns(Promise.resolve(mockedAllRatesData)); 
        const resulSet = await rateService.getAllRates();
        expect(resulSet.length).to.equal(2);
        expect(resulSet[1].productCode).to.equal('P176');
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE);
    })


    it('getRateById() gives back rate info by id', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'getModelById').returns(Promise.resolve(mockedAllRatesData[1])); 
        const resulSet = await rateService.getRateById('62b4e69a12fcd13b18df2986');
        expect(resulSet.productCode).to.equal('P176');
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE);
    })

    it('getRate() gives back rate info by product code ', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'getModelObject').returns(Promise.resolve(mockedAllRatesData[1])); 
        const resulSet = await rateService.getRate('P176');
        expect(resulSet.productCode).to.equal('P176');
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE);
    })

    it('addUpdateRate() updates rate properly ', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'addUpdateModel').returns(Promise.resolve(mockedAllRatesData[1])); 
        let ratePayload = {
            ...mockedAllRatesData[0],
            createdTimestamp: '2021-10-13 00:00:00.000',
            updatedTimestamp: '2021-10-14 00:00:00.000',
            updatedBy: 'Random, User',
            jsonData: JSON.stringify(mockedAllRatesData[0].jsonData.premiumRateMaster)
        }
        const resulSet = await rateService.addUpdateRate(ratePayload, {});
        expect(resulSet.productCode).to.equal('P176');
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE, 'ratesId', ratePayload.productCode, ratePayload, {});
    });

    it('deleteRate() deletes rate properly ', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'deleteModel').returns(Promise.resolve(mockedAllRatesData[1])); 
        const resulSet = await rateService.deleteRate('P176', {});
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE, 'P176', 'ratesId', {});
    });

    it('updateProductManifestReferenceId() deletes rate properly ', async () => {
        const spy =  sinon.stub(GenericModelService.prototype, 'updateProductManifestReferenceIdCommon').returns(Promise.resolve(mockedAllRatesData[1])); 
        const resulSet = await rateService.updateProductManifestReferenceId('P176', {});
        expect(resulSet.productCode).to.equal('P176');
        sinon.assert.calledWith(spy, DBConstants.TABLE_RATE, 'P176', 'ratesId', {});
    });
})