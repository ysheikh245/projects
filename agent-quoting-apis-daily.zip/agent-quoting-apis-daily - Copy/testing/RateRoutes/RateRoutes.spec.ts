const chai = require('chai');
const chaiHttp = require('chai-http');
const sinon = require('sinon');
sinon.restore();
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';

import { Util } from '../../src/server/util/Util';
import { Constants } from '../../src/server/util';
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});

const { expect } = chai;
chai.use(chaiHttp);

import { RateService }  from '../../src/server/service/RateService';
const mockedAllRatesData = [
    {
        '_id': '62b4e68112fcd13b18df2985',
        'productCode': 'Z00000010(P176)',
        'version': '2022-06-09 12:33:06.903',
        'effectiveDate': '2021-12-28 00:00:00.000',
        'jsonData': {
            'premiumRateMaster': []
        },
        'createdTimestamp': '2022-06-23T18:17:37',
        'updatedTimestamp': '2022-06-23T18:17:37',
        'updatedBy': 'Undefined'
    },
    {
        '_id': '62b4e69a12fcd13b18df2986',
        'productCode': 'P176',
        'version': '2022-06-09 12:33:06.344',
        'effectiveDate': '2021-12-28 00:00:00.000',
        'jsonData': {
            'premiumRateMaster': [
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0018000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '018'
                },
                {
                    'COVERAGE_CODE': 'P17600001',
                    'ARRAY_NUMBER': 1,
                    'STATE': 'CO',
                    'RATING_KEY': '0019000000000000',
                    'DISC_CODE': 6.04,
                    'PERSON_SUMMARY': '0',
                    'AGE': '019'
                }
            ]
        }
    }
];
let app;

describe('GET /rate', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });

        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('gets all rates properly', async () => {
        sinon.stub(RateService.prototype, 'getAllRates').returns(Promise.resolve(mockedAllRatesData));
        const response = await chai.request(app).get('/api/rate');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(2);
        expect(response.body.results[1].productCode).to.equal('P176');
    });

    // it('throws 404 response if details not found', async () => {
    //     sinon.stub(RateService.prototype, 'getAllRates').returns(Promise.resolve(null));
    //     const response = await chai.request(app).get('/api/rate');
    //     expect(response).to.have.status(404);
    //     expect(response.body.results).to.equal(null);
    // });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(RateService.prototype, 'getAllRates').returns(Promise.reject(error));
        const response = await chai.request(app).get('/api/rate');
        expect(response).to.have.status(500);
    });

})

describe('GET /rate/:productCode', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });

        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('gets all rates properly', async () => {
        sinon.stub(RateService.prototype, 'getRate').returns(Promise.resolve(mockedAllRatesData[1]));
        const response = await chai.request(app).get('/api/rate/P176');
        expect(response).to.have.status(200);
        expect(response.body.results[0].productCode).to.equal('P176');
    });

    it('should return empty array when produc data is null', async () => {
        sinon.stub(RateService.prototype, 'getRate').returns(Promise.resolve(null));
        const response = await chai.request(app).get('/api/rate/P176');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
    });

    // it('throws 404 response if details not found', async () => {
    //     sinon.stub(RateService.prototype, 'getRate').returns(Promise.resolve(null));
    //     const response = await chai.request(app).get('/api/rate/P176');
    //     expect(response).to.have.status(404);
    //     expect(response.body.results).to.equal(null);
    // });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(RateService.prototype, 'getRate').returns(Promise.reject(error));
        const response = await chai.request(app).get('/api/rate/P176');
        expect(response).to.have.status(500);
    });
})

describe('GET /rate/id/:id', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });

        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('gets all rates properly', async () => {
        sinon.stub(RateService.prototype, 'getRateById').returns(Promise.resolve(mockedAllRatesData[1]));
        const response = await chai.request(app).get('/api/rate/id/62b4e69a12fcd13b18df2986');
        expect(response).to.have.status(200);
        expect(response.body.results[0]._id).to.equal('62b4e69a12fcd13b18df2986');
    });

    it('should return empty array when product data is null', async () => {
        sinon.stub(RateService.prototype, 'getRateById').returns(Promise.resolve(null));
        const response = await chai.request(app).get('/api/rate/id/62b4e69a12fcd13b18df2986');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
    });

    it('throws 400 response if "Id" not found', async () => {
        sinon.stub(RateService.prototype, 'getRateById').returns(Promise.resolve(null));
        const response = await chai.request(app).get('/api/rate/id/123');
        expect(response).to.have.status(400);
        expect(response.body.message).to.equal(`Invalid object id : '123'`);
    });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(RateService.prototype, 'getRateById').returns(Promise.reject(error));
        const response = await chai.request(app).get('/api/rate/id/62b4e69a12fcd13b18df2986');
        expect(response).to.have.status(500);
    });
})

describe('POST /rate', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });
        sinon.stub(Util, 'filterHeader').returns({});
        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('inserts / updates rates properly', async () => {
        sinon.stub(RateService.prototype, 'addUpdateRate').returns(Promise.resolve(mockedAllRatesData[1]));
        const response = await chai.request(app).post('/api/rate').send(mockedAllRatesData[1]);
        expect(response).to.have.status(200);
        expect(response).to.have.status(200);
        expect(response.body.results.productCode).to.equal('P176');
    });

    it('throws 400 response if details not found in Util', async () => {
        sinon.stub(RateService.prototype, 'addUpdateRate').returns(Promise.resolve(mockedAllRatesData[1]));
        sinon.stub(RateService.prototype, 'validateRequest').returns(false);
        const response = await chai.request(app).post('/api/rate').send(mockedAllRatesData[1]);
        expect(response).to.have.status(400);
        expect(response.body.message).to.equal(Constants.INPUT_REQUIRED);
    });


    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(RateService.prototype, 'addUpdateRate').returns(Promise.reject(error));
        const response = await chai.request(app).post('/api/rate').send(mockedAllRatesData[1]);
        expect(response).to.have.status(500);
    });

})

describe('DELETE /rate/:productCode', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });
        sinon.stub(Util, 'filterHeader').returns({});
        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('deletes rates properly', async () => {
        sinon.stub(RateService.prototype, 'deleteRate').returns(Promise.resolve(mockedAllRatesData[1]));
        const response = await chai.request(app).delete('/api/rate/P176');
        expect(response).to.have.status(200);
        expect(response.body.result.productCode).to.equal('P176');
    });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(RateService.prototype, 'deleteRate').returns(Promise.reject(error));
        const response = await chai.request(app).delete('/api/rate/P176');
        expect(response).to.have.status(500);
    });

})



