const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { CheckUserValidityService, } = require("../../src/server/service/CheckUserValidityService");
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing CheckuserValidity Route-----", function () {
      beforeEach(() => {
            sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
                  next();
            });
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("it should return error if request body is empty", async () => {
            const response = await chai.request(app).post("/api/checkUserValidity")
                  .set('apiKey', "api")
            expect(response).to.have.status(400);
            expect(response.body).to.include("Bad request: id is required and must only contain 0-9, a-z, A-Z");
      });

      it("it should return error if id is not valid", async () => {
            sinon.stub(CheckUserValidityService.prototype, "validateRequest").returns(false)
            const response = await chai.request(app).post("/api/checkUserValidity")
                  .set('apiKey', "api")
                  .send({ "id": "211@" })
            expect(response).to.have.status(400);
            expect(response.body).to.include("Bad request: id is required and must only contain 0-9, a-z, A-Z");
      });

      it("Invalid User", async () => {
            sinon.stub(CheckUserValidityService.prototype, "validateRequest").returns(true)
            sinon.stub(CheckUserValidityService.prototype, "checkUserValidity").returns(Promise.resolve(false));
            const response = await chai.request(app).post("/api/checkUserValidity")
                  .set('apiKey', "ppp")
                  .send({ "id": "22aa" });
            expect(response).to.have.status(200);
            expect(response.body).to.include("INVALID");
      });

      it("Valid user", async () => {
            sinon.stub(CheckUserValidityService.prototype, "validateRequest").callsFake(() => {
                  return true;
            });
            sinon.stub(CheckUserValidityService.prototype, "checkUserValidity")
                  .returns(Promise.resolve(true));
            const response = await chai.request(app).post("/api/checkUserValidity")
                  .set('apiKey', "app")
                  .send({ "id": "0051U000005rtdvQAA" });
            expect(response).to.have.status(200);
            expect(response.body).to.include("VALID");
      });

      it("500 unexpected error", async () => {
            sinon.stub(CheckUserValidityService.prototype, "validateRequest").callsFake(() => {
                  return true;
            });
            sinon.stub(CheckUserValidityService.prototype, "checkUserValidity")
                  .throws(new Error("unexpected error"))
            const response = await chai.request(app).post("/api/checkUserValidity")
                  .set('apiKey', "app")
                  .send({ "id": "0" });
            expect(response).to.have.status(500);

      });
});











