const chai = require("chai");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { CheckUserValidityService, } = require("../../src/server/service/CheckUserValidityService");
import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
import { Constants } from "../../src/server/util";

const { expect } = chai;

const userValidityService = new CheckUserValidityService();

describe("-----Testing checkUserValidity Service-----", function () {

    afterEach(function () {
        sinon.restore();
    });

    it("validate request should return false if userId is empty", () => {
        const result = userValidityService.validateRequest("  ")
        expect(result).to.equal(false);
    })

    it("validate request should return false if userId is not alphanumeric", () => {
        const result = userValidityService.validateRequest("@")
        expect(result).to.equal(false);
    })

    it("validate request should return true if userId is valid", () => {
        const result = userValidityService.validateRequest("66aat6")
        expect(result).to.equal(true);
    })

    it("checkuerValidity should throw error if query result is empty", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                query: () => null
            }
        });
        try {
            await userValidityService.checkUserValidity("key")
        }
        catch (err) {
            expect(err.message).to.equal("No records were returned from user query")
        }
    });

    it("checkuerValidity should throw error if query result totalsize is zero", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                query: () => ({ totalSize: 0 })
            }
        });
        try {
            await userValidityService.checkUserValidity("key")
        }
        catch (err) {
            expect(err.message).to.equal("No records were returned from user query")
        }
    });

    it("checkuservalidity successful after initial connection failed", async () => {
        const stub = sinon.stub(SalesForceConnectionService, "getSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY).throws(new Error("error during first call"))
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY, true).returns({
            query: () => {
                return {
                    records: [{ IsActive: true }],
                    totalSize: 1
                }
            },
        })
        const result = await userValidityService.checkUserValidity("key")
        expect(result).to.equal(true);
    });

    it("checkuservalidity second attempt failed", async () => {
        const stub = sinon.stub(SalesForceConnectionService, "getSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY).throws(new Error("error during first call"))
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY, true).throws(new Error("error during second call"))
        expect(async () => await userValidityService.checkUserValidity("key").to.throw)
    });


    it("checkuservalidity successful", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                query: () => {
                    return {
                        records: [{ IsActive: true }],
                        totalSize: 1
                    }
                },
            }
        });

        const result = await userValidityService.checkUserValidity("key")
        expect(result).to.equal(true);
    });

    it("checkuservalidity unexpected error", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                query: () => ({})
            }
        });
        try {
            await userValidityService.checkUserValidity("123456789")
        }
        catch (err) {
            expect(err.message).to.equal("An unknown error occurred!")
        }
    });
});







