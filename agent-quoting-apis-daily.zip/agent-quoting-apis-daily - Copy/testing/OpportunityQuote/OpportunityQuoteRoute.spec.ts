const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { SalesforceService } = require("../../src/server/service/SalesforceService");
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing opportunity Quote Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("it should return error if request oppurtunityId is not available", async () => {
        const response = await chai.request(app).post("/api/opportunity/quote")
            .set('apiKey', "api")

        expect(response).to.have.status(400);
        expect(response.text).to.include("The opportunityId parameter was null or empty");
    });


    it("oppurtunity quote is successful", async () => {
        sinon.stub(SalesforceService.prototype, "addOpportunityQuote").returns(Promise.resolve(null));
        const response = await chai.request(app).post("/api/opportunity/quote")
            .set('apiKey', "ppp")
            .send({ "opportunityId": "22aa" });
        expect(response).to.have.status(200);
        expect(response.text).to.include("Successfully updated opportunity.");

    });

    it("/opportunity/quote 404 response", async () => {
        sinon.stub(SalesforceService.prototype, "addOpportunityQuote").returns(Promise.resolve({}));
        const response = await chai.request(app).post("/api/opportunity/quote")
            .set('apiKey', "ppp")
            .send({ "opportunityId": "22aa" });
        expect(response).to.have.status(404);
    });

    it("/opportunity/quote Internal server error", async () => {
        sinon.stub(SalesforceService.prototype, "addOpportunityQuote")
            .throws(new Error("unexpected error"))

        const response = await chai.request(app).post("/api/opportunity/quote")
            .set('apiKey', "app")
            .send({ "opportunityId": "22aa" });
        expect(response).to.have.status(500);
        expect(response.text).to.include("Internal Server error");

    });
});



