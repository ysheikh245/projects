const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { SalesforceService, } = require("../../src/server/service/SalesforceService");
import axios from "axios";
import { SalesForceConnectionService } from "../../src/server/salesforce/SalesForceConnectionService";
import { Constants } from "../../src/server/util";

const { expect } = chai;
chai.use(chaiHttp);

const salesforceService = new SalesforceService();

describe("-----Testing addOpportunityQuote Service-----", function () {

    afterEach(function () {
        sinon.restore();
    });

    it("addOpportunityQuote unexpected error", async () => {
        const stub = sinon.stub(SalesForceConnectionService, "getSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY).throws(new Error("unexpected error"))
        try {
            await salesforceService.addOpportunityQuote({})
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
    });

    it("addOpportunityQuote successful", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                update: () => ({ success: true })
            }
        });
      const result=  await salesforceService.addOpportunityQuote({ opportunityId: "22" })
      expect(result).to.equal(null);
    });

    it("addOpportunityQuote successful after initial timeout error", async () => {
        const stub = sinon.stub(SalesForceConnectionService, "getSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY).throws(new Error("ETIMEDOUT"))
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY, true).returns({
            update: () => ({ success: true })
        })
        const result=  await salesforceService.addOpportunityQuote({ opportunityId: "22" })
        expect(result).to.equal(null);
    });

    it("addOpportunityQuote second attempt failed", async () => {
        const stub = sinon.stub(SalesForceConnectionService, "getSalesForceConnection")
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY).throws(new Error("error during first attempt"))
        stub.withArgs(Constants.SALESFORCE_BATCH_CONFIG_KEY, true).throws(new Error("error during second attempt"))
        expect(async () => await salesforceService.addOpportunityQuote({ opportunityId: "22" }).to.throw)
    });

    it("addOpportunityQuote update is not successful", async () => {
        sinon.stub(SalesForceConnectionService, "getSalesForceConnection").callsFake(() => {
            return {
                update: () => ({errors: ["update unssuccessful"]})
            }
        });
        try {
            await salesforceService.addOpportunityQuote({ opportunityId: "22" })
        }
        catch (err) {
           expect(err).to.equal("update unssuccessful")
        }
    });

});

