const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) })
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
let genericModelService ;

describe("-----Testing GenericModel Service-----", function () {
    afterEach(()=>{
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/GenericModelService")]
        const { GenericModelService } = require("../../src/server/service/GenericModelService");
        genericModelService = new GenericModelService()   
      
    })

    it("add model with v2 db", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");

        const getModelObjectStub =  sinon.stub(GenericModelService.prototype, "getModelObject")
       
        sinon.stub(dbServiceV2, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getModelObjectStub.onFirstCall().returns(null);
        getModelObjectStub.onSecondCall().returns({
            productCode:"name12"
        })
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({
            productCode:"name12"
        })
       
        const result = await genericModelService.addUpdateModel("","","name12",{}, { 
             "end-user-id":"us12"
        })
        expect(result.productCode).to.equal("name12")
    })
})

describe("-----Testing GenericModel Service-----", function () {
    afterEach(()=>{
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/GenericModelService")]
        const { GenericModelService } = require("../../src/server/service/GenericModelService");
        genericModelService = new GenericModelService()   
      
    })

    it("add model", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");

        const getModelObjectStub =  sinon.stub(GenericModelService.prototype, "getModelObject")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getModelObjectStub.onFirstCall().returns(null);
        getModelObjectStub.onSecondCall().returns({
            productCode:"name12"
        })
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({
            productCode:"name12"
        })
       
        const result = await genericModelService.addUpdateModel("","","name12",{}, { 
             "end-user-id":"us12"
        })
        expect(result.productCode).to.equal("name12")
    })

    it("add model with userheader details empty", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");

        const getModelObjectStub =  sinon.stub(GenericModelService.prototype, "getModelObject")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getModelObjectStub.onFirstCall().returns(null);
        getModelObjectStub.onSecondCall().returns({
            productCode:"name12"
        })
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({
            productCode:"name12"
        })
       
        const result = await genericModelService.addUpdateModel("","","name12",{}, {})
        expect(result.productCode).to.equal("name12")
    })


    it("update model", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");

        const getModelObjectStub =  sinon.stub(GenericModelService.prototype, "getModelObject")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getModelObjectStub.onFirstCall().returns({
            productCode:"name12"
        });
        getModelObjectStub.onSecondCall().returns({
            id:"2As1",
            productCode:"nam12"
        })
       
        const result = await genericModelService.addUpdateModel("","","",{productCode:"nam12"}, {
            "end-user-id":"us12"
        })
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("nam12")
    })

    it("update model with userheader details empty", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");

        const getModelObjectStub =  sinon.stub(GenericModelService.prototype, "getModelObject")
       
        sinon.stub(DbService.prototype, "getCollection").returns({
            insertOne: () => { },
            updateOne: () => { }
        })
        getModelObjectStub.onFirstCall().returns({
            productCode:"name12"
        });
        getModelObjectStub.onSecondCall().returns({
            id:"2As1",
            productCode:"nam12"
        })
       
        const result = await genericModelService.addUpdateModel("","","",{productCode:"nam12"}, {})
        expect(result.id).to.equal("2As1")
        expect(result.productCode).to.equal("nam12")
    })

    it("error while add/update model", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await genericModelService.addUpdateModel("","","",{}, {})
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })

    it("get model", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: () => ({
                productCode: "nam123"
            }),
        })
        const result = await genericModelService.getModelObject("","nam123")
        expect(result.productCode).to.equal("nam123")
    })

    it("get model by Id", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            findOne: () => ({
                id: "507f1f77bcf86cd799439011",
                productCode:"nam123"
            }),
        })
        const result = await genericModelService.getModelById("","507f1f77bcf86cd799439011")
        expect(result.productCode).to.equal("nam123")
    })

    it("error while get model by Id", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await genericModelService.getModelById("","")
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })


    it("get all models", async () => {
        sinon.stub(DbService.prototype, "getCollection").returns({
            find: () =>(sinon.mongo.documentArray([{
                productCode: "nam123"
            }])),
               })
        const result = await genericModelService.getAllModels("")
        expect(result.length).to.equal(1)
    })

    it("error while get all models", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await genericModelService.getAllModels("")
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })


    it("delete model", async ()=>{
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({})
        sinon.stub(ProductManifestService.prototype,"addUpdateProductManifest")
        sinon.stub(DbService.prototype, "getCollection").returns({
            deleteOne: () => {},
            findOne: () => ({
                productCode: "nam123"
            })
        })
        sinon.stub(dbServiceV2, "getCollection").returns({
            deleteOne: () => {},
            findOne: () => ({
                productCode: "nam123"
            })
        })
        const result = await genericModelService.deleteModel("","61d634706a98a61edd42bf45")
        expect(result).to.equal(true)
   
    })

    it("error while delete model", async () => {
        sinon.stub(DbService.prototype, "getCollection").throws("unexpected error")
        try {
            await genericModelService.deleteModel("","")
        }
        catch (err) {
            expect(err.message).to.include("unexpected error")
        }
    })


    it("updateProductManifestReferenceIdCommon", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");
         sinon.stub(GenericModelService.prototype, "getModelObject").returns({
            _id:"23"
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns({
            _id:"23"
        })
        sinon.stub(ProductManifestService.prototype,"addUpdateProductManifest").returns({
            productCode:""
        })
       
        const result = await genericModelService.updateProductManifestReferenceIdCommon("","","")
        expect(result._id).to.equal("23")
    })

    it("updateProductManifestReferenceIdCommon product manifest data empty", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");
         sinon.stub(GenericModelService.prototype, "getModelObject").returns({
            _id:"23"
        })
        const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
        sinon.stub(ProductManifestService.prototype,"getProductManifest").returns(null)
       try{
        const result = await genericModelService.updateProductManifestReferenceIdCommon("","","")
       }
       catch(err){
        expect(err.message).to.equal("No Product Manifest Defined")
       }
    })

    it("error while updateProductManifestReferenceIdCommon", async () => {
        const { GenericModelService } = require("../../src/server/service/GenericModelService");
        sinon.stub(GenericModelService.prototype, "getModelObject").returns({
           _id:"23"
       })
       const { ProductManifestService } = require("../../src/server/service/ProductManifestService");
       sinon.stub(ProductManifestService.prototype,"getProductManifest").throws("unexpected error")
    try {
            await genericModelService.updateProductManifestReferenceIdCommon("","","")
        }
        catch (err) {
            expect(err.stack).to.include("unexpected error")
        }
    })

})