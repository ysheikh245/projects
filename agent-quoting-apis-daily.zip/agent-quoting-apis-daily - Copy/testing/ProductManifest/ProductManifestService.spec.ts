const chai = require('chai');
const sinon = require('sinon');
sinon.restore();
import { Constants } from '../../src/server/util';
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';
// import dbServiceV2 from '../../src/server/db/DbServiceV2';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});

const { expect } = chai;
import { Util } from '../../src/server/util/Util';
import { ProductManifestService } from '../../src/server/service/ProductManifestService';
let productManifestService: ProductManifestService;

const mockedProductManifestAll = [
    {
        '_id': '62c7247d665c3a0013ea1c79',
        'productCode': 'C250',
        'aedId': '62c768ac31b02d0014ccb8ea',
        'cashValueId': '62c768c031b02d0014ccb8ed',
        'nonforfeitureRPUId': '62c768cd31b02d0014ccb8ef',
        'nonforfeitureETIId': '62c768c731b02d0014ccb8ee',
        'planId': '62c768ba31b02d0014ccb8ec',
        'ratesId': '62c768b331b02d0014ccb8eb',
        'medSuppData': null,
        'createdTimestamp': '2022-07-07T13:22:53',
        'updatedTimestamp': '2022-07-07T18:14:21',
        'updatedBy': 'drn'
    },
    {
        '_id': '62c7583831b02d0014ccb8e3',
        'productCode': 'L030',
        'aedId': '62c767d431b02d0014ccb8e4',
        'cashValueId': '62c7684431b02d0014ccb8e7',
        'nonforfeitureRPUId': '62c7685231b02d0014ccb8e9',
        'nonforfeitureETIId': '62c7684b31b02d0014ccb8e8',
        'planId': '62c7683b31b02d0014ccb8e6',
        'ratesId': '62c7683231b02d0014ccb8e5',
        'medSuppData': null,
        'createdTimestamp': '2022-07-07T17:03:36',
        'updatedTimestamp': '2022-07-07T18:12:18',
        'updatedBy': 'drn'
    }
]

describe('productManifestService', function () {
    beforeEach(() => {
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
        ProductManifestService['isInitilized'] = false;
        productManifestService = new ProductManifestService();
    })
    afterEach(function () {
        sinon.restore();
    });


    it('getAllProductManifests() should return proper results', async () => {
        const findStub = sinon.stub();
        findStub.onFirstCall().returns({
            toArray: () => mockedProductManifestAll
        });

        sinon.stub(DbService.prototype, 'getCollection').returns({
            find: findStub
        })
        
        const resultSet = await productManifestService.getAllProductManifests();
        expect(resultSet.length).to.equal(2);
        expect(resultSet[0].productCode).to.equal('C250');
    });

    it('getAllProductManifests() catches DB error', async () => {
        try {
            const error = new Error('DB error occured');
            sinon.stub(DbService.prototype, 'getCollection').throws(error);
            const resultSet = await productManifestService.getAllProductManifests();
        } catch (e) {
            expect(e.message).to.equal('Error: DB error occured')
        }
    });


    it('getProductManifest() should return proper results', async () => {
        const mockCollection = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        sinon.stub(DbService.prototype, 'getCollection').returns(mockCollection);
        const resultSet = await productManifestService.getProductManifest('C250');
        expect(resultSet).not.to.equal(undefined);
        expect(resultSet.productCode).to.equal('C250');
    });

    it('getProductManifest() catches DB error', async () => {
        try {
            const error = new Error('DB error occured');
            sinon.stub(DbService.prototype, 'getCollection').throws(error);
            const resultSet = await productManifestService.getProductManifest('C250');
        } catch (e) {
            expect(e.message).to.equal('Error: DB error occured')
        }
    });

    it('deleteProductManifest() should delete the entry in db', async () => {
        const mockCollection = sinon.mongo.collection({
            deleteOne: sinon.stub().onCall(0).callsFake()
        });
        const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection').returns(mockCollection);
        const resultSet = await productManifestService.deleteProductManifest('C250');
        sinon.assert.calledWith(dbServiceStub, 'productManifest');
        sinon.assert.calledOnce(mockCollection.deleteOne);
        sinon.assert.calledWith(mockCollection.deleteOne, { productCode: 'C250' });
        expect(resultSet).to.equal(true);
    });

    it('deleteProductManifest() catches DB error', async () => {
        try {
            const error = new Error('DB error occured');
            sinon.stub(DbService.prototype, 'getCollection').throws(error);
            const resultSet = await productManifestService.deleteProductManifest('C250');
        } catch (e) {
            expect(e.message).to.equal('Error: DB error occured')
        }
    });

    it('addUpdateProductManifest() adds new product manifest without end user id header', async () => {
        const mockPayload = {
            ...mockedProductManifestAll[0]
        }
        const mockCollectionFind = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(null)
        });
        const mockCollectionInsert = sinon.mongo.collection({
            insertOne: sinon.stub().onCall(0).callsFake()
        });
        const mockCollectionFinal = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection');
        dbServiceStub.onCall(0).returns(mockCollectionFind);
        dbServiceStub.onCall(1).returns(mockCollectionInsert);
        dbServiceStub.onCall(2).returns(mockCollectionFinal);
        const resultSet = await productManifestService.addUpdateProductManifest(mockPayload, {});
        sinon.assert.calledWith(dbServiceStub, 'productManifest');
        sinon.assert.calledOnce(mockCollectionInsert.insertOne);
        sinon.assert.calledWith(mockCollectionFinal.findOne, { productCode: 'C250' });
        expect(resultSet.productCode).to.equal(mockedProductManifestAll[0].productCode);
    });

    it('addUpdateProductManifest() adds new product manifest with end user id header', async () => {
        const mockPayload = {
            ...mockedProductManifestAll[0]
        }
        const mockCollectionFind = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(null)
        });
        const mockCollectionInsert = sinon.mongo.collection({
            insertOne: sinon.stub().onCall(0).callsFake()
        });
        const mockCollectionFinal = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection');
        dbServiceStub.onCall(0).returns(mockCollectionFind);
        dbServiceStub.onCall(1).returns(mockCollectionInsert);
        dbServiceStub.onCall(2).returns(mockCollectionFinal);
        const resultSet = await productManifestService.addUpdateProductManifest(mockPayload, {'end-user-id': 'mockUserId'});
        sinon.assert.calledWith(dbServiceStub, 'productManifest');
        sinon.assert.calledOnce(mockCollectionInsert.insertOne);
        sinon.assert.calledWith(mockCollectionFinal.findOne, { productCode: 'C250' });
        expect(resultSet.productCode).to.equal(mockedProductManifestAll[0].productCode);
    });

    it('addUpdateProductManifest() updates new product manifest without end user id header', async () => {
        const mockPayload = {
            ...mockedProductManifestAll[0]
        }
        const mockCollectionFind = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const mockCollectionUpdate = sinon.mongo.collection({
            updateOne: sinon.stub().onCall(0).callsFake()
        });
        const mockCollectionFinal = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection');
        dbServiceStub.onCall(0).returns(mockCollectionFind);
        dbServiceStub.onCall(1).returns(mockCollectionUpdate);
        dbServiceStub.onCall(2).returns(mockCollectionFinal);
        const resultSet = await productManifestService.addUpdateProductManifest(mockPayload, {});
        sinon.assert.calledWith(dbServiceStub, 'productManifest');
        sinon.assert.calledOnce(mockCollectionUpdate.updateOne);
        sinon.assert.calledWith(mockCollectionFinal.findOne, { productCode: 'C250' });
        expect(resultSet.productCode).to.equal(mockedProductManifestAll[0].productCode);
    });

    it('addUpdateProductManifest() updates new product manifest with end user id header', async () => {
        const mockPayload = {
            ...mockedProductManifestAll[0]
        }
        const mockCollectionFind = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const mockCollectionUpdate = sinon.mongo.collection({
            updateOne: sinon.stub().onCall(0).callsFake()
        });
        const mockCollectionFinal = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection');
        dbServiceStub.onCall(0).returns(mockCollectionFind);
        dbServiceStub.onCall(1).returns(mockCollectionUpdate);
        dbServiceStub.onCall(2).returns(mockCollectionFinal);
        const resultSet = await productManifestService.addUpdateProductManifest(mockPayload, {'end-user-id': 'mockUserId'});
        sinon.assert.calledWith(dbServiceStub, 'productManifest');
        sinon.assert.calledOnce(mockCollectionUpdate.updateOne);
        sinon.assert.calledWith(mockCollectionFinal.findOne, { productCode: 'C250' });
        expect(resultSet.productCode).to.equal(mockedProductManifestAll[0].productCode);
    })

    it('addUpdateProductManifest() do not update or add on error', async () => {
        try {
            const error = new Error('DB error occured');
            const mockPayload = {
                ...mockedProductManifestAll[0]
            }
            const mockCollectionFind = sinon.mongo.collection({
                findOne: sinon.stub().onCall(0).returns(null)
            });
            const mockCollectionInsert = sinon.mongo.collection({
                insertOne: sinon.stub().onCall(0).callsFake()
            });
            const mockCollectionFinal = sinon.mongo.collection({
                findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
            });
            const dbServiceStub = sinon.stub(DbService.prototype, 'getCollection');
            dbServiceStub.onCall(0).returns(mockCollectionFind);
            dbServiceStub.onCall(1).throws(error);
            dbServiceStub.onCall(2).returns(mockCollectionFinal);
            const resultSet = await productManifestService.addUpdateProductManifest(mockPayload, {'end-user-id': 'mockUserId'});
        } catch(e) {
            expect(e.message).to.equal('Error: DB error occured')
        }
    });

    it('getProductManifestByReferenceObjectId() should return proper results', async () => {
        const mockCollection = sinon.mongo.collection({
            findOne: sinon.stub().onCall(0).returns(mockedProductManifestAll[0])
        });
        sinon.stub(DbService.prototype, 'getCollection').returns(mockCollection);
        const resultSet = await productManifestService.getProductManifestByReferenceObjectId('C250', '61d634706a98a61edd42bf45');
        expect(resultSet).not.to.equal(undefined);
        expect(resultSet.productCode).to.equal('C250');
    });

    it('getProductManifestByReferenceObjectId() catches DB error', async () => {
        try {
            const error = new Error('DB error occured');
            sinon.stub(DbService.prototype, 'getCollection').throws(error);
            const resultSet = await productManifestService.getProductManifestByReferenceObjectId('C250', 'C250');
        } catch (e) {
            expect(e.message).to.equal('Error: DB error occured')
        }
    });

})

describe('productManifestService constructor test DB V2', () => {

    beforeEach(() => {
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
    })

    afterEach(function () {
        sinon.restore();
    });

    it('getAllProductManifests() should return proper results for V2', async () => {
        const findStub = sinon.stub();
        findStub.onFirstCall().returns({
            toArray: () => mockedProductManifestAll
        });

        sinon.stub(dbServiceV2, 'getCollection').returns({
            find: findStub
        })

        ProductManifestService['isInitilized'] = false;
        productManifestService = new ProductManifestService();
        
        const resultSet = await productManifestService.getAllProductManifests();
        expect(resultSet.length).to.equal(2);
        expect(resultSet[0].productCode).to.equal('C250');
    });

})
