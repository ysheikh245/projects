const chai = require('chai');
const chaiHttp = require('chai-http');
const sinon = require('sinon');
sinon.restore();
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);

import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import { ProductManifestService } from '../../src/server/service/ProductManifestService';
let app;
const mockedProductManifestAll = [
    {
        '_id': '62c7247d665c3a0013ea1c79',
        'productCode': 'C250',
        'aedId': '62c768ac31b02d0014ccb8ea',
        'cashValueId': '62c768c031b02d0014ccb8ed',
        'nonforfeitureRPUId': '62c768cd31b02d0014ccb8ef',
        'nonforfeitureETIId': '62c768c731b02d0014ccb8ee',
        'planId': '62c768ba31b02d0014ccb8ec',
        'ratesId': '62c768b331b02d0014ccb8eb',
        'medSuppData': null,
        'createdTimestamp': '2022-07-07T13:22:53',
        'updatedTimestamp': '2022-07-07T18:14:21',
        'updatedBy': 'drn'
    },
    {
        '_id': '62c7583831b02d0014ccb8e3',
        'productCode': 'L030',
        'aedId': '62c767d431b02d0014ccb8e4',
        'cashValueId': '62c7684431b02d0014ccb8e7',
        'nonforfeitureRPUId': '62c7685231b02d0014ccb8e9',
        'nonforfeitureETIId': '62c7684b31b02d0014ccb8e8',
        'planId': '62c7683b31b02d0014ccb8e6',
        'ratesId': '62c7683231b02d0014ccb8e5',
        'medSuppData': null,
        'createdTimestamp': '2022-07-07T17:03:36',
        'updatedTimestamp': '2022-07-07T18:12:18',
        'updatedBy': 'drn'
    }
]
describe('GET /productmanifest', function () {
    beforeEach(() => {
        sinon.stub(auth, 'performAPIKeyValidation').callsFake((request, response, next) => {
            next();
        });
        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('gets valid product manifest', async () => {
        const mockedResponse = mockedProductManifestAll;
        sinon.stub(ProductManifestService.prototype, 'getAllProductManifests').returns(Promise.resolve(mockedResponse));
        const response = await chai.request(app).get('/api/productmanifest');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(2);
        expect(response.body.results[0].productCode).to.equal('C250');
    });

    // it('throws 404 response if product manifest not found', async () => {
    //     sinon.stub(ProductManifestService.prototype, 'getAllProductManifests').returns(Promise.resolve(null));
    //     const response = await chai.request(app).get('/api/productmanifest');
    //     expect(response).to.have.status(404);
    //     expect(response.body.results).to.equal(null);
    // });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(ProductManifestService.prototype, 'getAllProductManifests').returns(Promise.reject(error));
        const response = await chai.request(app).get('/api/productmanifest');
        expect(response).to.have.status(500);
    });
})


describe('GET /productmanifest/:productCode', function () {
    beforeEach(() => {
        app = require('../../src/server/index.ts');
    })
    afterEach(function () {
        sinon.restore();
    });

    it('gets valid product manifest by id', async () => {
        const mockedResponse = mockedProductManifestAll[0];
        sinon.stub(ProductManifestService.prototype, 'getProductManifest').returns(Promise.resolve(mockedResponse));
        const response = await chai.request(app).get('/api/productmanifest/C250');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal('C250');
    });

    // it('throws 404 response if product manifest not found', async () => {
    //     sinon.stub(ProductManifestService.prototype, 'getProductManifest').returns(Promise.resolve(null));
    //     const response = await chai.request(app).get('/api/productmanifest/C250');
    //     expect(response).to.have.status(404);
    //     expect(response.body.results).to.equal(null);
    // });

    it('throws 500 response on API error', async () => {
        const error = new Error('API error occured');
        sinon.stub(ProductManifestService.prototype, 'getProductManifest').returns(Promise.reject(error));
        const response = await chai.request(app).get('/api/productmanifest/C250');
        expect(response).to.have.status(500);
    });

    it('should return empty array when produc data is null', async () => {
        const mockedResponse = mockedProductManifestAll[0];
        sinon.stub(ProductManifestService.prototype, 'getProductManifest').returns(Promise.resolve(null));
        const response = await chai.request(app).get('/api/productmanifest/C250');
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
    });

})
export { };