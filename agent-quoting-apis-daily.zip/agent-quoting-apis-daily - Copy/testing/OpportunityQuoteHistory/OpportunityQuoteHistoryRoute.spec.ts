const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { SalesforceService } = require("../../src/server/service/SalesforceService");
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("-----Testing opportunite QuoteHistory Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("it should return error if request quote is not available", async () => {
        const response = await chai.request(app).post("/api/opportunity/quote/history")
            .set('apiKey', "api")

        expect(response).to.have.status(400);
        expect(response.text).to.include("body is required");
    });


    it("oppurtunity quote history is successful", async () => {
        sinon.stub(SalesforceService.prototype, "addOpportunityQuoteHistory").returns(Promise.resolve(null));
        const response = await chai.request(app).post("/api/opportunity/quote/history")
            .set('apiKey', "ppp")
            .send({ "quote": "22aa" });
        expect(response).to.have.status(200);
        expect(response.text).to.include("Successfully added quote history.");

    });

    it("/opportunity/quote/history unexpected error", async () => {
        sinon.stub(SalesforceService.prototype, "addOpportunityQuoteHistory")
            .throws(new TypeError("unexpected error"))

        const response = await chai.request(app).post("/api/opportunity/quote/history")
            .set('apiKey', "app")
            .send({"quote": "22aa" });
           
        expect(response).to.have.status(500);
    });
});
