const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import axios from "axios";
const { expect } = chai;

describe("-----Testing opportunite QuoteHistory Service-----", function () {
    
    beforeEach(()=>{
        delete require.cache[require.resolve("../../src/server/service/SalesforceService")]
    })

    afterEach(function () {
        sinon.restore();
    });

    it("addOpportunityQuoteHistory success",async function (){
        sinon.stub(axios, "create").callsFake((obj)=>{
            return {
              ...obj,
              post:()=>{}
            }
        })
       
        const { SalesforceService } = require("../../src/server/service/SalesforceService");
        const salesforce = new SalesforceService();
         await salesforce.addOpportunityQuoteHistory({ opportunityId: "22" })
    
    })

    it("addOpportunityQuoteHistory error",async function (){
        sinon.stub(axios, "create").callsFake((obj)=>{
            return {
              ...obj,
              post:()=>{throw new Error("custom error")}
            }
        })
       
        const { SalesforceService } = require("../../src/server/service/SalesforceService");
        const salesforce = new SalesforceService();
        try {
            await salesforce.addOpportunityQuoteHistory({ opportunityId: "22" })
        }
        catch (err) {
          expect(err.message).to.include("custom error")
        }
    })
})





