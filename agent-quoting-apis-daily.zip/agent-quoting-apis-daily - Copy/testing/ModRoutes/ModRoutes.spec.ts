const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { ModService } = require("../../src/server/service/ModService");
const { expect } = chai;
chai.use(chaiHttp);

const modService = new ModService();

let app;
describe("Mod Routes", function () {
      beforeEach(() => {
            sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
                  next();
            });
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("POST - it should return 200 status if addUpdateMod return success", async () => {
            const payload = {
                  "version": "2021-11-04 09:25:11.181",
                  "effectiveDate": "2021-10-12 00:00:00.000",
                  "jsonData": {
                     
                  } 
            }
            sinon.stub(ModService.prototype,"addUpdateMod").returns(Promise.resolve(true));
            const response = await chai.request(app).post("/api/mod").set('apiKey', "api").send(payload)
            expect(response).to.have.status(200);
      });

      it("POST - it should return 200 status if addUpdateMod return success without data", async () => {
            const payload = {
                  "version": "2021-11-04 09:25:11.181",
                  "effectiveDate": "2021-10-12 00:00:00.000",
                  "jsonData": {
                     
                  } 
            }
            sinon.stub(ModService.prototype,"addUpdateMod").returns(Promise.resolve(null));
            const response = await chai.request(app).post("/api/mod").set('apiKey', "api").send(payload)
            expect(response).to.have.status(200);
      });
      it("POST - it should return 500 status if addUpdateMod return error", async () => {
            const payload = {
                  "version": "2021-11-04 09:25:11.181",
                  "effectiveDate": "2021-10-12 00:00:00.000",
                  "jsonData": {
                     
                  } 
            }
            sinon.stub(ModService.prototype,"addUpdateMod").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).post("/api/mod").set('apiKey', "api").send(payload)
            expect(response).to.have.status(500);
      });

      it("POST - it should return 400 status if body is empty", async () => {
            sinon.stub(ModService.prototype,"addUpdateMod").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).post("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(400);
      });

      it("DELETE - it should return 500 status if deleteMod return error", async () => {
            sinon.stub(ModService.prototype,"deleteMod").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      it("DELETE - it should return 200 status if deleteMod return success", async () => {
            sinon.stub(ModService.prototype,"deleteMod").returns(Promise.resolve(true));
            const response = await chai.request(app).delete("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("DELETE - it should return 500 status if deleteMod return error", async () => {
            sinon.stub(ModService.prototype,"deleteMod").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/mod/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      it("DELETE - it should return 400 status if mod id is invalid", async () => {
            sinon.stub(ModService.prototype,"deleteMod").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).delete("/api/mod/123").set('apiKey', "api")
            expect(response).to.have.status(400);
      });

      it("DELETE - it should return 200 status if deleteMod return success", async () => {
            sinon.stub(ModService.prototype,"deleteMod").returns(Promise.resolve(true));

            const response = await chai.request(app).delete("/api/mod/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getAllMods return success", async () => {
            sinon.stub(ModService.prototype,"getAllMods").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(200);
      });

      it("GET - it should return 200 status if getAllMods return success without data", async () => {
            sinon.stub(ModService.prototype,"getAllMods").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET - it should return 500 status if getAllMods return error", async () => {
            sinon.stub(ModService.prototype,"getAllMods").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/mod").set('apiKey', "api")
            expect(response).to.have.status(500);
      });

      it("GET BY ID - it should return 200 status if getModById return success", async () => {
            sinon.stub(ModService.prototype,"getModById").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/mod/id/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET BY ID - it should return 400 status if id is not valid", async () => {
            sinon.stub(ModService.prototype,"getModById").returns(Promise.resolve(true));
            const response = await chai.request(app).get("/api/mod/id/123").set('apiKey', "api")
            expect(response).to.have.status(400);
      });

      it("GET BY ID- it should return 200 status if getModById return success without data", async () => {
            sinon.stub(ModService.prototype,"getModById").returns(Promise.resolve(null));
            const response = await chai.request(app).get("/api/mod/id/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(200);
      });
      it("GET BY ID- it should return 500 status if getModById return error", async () => {
            sinon.stub(ModService.prototype,"getModById").returns(Promise.reject('Test Error'));
            const response = await chai.request(app).get("/api/mod/id/62fd2c3d3b34e000997fedc3").set('apiKey', "api")
            expect(response).to.have.status(500);
      });

});












