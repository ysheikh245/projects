const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
require('sinon-mongo')
import { MongoClient } from "mongodb";
import { DbService } from "../../src/server/db/DbService";
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
let commonManifestService ;
let modService;

import { Constants } from '../../src/server/util';
import { DBConstants } from '../../src/server/db/DbConstants';

const modData = {
    _id: '62a2365828e1500189339333',
    createdTimestamp: '2021-12-28 00:00:00.000',
    updatedTimestamp: '2021-12-28 00:00:00.000',
    updatedBy: 'Random, User'
}

describe("ModService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V2'});
        delete require.cache[require.resolve("../../src/server/service/CommonManifestService")]
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/ModService")]
        const { ModService } = require("../../src/server/service/ModService");
        modService = new ModService() 
    })

    it("get mod with v2 db", async() => {

        sinon.stub(dbServiceV2,"getCollection").returns({
            findOne: () => ({
                modName:"test"
            }),
        })
       const result =  await modService.getMod();
       expect(result.modName).to.equal('test');
       
    })
})

describe("ModService", function () {

    afterEach(function () {
        sinon.restore();
    });
    beforeEach(()=>{
        sinon.restore();
        sinon.stub(DbService, "withDbService").callsFake((f) => { return f(dbService) });
        sinon.stub(Util.config, 'dbServiceConfig').value({version: 'V1'});
        delete require.cache[require.resolve("../../src/server/service/CommonManifestService")]
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
         
        
        delete require.cache[require.resolve("../../src/server/service/ModService")]
        const { ModService } = require("../../src/server/service/ModService");
        modService = new ModService() 
    })

    it("get mod", async() => {

        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                modName:"test"
            }),
        })
       const result =  await modService.getMod();
       expect(result.modName).to.equal('test');
       
    })

    it("get mod by Id", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            findOne: () => ({
                modName:"test"
            }),
        })
       const result =  await modService.getModById('62fd2c3d3b34e000997fedc3');
       expect(result.modName).to.equal('test');
       
    })

    it("get mod by Id - Error", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws("unexpected error")
        try {
            await modService.getModById('62fd2c3d3b34e000997fedc3');
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
       
    })

    it("get all mods", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            find: () => ({
                toArray:() => ([{name: 'test'}]),
            }),
        })
        const result = await modService.getAllMods();
        expect(result.length).to.equal(1);
       
    })

    it("get all mods  - Error", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws("unexpected error")
        try {
            await modService.getAllMods();
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
       
    })

    it("delete mod", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
        })

        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        
        sinon.stub(CommonManifestService.prototype,"getCommonManifest").returns({modId: ''});
        sinon.stub(CommonManifestService.prototype,"addUpdateCommonManifest").returns(true)
        
        const result = await modService.deleteMod({}, '62fd2c3d3b34e000997fedc3');
        expect(result).to.equal(true);
   
    })

    it("delete mod - if getCommonManifest return null ", async() => {
        sinon.stub(DbService.prototype,"getCollection").returns({
            deleteOne: () => (true),
        })
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        sinon.stub(CommonManifestService.prototype,"getCommonManifest").returns(null);
        sinon.stub(CommonManifestService.prototype,"addUpdateCommonManifest").returns(true)
        
        const result = await modService.deleteMod({}, '62fd2c3d3b34e000997fedc3');
        expect(result).to.equal(true);
   
    })

    it("delete mod  - Error", async() => {
        sinon.stub(DbService.prototype,"getCollection").throws("unexpected error")
        try {
            await modService.deleteMod({}, '62fd2c3d3b34e000997fedc3');
        }
        catch (err) {
            expect(err.message).to.equal("unexpected error")
        }
       
    })

    it("updateCommonManifestReferenceId", async() => {
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        
        const { ModService } = require("../../src/server/service/ModService");
        sinon.stub(ModService.prototype, 'getMod').returns({_id: 'testId'})
        sinon.stub(CommonManifestService.prototype,"getCommonManifest").returns({modId: ''});
        sinon.stub(CommonManifestService.prototype,"addUpdateCommonManifest").returns(true)
        const result = await modService.updateCommonManifestReferenceId({});
        expect(result._id).to.equal('testId')
       
    })

    it("updateCommonManifestReferenceId if commonManifest return null", async() => {
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        
        const { ModService } = require("../../src/server/service/ModService");
        sinon.stub(ModService.prototype, 'getMod').returns({_id: 'testId'})
        sinon.stub(CommonManifestService.prototype,"getCommonManifest").returns(null);
        sinon.stub(CommonManifestService.prototype,"addUpdateCommonManifest").returns(true)
        const result = await modService.updateCommonManifestReferenceId({});
        expect(result._id).to.equal('testId')
       
    })

    it("updateCommonManifestReferenceId - Error", async() => {
        const { CommonManifestService } = require("../../src/server/service/CommonManifestService");
        
        const { ModService } = require("../../src/server/service/ModService");
        sinon.stub(ModService.prototype, 'getMod').throws("unexpected error")
        sinon.stub(CommonManifestService.prototype,"getCommonManifest").returns({modId: ''});
        sinon.stub(CommonManifestService.prototype,"addUpdateCommonManifest").returns(true)

        try {
            await modService.updateCommonManifestReferenceId({});
        }
        catch (err) {
            expect(err.name).to.equal('unexpected error')
        }
       
       
    })

    it("addUpdateMod - Add Case", async() => {
        const addModelObj = {
            name: 'test'
        }

        const { ModService } = require("../../src/server/service/ModService");
        
        const getModStub = sinon.stub(ModService.prototype, 'getMod')
        getModStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(ModService.prototype , 'updateCommonManifestReferenceId').returns(addModelObj)
        getModStub.onCall(1).returns(addModelObj)
        const result = await modService.addUpdateMod(modData, {});
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateMod - Add Case - user detail is present", async() => {
        const addModelObj = {
            name: 'test'
        }
        const { ModService } = require("../../src/server/service/ModService");
        
        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        const getModStub = sinon.stub(ModService.prototype, 'getMod')
        getModStub.onCall(0).returns(null)
        sinon.stub(DbService.prototype,"getCollection").returns({
            insertOne: () => (true),
        })
        sinon.stub(ModService.prototype , 'updateCommonManifestReferenceId').returns(addModelObj)
        getModStub.onCall(1).returns(addModelObj)
        const result = await modService.addUpdateMod(modData, userHeaderDetails);
        expect(result.name).to.equal('test');
       
    })

    it("addUpdateMod - Edit Case", async() => {
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
        const { ModService } = require("../../src/server/service/ModService");
        
        const getModStub = sinon.stub(ModService.prototype, 'getMod')
        getModStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        
        getModStub.onCall(1).returns(existingModelObj)
        const result = await modService.addUpdateMod(modData, {});
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })

    it("addUpdateMod - Edit Case - user detail is present", async() => {
        const existingModelObj = {
            _id: '507f1f77bcf86cd799439011',
            createdTimestamp: '',
            productCode: 'test'

        }
        const { ModService } = require("../../src/server/service/ModService");
        
        const userHeaderDetails = {};
        userHeaderDetails[Constants.HTTPHEADER_END_USER] = 'TestUserId';
        const getModStub = sinon.stub(ModService.prototype, 'getMod')
        getModStub.onCall(0).returns(existingModelObj)
        sinon.stub(DbService.prototype,"getCollection").returns({
            updateOne: () => (true),
        })
        
        getModStub.onCall(1).returns(existingModelObj)

        const result = await modService.addUpdateMod(modData, userHeaderDetails);
        expect(result._id).to.equal('507f1f77bcf86cd799439011');
       
    })


    it("addUpdateMod - Error", async() => {
        const { ModService } = require("../../src/server/service/ModService");
        
        sinon.stub(ModService.prototype, 'getMod').throws("unexpected error")
       

        try {
            await modService.addUpdateMod(modData, {});
        }
        catch (err) {
            expect(err.message).to.equal('unexpected error')
        }
       
       
    })

    
 });







