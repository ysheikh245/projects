import chai from "chai";
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
const { expect } = chai;
chai.use(chaiHttp);
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { GenericModelService } = require("../../src/server/service/GenericModelService");
const { CashValueService } = require("../../src/server/service/CashValueService");

const cashValueService = new CashValueService()

const mockdata =
{
    "_id": "12a432a111b02d0014cc1a11",
    "productCode": "L708",
    "version": "2022-06-09 12:33:16.881",
    "effectiveDate": "2021-12-28 00:00:00.000",
    "jsonData": {
        "cashValueFactor": [
            {
                "SMOKER_IND": "Z",
                "AGE": 1
            }]
    }
}

describe("-----Testing CashValueService-----", function () {
    afterEach(function () {
        sinon.restore();
    });

    it("addUpdateCashValue", async () => {
        const productCode = "L708"
        sinon.stub(GenericModelService.prototype, "addUpdateModel").returns(mockdata)
        const result = await cashValueService.addUpdateCashValue(mockdata)
        expect(result.productCode).to.equal(productCode)
    });

    it("getCashValue", async () => {
        const productCode = "L708"
        sinon.stub(GenericModelService.prototype, "getModelObject").returns(mockdata)
        const result = await cashValueService.getCashValue(productCode)
        expect(result.productCode).to.equal(productCode)
    });

    it("getCashValueById", async () => {
        const id = "12a432a111b02d0014cc1a11"
        sinon.stub(GenericModelService.prototype, "getModelById").returns(mockdata)
        const result = await cashValueService.getCashValueById(id)
        expect(result._id).to.equal(id)
    });

    it("getAllCashValues", async () => {
        sinon.stub(GenericModelService.prototype, "getAllModels").returns([mockdata])
        const result = await cashValueService.getAllCashValues()
        expect(result.length).to.equal(1)
        expect(result[0].productCode).to.equal("L708")
    });

    it("deleteCashValue", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "deleteModel").returns(true)
        const result = await cashValueService.deleteCashValue(productCode)
        expect(result).to.equal(undefined)
    });

    it("updateProductManifestReferenceId CashValue", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({ productCode })
        const result = await cashValueService.updateProductManifestReferenceId(productCode)
        expect(result.productCode).to.equal(productCode)
    });

    it("Validate request with empty object", async () => {
        const result = await cashValueService.validateRequest({})
        expect(result).to.equal(false)
    });

    it("Validate request without productCode", async () => {
        const result = await cashValueService.validateRequest({ "version": "123" })
        expect(result).to.equal(false)
    });

    it("Validate request with valid object", async () => {
        const result = await cashValueService.validateRequest({ productCode: "123" })
        expect(result).to.equal(true)
    });

})