const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { CashValueService } = require("../../src/server/service/CashValueService")
const { expect } = chai;
chai.use(chaiHttp);

let app;
const mockdata =
{
    "_id": "12a432a111b02d0014cc1a11",
    "productCode": "L708",
    "version": "2022-06-09 12:33:16.881",
    "effectiveDate": "2021-12-28 00:00:00.000",
    "jsonData": {
        "cashValueFactor": [
            {
                "SMOKER_IND": "Z",
                "AGE": 1
            }]
    }
}

describe("-----Testing Cashvalue Routes/get Cashvalue by productCode Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get Cashvalue by productCode success", async () => {
        const productCode = "L708"
        sinon.stub(CashValueService.prototype, "getCashValue").returns(Promise.resolve(mockdata))
        const response = await chai.request(app).get(`/api/cashvalue/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results).to.be.instanceof(Array);
        expect(response.body.results[0].productCode).to.equal(productCode);
    });

    it("get Cashvalue by productCode success with empty return", async () => {
        const productCode = "L708"
        sinon.stub(CashValueService.prototype, "getCashValue").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/cashvalue/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get Cashvalue by productCode 500 error", async () => {
        const productCode = "L708"
        sinon.stub(CashValueService.prototype, "getCashValue").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get(`/api/cashvalue/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing Cashvalue Routes/get Cashvalue by ID Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get cashvalue by ID success", async () => {
        const id = "12a432a111b02d0014cc1a11"
        sinon.stub(CashValueService.prototype, "getCashValueById").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).get(`/api/cashvalue/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal("L708");
        expect(response.body.results[0]._id).to.equal(id);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get cashvalue by ID success with empty return", async () => {
        const id = "12a432a111b02d0014cc1a11"
        sinon.stub(CashValueService.prototype, "getCashValueById").returns(Promise.resolve(null))
        const response = await chai.request(app).get(`/api/cashvalue/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get cashvalue by ID 500 error", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(CashValueService.prototype, "getCashValueById").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get(`/api/cashvalue/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });

    it("get cashvalue by ID 400 error", async () => {
        const id = "44a4a61c12fcd13b12ca123"
        const response = await chai.request(app).get(`/api/cashvalue/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
        expect(response.body.message).to.include("Invalid object id")
    });
})

describe("-----Testing cashvalue Routes/get all cashvalue -----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get cashvalue success", async () => {
        sinon.stub(CashValueService.prototype, "getAllCashValues").returns(Promise.resolve
            ([mockdata]))
        const response = await chai.request(app).get("/api/cashvalue")
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal("L708");
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get cashvalue 500 error", async () => {
        sinon.stub(CashValueService.prototype, "getAllCashValues").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get("/api/cashvalue")
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing cashvalue Routes/Post cashvalue Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("Post cashvalue success", async () => {
        sinon.stub(CashValueService.prototype, "addUpdateCashValue").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).post("/api/cashvalue")
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(200);
        expect(response.body.results.productCode).to.equal('L708');
        expect(response.body.results).to.be.instanceof(Object);
    });

    it("Post cashvalue 500 error", async () => {
        sinon.stub(CashValueService.prototype, "addUpdateCashValue").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).post("/api/cashvalue")
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(500);
    });

    it("post cashvalue  400 data missingerror", async () => {
        const response = await chai.request(app).post(`/api/cashvalue`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
    });

})

describe("-----Testing cashvalue Routes/delete by productCode-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("deletecashvalue success", async () => {
        const productCode = "23as"
        sinon.stub(CashValueService.prototype, "deleteCashValue").returns(Promise.resolve(undefined))
        const response = await chai.request(app).delete(`/api/cashvalue/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
    });

    it("deletecashvalue 500 error", async () => {
        const productCode = "23as"
        sinon.stub(CashValueService.prototype, "deleteCashValue").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).delete(`/api/cashvalue/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})