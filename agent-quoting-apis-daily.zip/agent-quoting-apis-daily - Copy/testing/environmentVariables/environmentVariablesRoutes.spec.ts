const chai = require("chai");
const chaiHttp = require("chai-http");

const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});

import * as auth from '../../src/server/routes/EnvironmentVariables';
import { Util } from '../../src/server/util/Util';
const { expect } = chai;
chai.use(chaiHttp);

let app;
describe("GET /environmentVariable", function () {
      beforeEach(() => {
            app = require("../../src/server/index.ts");
      })
      afterEach(function () {
            sinon.restore();
      });

      it("it should return 200 status for default env variables", async () => {

            const response = await chai.request(app).get("/api/environmentVariable");

            expect(response).to.have.status(200);

      });


      it("it should return mocked data", async () => {

            sinon.stub(Util.config, 'environmentVariables').value({test: 'Test Value'})

            const response = await chai.request(app).get("/api/environmentVariable");

            expect(response.text).to.equal('{"environmentvariables":[{"id":"test","environmentKey":"test","environmentValue":"Test Value","saveToDevice":true}]}')

      });

      it("it should return empty array if environment variable not exist", async () => {

            sinon.stub(Util.config, 'environmentVariables').value(null)

            const response = await chai.request(app).get("/api/environmentVariable");

            expect(response.text).to.equal('{"environmentvariables":[]}')

      });

    
})

export { };
