import chai from "chai";
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
const { expect } = chai;
chai.use(chaiHttp);
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
const { GenericModelService } = require("../../src/server/service/GenericModelService");
const { NonforfeitureETIService } = require("../../src/server/service/NonforfeitureETIService");

const nonforfeitureETIService = new NonforfeitureETIService()

const mockdata=
{
    "_id": "23ae132111b02d0014ccd777",
    "productCode": "L030",
    "version": "2021-02-01 12:01:41.645",
    "effectiveDate": "2021-08-12 11:00:00.000",
    "jsonData": {
        "nonforfeitureETIs": []
    }
}

describe("-----Testing NonforfeitureETIService-----", function () {
    afterEach(function () {
        sinon.restore();
    });

    it("addUpdateNonforfeitureETI", async () => {
        const productCode = "L030"
        sinon.stub(GenericModelService.prototype, "addUpdateModel").returns(mockdata)
        const result = await nonforfeitureETIService.addUpdateNonforfeitureETI(mockdata)
        expect(result.productCode).to.equal(productCode)
    });

    it("getNonforfeitureETI", async () => {
        const productCode = "L030"
        sinon.stub(GenericModelService.prototype, "getModelObject").returns(mockdata)
        const result = await nonforfeitureETIService.getNonforfeitureETI(productCode)
        expect(result.productCode).to.equal(productCode)
    });

    it("getNonforfeitureETIById", async () => {
        const id = "23ae132111b02d0014ccd777"
        sinon.stub(GenericModelService.prototype, "getModelById").returns(mockdata)
        const result = await nonforfeitureETIService.getNonforfeitureETIById(id)
        expect(result._id).to.equal(id)
    });

    it("getAllNonforfeitureETIs", async () => {
        sinon.stub(GenericModelService.prototype, "getAllModels").returns([mockdata])
        const result = await nonforfeitureETIService.getAllNonforfeitureETIs()
        expect(result.length).to.equal(1)
        expect(result[0].productCode).to.equal("L030")
    });

    it("deleteNonforfeitureETI", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "deleteModel").returns(true)
        const result = await nonforfeitureETIService.deleteNonforfeitureETI(productCode)
        expect(result).to.equal(undefined)
    });

    it("updateProductManifestReferenceId nonforfeitureETI", async () => {
        const productCode = "23as"
        sinon.stub(GenericModelService.prototype, "updateProductManifestReferenceIdCommon").returns({ productCode })
        const result = await nonforfeitureETIService.updateProductManifestReferenceId(productCode)
        expect(result.productCode).to.equal(productCode)
    });

    it("Validate request with empty object", async () => {
        const result= await nonforfeitureETIService.validateRequest({})
        expect(result).to.equal(false)
    });

    it("Validate request without productCode", async () => {
        const result= await nonforfeitureETIService.validateRequest({"version":"123"})
        expect(result).to.equal(false)
    });

    it("Validate request with valid object", async () => {
        const result= await nonforfeitureETIService.validateRequest({productCode:"123"})
        expect(result).to.equal(true)
    });
})