const chai = require("chai");
const chaiHttp = require("chai-http");
const sinon = require("sinon");
sinon.restore();
import { DbService } from '../../src/server/db/DbService';
import { DBConstants } from '../../src/server/db/DbConstants';

require('sinon-mongo');
import { MongoClient } from 'mongodb';
let client: MongoClient = sinon.mongo.mongoClient()
const dbService = new DbService(client);
sinon.stub(DbService, 'withDbService').callsFake((f) => { return f(dbService) });
import dbServiceV2 from '../../src/server/db/DbServiceV2';
sinon.stub(dbServiceV2, 'connect').callsFake(() => {console.warn('db v2 mock')});
import * as auth from '../../src/server/routes/ApiKeyValidationRoutes';
const { NonforfeitureETIService } = require("../../src/server/service/NonforfeitureETIService")
const { expect } = chai;
chai.use(chaiHttp);

let app;

const mockdata=
{
    "_id": "23ae132111b02d0014ccd777",
    "productCode": "L030",
    "version": "2021-02-01 12:01:41.645",
    "effectiveDate": "2021-08-12 11:00:00.000",
    "jsonData": {
        "nonforfeitureETIs": []
    }
}

describe("-----Testing nonforfeitureeti/get by productCode Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get nonforfeitureeti by product code success", async () => {
        const productCode = "L030"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETI").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200)
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal(productCode);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("get nonforfeitureeti by product code success with null return", async () => {
        const productCode = "L030"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETI").returns(Promise.resolve
            (null))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results).to.be.instanceof(Array);
        expect(response.body.results.length).to.equal(0);
    });

    it("get nonforfeitureeti by product code 500 error", async () => {
        const productCode = "L030"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETI").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})


describe("-----Testing nonforfeitureeti/get by ID Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("getNonforfeitureETIById success", async () => {
        const id = "23ae132111b02d0014ccd777"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETIById").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0]._id).to.equal(id);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("getNonforfeitureETIById success with null return", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETIById").returns(Promise.resolve
            (null))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(0);
        expect(response.body.results).to.be.instanceof(Array);
    });

    it("getNonforfeitureETIById 500 error", async () => {
        const id = "44a4a61c12fcd13b12ca123e"
        sinon.stub(NonforfeitureETIService.prototype, "getNonforfeitureETIById").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get(`/api/nonforfeitureeti/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
    
    it("getNonforfeitureETIById 400 error", async () => {
        const id = "44a4a61c12fcd13b12ca123"
        const response = await chai.request(app).get(`/api/nonforfeitureeti/id/${id}`)
            .set('apiKey', "api")
        expect(response).to.have.status(400);
    });
})


describe("-----Testing nonforfeitureeti/get all Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("get allsuccess", async () => {
        sinon.stub(NonforfeitureETIService.prototype, "getAllNonforfeitureETIs").returns(Promise.resolve
            ([mockdata]))
        const response = await chai.request(app).get("/api/nonforfeitureeti")
            .set('apiKey', "api")
        expect(response).to.have.status(200);
        expect(response.body.results.length).to.equal(1);
        expect(response.body.results[0].productCode).to.equal("L030");
        expect(response.body.results).to.be.instanceof(Array);   
    });

    it("get all 500 error", async () => {
        sinon.stub(NonforfeitureETIService.prototype, "getAllNonforfeitureETIs").returns((Promise.reject("unexpected error")))
        const response = await chai.request(app).get("/api/nonforfeitureeti")
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})

describe("-----Testing nonforfeitureeti/Post Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("addUpdateNonforfeitureETI success", async () => {
        sinon.stub(NonforfeitureETIService.prototype, "addUpdateNonforfeitureETI").returns(Promise.resolve
            (mockdata))
        const response = await chai.request(app).post(`/api/nonforfeitureeti`)
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(200);
        expect(response.body.results).to.be.instanceof(Object);  
        expect(response.body.results.productCode).to.equal("L030");
    });

    it("addUpdateNonforfeitureETI 500 error", async () => {
        sinon.stub(NonforfeitureETIService.prototype, "addUpdateNonforfeitureETI").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).post(`/api/nonforfeitureeti`)
            .set('apiKey', "api")
            .send(mockdata)
        expect(response).to.have.status(500);
    });

    it("addupdateNonforfeitureETI 400 data missing error", async () => {
        const response = await chai.request(app).post(`/api/nonforfeitureeti`)
            .set('apiKey', "api")
         expect(response).to.have.status(400);
    });

})

describe("-----Testing nonforfeitureeti/delete Route-----", function () {
    beforeEach(() => {
        sinon.stub(auth, "performAPIKeyValidation").callsFake((request, response, next) => {
            next();
        });
        app = require("../../src/server/index.ts");
    })
    afterEach(function () {
        sinon.restore();
    });

    it("Delete nonforfeitureeti success", async () => {
        const productCode = "23as"
        sinon.stub(NonforfeitureETIService.prototype, "deleteNonforfeitureETI").returns(Promise.resolve(undefined))
        const response = await chai.request(app).delete(`/api/nonforfeitureeti/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(200);
    });

    it("Delete nonforfeitureeti 500 error", async () => {
        const productCode = "23as"
        sinon.stub(NonforfeitureETIService.prototype, "deleteNonforfeitureETI").returns(Promise.reject("unexpected error"))
        const response = await chai.request(app).delete(`/api/nonforfeitureeti/${productCode}`)
            .set('apiKey', "api")
        expect(response).to.have.status(500);
    });
})