#!/bin/sh
WORKING_DIR=`pwd`

cd dist
/secret-config-replace.sh /agent-quoting-api.config /run/secrets/agent-quoting-api.secret
cd $WORKING_DIR

npm run run:server