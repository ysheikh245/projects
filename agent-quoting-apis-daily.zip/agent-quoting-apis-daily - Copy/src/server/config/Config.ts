export interface Config {
  credentials: {
    [key: string]: Credentials
  },
  emails: {
    [key: string]: string
  }
}

export interface Credentials {
  host: string;
  'context-root'?: string;
  'client-header'?: string;
  'end-user-id'?: string;
  username?: string;
	password?: string;
	environment?: string;
	sitekey?: string;
	secret?: string;
	threshold?: number;
	headers?: {[key : string] : string}
}