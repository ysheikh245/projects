import { Access } from '../decorators/access';

export class App {
  @Access()
  public app?:string;
  
  @Access()
  public user?:string;

  @Access()
  public gitChanges?:string;

  @Access()
  public taskNumber?:string;
}