import {MongoClient } from 'mongodb';
import { $log } from "@tsed/common";


const MONGO_USER = process.env.MONGO_USER || 'root';
//const MONGO_PASSWORD = process.env.MONGO_PASSWORD || 'admin';
const MONGO_PASSWORD = process.env.MONGO_PASSWORD || 'example';
const MONGO_SERVER = process.env['MONGO_SERVER'] || '127.0.0.1';
const MONGO_PORT = process.env['MONGO_PORT'] || '27017';
// const MONGO_PORT = process.env['MONGO_PORT'] || '27017';

// const CHUNK_SIZE = 255*1024;
export class DbService {
  public client: MongoClient;
  public versionNumber: string;

  constructor(client: MongoClient) {
    this.client = client;
    this.versionNumber = '1';
  }

  static withDbService = async <T>(f: (service: DbService) => Promise<T> ): Promise<T> => {
    let client: MongoClient | null = null;
    try {
      // const url = `mongodb://${MONGO_SERVER}:${MONGO_PORT}`;
      const url = `mongodb://${MONGO_USER}:${MONGO_PASSWORD}@${MONGO_SERVER}:${MONGO_PORT}`;
      $log.info('CONNECTING', url);
      client = new MongoClient(url, {useUnifiedTopology: true});
      await client.connect();
      $log.info('CONNECTED');
      const s = new DbService(client);
      return await f(s);
    } catch (e) {
      $log.error('Error connecting to Mongo...', e);
    } finally {
      $log.info('MONGO DISCONNECTED');
      client?.close();
    }
  }

  // async getAllFiles() {
  //   // const allFiles = await this.getCollection('files').find().toArray()
  //   return (await this.getCollection('files').find().toArray()).reduce((acc, curr) => {
  //     if (acc[curr.metadata.project]) {
  //       acc[curr.metadata.project].files.push(curr)
  //     } else {
  //       acc[curr.metadata.project] = {
  //         isCollapsed: true,
  //         files: [curr]
  //       }
  //     }
  //     return acc
  //   }, {})
  // }

  // async getFileMetadataById(id: string) {
  //   return await this.getCollection('files').findOne({_id: new ObjectId(id)}) as {id: string, filename: string, uploadDate: Date, length: number}
  // }

  // async getFileById(id: string) {
  //   const grid = new GridFSBucket(this.client.db('fs'))
  //   return await new Promise<Buffer>((resolve, reject) => {
  //     const stream = grid.openDownloadStream(new ObjectId(id));
  //     const bufs: Buffer[] = [];
  //     stream.on('data', b => bufs.push(b));
  //     stream.on('end', () => {
  //       resolve(Buffer.concat(bufs))
  //     })
  //     stream.on('error', reject);
  //   })
  // }

  // async saveFile(name: string, metadata: {[key: string]: any}, bytes: Buffer) {
  //   const grid = new GridFSBucket(this.client.db('fs'))

  //   const uploadStream = grid.openUploadStream(name, {metadata})
  //   const id = await new Promise((resolve, reject) => {
  //     Readable.from([bytes]).pipe(uploadStream)
  //       .on('error', (error: any) => {
  //         console.error("Error uploading file", error);
  //         reject(error);
  //       }).on('finish', () => {
  //         console.log("Done uploading file ", name);
  //         resolve(uploadStream.id)
  //       });
  //   })
  //   return id;
  // }

  // async projects() {
  //   return await this.client.db('fs').collection('fs.files').distinct('metadata.project')
  // }

  // async delete(id?: string) {
  //   if(id) {
  //     let files = await this.client.db('fs').collection('fs.files')
  //     let filesDeleted = (await files.deleteOne({_id: new ObjectId(id)})).deletedCount
  //     let chunks = await this.client.db('fs').collection('fs.chunks')
  //     let chunksDeleted = (await chunks.deleteMany({files_id: new ObjectId(id)})).deletedCount
  //     console.log("Should have deleted from fs and chunks", id, {filesDeleted, chunksDeleted});
  //   } else {
  //     await this.client.db('fs').dropDatabase();
  //   }
  // }

  // async deleteMatching(details: any) {
  //   let files = await this.client.db('fs').collection('fs.files')
  //   let toDelete = (await files.find(details).toArray()).map(f => f._id);
  //   let filesDeleted = (await files.deleteMany({_id: {$in: toDelete}})).deletedCount;
  //   let chunks = await this.client.db('fs').collection('fs.chunks')
  //   let chunksDeleted = (await chunks.deleteMany({files_id: {$in: toDelete}})).deletedCount
  //   console.log("Deleted files matching", details, {filesDeleted, chunksDeleted})
  // }

  // async search(details: any, count: number | undefined) {
  //   console.log("SEARCHING", details, count)
  //   let query = this.client.db('fs').collection('fs.files').find(details).sort({uploadDate: -1})
  //   if(count !== undefined) {
  //     console.log("LIMITING", count);
  //     query = query.limit(count * 2)
  //   }
  //   let results = await query.toArray();
  //   let grouped: {[key: string]: any[]} = {}
  //   results.forEach((file: any) => {
  //     let key = `${file.metadata.project}/${file.metadata.channel}`;
  //     grouped[key] = [...grouped[key] || [], file]
  //   })
  //   return Object.values(grouped).map((files: any[]) => ({
  //     project: files[0].metadata.project,
  //     channel: files[0].metadata.channel,
  //     files: files
  //   })).slice(0, count);
  // }

  getCollection(collectionName: string) {
    const db = this.client.db('agent-quoting')
    return db.collection('agent-quoting.' + collectionName)
    // return this.client.database('fs').collection(collectionName)
  }
}