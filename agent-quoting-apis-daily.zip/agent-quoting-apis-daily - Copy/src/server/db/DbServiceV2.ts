import { MongoClient } from 'mongodb';
import { $log } from "@tsed/common";
import { Util } from "../util/Util";


const MONGO_USER = process.env.MONGO_USER || 'root';
//const MONGO_PASSWORD = process.env.MONGO_PASSWORD || 'admin';
const MONGO_PASSWORD = process.env.MONGO_PASSWORD || 'example';
const MONGO_SERVER = process.env['MONGO_SERVER'] || '127.0.0.1';
const MONGO_PORT = process.env['MONGO_PORT'] || '27017';

const MONGODB_URL = `mongodb://${MONGO_SERVER}:${MONGO_PORT}`;
//const MONGODB_URL = `mongodb://${MONGO_USER}:${MONGO_PASSWORD}@${MONGO_SERVER}:${MONGO_PORT}`;

console.log('from db service', Util.config.dbServiceConfig)
const dbServiceV2 = {
    client: undefined,
    connect: (callback) => {
        MongoClient.connect(MONGODB_URL, 
                {
                    minPoolSize: Util.config.dbServiceConfig.minPoolSize ? Util.config.dbServiceConfig.minPoolSize : 5,
                    maxPoolSize: Util.config.dbServiceConfig.maxPoolSize ? Util.config.dbServiceConfig.maxPoolSize : 10,
                    useUnifiedTopology: true
                },(err, client) => {
            if (err) {
              $log.error('Error connecting to Mongo...', err);
              $log.error('Error connecting to Mongo...', err.stack);
                callback(err);
            }
           
            dbServiceV2.client = client;
            $log.info('DBService V2 Connected to Database');
            callback(null);
        });
    },
    getCollection(collectionName: string) {
        const db = dbServiceV2.client.db('agent-quoting')
        return db.collection('agent-quoting.' + collectionName)
    },
    versionNumber: '2'
};

export default dbServiceV2;

