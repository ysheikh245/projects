export class DBConstants {
    public static readonly TABLE_AED = "aed";
    public static readonly TABLE_AED_v2 = "aedv2";
    public static readonly TABLE_PRODUCT_UI_CONFIG = "productUIConfig";
    public static readonly TABLE_CASH_VALUE = "cashValue";
    public static readonly TABLE_COMMON_MANIFEST = "commonManifest";
    public static readonly TABLE_ENV_VARIABLES = "envVariables";
    public static readonly TABLE_MANIFEST = "manifest";
    public static readonly TABLE_MOD = "mod";
    public static readonly TABLE_NONFORFEITURE_ETI = "nonforfeitureETI";
    public static readonly TABLE_NONFORFEITURE_RPU = "nonforfeitureRPU";
    public static readonly TABLE_PLAN = "plan";
    public static readonly TABLE_PRODUCT = "product";
    public static readonly TABLE_PRODUCT_MANIFEST = "productManifest";
    public static readonly TABLE_QMS_ADJUSTMENT_GROUP = "qmsAdjGroup";
    public static readonly TABLE_QMS_AREAS = "qmsAreas";
    public static readonly TABLE_QMS_RATES = "qmsRates";
    public static readonly TABLE_RATE = "rates";

    // MobileRates
    public static readonly TABLE_MOBILE_RATE_ADJUSTMENT_GROUP = "mobileRateAdjGroup";
    public static readonly TABLE_MOBILE_RATE_AREAS = "mobileRateAreas";
    public static readonly TABLE_MOBILE_RATE_RATES = "mobileRateRates";

    public static readonly DATE_TIME_FORMAT = 'YYYY-MM-DDTHH:mm:ss';

}