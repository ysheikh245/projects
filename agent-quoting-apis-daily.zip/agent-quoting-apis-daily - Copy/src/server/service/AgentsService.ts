import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Aed } from '../models';
import { GenericModelService } from './GenericModelService';
import { Util } from "../util/Util";
import {Constants} from "../util";
import axios from "axios";

const https = require('https');
const Axios = axios.create({
    httpsAgent: new https.Agent({
        rejectUnauthorized: false
    }),
    responseType: 'json'
});


export class AgentsService {

    public async getAgentDetails(_npn: string) {
        var credentials = Util.config.credentials[Constants.AGENTS_PMAPI_CONFIG_KEY];
        let AGENTS_PMAPI_URL = Util.addPathSegment(credentials.host, _npn)

        //$log.info(`Username=, Password=, URL=`, credentials.username, credentials.password, credentials.host)

        let headers = {
            'Authorization': `Basic ${Buffer.from(`${credentials.username}:${credentials.password}`).toString('base64')}`,
            'content-type': 'application/json',
            'client-header': `${credentials["client-header"]}`,
            'end-user-id': `${credentials["end-user-id"]}`,
        }

        let response = await Axios.get(AGENTS_PMAPI_URL, {headers});
        return response['data']['response'];
    }
}
