import {CommonManifest, Product, ProductManifest, QmsAdjustmentGroup, QmsArea} from "../models";
import {ProductService} from "./ProductService";
import {ProductManifestService} from "./ProductManifestService";
import {AppManifest} from "../models/AppManifest";
import {State} from "../models/State";
import {AppManifestMedSuppData, AppManifestProduct} from "../models/AppManifestProduct"
import {Element} from "../models/Element";
import {CommonManifestService} from "./CommonManifestService";
import {$log} from "@tsed/common";
import {QmsAreaService} from "./QmsAreaService";
import {QmsAdjustmentGroupService} from "./QmsAdjustmentGroupService";
import {QmsRatesService} from "./QmsRatesService";
import {Constants, DateUtil} from "../util";
import {AppManifestProduct2} from "../models/AppManifestProduct2";
import {AppManifest2} from "../models/AppManifest2";
import {MobileRateAdjustmentGroupService} from "./MobileRateAdjustmentGroupService";
import {MobileRateAreasService} from "./MobileRateAreasService";
import {MobileRateRatesService} from "./MobileRateRatesService";
import {Util} from "../util/Util";

const commonManifestService = new CommonManifestService();
const productService = new ProductService();
const productManifestService = new ProductManifestService();
const qmsAdjustmentGroupService = new QmsAdjustmentGroupService();
const qmsAreaService = new QmsAreaService();
const qmsRatesService = new QmsRatesService();

const mobileRateAdjustmentGroupService = new MobileRateAdjustmentGroupService();
const mobileRateAreaService = new MobileRateAreasService();
const mobileRateRatesService = new MobileRateRatesService();


export class CheckForUpdateService {
    public validateRequest (appManifest: AppManifest) {
        $log.info('CheckForUpdateService validating request');
        return (appManifest && appManifest!= null && appManifest.products);
    }

    public filterDuplicateProducts (appManifestProducts: Array<Product>) {
        // exports.filterDuplicateProducts = function (appManifestProducts: Array<Product>): Array<Product> {
        $log.info('CheckForUpdateService filterDuplicateProducts(): Start');
        const productCodes = appManifestProducts.map(product => product.productCode)
        const uniqueProducts = appManifestProducts.filter(({productCode}, index) => !productCodes.includes(productCode, index + 1))
        $log.info('CheckForUpdateService filterDuplicateProducts(): Completed');
        return uniqueProducts;
    }

    public findStates () {
        $log.info('CheckForUpdateService findStates(): Start');
        // Query the model or read a configuration file and get all the states present in the model
        $log.info('CheckForUpdateService findStates(): Completed');
        return [];
    }

    public async updateStateManifest (appManifest: AppManifest, statesInServer: Array<State>) {
        $log.info('CheckForUpdateService updateStateManifest(): Start');
        if (statesInServer && statesInServer.length > 0) { // iterate only if there is any value present in the states array
            //let appManifestStates: Array<State> = appManifest.states
            if (appManifest.states && appManifest.states.length > 0) {

                // Part1 - In appManifest but not in statesJSON
                let serverStates = statesInServer.map(state => state.code)
                appManifest.states.forEach(appManifestState => {
                    if (!serverStates.includes(appManifestState.code)) {
                        appManifestState.deleteFlag = true;
                    } else {
                        appManifestState.deleteFlag = false;
                        // delete appManifestState['deleteFlag'];
                    }
                });

                // Part2 - In statesJSON; but not in appManifest
                let appManifestStates = appManifest.states.map(appManifestStates => appManifestStates.code)
                statesInServer.forEach((state, index) => {
                    //$log.info('****************** ' + state)
                    if (!appManifestStates.includes(state.code)) {
                        //var newState: { deleteFlag: boolean; code: string; name: string; active: string; localId: string; serverId: string } = {
                        var newState = new State();
                        newState.localId = "";
                        newState.serverId = statesInServer[index].id;
                        newState.code = statesInServer[index].code;
                        newState.name = statesInServer[index].name;
                        newState.active = statesInServer[index].active;
                        newState.deleteFlag = false
                        appManifest.states.push(newState);
                    }
                });
            } else {
                let updatedStates: Array<State> = []
                statesInServer.forEach(state => {
                    let newState = new State();
                    newState.localId = "";
                    newState.serverId = state.id;
                    newState.code = state.code;
                    newState.name = state.name;
                    newState.active = state.active;
                    newState.deleteFlag = false;
                    updatedStates.push(newState);
                })
                appManifest.states = updatedStates
            }
        }
        $log.info('CheckForUpdateService updateStateManifest(): Completed');
    };

    public async findCommonManifest () {
        $log.info('CheckForUpdateService findCommonManifest(): Start');
        const commonManifest = await commonManifestService.getAllCommonManifests();
        //$log.info(`CommonManifest = ${JSON.stringify(commonManifest)}`)
        $log.info('CheckForUpdateService findCommonManifest(): Completed');
        return commonManifest;
    };

    public async updateCommonManifest (appManifest, commonManifest: Array<CommonManifest>) {
        $log.info('CheckForUpdateService updateCommonManifest(): Start');
        if (commonManifest && commonManifest.length > 0) {
            $log.info('Processing records found in CommonManifest.');
            //$log.info('Inside updateCommonManifest - if part');
            if (appManifest && appManifest.mod) {
                //$log.info(`CommonManifest[0]= ${JSON.stringify(commonManifest[0])}`)
                appManifest.mod.serverId = commonManifest[0].modId;
            } else {
                //$log.info('Inside updateCommonManifest - else part');
                appManifest.mod = {
                    "description": "Common Rate Data (defined on server)",
                    "localId": "",
                    "serverId": commonManifest[0].modId
                };
            }
        } else {
            $log.info(`No records found in CommonManifest.`);
            //$log.debug(`CommonManifest=${JSON.stringify(commonManifest)}`)
        }
        $log.info('CheckForUpdateService updateCommonManifest(): Completed');
    };

    public async findAllProducts () {
        $log.info('CheckForUpdateService findAllProducts(): Start');
        const products = await productService.getAllProducts();
        $log.info(`Queried Products Table. Total Products=${products.length}`);
        //$log.info('************************************************* ' + products + 'Type: ' + JSON.stringify(products))
        const productCodes = products.map((product: any) => product.productCode as string);
        const uniqueProducts = products.filter(({productCode}: any, index: number) => !productCodes.includes(productCode, index + 1));
        //$log.info('uniqueProducts: ' + uniqueProducts);
        $log.info('CheckForUpdateService findAllProducts(): Completed');
        return uniqueProducts;
    };

    public async processQMSData(genericDataSet : boolean, productCode: string) {
        const medSuppData = new AppManifestMedSuppData();
        try {
            $log.info('Processing QMSData - Start');
            let states = new Set();
            let qmsAreasMap = new Map();
            let qmsRatesMap = new Map();
            let areaElement: Array<string>;
            let rateElement: Array<string>;

            let qmsAdjustmentGroups, qmsAreas, qmsRates = null;

            if(genericDataSet) {
                // Query Mobile xxx Entities
                $log.info('Querying MobileRateAdjustmentGroups, MobileRateAreas, MobileRateRates - Started');
                let businessType = Util.getBusinessType(productCode)
                qmsAdjustmentGroups = await mobileRateAdjustmentGroupService.getMobileRateAdjustmentGroupByBusinessType(businessType);
                //console.log(`QMSAdjustmentGroups: ${qmsAdjustmentGroups}`);
                qmsAreas = await mobileRateAreaService.getMobileRateAreasByBusinessType(businessType);
                qmsRates = await mobileRateRatesService.getMobileRateRatesByBusinessType(businessType);
                $log.info('Querying MobileRateAdjustmentGroups, MobileRateAreas, MobileRateRates - Completed');
            } else {
                // Query QMS Entities
                $log.info('Querying MobileRateAdjustmentGroups, MobileRateAreas, MobileRateRates - Started');
                let businessType = Util.getBusinessType(productCode)
                qmsAdjustmentGroups = await qmsAdjustmentGroupService.getQmsAdjustmentGroupByBusinessType(businessType);
                qmsAreas = await qmsAreaService.getQMSAreasByBusinessType(businessType);
                qmsRates = await qmsRatesService.getQMSRatesByBusinessType(businessType);
                //console.log(`Count ==> AdjGroups=${qmsAdjustmentGroups.length}, Areas=${qmsAreas.length}, Rates=${qmsRates.length}`)
                $log.info('Querying QMSAdjustmentGroups, QMSAreas, QMSRates - Completed');
            }

            // Process QMSAdjustmentGroups
            if (qmsAdjustmentGroups != null) {
                qmsAdjustmentGroups.forEach((qmsAdjustmentGroup) => {
                    medSuppData.adjGroups.push(qmsAdjustmentGroup._id);
                });
            } else {
                $log.info('No data returned for QMSAdjustmentGroups from the database. Object is NULL');
            }

            // Process QMSAreas
            qmsAreas.map(item => {
                states.add(item.state);
                areaElement = qmsAreasMap.get(item.state);

                if (!areaElement || areaElement == null) {
                    areaElement = new Array();
                }
                areaElement.push(item._id);
                qmsAreasMap.set(item.state, areaElement);
            });

            // Process QMSRates
            qmsRates.map(item => {
                states.add(item.state);
                rateElement = qmsRatesMap.get(item.state);
                if (!rateElement || rateElement == null) {
                    rateElement = new Array();
                }
                rateElement.push(item._id);
                qmsRatesMap.set(item.state, rateElement);
            });

            $log.debug(`States to be processed: ${states}`);

            // Consolidate QMSAreas and QMSRates in the AppManifestProduct object
            states.forEach((state) => {
                medSuppData.stateRates[`${state}`] = new Object();
                medSuppData.stateRates[`${state}`].areas = new Array();
                medSuppData.stateRates[`${state}`].rates = new Array();

                if (qmsAreasMap.get(state) != null) {
                    medSuppData.stateRates[`${state}`].areas = qmsAreasMap.get(state);
                }

                if (qmsRatesMap.get(state) != null) {
                    medSuppData.stateRates[`${state}`].rates = qmsRatesMap.get(state);
                }
            });
            $log.debug(`MedSuppData=${JSON.stringify(medSuppData)}`);
            $log.info('Processing QMSData - Completed');
        } catch (error) {
            $log.error('Processing QMSData - Failed. Error ' + error.stack);
        }
        return medSuppData;
    }

    public async updateProductManifest (appManifestProducts, products) {
        $log.info('CheckForUpdateService updateProductManifest(): Start');
        const productsManifest = await productManifestService.getAllProductManifests();

        const appManifestProductsMap = new Map(appManifestProducts.map(appManifestProduct => {
            return [appManifestProduct.productCode, appManifestProduct];
        }));

        const productsManifestMap: any = new Map(productsManifest.map(productsManifest => {
            return [productsManifest.productCode, productsManifest];
        }));

        $log.debug('AppManifestProductsMap: ' + JSON.stringify(Object.fromEntries(appManifestProductsMap)));
        $log.debug('ProductsManifestMap: ' + JSON.stringify(Object.fromEntries(productsManifestMap)));

        // Iterate through the Products table array
        for (const product of products) {
            $log.info('Processing Product : ' + product.productCode)
            let appManifestProduct: AppManifestProduct = appManifestProductsMap.get(product.productCode) as AppManifestProduct;

            if (!appManifestProduct || appManifestProduct == null) { // In Products, not in AppManifest; add the product
                $log.info(`ProductCode=${product.productCode}. In ProductsTable=Found; In AppManifestProductIncomingPayload=Not Found`);
                let newProduct = new AppManifestProduct();
                newProduct.productCode = product.productCode;
                newProduct.productType = product.type;
                newProduct.productDescription = product.name;
                newProduct.active = product.active;
                newProduct.deleteFlag = product.deleteFlag;

                //let productManifest : ProductManifest = productsManifestMap[product.productCode];
                let productManifest: ProductManifest = productsManifestMap.get(product.productCode);
                if (productManifest) {
                    $log.info(`ProductCode=${product.productCode}. Processing Product further to send it back in AppManifest`);
                    newProduct.aed = new Element();
                    newProduct.aed.localId = Constants.BLANK;
                    newProduct.aed.serverId = productManifest.aedId;

                    newProduct.plan = new Element();
                    newProduct.plan.localId = Constants.BLANK;
                    newProduct.plan.serverId = productManifest.planId;

                    newProduct.rate = new Element();
                    newProduct.rate.localId = Constants.BLANK;
                    newProduct.rate.serverId = productManifest.ratesId;

                    newProduct.cashValue = new Element();
                    newProduct.cashValue.localId = Constants.BLANK;
                    newProduct.cashValue.serverId = productManifest.cashValueId;

                    newProduct.nonforfeitureRPU = new Element();
                    newProduct.nonforfeitureRPU.localId = Constants.BLANK;
                    newProduct.nonforfeitureRPU.serverId = productManifest.nonforfeitureRPUId;

                    newProduct.nonforfeitureETI = new Element();
                    newProduct.nonforfeitureETI.localId = Constants.BLANK;
                    newProduct.nonforfeitureETI.serverId = productManifest.nonforfeitureETIId;

                    // Process QMS only L030 types
                    if (productManifest.productCode === Constants.PRODUCT_CODE_L030 || Constants.PRODUCT_CODE_S060) {
                        $log.info(`Processing QMS data as productCode=${productManifest.productCode}`);
                        newProduct.medSuppData = await this.processQMSData(false, productManifest.productCode);
                    }
                } else {
                    $log.info(`ProductCode=${product.productCode}. In ProductsTable=Found; In AppManifestProductIncomingPayload=Not Found. ProductManifest=Not Found`);
                }
                appManifestProducts.push(newProduct); // Push the newly created to appManifestProducts array
                appManifestProductsMap.set(newProduct.productCode, newProduct);
            } else { // In AppManifest, and in Products; update the AppManifestProduct with server values
                $log.info(`ProductCode=${product.productCode}. In ProductsTable=Found; In AppManifestProductIncomingPayload=Found. Re-syncing them for sending back updated values`);
                let productManifest: ProductManifest = productsManifestMap.get(product.productCode);

                appManifestProduct.active = product.active;
                appManifestProduct.productType = product.type;
                appManifestProduct.productDescription = product.name;
                //appManifestProduct.name                 = product.name;

                if (productManifest) {
                    if (appManifestProduct.aed) {
                        appManifestProduct.aed.serverId = productManifest.aedId;
                    }
                    if (appManifestProduct.plan) {
                        appManifestProduct.plan.serverId = productManifest.planId;
                    }
                    if (appManifestProduct.rate) {
                        appManifestProduct.rate.serverId = productManifest.ratesId;
                    }
                    if (appManifestProduct.cashValue) {
                        appManifestProduct.cashValue.serverId = productManifest.cashValueId;
                    }
                    if (appManifestProduct.nonforfeitureRPU) {
                        appManifestProduct.nonforfeitureRPU.serverId = productManifest.nonforfeitureRPUId;
                    }
                    if (appManifestProduct.nonforfeitureETI) {
                        appManifestProduct.nonforfeitureETI.serverId = productManifest.nonforfeitureETIId;
                    }

                    // Process QMS only L030 types
                    if (product.productCode === Constants.PRODUCT_CODE_L030 || Constants.PRODUCT_CODE_S060) {
                        $log.info('Processing QMS data as productCode=L030');
                        appManifestProduct.medSuppData = await this.processQMSData(false, productManifest.productCode);
                    }
                } else {
                    // The product entry is present in appManifest but not in the Products table
                    $log.info(`ProductCode=${product.productCode}. In ProductsTable=Found; In AppManifestProductIncomingPayload=Found. ProductManifest=Not Found`);
                }
            }
        }

        // Iterate the Map object and send back the updated Products array back in the response
        const updatedProducts = []
        appManifestProductsMap.forEach((value, key) => {
            updatedProducts.push(value);
        });
        //$log.debug(`Updated Products: ${JSON.stringify(updatedProducts)}`);
        $log.info('CheckForUpdateService updateProductManifest(): Completed');
        return updatedProducts;
    }


    public async checkForUpdates() {
        const commonManifest = await this.findCommonManifest();
        const productsManifest = await productManifestService.getAllProductManifests();
        const productsManifestMap: any = new Map(productsManifest.map(productsManifest => {
            return [productsManifest.productCode, productsManifest];
        }));

        let products = await productService.getAllProducts();
        let activeProducts = products.filter(product => product['active'] == true);
        let appManifestProductsArray : Array<AppManifestProduct2> = new Array();

        for(const activeProduct of activeProducts) {
            let productManifest: ProductManifest = productsManifestMap.get(activeProduct['productCode']);
            let appManifestProduct2 = new AppManifestProduct2()
            appManifestProduct2.productCode = activeProduct['productCode'];
            appManifestProduct2.productType = activeProduct['type'];
            appManifestProduct2.productDescription = activeProduct['name'];
            appManifestProduct2.active = activeProduct['active'];
            appManifestProduct2.lastUpdated = activeProduct['updatedTimestamp'];
            appManifestProduct2.productUIConfigId = productManifest['productUIConfig']
            appManifestProduct2.planId = productManifest['planId'];
            appManifestProduct2.rateId = productManifest['ratesId'];
            appManifestProduct2.cashValueId = productManifest['cashValueId'];
            appManifestProduct2.nonforfeitureRPUId = productManifest['nonforfeitureRPUId'];
            appManifestProduct2.nonforfeitureETIId = productManifest['nonforfeitureETIId'];

            // Process QMS only L030 types
            if (activeProduct['productCode'] === Constants.PRODUCT_CODE_L030 || activeProduct['productCode'] === Constants.PRODUCT_CODE_S060) {
                $log.info('Processing QMS data as productCode=L030 or S060');
                appManifestProduct2.mobileData = await this.processQMSData(false, activeProduct['productCode']);
            }

            if(activeProduct['productCode'] === 'C254') {
                $log.info('Processing QMS data as productCode=C254');
                appManifestProduct2.mobileData = await this.processQMSData(true, activeProduct['productCode']);
            }
            appManifestProductsArray.push(appManifestProduct2);
        }

        let appManifest2 = new AppManifest2();
        appManifest2.commonManifest = commonManifest[0];
        appManifest2.products = appManifestProductsArray;
        appManifest2.lastChecked = DateUtil.formatCurrentDate('YYYY-MM-DD HH:mm:ss.SSS');
        return appManifest2;
    }
}