import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Aed } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_AED_v2;
const MANIFEST_ID = 'aedIdv2';

export class AedServicev2 extends GenericModelService {
    public async addUpdateAed(aedDetails: Aed, userHeaderDetails: any) {
        $log.debug('AedServicev2.addUpdateAed..........', aedDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, aedDetails.productCode, aedDetails, userHeaderDetails);
    }


    public async getAed(_productCode: string) {
        $log.debug('AedServicev2.getAed..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getAedById(_id: string) {
        $log.debug('AedServicev2.getAedById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllAeds() {
        $log.debug('AedServicev2.getAllAeds..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteAed(objectId: string, userHeaderDetails: any) {
        $log.debug('AedServicev2.deleteAed..........', objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteAedByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('AedServicev2.deleteAedByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('AedServicev2.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        //return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
        return;
    }

    public validateRequest (data) {
        $log.info('AedServicev2.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`AedServicev2.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}