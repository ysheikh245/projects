import { $log } from '@tsed/common';
import { DbService } from '../db/DbService';
import dbServiceV2 from '../db/DbServiceV2';
import { DBConstants } from '../db/DbConstants';
import { Constants } from '../util/Constants';
import { Util } from "../util/Util";
import { ProductManifest } from '../models';
import moment, { Moment } from 'moment';
import { ObjectId } from "mongodb";

let dbService: any;
/* Approach 1 */
// const intiDbServiceV1 = () => {
//     DbService.withDbService(async svc => {
//         dbService = svc;
//         console.log('ProductManifestService db v1 init');
//         return await new Promise((resolve, reject) => {
//             // never ending promise to keep connection forever
//         });
//     })
// }

// if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
//     intiDbServiceV1();  
// } else {
//     dbService = dbServiceV2;
// }


const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`ProductManifestService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}


export class ProductManifestService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`ProductManifestService..........constructor`);
        if (!ProductManifestService.isInitilized) {
            $log.debug(`ProductManifestService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`ProductManifestService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            ProductManifestService.isInitilized = true;
        }
    }

    public async addUpdateProductManifest(productManifestDetails: ProductManifest, userHeaderDetails: any) {
        try {
            let foundProductManifest = await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).findOne({ productCode: productManifestDetails.productCode });
            $log.debug(`addUpdateProductManifest..........foundProductManifest`);
            // $log.debug(`addUpdateProductManifest..........foundProductManifest`, foundProductManifest);
            const timestamp = moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
            if (foundProductManifest == null) {
                $log.info(`addUpdateProductManifest.......... Inserting the product manifest for ` + productManifestDetails.productCode);

                productManifestDetails.updatedTimestamp = timestamp;
                productManifestDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';

                await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).insertOne(productManifestDetails);
                foundProductManifest = await this.getProductManifest(productManifestDetails.productCode);
                $log.info(`addUpdateProductManifest ..........getProductManifest foundProductManifest `, foundProductManifest);
                return foundProductManifest;
            } else {
                $log.info(`addUpdateProductManifest.......... updating the product manifest for ` + productManifestDetails.productCode);

                productManifestDetails._id = foundProductManifest._id
                productManifestDetails.createdTimestamp = foundProductManifest.createdTimestamp;
                productManifestDetails.updatedTimestamp = timestamp;
                productManifestDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
                const query = { productCode: foundProductManifest.productCode };

                await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).updateOne(query, { $set: productManifestDetails });
                foundProductManifest = await this.getProductManifest(productManifestDetails.productCode);
                // $log.info(`addUpdateProductManifest ..........getProductManifest result `, foundProductManifest);
                $log.info(`addUpdateProductManifest ..........getProductManifest result `);
                return foundProductManifest;
            }
        } catch (err) {
            $log.error(`deleteProductManifest..........Error `, err);
            throw new Error(err);
        }
    }

    public async getProductManifest(_productCode: string) {
        $log.debug(`getProductManifest..........`, _productCode);
        try {
            let productManifest = await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).findOne({ productCode: _productCode });
            // $log.info(`getProductManifest..........Returned ProductManifests for ${_productCode}.`, productManifest);
            $log.info(`getProductManifest..........Returned ProductManifests for ${_productCode}.`);
            return productManifest;
        } catch (err) {
            $log.error(`getProductManifest..........Error `, err);
            throw new Error(err);
        }
    }

    public async getProductManifestByReferenceObjectId(_productManifestReferenceName: string, objectId: string) {
        $log.debug(`getProductManifest by id..........`, objectId);
        try {
            let productManifest = await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).findOne({[_productManifestReferenceName]: new ObjectId(objectId)});
            $log.info(`getProductManifest by id...........Returned ProductManifests for ${objectId}.`);
            return productManifest;
        } catch (err) {
            $log.error(`getProductManifest by id..........Error `, err);
            throw new Error(err);
        }
    }

    public async getAllProductManifests() {
        $log.debug(`getAllProductManifests..........`);
        try {
            $log.debug(dbService);
            let productManifests = await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).find().toArray();
            $log.info(`getAllProductManifests..........productManifests completed`);
            //$log.debug(`getAllProductManifests..........productManifests  `, productManifests);
            return productManifests;
        } catch (err) {
            $log.error(`getAllProductManifests..........Error `, err);
            throw new Error(err);
        }
    }

    public async deleteProductManifest(_productCode: string) {
        $log.debug(`deleteProductManifest..........`, _productCode);
        try {
            await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).deleteOne({ productCode: _productCode });
            $log.debug(`deleteProductManifest..........Deleted product manfifest for ${_productCode}`);
            return true;
        } catch (err) {
            $log.error(`deleteProductManifest..........Error `, err);
            throw new Error(err);
        }
    }

    public async deleteProductManifestById(_productId: string) {
        $log.debug(`deleteProductManifestbyId..........`, _productId);
        try {
            await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).deleteOne({_id: new ObjectId(_productId)});
            $log.debug(`deleteProductManifestbyId..........Deleted product manfifest for ${_productId}`);
            return true;
        } catch (err) {
            $log.error(`deleteProductManifestById..........Error `, err);
            throw new Error(err);
        }
    }

}