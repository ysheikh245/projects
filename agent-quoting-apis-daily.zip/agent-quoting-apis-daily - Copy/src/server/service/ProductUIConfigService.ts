import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { ProductUIConfig } from '../models/ProductUIConfig'
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_PRODUCT_UI_CONFIG;
const MANIFEST_ID = 'productUIConfig';

export class ProductUIConfigService extends GenericModelService {
    public async addUpdateProductUIConfig(productUIConfig: ProductUIConfig, userHeaderDetails: any) {
        $log.debug('ProductUIConfig.addUpdateProductUIConfig..........', productUIConfig);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, productUIConfig.productCode, productUIConfig, userHeaderDetails);
    }


    public async getProductUIConfig(_productCode: string) {
        $log.debug('ProductUIConfig.getProductUIConfig ..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getProductUIConfigById(_id: string) {
        $log.debug('ProductUIConfig.getProductUIConfigById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllProductUIConfigs() {
        $log.debug('ProductUIConfig.getAllProductUIConfigs..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteProductUIConfig(objectId: string, userHeaderDetails: any) {
        $log.debug('ProductUIConfig.deleteProductUIConfig..........', objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteProductUIConfigByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('ProductUIConfig.deleteProductUIConfigByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('ProductUIConfig.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        //return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
        return;
    }

    public validateRequest (data) {
        $log.info('ProductUIConfig.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`ProductUIConfig.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}