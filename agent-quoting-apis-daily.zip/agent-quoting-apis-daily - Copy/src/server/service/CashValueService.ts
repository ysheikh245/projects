import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Aed } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_CASH_VALUE;
const MANIFEST_ID = 'cashValueId';

export class CashValueService extends GenericModelService {
    public async addUpdateCashValue(cashValueDetails: Aed, userHeaderDetails: any) {
        $log.debug('CashValueService.addUpdateCashValue..........', cashValueDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, cashValueDetails.productCode, cashValueDetails, userHeaderDetails);
    }


    public async getCashValue(_productCode: string) {
        $log.debug('CashValueService.getCashValue..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getCashValueById(_id: string) {
        $log.debug('CashValueService.getCashValueById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllCashValues() {
        $log.debug('CashValueService.getAllCashValues..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteCashValue(_objectId: string, userHeaderDetails: any) {
        $log.debug('CashValueService.deleteCashValue..........', _objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, _objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteCashValueByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('CashValueService.deleteCashValueByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('CashValueService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('CashValueService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`CashValueService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}