import {$log} from "@tsed/common";
import {ObjectId, ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {ProductManifestService} from './ProductManifestService';

import moment from 'moment';
import dbServiceV2 from '../db/DbServiceV2';
import {Util} from "../util/Util";
import {MobileRateAdjustmentGroup} from "../models/MobileRateAdjustmentGroup";


const _databaseName = DBConstants.TABLE_MOBILE_RATE_ADJUSTMENT_GROUP;

const productManifestService = new ProductManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`MobileRateAdjustmentGroupService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class MobileRateAdjustmentGroupService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`MobileRateAdjustmentGroupService..........constructor`);
        if (!MobileRateAdjustmentGroupService.isInitilized) {
            $log.debug(`MobileRateAdjustmentGroupService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`MobileRateAdjustmentGroupService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            MobileRateAdjustmentGroupService.isInitilized = true;
        }
    }
    public async addUpdateMobileRateAdjustmentGroup(mobileRateAdjustmentGroup: MobileRateAdjustmentGroup, userHeaderDetails: any) {
        //const productCode = Util.getProductCode(mobileRateAdjustmentGroup?.businessType);
        $log.info('addUpdateMobileRateAdjustmentGroup - mobileRateAdjustmentGroup.businessType..........', mobileRateAdjustmentGroup.businessType);
        $log.info('addUpdateMobileRateAdjustmentGroup - mobileRateAdjustmentGroup.effectiveDate..........', mobileRateAdjustmentGroup.effectiveDate);
        //$log.info('addUpdateMobileRateAdjustmentGroup - mobileRateAdjustmentGroup.state..........', mobileRateAdjustmentGroup.state);
        //$log.info('addUpdateMobileRateAdjustmentGroup - mobileRateAdjustmentGroup.systemType..........', mobileRateAdjustmentGroup.systemType);
        const foundModel = await this.getMobileRateAdjustmentGroup(mobileRateAdjustmentGroup.businessType, mobileRateAdjustmentGroup.effectiveDate);
        $log.info('addUpdateMobileRateAdjustmentModel - foundModel..........', foundModel);
        $log.info('addUpdateMobileRateAdjustmentGroup - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateMobileRateAdjustmentGroup - Updated MobileRateAdjustmentGroup ..........', mobileRateAdjustmentGroup.businessType);
            await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(foundModel._id)});
            //mobileRateAdjustmentGroup._id = foundModel._id;
            mobileRateAdjustmentGroup.createdTimestamp = foundModel.createdTimestamp;
            mobileRateAdjustmentGroup.updatedTimestamp = timestamp;
            mobileRateAdjustmentGroup.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateAdjustmentGroup);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: mobileRateAdjustmentGroup });
            returnModelDetails = await this.getMobileRateAdjustmentGroup(mobileRateAdjustmentGroup.businessType, mobileRateAdjustmentGroup.effectiveDate);
        } else {
            $log.info("addUpdateMobileRateAdjustmentGroup - Adding new MobileRateAdjustmentGroup ..........");
            mobileRateAdjustmentGroup.createdTimestamp = timestamp;
            mobileRateAdjustmentGroup.updatedTimestamp = timestamp;
            mobileRateAdjustmentGroup.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateAdjustmentGroup);
            returnModelDetails = await this.getMobileRateAdjustmentGroup(mobileRateAdjustmentGroup.businessType, mobileRateAdjustmentGroup.effectiveDate);
            //await this.updateProductManifest(productCode, mobileRateAdjustmentGroup.businessType, userHeaderDetails);
        }
        // $log.info('addUpdateMobileRateAdjustmentGroup - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }

    public async getMobileRateAdjustmentGroup(_businessType: string, _effectiveDate: string) {
        $log.info('getMobileRateAdjustmentGroup..........', _businessType);
        $log.info('getMobileRateAdjustmentGroup..........', _effectiveDate);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate});
        $log.info(`getMobileRateAdjustmentGroup - found model from ${_databaseName}..........`);
        // $log.info(`getMobileRateAdjustmentGroup - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getMobileRateAdjustmentGroupByBusinessType(_businessType: string) {
        $log.info('getMobileRateAdjustmentGroupByBusinessType..........', _businessType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getMobileRateAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`);
        // $log.info(`getMobileRateAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    /*public async getMobileRateAdjustmentGroupByProductAndStateAndSystemType(productCode: string, state: string, systemType: string) {
        $log.info('getMobileRateAdjustmentGroupByProductAndStateAndSystemType..........', productCode, state, systemType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({productCode: productCode, state: state, systemType: systemType}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getMobileRateAdjustmentGroupByProductAndStateAndSystemType - found models from ${_databaseName}..........`);
        // $log.info(`getMobileRateAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }*/

    public async getMobileRateAdjustmentGroupById(_id: string) {
        $log.info('getMobileRateAdjustmentGroupById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getMobileRateAdjustmentGroupById - foundProduct from ${_databaseName}..........`);
        // $log.info(`getMobileRateAdjustmentGroupById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllMobileRateAdjustmentGroups() {
        $log.info('getAllMobileRateAdjustmentGroups..........');
        let items: MobileRateAdjustmentGroup[] = null;
        try {
            items = await dbService.getCollection(_databaseName).find().toArray();
            $log.info(`Successfully found AllMobileRateAdjustmentGroups models from ${_databaseName}.`)
        } catch(error) {
            $log.error(`Failed to find modles from ${_databaseName}: ${error}`)
        }
        return items;
        /*return await dbService.getCollection(_databaseName).find().toArray().then(items => {
            $log.info(`Successfully found AllMobileRateAdjustmentGroups models from ${_databaseName}.`)
            $log.info(items);
            return items;
        }).catch(err => {
            $log.error(`Failed to find modles from ${_databaseName}: ${err}`)
        });*/
    }

    // public async deleteMobileRateAdjustmentGroup(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
    //     $log.info('deleteMobileRateAdjustmentGroup..........', _productCode);
    //     try {
    //         await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
    //         let productManifest = await productManifestService.getProductManifest(_productCode);
    //         $log.info('delete ${_referenceName} from productManifest..........', productManifest);
    //         productManifest[_productManifestReferenceName] = null;
    //         // await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
    //         this.updateProductManifest(_databaseName)

    //         return true;
    //     } catch (e) {
    //         $log.error('Error occurred while deleting the model from ${_database} ' + _productCode, e);
    //         return false;
    //     }
    // }

    public async deleteMobileRateAdjustmentGroupById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteMobileRateAdjustmentGroup..........', _id);
        try {
            const foundModel = await this.getMobileRateAdjustmentGroupById(_id);
            let productCode = Util.getProductCode(foundModel?.businessType);
            // $log.info('foundModel..........', foundModel);
            if ( foundModel != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                // let productManifest = await productManifestService.getProductManifest(_id); //TODO: We are not using productManifest anywhere in code then why we are fetching it
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                /*if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundModel.businessType, userHeaderDetails)
                }*/
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    /*private async updateProductManifest(_productCode: string, _businessType: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let qmsAdjustmentGroups = await this.getMobileRateAdjustmentGroupByBusinessType(_businessType);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateQmsAdjGroupList = [];
        for (const qag of qmsAdjustmentGroups) {
            // console.log(qag);
            $log.info(`updateProductManifest - qmsAdjustmentGroups ${qag.effectiveDate}, ${timestamp} ..........`);
            if ( qag.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${qag.effectiveDate}, ${qag._id} ..........`);
                if ( !updateQmsAdjGroupList.includes(qag._id) ) {
                    updateQmsAdjGroupList.push(qag._id); 
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${qag.effectiveDate}, ${qag._id} ..........`);
                    if ( !updateQmsAdjGroupList.includes(qag._id) ) {
                        updateQmsAdjGroupList.push(qag._id);
                    }
                    removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${qag.effectiveDate}, ${qag._id} ..........`);
                    await this.deleteMobileRateAdjustmentGroupById(qag._id, userHeaderDetails, false);
                }
            }
        }
        
        $log.info("updateProductManifest - updated Qms Adjustment Group List ..........", updateQmsAdjGroupList);
        if ( prodManifest.medSuppData == null ) {
            // prodManifest.medSuppData = new MedSuppData();
            prodManifest.medSuppData = {};
        }
        prodManifest.medSuppData.adjGroups = updateQmsAdjGroupList;

        // $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }*/

    public validateRequest (data) {
        $log.info('MobileRateAdjustmentGroupService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`MobileRateAdjustmentGroupService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

}