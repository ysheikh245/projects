import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { NonforfeitureRPU } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_NONFORFEITURE_RPU;
const MANIFEST_ID = 'nonforfeitureRPUId';

export class NonforfeitureRPUService extends GenericModelService {
    public async addUpdateNonforfeitureRPU(nonforfeitureRPUDetails: NonforfeitureRPU, userHeaderDetails: any) {
        $log.debug('NonforfeitureRPUService.addUpdateNonforfeitureRPU..........', nonforfeitureRPUDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, nonforfeitureRPUDetails.productCode, nonforfeitureRPUDetails, userHeaderDetails);
    }


    public async getNonforfeitureRPU(_productCode: string) {
        $log.debug('NonforfeitureRPUService.getNonforfeitureRPU..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getNonforfeitureRPUById(_id: string) {
        $log.debug('NonforfeitureRPUService.getNonforfeitureRPUById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllNonforfeitureRPUs() {
        $log.debug('NonforfeitureRPUService.getAllNonforfeitureRPU..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteNonforfeitureRPU(_objectId: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureRPUService.deleteNonforfeitureRPU..........', _objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, _objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteNonforfeitureRPUByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureRPUService.deleteNonforfeitureRPUByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureRPUService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('NonforfeitureRPUService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`NonforfeitureRPUService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

}