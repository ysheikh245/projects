import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Aed } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_AED;
const MANIFEST_ID = 'aedId';

export class AedService extends GenericModelService {
    public async addUpdateAed(aedDetails: Aed, userHeaderDetails: any) {
        $log.debug('AedService.addUpdateAed..........', aedDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, aedDetails.productCode, aedDetails, userHeaderDetails);
    }


    public async getAed(_productCode: string) {
        $log.debug('AedService.getAed..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getAedById(_id: string) {
        $log.debug('AedService.getAedById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllAeds() {
        $log.debug('AedService.getAllAeds..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteAed(objectId: string, userHeaderDetails: any) {
        $log.debug('AedService.deleteAed..........', objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteAedByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('AedService.deleteAedByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('AedService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('AedService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`AedService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}