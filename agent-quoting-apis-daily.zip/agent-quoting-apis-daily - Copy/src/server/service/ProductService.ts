import {$log} from "@tsed/common";
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {Product, ProductManifest} from '../models';
import {ProductManifestService} from './ProductManifestService';
import {AedService} from "./AedService";

import moment from 'moment';
import {ObjectId} from "mongodb";
import dbServiceV2 from '../db/DbServiceV2';
import { Util } from "../util/Util";
import {ProductUIConfigService} from "./ProductUIConfigService";

let dbService: any;
let aedService = new AedService();
let productUIConfigService = new ProductUIConfigService();

const productManifestService = new ProductManifestService();

const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`ProdutService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class ProductService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`ProductService..........constructor`);
        if (!ProductService.isInitilized) {
            $log.debug(`ProductService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`ProductService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            ProductService.isInitilized = true;
        }
    }
    public async addUpdateProduct(productDetails: Product, userHeaderDetails: any) {
        try { 
            // $log.info(`dbService..........`, dbService);
            // $log.info(`dbService.getCollection(DBConstants.TABLE_PRODUCT)..........`, dbService.getCollection(DBConstants.TABLE_PRODUCT));
            const foundProduct = await this.getProduct(productDetails.productCode);
            $log.info(`addUpdateProduct - foundProduct ...............`, foundProduct);
            $log.info(`addUpdateProduct - userHeaderDetails ..........`, userHeaderDetails);
            const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
            let updatedProductDetails = {};
            if ( foundProduct  && foundProduct.productCode ) {
                $log.info(`Updated product ..........`, productDetails.productCode);
                const query = { productCode: productDetails.productCode };
                productDetails.updatedTimestamp = timestamp;
                productDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';

                await dbService.getCollection(DBConstants.TABLE_PRODUCT).updateOne(query, { $set: productDetails });
                updatedProductDetails = this.getProduct(productDetails.productCode);
                $log.info(`addUpdateProduct - Updated Product..........`, updatedProductDetails);
            } else {
                $log.info("addUpdateProduct - Added new product ..........", productDetails.productCode);
                productDetails.createdTimestamp = timestamp;
                productDetails.updatedTimestamp = timestamp;
                productDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';

                await dbService.getCollection(DBConstants.TABLE_PRODUCT).insertOne(productDetails);
                let prodManifest: ProductManifest = {
                    productCode: productDetails.productCode,
                    _id: null,
                    aedId: null,
                    productUIConfig: null,
                    cashValueId: null,
                    nonforfeitureRPUId: null,
                    nonforfeitureETIId: null,
                    planId: null,
                    ratesId: null,
                    medSuppData: null,
                    createdTimestamp: timestamp,
                    updatedTimestamp: timestamp,
                    updatedBy: null
                };
                productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
                updatedProductDetails = this.getProduct(productDetails.productCode);
                $log.info(`addUpdateProduct - Inserted Product..........`, updatedProductDetails);
            }


            return updatedProductDetails;
        } catch (err) {
            $log.error(`Error occurred while addUpdateProduct for ${productDetails} `, err);
            throw new Error(err);
        }
    }


    public async getProduct(_productCode: string) {
        $log.info(`getProduct..........`, _productCode);
        try {
            const foundProduct = await dbService.getCollection(DBConstants.TABLE_PRODUCT).findOne({productCode: _productCode});
            $log.info(`getProduct - foundProduct..........`, foundProduct);
            return await this.populateProductStateInfo(foundProduct);
        } catch (err) {
            $log.error(`getProduct - Error occurred while getProduct for ${_productCode} `, err);
            throw new Error(err);
        }
   }

    // public async getProductById(_id: string) {
    //     $log.info(`getProductById..........`, _id);
    //     try {
    //         const foundProduct = await dbService.getCollection((DBConstants.TABLE_PRODUCT)).findOne({ _id: new ObjectId(_id) });
    //         $log.info(`getProductById - foundProduct..........`, foundProduct);
    //         return foundProduct;
    //     } catch (err) {
    //         $log.error(`getProductById - Error occurred while getProductById for ${_id}`, err);
    //         throw new Error(err);
    //     }
    // }

    public async getAllProducts() {
        $log.info(`getAllProducts..........`);

        try {
            $log.debug(dbService);
            let items = await dbService.getCollection(DBConstants.TABLE_PRODUCT).find().toArray();
            $log.info(`getAllProducts - Successfully found ` + items.length + ` Products.`)
            return await this.populateStateInformation(items);
            //return items;
        } catch (err) {
            $log.error(`getAllProducts - Error occurred while getAllProducts `, err);
            throw new Error(err);
        }
    }

    public async deleteProductById(_productId: string, userHeaderDetails: any) {
        $log.info(`deleteProductbyId..........`, _productId);
        try {
            await dbService.getCollection(DBConstants.TABLE_PRODUCT).deleteOne({_id: new ObjectId(_productId)});
            $log.info(`Deleted product by ID..........`, _productId);
            return true;
        } catch (error) {
            $log.error(`deleteProductById - Error occurred while deleting ` + _productId, error);
            throw new Error(error);
        }
    }

    public async deleteProduct(_productCode: string, userHeaderDetails: any) {
        $log.info(`deleteProduct..........`, _productCode);
        try {
            if ( this.isMedSupp(_productCode ) ) {
                const productManifest = await productManifestService.getProductManifest(_productCode);
                if ( productManifest != null ) {
                    const medSuppData = productManifest.medSuppData;

                    //array of adjustment Groups
                    const adjGroups = medSuppData.adjGroups;

                    if ( adjGroups != null ) {
                        for (var adjGroupId of adjGroups) {
                            $log.info(`deleteProduct - deleting adjustment group of ${adjGroupId}..........`);
                            await dbService.getCollection(DBConstants.TABLE_QMS_ADJUSTMENT_GROUP).deleteOne({_id: new ObjectId(adjGroupId)});
                        }                        
                    }

                    //array of state rates
                    const stateRates = medSuppData.stateRates;

                    if ( stateRates != null ) {
                        for ( var stateObj of stateRates ) {
                            $log.info(`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`);
                            $log.info(`deleteProduct - MedSupp details of ${stateObj.state}..........`);
                            $log.info(`~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`);
                            if ( stateObj.rates != null ) {
                                for (var rateId of stateObj.rates) {
                                    $log.info(`deleteProduct - deleting rate of ${rateId}..........`);
                                    await dbService.getCollection(DBConstants.TABLE_QMS_RATES).deleteOne({_id: new ObjectId(rateId)});
                                }                                  
                            }
                            if ( stateObj.areas != null ) {
                                for (var areaId of stateObj.areas) {
                                    $log.info(`deleteProduct - deleting area of ${areaId}..........`);
                                    await dbService.getCollection(DBConstants.TABLE_QMS_AREAS).deleteOne({_id: new ObjectId(areaId)});
                                }                                  
                            }
                        }
                    }                
                }
            } else {
                await dbService.getCollection(DBConstants.TABLE_CASH_VALUE).deleteOne({productCode: _productCode});
                await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_ETI).deleteOne({productCode: _productCode});
                await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_RPU).deleteOne({productCode: _productCode});
                await dbService.getCollection(DBConstants.TABLE_PLAN).deleteOne({productCode: _productCode});
                await dbService.getCollection(DBConstants.TABLE_RATE).deleteOne({productCode: _productCode});
            }

            await dbService.getCollection(DBConstants.TABLE_AED).deleteOne({productCode: _productCode});
            await productManifestService.deleteProductManifest(_productCode);
            await dbService.getCollection(DBConstants.TABLE_PRODUCT).deleteOne({productCode: _productCode});

            return true;
        } catch (err) {
            $log.error(`deleteProduct - Error occurred while deleting ` + _productCode, err);
            throw new Error(err);
        }
    }

    private isMedSupp(_productCode: string) {
        if ( _productCode == 'L030' || _productCode === 'S060' ) {
            return true;
        }

        return false;
    }

    public validateRequest (data) {
        $log.info('ProductService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`ProductService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

    private async populateStateInformation(items) {
        $log.info('ProductService.populateStateInformation() ::: Start');
        $log.info('Iterating items in the products array');
        let products = await Promise.all(items.map(async (item) => await this.populateProductStateInfo(item)));
        $log.info('ProductService.populateStateInformation() ::: Completed');
        return products;
    }

    private async populateProductStateInfo(item) {
        try {
            $log.info('ProductService.populateProductStateInfo() ::: Start', item);
            if (item['type'].includes('Health') || item['type'].includes('Life')) {
                $log.info(`Attempting to fetch ProductUIConfig information for `, item.productCode);
                const productUIConfig = await this.getProductUIConfig(item.productCode);
                //console.log(`productUIConfig`, productUIConfig);
                if (productUIConfig && productUIConfig != null) {
                    item['states'] = productUIConfig.jsonData.productDefinition.allowedChannels.allowedStates;
                    if(!this.isEmpty(productUIConfig.jsonData.productDefinition.displayName)) {
                        item['displayName'] = productUIConfig.jsonData.productDefinition.displayName
                    } else {
                        item['displayName'] = productUIConfig.jsonData.productDefinition.productTitle
                    }
                } else {
                    $log.info(`ProductUIConfig information for product is NULL or undefined: `, item.productCode);
                }
            } else {
                $log.info(`Product Type is not Health or Life:`, item.productCode);
            }
        } catch (err) {
            $log.error('ProductService.populateStateInformation() ::: Failed');
            $log.error(`Exception occurred while getting states for the Products`, err);
        }
        return item;
    }

    private async getProductUIConfig(productCode: string) {
        $log.info('ProductService.getProductUIConfig() ::: Start');
        const productUIConfig = await productUIConfigService.getProductUIConfig(productCode)
        $log.info('ProductService.getProductUIConfig() ::: Completed');
        return productUIConfig;
    }

    private isEmpty(data) {
        return (data === undefined || data == null || data.length == 0) ? true : false;
    }

}
