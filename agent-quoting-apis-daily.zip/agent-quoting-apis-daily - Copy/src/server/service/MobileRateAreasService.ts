import {$log} from "@tsed/common";
import {ObjectId, ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {ProductManifestService} from './ProductManifestService';

import moment from 'moment';
import dbServiceV2 from '../db/DbServiceV2';
import {Util} from "../util/Util";
import {MobileRateAreas} from "../models/MobileRateAreas";


const _databaseName = DBConstants.TABLE_MOBILE_RATE_AREAS;

const productManifestService = new ProductManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`MobileRateAreaService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}

export class MobileRateAreasService {
    private static isInitialized: boolean = false;
    constructor() {
        $log.debug(`MobileRateAreaService..........constructor`);
        if (!MobileRateAreasService.isInitialized) {
            $log.debug(`MobileRateAreaService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`MobileRateAreaService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            MobileRateAreasService.isInitialized = true;
        }
    }
    public async addUpdateMobileRateAreas(mobileRateAreas: MobileRateAreas, userHeaderDetails: any) {
        //const productCode = Util.getProductCode(mobileRateAreas?.businessType);
        const foundModel = await this.getMobileRateAreas(mobileRateAreas.businessType, mobileRateAreas.effectiveDate, mobileRateAreas.state);
        $log.info('addUpdateMobileRateAreas - foundModel..........', foundModel);
        $log.info('addUpdateMobileRateAreas - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateMobileRateAreas - Updated MobileRateArea ..........', foundModel.businessType);
            await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(foundModel._id)});
            //mobileRateAreas._id = foundModel._id;
            mobileRateAreas.createdTimestamp = foundModel.createdTimestamp;
            mobileRateAreas.updatedTimestamp = timestamp;
            mobileRateAreas.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateAreas);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: mobileRateAreas });
            returnModelDetails = await this.getMobileRateAreas(mobileRateAreas.businessType, mobileRateAreas.effectiveDate, mobileRateAreas.state);
        } else {
            $log.info("addUpdateMobileRateAreas - Adding new MobileRateAreas ..........");
            mobileRateAreas.createdTimestamp = timestamp;
            mobileRateAreas.updatedTimestamp = timestamp;
            mobileRateAreas.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateAreas);
            returnModelDetails = await this.getMobileRateAreas(mobileRateAreas.businessType, mobileRateAreas.effectiveDate, mobileRateAreas.state);
            //await this.updateProductManifest(productCode, mobileRateAreas.businessType, mobileRateAreas.state, userHeaderDetails);
        }
        $log.info('addUpdateMobileRateAreas - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }


    public async getMobileRateAreas(_businessType: string, _effectiveDate: string, _state: string) {
        $log.info('getMobileRateArea..........', _businessType);
        $log.info('getMobileRateArea..........', _effectiveDate);
        $log.info('getMobileRateArea..........', _state);
        //$log.info('getMobileRateArea..........', _systemType);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate, state: _state});
        $log.info(`getMobileRateArea - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getMobileRateAreasByBusinessTypeAndState(_businessType: string, _state: string) {
        $log.info('getMobileRateAreasByBusinessTypeAndState..........', _businessType);
        $log.info('getMobileRateAreasByBusinessTypeAndState..........', _state);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType, state: _state}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getMobileRateAreasByBusinessTypeAndState - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    public async getMobileRateAreaById(_id: string) {
        $log.info('getMobileRateAreaById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getMobileRateAreaById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllMobileRateAreas() {
        $log.info('getAllMobileRateAreas..........');
        let items: MobileRateAreas[] = null;
        try {
            items = await dbService.getCollection(_databaseName).find().toArray();
            $log.info(`Successfully found AllMobileRateAreas models from ${_databaseName}.`)
            return items;
        } catch (error) {
            $log.error(`Failed to find modules from ${_databaseName}: ${error}`)
        }
        return items;
        /*return await dbService.getCollection(_databaseName).find().toArray().then(items => {
            $log.info(`Successfully found AllMobileRateAreas models from ${_databaseName}.`)
            $log.info(items);
            return items;
        }).catch(err => {
            $log.error(`Failed to find modles from ${_databaseName}: ${err}`)
        });*/
    }

    // public async deleteMobileRateArea(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
    //     $log.info('deleteMobileRateArea..........', _productCode);
    //     try {
    //         await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
    //         let productManifest = await productManifestService.getProductManifest(_productCode);
    //         $log.info('delete ${_referenceName} from productManifest..........', productManifest);
    //         productManifest[_productManifestReferenceName] = null;
    //         // await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
    //         this.updateProductManifest(_databaseName)

    //         return true;
    //     } catch (e) {
    //         $log.error('Error occurred while deleting the model from ${_database} ' + _productCode, e);
    //         return false;
    //     }
    // }

    public async getMobileRateAreasByProductAndSystemType(_productCode: string, _systemType: string) {
        $log.info('getMobileRateAreasByProductAndSystemType..........', _productCode);
        $log.info('getMobileRateAreasByProductAndSystemType..........', _systemType);
        const foundModel = await dbService.getCollection(_databaseName).findOne({productCode: _productCode, systemType: _systemType});
        $log.info(`getMobileRateAreasByProductAndSystemType - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async deleteMobileRateAreaById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteMobileRateArea..........', _id);
        try {
            const foundModel = await this.getMobileRateAreaById(_id);
            const productCode = Util.getProductCode(foundModel?.businessType);
            $log.info('foundMobileRateArea..........', foundModel);
            if ( foundModel != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                let productManifest = await productManifestService.getProductManifest(_id);
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                /*if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundModel.businessType, foundModel.state, userHeaderDetails)
                }*/
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    /*private async updateProductManifest(_productCode: string, _businessType: string, _state: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let qmsAreas = await this.getMobileRateAreaByBusinessTypeState(_businessType, _state);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateMobileRateAreaList = [];
        for (const qmsArea of qmsAreas) {
            if ( qmsArea.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                if ( !updateMobileRateAreaList.includes(qmsArea._id) ) {
                    updateMobileRateAreaList.push(qmsArea._id);
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                    if ( !updateMobileRateAreaList.includes(qmsArea._id) ) {
                        updateMobileRateAreaList.push(qmsArea._id);
                    }
                    removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                    await this.deleteMobileRateAreaById(qmsArea._id, userHeaderDetails, false);
                }
            }
        }
   
        
        $log.info("updateProductManifest - updated Qms Area List ..........", updateMobileRateAreaList);
        if ( prodManifest.medSuppData == null ) {
            let medSuppData: MedSuppData  = {
                adjGroups: [],
                stateRates: []
            }

            prodManifest.medSuppData = medSuppData;

        }

        if ( prodManifest.medSuppData.stateRates == null || prodManifest.medSuppData.stateRates.length == 0 ) {

            let localStateRates: MedSuppStateData[] = [];
            prodManifest.medSuppData.stateRates = localStateRates;
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: []
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }


        $log.info("updateProductManifest - prodManifest.medSuppData.stateRates .......... " +  prodManifest.medSuppData.stateRates);
        let stateIndex =  prodManifest.medSuppData.stateRates.findIndex((element:MedSuppStateData) => {
            return element.state == _state;
        });
        $log.info("updateProductManifest - stateIndex .......... " +  stateIndex);
        if ( stateIndex != -1 ) {
            prodManifest.medSuppData.stateRates[stateIndex].areas = updateMobileRateAreaList;
        } else {
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: updateMobileRateAreaList
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }

        $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }*/

    public validateRequest (data) {
        $log.info('MobileRateAreaService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`MobileRateAreaService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

    public async getMobileRateAreasByBusinessType(_businessType: string) {
        $log.info('getMobileRateAreasByBusinessType..........', _businessType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getMobileRateAreasByBusinessType - found models from ${_databaseName}..........`);
        // $log.info(`getMobileRateAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

}