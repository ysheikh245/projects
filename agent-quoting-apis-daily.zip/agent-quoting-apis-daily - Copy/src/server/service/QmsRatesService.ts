import {$log} from "@tsed/common";
import {ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import dbServiceV2 from '../db/DbServiceV2';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {Util} from "../util/Util";
import {ProductManifestService} from './ProductManifestService';
import {QmsRates} from '../models/QmsRates';

import moment from 'moment';
import {MedSuppData, MedSuppStateData} from "../models";

let dbService: any;

const _databaseName = DBConstants.TABLE_QMS_RATES;

const productManifestService = new ProductManifestService();

const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`QmsRatesService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class QmsRatesService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`QmsRatesService..........constructor`);
        if (!QmsRatesService.isInitilized) {
            $log.debug(`QmsRatesService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`QmsRatesService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            QmsRatesService.isInitilized = true;
        }
    }

    public async addUpdateQmsRates(qmsRates: QmsRates, userHeaderDetails: any) {
        const productCode = Util.getProductCode(qmsRates?.businessType);
        const foundModel = await this.getQmsRates(qmsRates.businessType, qmsRates.effectiveDate, qmsRates.state);
        $log.info('addUpdateQmsRates - foundModel..........', foundModel);
        $log.info('addUpdateQmsRates - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateQmsRates - Updated QmsRates ..........', productCode);
            await dbService.getCollection(_databaseName).deleteOne({"_id": foundModel._id});
            //qmsRates._id = foundModel._id;
            qmsRates.createdTimestamp = foundModel.createdTimestamp;
            qmsRates.updatedTimestamp = timestamp;
            qmsRates.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsRates);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: qmsRates });
            returnModelDetails = await this.getQmsRates(qmsRates.businessType, qmsRates.effectiveDate, qmsRates.state);
        } else {
            $log.info("addUpdateQmsRates - Added new QmsRates ..........", productCode);
            qmsRates.createdTimestamp = timestamp;
            qmsRates.updatedTimestamp = timestamp;
            qmsRates.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsRates);
            returnModelDetails = await this.getQmsRates(qmsRates.businessType, qmsRates.effectiveDate, qmsRates.state);

            $log.info('addUpdateQmsRates..........', qmsRates.businessType);
            $log.info('addUpdateQmsRates..........', qmsRates.businessType);
            $log.info('addUpdateQmsRates..........', qmsRates.state);

            await this.updateProductManifest(productCode, qmsRates.businessType, qmsRates.state, userHeaderDetails);
        }


        $log.info('addUpdateQmsRates - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }


    public async getQmsRates(_businessType: string, _effectiveDate: string, _state: string) {
        $log.info('getQmsRates..........', _businessType);
        $log.info('getQmsRates..........', _effectiveDate);
        $log.info('getQmsRates..........', _state);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate, state: _state});
        $log.info(`getQmsRates - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getQmsRatesByBusinessTypeState(_businessType: string, _state: string) {
        $log.info('getQmsRatesByBusinessType..........', _businessType);
        $log.info('getQmsRatesByBusinessType..........', _state);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType, state: _state}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getQmsRatesByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    public async getQmsRatesById(_id: string) {
        $log.info('getQmsRatesById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getQmsRatesById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllQmsRates() {
        $log.info('getAllQmsRates..........');
        let items: QmsRates[] = null;
        try {
            $log.debug(dbService);
            items = await dbService.getCollection(_databaseName).find().toArray()
            $log.info(`Successfully found AllQmsRatess models from ${_databaseName}.`)
            return items;
        } catch(error) {
            $log.error(`Failed to find modles from ${_databaseName}: ${error}`)
        }
        return items;
        /*$log.info('getAllQmsRates..........');
        return await dbService.getCollection(_databaseName).find().toArray().then(items => {
            $log.info(`Successfully found AllQmsRatess models from ${_databaseName}.`)
            $log.info(items);
            return items;
        }).catch(err => {
            $log.error(`Failed to find modles from ${_databaseName}: ${err}`)
        });*/
    }

    // public async deleteQmsRates(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
    //     $log.info('deleteQmsRates..........', _productCode);
    //     try {
    //         await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
    //         let productManifest = await productManifestService.getProductManifest(_productCode);
    //         $log.info('delete ${_referenceName} from productManifest..........', productManifest);
    //         productManifest[_productManifestReferenceName] = null;
    //         // await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
    //         this.updateProductManifest(_databaseName)

    //         return true;
    //     } catch (e) {
    //         $log.error('Error occurred while deleting the model from ${_database} ' + _productCode, e);
    //         return false;
    //     }
    // }

    public async deleteQmsRatesById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteQmsRates..........', _id);
        try {
            const foundQmsAdjGroup = await this.getQmsRatesById(_id);
            const productCode = Util.getProductCode(foundQmsAdjGroup?.businessType);
            // $log.info('foundQmsRates..........', foundQmsAdjGroup);
            if ( foundQmsAdjGroup != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                let productManifest = await productManifestService.getProductManifest(_id);
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundQmsAdjGroup.businessType, foundQmsAdjGroup.state, userHeaderDetails)
                }
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    private async updateProductManifest(_productCode: string, _businessType: string, _state: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let qmsRatess = await this.getQmsRatesByBusinessTypeState(_businessType, _state);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateQmsRatesList = [];
        for (const qmsRates of qmsRatess) {
            if ( qmsRates.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${qmsRates.effectiveDate}, ${qmsRates._id} ..........`);
                if ( !updateQmsRatesList.includes(qmsRates._id) ) {
                    updateQmsRatesList.push(qmsRates._id);
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${qmsRates.effectiveDate}, ${qmsRates._id} ..........`);
                    if ( !updateQmsRatesList.includes(qmsRates._id) ) {
                        updateQmsRatesList.push(qmsRates._id);
                    }
                        removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${qmsRates.effectiveDate}, ${qmsRates._id} ..........`);
                    await this.deleteQmsRatesById(qmsRates._id, userHeaderDetails, false);
                }
            }
        }
   
        
        $log.info("updateProductManifest - updated Qms Rate List ..........", updateQmsRatesList);
        if ( prodManifest.medSuppData == null ) {
            let medSuppData: MedSuppData  = {
                adjGroups: [],
                stateRates: []
            }

            prodManifest.medSuppData = medSuppData;

        }

        if ( prodManifest.medSuppData.stateRates == null || prodManifest.medSuppData.stateRates.length == 0 ) {

            let localStateRates: MedSuppStateData[] = [];
            prodManifest.medSuppData.stateRates = localStateRates;
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: []
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }


        $log.info("updateProductManifest - prodManifest.medSuppData.stateRates .......... " +  prodManifest.medSuppData.stateRates);
        let stateIndex =  prodManifest.medSuppData.stateRates.findIndex((element:MedSuppStateData) => {
            return element.state == _state;
        });


        $log.info("updateProductManifest - stateIndex .......... " +  stateIndex);
        if ( stateIndex != -1 ) {
            prodManifest.medSuppData.stateRates[stateIndex].rates = updateQmsRatesList;
        } else {
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: updateQmsRatesList,
                areas: []
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }

        $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('QmsRatesService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`QmsRatesService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

    public async getQMSRatesByBusinessType(_businessType: string) {
        $log.info('getQMSRatesByBusinessType..........', _businessType);
        //const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType});
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModel = foundModelsCursor.toArray();
        $log.info(`getQMSRatesByBusinessType - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

}