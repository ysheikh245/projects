import {$log} from "@tsed/common";
import {ObjectId, ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {ProductManifestService} from './ProductManifestService';
import {QmsAdjustmentGroup} from '../models/QmsAdjustmentGroup';

import moment from 'moment';
import dbServiceV2 from '../db/DbServiceV2';
import {Util} from "../util/Util";


const _databaseName = DBConstants.TABLE_QMS_ADJUSTMENT_GROUP;

const productManifestService = new ProductManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`QmsAdjustmentGroupService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class QmsAdjustmentGroupService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`QmsAdjustmentGroupService..........constructor`);
        if (!QmsAdjustmentGroupService.isInitilized) {
            $log.debug(`QmsAdjustmentGroupService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`QmsAdjustmentGroupService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            QmsAdjustmentGroupService.isInitilized = true;
        }
    }
    public async addUpdateQmsAdjustmentGroup(qmsAdjustmentGroup: QmsAdjustmentGroup, userHeaderDetails: any) {
        const productCode = Util.getProductCode(qmsAdjustmentGroup?.businessType);
        $log.info('addUpdateQmsAdjustmentModel - qmsAdjustmentGroup.businessType..........', qmsAdjustmentGroup.businessType);
        $log.info('addUpdateQmsAdjustmentModel - qmsAdjustmentGroup.effectiveDate..........', qmsAdjustmentGroup.effectiveDate);
        const foundModel = await this.getQmsAdjustmentGroup(qmsAdjustmentGroup.businessType, qmsAdjustmentGroup.effectiveDate);
        $log.info('addUpdateQmsAdjustmentModel - foundModel..........', foundModel);
        $log.info('addUpdateQmsAdjustmentModel - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateQmsAdjustmentGroup - Updated QmsAdjustmentGroup ..........', productCode);
            await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(foundModel._id)});
            //qmsAdjustmentGroup._id = foundModel._id;
            qmsAdjustmentGroup.createdTimestamp = foundModel.createdTimestamp;
            qmsAdjustmentGroup.updatedTimestamp = timestamp;
            qmsAdjustmentGroup.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsAdjustmentGroup);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: qmsAdjustmentGroup });
            returnModelDetails = await this.getQmsAdjustmentGroup(qmsAdjustmentGroup.businessType, qmsAdjustmentGroup.effectiveDate);
        } else {
            $log.info("addUpdateQmsAdjustmentGroup - Added new QmsAdjustmentGroup ..........", productCode);
            qmsAdjustmentGroup.createdTimestamp = timestamp;
            qmsAdjustmentGroup.updatedTimestamp = timestamp;
            qmsAdjustmentGroup.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsAdjustmentGroup);
            returnModelDetails = await this.getQmsAdjustmentGroup(qmsAdjustmentGroup.businessType, qmsAdjustmentGroup.effectiveDate);
            await this.updateProductManifest(productCode, qmsAdjustmentGroup.businessType, userHeaderDetails);
        }


        // $log.info('addUpdateQmsAdjustmentGroup - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }


    public async getQmsAdjustmentGroup(_businessType: string, _effectiveDate: string) {
        $log.info('getQmsAdjustmentGroup..........', _businessType);
        $log.info('getQmsAdjustmentGroup..........', _effectiveDate);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate});
        $log.info(`getQmsAdjustmentGroup - found model from ${_databaseName}..........`);
        // $log.info(`getQmsAdjustmentGroup - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getQmsAdjustmentGroupByBusinessType(_businessType: string) {
        $log.info('getQmsAdjustmentGroupByBusinessType..........', _businessType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getQmsAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`);
        // $log.info(`getQmsAdjustmentGroupByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    public async getQmsAdjustmentGroupById(_id: string) {
        $log.info('getQmsAdjustmentGroupById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getQmsAdjustmentGroupById - foundProduct from ${_databaseName}..........`);
        // $log.info(`getQmsAdjustmentGroupById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllQmsAdjustmentGroups() {
        $log.info('getAllQmsAdjustmentGroups..........');
        let items: QmsAdjustmentGroup[] = null;
        try {
            items = await dbService.getCollection(_databaseName).find().toArray();
            $log.info(`Successfully found AllQmsAdjustmentGroups models from ${_databaseName}.`)
        } catch(error) {
            $log.error(`Failed to find modles from ${_databaseName}: ${error}`)
        }
        return items;
        /*return await dbService.getCollection(_databaseName).find().toArray().then(items => {
            $log.info(`Successfully found AllQmsAdjustmentGroups models from ${_databaseName}.`)
            $log.info(items);
            return items;
        }).catch(err => {
            $log.error(`Failed to find modles from ${_databaseName}: ${err}`)
        });*/
    }

    // public async deleteQmsAdjustmentGroup(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
    //     $log.info('deleteQmsAdjustmentGroup..........', _productCode);
    //     try {
    //         await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
    //         let productManifest = await productManifestService.getProductManifest(_productCode);
    //         $log.info('delete ${_referenceName} from productManifest..........', productManifest);
    //         productManifest[_productManifestReferenceName] = null;
    //         // await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
    //         this.updateProductManifest(_databaseName)

    //         return true;
    //     } catch (e) {
    //         $log.error('Error occurred while deleting the model from ${_database} ' + _productCode, e);
    //         return false;
    //     }
    // }

    public async deleteQmsAdjustmentGroupById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteQmsAdjustmentGroup..........', _id);
        try {
            const foundQmsAdjGroup = await this.getQmsAdjustmentGroupById(_id);
            let productCode = Util.getProductCode(foundQmsAdjGroup?.businessType);
            // $log.info('foundQmsAdjGroup..........', foundQmsAdjGroup);
            if ( foundQmsAdjGroup != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                // let productManifest = await productManifestService.getProductManifest(_id); //TODO: We are not using productManifest anywhere in code then why we are fetching it
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundQmsAdjGroup.businessType, userHeaderDetails)
                }
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    private async updateProductManifest(_productCode: string, _businessType: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let qmsAdjustmentGroups = await this.getQmsAdjustmentGroupByBusinessType(_businessType);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateQmsAdjGroupList = [];
        for (const qag of qmsAdjustmentGroups) {
            // console.log(qag);
            $log.info(`updateProductManifest - qmsAdjustmentGroups ${qag.effectiveDate}, ${timestamp} ..........`);
            if ( qag.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${qag.effectiveDate}, ${qag._id} ..........`);
                if ( !updateQmsAdjGroupList.includes(qag._id) ) {
                    updateQmsAdjGroupList.push(qag._id); 
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${qag.effectiveDate}, ${qag._id} ..........`);
                    if ( !updateQmsAdjGroupList.includes(qag._id) ) {
                        updateQmsAdjGroupList.push(qag._id);
                    }
                    removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${qag.effectiveDate}, ${qag._id} ..........`);
                    await this.deleteQmsAdjustmentGroupById(qag._id, userHeaderDetails, false);
                }
            }
        }
        
        $log.info("updateProductManifest - updated Qms Adjustment Group List ..........", updateQmsAdjGroupList);
        if ( prodManifest.medSuppData == null ) {
            // prodManifest.medSuppData = new MedSuppData();
            prodManifest.medSuppData = {};
        }
        prodManifest.medSuppData.adjGroups = updateQmsAdjGroupList;

        // $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('QmsAdjustmentGroupService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`QmsAdjustmentGroupService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

}