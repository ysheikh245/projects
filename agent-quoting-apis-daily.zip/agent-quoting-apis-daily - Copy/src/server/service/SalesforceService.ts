import {$log} from '@tsed/common';
import {Util} from '../util/Util'
import {Constants} from '../util/Constants';
import {SalesForceConnectionService} from "../salesforce/SalesForceConnectionService";
import {isNotEmpty} from "../util/StringUtility";
import { SalesForceHelper }  from '../salesforce/SalesForceHelper';
import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'

const Axios = axios.create({
  responseType: 'json'
});


const salesForceHelper = new SalesForceHelper();


// const salesForceHelper = require('../salesforce/SalesForceHelper')

export class SalesforceService {

    public async addOpportunityQuote(opportunityJSON: any) {
        $log.info('SalesforceService.addOpportunityQuote - Start');
        var credentials = Util.config.credentials[Constants.SALESFORCE_BATCH_CONFIG_KEY];
        var salesforceLoginURL = Util.addPathSegment(credentials.host, credentials['context-root']);
        $log.debug('salesforceLoginURL........... ', salesforceLoginURL);

        let connection = null;
        let updateQuoteResult = null;

        try {
            $log.info('SalesforceService.addOpportunityQuote - Attempting to establish connection to SalesForce');
            connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY);
            $log.info('SalesforceService.addOpportunityQuote - SalesForce connection established');
            updateQuoteResult = await connection.update('Opportunity', this.getOpportunityObject(opportunityJSON));
            $log.info('SalesforceService.addOpportunityQuote - Updated Opportunity Information with SalesForce');
        } catch(error) {
            $log.info(`SalesforceService.addOpportunityQuote - Failed. Error=${error.stack}`);
            //console.error(`Error=${error.stack}`);
            //console.error(`Code=${error.code}`);
            if(error && error.stack && error.stack.includes('ETIMEDOUT')) {
                $log.info('SalesforceService.addOpportunityQuote - Reattempting to establish SalesForceConnection');
                connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY, true);
                updateQuoteResult = await connection.update('Opportunity', this.getOpportunityObject(opportunityJSON));
                $log.info('SalesforceService.addOpportunityQuote - Reattempt successful');
            } else {
                $log.error('SalesforceService.addOpportunityQuote - Doesnt look like an timeout error. Throwing Error back');
                throw error;
            }
        }

        if(updateQuoteResult && !updateQuoteResult.success) {
            $log.error(`SalesforceService.addOpportunityQuote error ........... , ${updateQuoteResult.errors[0]}`);
            throw updateQuoteResult.errors[0];
        } else {
            $log.info('SalesforceService.addOpportunityQuote - Completed');
            return null;
        }
    }

    public async addOpportunityQuoteHistory(requestBody) {
        $log.info('SalesforceService.addOpportunityQuoteHistory - Start');
        try {
            var credentials = Util.config.credentials[Constants.PRODUCT_API_CONFIG_KEY];
            let PRODUCT_API_URL = Util.addPathSegment(credentials.host, credentials['context-root']);

            let headers = {
                'Authorization': `Basic ${Buffer.from(`${credentials.username}:${credentials.password}`).toString('base64')}`,
                'content-type': 'application/json',
                'client-header': 'mobile@pmic.com'
            }

            $log.info('Attempting to invoke product API quotes history API');
            await Axios.post(PRODUCT_API_URL, JSON.stringify(requestBody),  {headers});

            // await requestPromise.post(PRODUCT_API_URL + "/quoteshistory", {
            //     body: JSON.stringify(requestBody),
            //     headers: headers
            // });
            $log.info('Completed invoking product API quotes history API');
            $log.info('SalesforceService.addOpportunityQuoteHistory - Completed');
        } catch(error) {
            $log.error('SalesforceService.addOpportunityQuoteHistory - Failed');
            throw error;
        }
    }

    public validateRequest(username:string, password:string) {
        $log.info('SalesforceService-validateRequest(): Start');
        let validRequest: boolean = isNotEmpty(username) && isNotEmpty(password); 
        $log.info('SalesforceService-validateRequest(): Completed. validRequest flag=' + validRequest);
        return validRequest;

    }

    public async getSpecificSalesForceConnection(username:string, password:string) {
        $log.info('SalesforceService-getSpecificSalesForceConnection(): Start');
        let connection = await SalesForceConnectionService.getSpecificSalesForceConnection(Constants.SALESFORCE_LOGIN_CONFIG_KEY, username, password);
        $log.info('SalesforceService-getSpecificSalesForceConnection(): Completed');
        return connection;
    }

    public async queryUserTable(connection, userId, columns) {
        $log.info('SalesforceService-queryUserTable(): Start');
        let userQueryResult = await connection.query("SELECT " + columns + " FROM User where Id = '" + userId + "'");
        $log.info('SalesforceService-queryUserTable(): Completed');
        return userQueryResult;
    }

    public async queryContactTable(connection, contactId, columns) {
        $log.info('SalesforceService-queryContactTable(): Start');
        let contactQueryResult = await connection.query("SELECT " + columns + " FROM Contact where Id = '" + contactId + "'");
        $log.info('SalesforceService-queryContactTable(): Completed');
        return contactQueryResult;
    }

    public async queryAccountTable(connection, accountId, columns) {
        $log.info('SalesforceService-queryAccountTable(): Start');
        let accountQueryResult = await connection.query("SELECT " + columns + " FROM Account WHERE Id = '" + accountId + "'")
        $log.info('SalesforceService-queryAccountTable(): Completed');
        return accountQueryResult;
    }

    public async isUserActive(connection, userId) {
        $log.info('SalesforceService-isUserActive(): Start');
        let userQueryResult = await this.queryUserTable(connection, userId, Constants.SALES_FORCE_USER_IS_ACTIVE_COLUMN);
        $log.info('SalesforceService-isUserActive(): Completed');
        return (userQueryResult && userQueryResult.records) ? userQueryResult.records[0].IsActive : false;
    }

    public async getUserRecord(connection, userId) {
        $log.info('SalesforceService-getUserRecord(): Start');
        let userQueryResult = await this.queryUserTable(connection, userId, Constants.SALES_FORCE_USER_QUERY_FIELDS);
        $log.info('SalesforceService-getUserRecord(): Completed');
        return (userQueryResult && userQueryResult.records) ? (userQueryResult.records[0]) : null;
    }

    public async getUserContactRecord(connection, contactId) {
        $log.info('SalesforceService-getUserContactRecord(): Start');
        let userContactRecords = await this.queryContactTable(connection, contactId, Constants.SALES_FORCE_CONTACT_QUERY_FIELDS)
        $log.info('SalesforceService-getUserContactRecord(): Completed');
        return (userContactRecords && userContactRecords.records) ? (userContactRecords.records[0]) : null;
    }

    public async getUserAccountRecord(connection, contactId) {
        $log.info('SalesforceService-getUserAccountRecord(): Start');
        let userAccountRecords = await this.queryAccountTable(connection, contactId, Constants.SALES_FORCE_ACCOUNT_QUERY_FIELDS)
        $log.info('SalesforceService-getUserAccountRecord(): Completed');
        return (userAccountRecords && userAccountRecords.records) ? (userAccountRecords.records[0]) : null;
    }

    public async getDetailedUserRecord(username: string, userConsolidatedRecord) {
        $log.info('SalesforceService-getDetailedUserRecord(): Start');
        let detailedUserConsolidatedRecord : any = new Object();
        detailedUserConsolidatedRecord.userType = (username.match((/^\d+$/))) ? "AGENT" : "EMPLOYEE";
        await salesForceHelper.copyTo(userConsolidatedRecord.userRecord, salesForceHelper.getUserMapping(), detailedUserConsolidatedRecord);
        await salesForceHelper.copyTo(userConsolidatedRecord.contactRecord, salesForceHelper.getContactMapping(), detailedUserConsolidatedRecord);
        await salesForceHelper.copyTo(userConsolidatedRecord.divisionOfficeRecord, salesForceHelper.divisionOfficeMapping, detailedUserConsolidatedRecord);

        if (userConsolidatedRecord.Address != null) {
            //await this.populateAddressInDetailedUserConsolidatedRecord(userConsolidatedRecord, detailedUserConsolidatedRecord);
            await salesForceHelper.copyTo(userConsolidatedRecord.Address, salesForceHelper.addressMapping, detailedUserConsolidatedRecord);
        }

        if (userConsolidatedRecord.contactRecord.MailingAddress != null) {
            //await salesForceService.populateMailingAddressInDetailedUserConsolidatedRecord(userConsolidatedRecord, detailedUserConsolidatedRecord);
            await salesForceHelper.copyTo(userConsolidatedRecord.contactRecord.MailingAddress, salesForceHelper.addressMapping, detailedUserConsolidatedRecord);
        }

        $log.info('SalesforceService-getDetailedUserRecord(): Completed');
        return detailedUserConsolidatedRecord;
    }

    private getOpportunityObject(opportunityJSON: any) {
        return {
            "Id": opportunityJSON.opportunityId,
            "Change_Type__c": "U",
            "Change_Type_Name__c": "QuoteApp",
            "StageName": "Provided Quote",
            "Stage_Reason__c": "Ran Presentation"
        };
    }
}