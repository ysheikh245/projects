import { $log } from '@tsed/common';
import { DbService } from '../db/DbService';
import { DBConstants } from '../db/DbConstants';
import { Constants } from '../util/Constants';
import { CommonManifestService } from './CommonManifestService';
import { CommonManifest } from '../models';


import moment from 'moment';
import { GenericAuditModel } from "../models";
import { ObjectId } from "mongodb";
import dbServiceV2 from '../db/DbServiceV2';
import { Util } from "../util/Util";


const commonManifestService = new CommonManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`ModService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}

const MODEL_DATABASE = DBConstants.TABLE_MOD;
const MANIFEST_ID = 'modId';

export class ModService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`ModService..........constructor`);
        if (!ModService.isInitilized) {
            $log.debug(`ModService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`ModService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            ModService.isInitilized = true;
        }
    }
    public async addUpdateMod(auditModel: GenericAuditModel, userHeaderDetails: any) {
        $log.debug(`addUpdateModel - start..........`);
        try {
            let foundModel = await this.getMod();
            $log.info(`addUpdateModel - foundModel..........`, foundModel);
            $log.info(`addUpdateModel - userHeaderDetails..........`, userHeaderDetails);
            const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
            let returnModelDetails:any;
            if (foundModel != null) {
                $log.info(`addUpdateModel - Updated mod ..........`);
                const query = { _id: new ObjectId(foundModel._id) };
                auditModel._id = foundModel._id;
                auditModel.createdTimestamp = foundModel.createdTimestamp;
                auditModel.updatedTimestamp = timestamp;
                auditModel.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
    
                await dbService.getCollection(MODEL_DATABASE).updateOne(query, { $set: auditModel });
                returnModelDetails = await this.getMod();
                $log.info(`addUpdateModel - Updated mod..........`, returnModelDetails);
                return returnModelDetails;
            } else {
                $log.info(`addUpdateModel - Added new mod ..........`);
                auditModel.createdTimestamp = timestamp;
                auditModel.updatedTimestamp = timestamp;
                auditModel.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
    
                await dbService.getCollection(MODEL_DATABASE).insertOne(auditModel);
                returnModelDetails = await this.getMod();
                $log.info(`addUpdateModel - Updated mod..........`, returnModelDetails);
                returnModelDetails = await this.updateCommonManifestReferenceId(userHeaderDetails);
                $log.info(`addUpdateModel - Inserted mod..........`, returnModelDetails);
                return returnModelDetails;
    }   
        } catch (e) {
            $log.error(`Error occurred while getAllModels from ${MODEL_DATABASE}`, e);
            throw new Error(e);
        }
    }


    public async getMod() {
        const foundModel = await dbService.getCollection(MODEL_DATABASE).findOne({}, {sort: {"updatedTimestamp": -1}});
        $log.info(`getMod - found model from ${MODEL_DATABASE}..........`, foundModel);
        return foundModel;
    }

    public async getModById(_id: string) {
        $log.info(`getModById..........`, _id);
        try {
            //const foundProduct = await dbService.getCollection(MODEL_DATABASE).findOne({_id: _id});
            const foundProduct = await dbService.getCollection(MODEL_DATABASE).findOne({_id: new ObjectId(_id)});
            $log.info(`getModById - foundProduct..........`, foundProduct);
            return foundProduct;
        } catch (e) {
            $log.error(`getModById - Error occurred while getAllModels from ${MODEL_DATABASE}`, e);
            throw new Error(e);
        }
    }

    public async getAllMods() {
        $log.info(`getAllMods..........`);
        try {
            let items = await dbService.getCollection(MODEL_DATABASE).find().toArray();
            $log.info(`getAllMods - Successfully found all models from ${MODEL_DATABASE}.`)
            $log.info(items);
            return items;
        } catch (e) {
            $log.error(`getAllMods - Error occurred while getAllModels from ${MODEL_DATABASE}`, e);
            throw new Error(e);
        }
    }

    public async deleteMod(userHeaderDetails: any, id: string) {
        $log.info(`deleteMod..........`);
        try {
            let filter = (id != null) ? {_id: new ObjectId(id)} : {}
            await dbService.getCollection(MODEL_DATABASE).deleteOne(filter);
            let commonManifest = await commonManifestService.getCommonManifest();
            if ( commonManifest != null ) {
                $log.info(`deleteModel - delete mod from commonManifest..........`, commonManifest);
                commonManifest.modId = null;
                await commonManifestService.addUpdateCommonManifest(commonManifest, userHeaderDetails);
            }

            return true;
        } catch (e) {
            $log.error(`deleteMod - Error occurred while deleting the mod from ${MODEL_DATABASE}`, e);
            throw new Error(e);
        }
    }

    public async updateCommonManifestReferenceId(userHeaderDetails: any) {
        $log.info(`updateCommonManifestReferenceId..........`);
        try {
            let returnModDetails = await this.getMod();

            $log.info("updateCommonManifestReferenceId - returnModelDetails ..........", returnModDetails);
            let commonManifest = await commonManifestService.getCommonManifest();
            if ( commonManifest == null ) {
                commonManifest = {
                };                
                // // $log.error(`updateCommonManifestReferenceId - There was not a commonManifest manifest defined with the mod from ${MODEL_DATABASE}`);
                // // throw new Error('No Product Manifest Defined');
            }
            commonManifest.modId = returnModDetails._id;
            
            $log.info("updateCommonManifestReferenceId - prodManifest ..........", commonManifest);
            await commonManifestService.addUpdateCommonManifest(commonManifest, userHeaderDetails);

            return returnModDetails;
        } catch (e) {
            $log.error(`updateCommonManifestReferenceId - Error occurred while updating the manifest with the mod model from ${MODEL_DATABASE}`, e);
            throw e;
        }
    }

    public validateRequest (data) {
        $log.info('ModService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`ModService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}