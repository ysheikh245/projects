import {SalesForceConnectionService} from "../salesforce/SalesForceConnectionService";

import {isNotEmpty, isAlphaNumeric} from '../util/StringUtility'
import {Constants} from "../util";
import {$log} from "@tsed/common";

export class CheckUserValidityService {

    public validateRequest (userId: string) {
        $log.info(`CheckUserValidityService-validateRequest. UserId=${userId}`);
        return (isNotEmpty(userId) && isAlphaNumeric(userId));
    }

    // const checkUserValidity = async (id: string) => {
    public async checkUserValidity (id: string) {
        let connection = null;
        let result = null;
        // this is for performance improvement and also ensures we don't error out; we try to use cached connection.
        try {
            $log.info('CheckUserValidityService-checkUserValidity(): Start');
            $log.info('CheckUserValidityService-checkUserValidity(). Attempting to query the user in SalesForce');
            connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY);
            result     = await connection.query("SELECT IsActive FROM User where Id = '" + id + "'");
            $log.info('CheckUserValidityService-checkUserValidity(). SalesForce responded with results');
        } catch(error) { // In case of an error, we force to re-connect by passing force=true in the catch block
            $log.error(`CheckUserValidityService-checkUserValidity(): Failed. Error Occurred =${error.stack}. Re-attempting to connect to SalesForce`);
            connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY, true);
            result     = await connection.query("SELECT IsActive FROM User where Id = '" + id + "'");
        }

        if(!result || result.totalSize ==0) {
            $log.error('CheckUserValidityService-checkUserValidity(): No records returned from SalesForce');
            throw Error('No records were returned from user query');
        } else if(result.totalSize > 0) {
            $log.info('CheckUserValidityService-checkUserValidity(): Completed');
            return result.records[0].IsActive
        } else {
            $log.error('CheckUserValidityService-checkUserValidity(): An unknown error occurred');
            throw Error('An unknown error occurred!'); // code should not never reach here; but just in case
        }
    }
}
// const validateRequest = (userId: string) => {
//     return (isNotEmpty(userId) && isAlphaNumeric(userId));
// }

// const checkUserValidity = async (id: string) => {
//     let connection = null;
//     let result = null;
//     // this is for performance improvement and also ensures we don't error out; we try to use cached connection.
//     try {
//         connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY);
//         result     = await connection.query("SELECT IsActive FROM User where Id = '" + id + "'");
//     } catch(error) { // In case of an error, we force to re-connect by passing force=true in the catch block
//         console.log('checkUserValidity. Error Occurred. Error= ' + error.stack);
//         connection = await SalesForceConnectionService.getSalesForceConnection(Constants.SALESFORCE_BATCH_CONFIG_KEY, true);
//         result     = await connection.query("SELECT IsActive FROM User where Id = '" + id + "'");
//     }

//     if(!result || result.totalSize ==0) {
//         throw Error('No records were returned from user query');
//     } else if(result.totalSize > 0) {
//         return result.records[0].IsActive
//     } else {
//         throw Error('An unknown error occurred!'); // code should not never reach here; but just in case
//     }
// }

// exports.validateRequest   = validateRequest;
// exports.checkUserValidity = checkUserValidity;