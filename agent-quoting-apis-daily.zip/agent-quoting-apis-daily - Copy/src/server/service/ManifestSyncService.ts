import {DBConstants} from "../db/DbConstants";
import {ManifestSync, Mod, Product, ManifestMedSuppData, ManifestSyncAdjustmentGroup} from "../models/ManifestSync";
import {$log} from "@tsed/common";
import {GenericModelService} from "./GenericModelService";
import {ProductService} from "./ProductService";
import {AedService} from "./AedService";
import {PlanService} from "./PlanService";
import {RateService} from "./RateService";
import {CashValueService} from "./CashValueService";
import {NonforfeitureRPUService} from "./NonforfeitureRPUService";
import {NonforfeitureETIService} from "./NonforfeitureETIService";
import {
    Aed,
    CashValue,
    NonforfeitureETI,
    NonforfeitureRPU,
    Plan,
    ProductManifest,
    QmsAdjustmentGroup,
    QmsArea,
    QmsRates,
    Rate
} from "../models";
import {ModService} from "./ModService";
import {ProductManifestService} from "./ProductManifestService";
import {Constants} from "../util";
import {QmsAdjustmentGroupService} from "./QmsAdjustmentGroupService";
import {QmsAreaService} from "./QmsAreaService";
import {QmsRatesService} from "./QmsRatesService";
import { Util } from "../util/Util";

const MODEL_DATABASE = DBConstants.TABLE_PRODUCT_MANIFEST;

export class ManifestSyncService extends GenericModelService {

    private aedService = new AedService();
    private planService = new PlanService();
    private rateService = new RateService();
    private cashValueService = new CashValueService();
    private nonforfeitureRPUService = new NonforfeitureRPUService();
    private nonforfeitureETIService = new NonforfeitureETIService();
    private productService = new ProductService();
    private modService = new ModService();
    private productManifestService = new ProductManifestService();
    private qmsAdjustmentGroupService = new QmsAdjustmentGroupService();
    private qmsAreaService = new QmsAreaService();
    private qmsRatesService = new QmsRatesService();

    /**
     * Validates the incoming request
     * @param appManifest
     */
    public validateRequest(appManifest: ManifestSync) {
        $log.info('ManifestSyncService.validateRequest() ::: Start');
        // request is validate only if
        //  (a) appManifest is present and
        //  (b) either PRODUCTS array or MOD object is present in the request
        let validRequest: boolean = (appManifest && ((appManifest.products && appManifest.products.length>0) || (appManifest.mod && Object.keys(appManifest.mod).length>0)));
        $log.info(`ManifestSyncService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

    /**
     * Gets the manifest sync for all the products - GET request
     */
    public async getManifestSyncForAllProducts() {
        $log.info('ManifestSyncService.getManifestSyncForAllProducts ::: Start');
        let products = await super.getAllModels(MODEL_DATABASE);
        let appManifest = new ManifestSync();

        // Iterate through the Products and form the response
        if(products != null) {
            $log.info('ManifestSyncService.getManifestSync - Products found in DB: ' + products.length);
            for (let _product of products) {
                let manifestSyncProduct = await this.mapManifestSyncProduct(_product);
                appManifest.products.push(manifestSyncProduct);
            }
        } else {
            $log.info('ManifestSyncService.getManifestSyncForAllProducts ::: No records returned from the query');
        }
        $log.info('ManifestSyncService.getManifestSyncForAllProducts ::: Completed');
        return appManifest;
    }

    /**
     * Gets the manifest sync for a specific productCode - GET request
     * @param _productCode
     */
    public async getManifestSyncByProductCode(_productCode: string) {
        $log.info('ManifestSyncService.getManifestSyncByProductCode ::: Start');
        let product = await super.getModelObject(MODEL_DATABASE, _productCode)
        let manifestSyncProduct = await this.mapManifestSyncProduct(product);
        let appManifest = new ManifestSync();

        if(manifestSyncProduct != null) {
            $log.info('ManifestSyncService.getManifestSyncByProductCode ::: Product Found in Database');
            appManifest.products.push(manifestSyncProduct);
        } else {
            $log.info('ManifestSyncService.getManifestSyncByProductCode ::: Product Not Found in Database');
        }
        $log.info('ManifestSyncService.getManifestSyncByProductCode ::: Completed');
        return appManifest;
    }

    /**
     * Gets the manifest sync from the appManifest supplied as a payload in the POST operation - POST request
     * @param products
     */
    public async getManifestSync(requestAppManifest: ManifestSync) {
        let products = requestAppManifest.products;
        let states = requestAppManifest.states;
        $log.info('ManifestSyncService.getManifestSync ::: Start');
        let appManifest = new ManifestSync();
        let results : Product[] = [];

        // Iterate through the Product array
        for(let product of products) {
            let result = new Product();
            let retrievedProduct = await this.productService.getProduct(product.productCode);
            result.productCode = product.productCode;
            result.productType = product.productType;
            result.productDescription = product.productDescription;
            result.update = product.update;
            result.kindCode = retrievedProduct?.kindCode;
            result.active = retrievedProduct?.active;
            result.deleteFlag = retrievedProduct?.deleteFlag;
            result.version = retrievedProduct?.version;
            result.effectiveDate = retrievedProduct?.effectiveDate;
            result.type = product?.type;
            result.name = product?.name;
            result.medSuppData = new ManifestMedSuppData();

            await this.processAED(product, result);                 // Process AED
            await this.processPlan(product, result);                // Process Plan
            await this.processRate(product, result);                // Process Rate
            await this.processCashValue(product, result);           // Process CashValue
            await this.processNonforfeitureRPU(product, result);    // Process NonForfeitureRPU
            await this.processNonForfeitureETI(product, result);    // Process NonForfeitureETI

            // Process MedSuppData only for L030
            if(product.productCode === Constants.PRODUCT_CODE_L030 || product.productCode === Constants.PRODUCT_CODE_S060) {
                $log.info(`Processing MedSuppData for ProductCode=${product.productCode}`);
                appManifest.states = await this.processMedSuppData(product, result, states);
            }

            results.push(result); // push the data in array in order to send it back in the response
        }
        appManifest.products = results;
        $log.info('ManifestSyncService.getManifestSync ::: Completed');
        return appManifest;
    }

    public async getModManifestSync(mod: Mod) {
        $log.info('ManifestSyncService.getModManifestSync ::: Start');
        let appManifest = new ManifestSync();
        let result = new Mod();
        $log.info(`Querying the mod table for id=${mod.id}`);
        let modDBObject = await this.modService.getModById(mod.id);

        // Map the elements
        if(modDBObject != null) {
            $log.info(`Data found for mod for id=${mod.id}. Populating the object`);
            result.id = modDBObject['_id'];
            result.version = modDBObject['version'];
            result.effectiveDate = modDBObject['effectiveDate'];
            result.jsonData = modDBObject['jsonData'];
        } else {
            $log.info(`Mod table does not contain record for ${mod.id}`)
        }
        appManifest.mod = result;
        $log.info('ManifestSyncService.getModManifestSync ::: Completed');
        return appManifest;
    }

    private async mapManifestSyncProduct(_product) {
        $log.info('ManifestSyncService.mapManifestSyncProduct ::: Start');
        $log.info(`Querying Product for productCode ${_product.productCode}`);
        let product = await this.productService.getProduct(_product.productCode);
        let manifestSyncProduct = new Product();

        // Populate type and name fields
        if(product != null) {
            manifestSyncProduct.productType = product['type'];
            manifestSyncProduct.productDescription = product['name'];
        } else {
            $log.info(`Product table does not contain record for ${_product.productCode}`)
        }

        // Populate the other fields
        manifestSyncProduct.productCode = _product['productCode'];
        manifestSyncProduct.update = true;
        /*manifestSyncProduct.aed = this.getManifestSyncElement(_product['aedId']);
        manifestSyncProduct.plan = this.getManifestSyncElement(_product['planId']);
        manifestSyncProduct.rate = this.getManifestSyncElement(_product['ratesId']);
        manifestSyncProduct.cashValue = this.getManifestSyncElement(_product['cashValueId']);
        manifestSyncProduct.nonforfeitureRPU = this.getManifestSyncElement(_product['nonforfeitureRPUId']);
        manifestSyncProduct.nonforfeitureETI = this.getManifestSyncElement(_product['nonforfeitureETIId']);*/
        $log.info('ManifestSyncService.mapManifestSyncProduct ::: Completed');
        return manifestSyncProduct;
    }

    /*private getManifestSyncElement(id: string) {
        let element = new ManifestSyncElement();
        element.id = id;
        return element;
    }*/

    private async processAED(product: Product, result: Product) {
        if (product.aed != null && product.aed.id != null) {
            $log.info(`Processing AEDs for manifestSync. Id=${product.aed.id}`);
            let aed: Aed = await this.aedService.getAedById(product.aed.id);
            if(aed != null) {
                result.aed.id = aed._id;
                result.aed.productCode = aed.productCode;
                result.aed.version = aed.version;
                result.aed.effectiveDate = aed.effectiveDate;
                result.aed.jsonData = aed.jsonData;
            } else {
                $log.info(`AED data not found for: ${product.aed.id}`);
            }
        } else {
            $log.info(`No AED to process for manifestSync ${product.productCode}`);
        }
    }

    private async processPlan(product: Product, result: Product) {
        if (product?.plan != null && product.plan.id != null) {
            $log.info(`Processing Plan for manifestSync. Id=${product.plan.id}`);
            let plan: Plan = await this.planService.getPlanById(product.plan.id);
            if(plan != null) {
                result.plan.id = plan._id;
                result.plan.productCode = plan.productCode;
                result.plan.version = plan.version;
                result.plan.effectiveDate = plan.effectiveDate;
                result.plan.jsonData = plan.jsonData;
            } else {
                $log.info(`Plan data not found for: ${product.plan.id}`);
            }
        } else {
            $log.info(`No Plan to process for manifestSync ${product.productCode}`);
        }

    }

    private async processRate(product: Product, result: Product) {
        // Process Rate
        if (product?.rate != null && product.rate.id != null) {
            $log.info(`Processing Rate for manifestSync. Id=${product.rate.id}`);
            let rate: Rate = await this.rateService.getRateById(product.rate.id);
            if(rate != null) {
                result.rate.id = rate._id;
                result.rate.productCode = rate.productCode;
                result.rate.version = rate.version;
                result.rate.effectiveDate = rate.effectiveDate;
                result.rate.jsonData = rate.jsonData;
            } else {
                $log.info(`Rate data not found for: ${product.rate.id}`);
            }
        } else {
            $log.info(`No Rate to process for manifestSync ${product.productCode}`);
        }
    }

    private async processCashValue(product: Product, result: Product) {
        // Process CashValue
        if (product?.cashValue != null && product.cashValue.id != null) {
            $log.info(`Processing CashValue for manifestSync. Id=${product.cashValue.id}`);
            let cashValue: CashValue = await this.cashValueService.getCashValueById(product.cashValue.id);
            if(cashValue != null) {
                result.cashValue.id = cashValue._id;
                result.cashValue.productCode = cashValue.productCode;
                result.cashValue.version = cashValue.version;
                result.cashValue.effectiveDate = cashValue.effectiveDate;
                result.cashValue.jsonData = cashValue.jsonData;
            } else {
                $log.info(`CashValue data not found for: ${product.cashValue.id}`);
            }
        } else {
            $log.info(`No CashValue to process for manifestSync ${product.productCode}`);
        }
    }

    private async processNonforfeitureRPU(product: Product, result: Product) {
        // Process NonForfeitureRPU
        if (product?.nonforfeitureRPU != null && product.nonforfeitureRPU.id != null) {
            $log.info(`Processing NonforfeitureRPU for manifestSync. Id=${product.nonforfeitureRPU.id}`);
            let nonforfeitureRPU: NonforfeitureRPU = await this.nonforfeitureRPUService.getNonforfeitureRPUById(product.nonforfeitureRPU.id);
            if(nonforfeitureRPU != null) {
                result.nonforfeitureRPU.id = nonforfeitureRPU._id;
                result.nonforfeitureRPU.productCode = nonforfeitureRPU.productCode;
                result.nonforfeitureRPU.version = nonforfeitureRPU.version;
                result.nonforfeitureRPU.effectiveDate = nonforfeitureRPU.effectiveDate;
                result.nonforfeitureRPU.jsonData = nonforfeitureRPU.jsonData;
            } else {
                $log.info(`NonforfeitureRPU data not found for: ${product.nonforfeitureRPU.id}`);
            }
        } else {
            $log.info(`No NonforfeitureRPU to process for manifestSync ${product.productCode}`);
        }
    }

    private async processNonForfeitureETI(product: Product, result: Product) {
        // Process NonForfeitureETI
        if (product?.nonforfeitureETI != null && product.nonforfeitureETI.id != null) {
            $log.info(`Processing NonforfeitureETI for manifestSync. Id=${product.nonforfeitureETI.id}`);
            let nonforfeitureETI: NonforfeitureETI = await this.nonforfeitureETIService.getNonforfeitureETIById(product.nonforfeitureETI.id);
            if(nonforfeitureETI != null) {
                result.nonforfeitureETI.id = nonforfeitureETI._id;
                result.nonforfeitureETI.productCode = nonforfeitureETI.productCode;
                result.nonforfeitureETI.version = nonforfeitureETI.version;
                result.nonforfeitureETI.effectiveDate = nonforfeitureETI.effectiveDate;
                result.nonforfeitureETI.jsonData = nonforfeitureETI.jsonData;
            } else {
                $log.info(`NonforfeitureETI data not found for: ${product.nonforfeitureETI.id}`);
            }
        } else {
            $log.info(`No NonforfeitureETI to process for manifestSync ${product.productCode}`);
        }
    }

    private async processMedSuppData(product: Product, result: Product, states:Array<string>) {
        $log.info('ManifestSyncService.processMedSuppData ::: Start');
        let stateResults : Array<string> = [];
        // if (product.medSuppData != null && product.medSuppData.id != null) {
            $log.info(`Proceeding to fetch data from Product Manifest table for ${product.productCode}`);
            let retrievedProductManifest = await this.productManifestService.getProductManifest(product.productCode);
            // if(product.medSuppData.id == retrievedProductManifest._id) {
                $log.info(`Incoming id\'s matched with ${product.productCode} Product Manifest. Fetching Adjustment Group Ids information now`);
                let adjGroupIds = retrievedProductManifest.medSuppData.adjGroups;
                //let stateRates = retrievedProductManifest.medSuppData.stateRates;

                // Adjustment Group
                for(let adjGroupId of adjGroupIds) {
                    $log.info(`Attempting to fetch data for QMSAdjustmentGroup. id=${adjGroupId}`);
                    let retrievedQMSAdjustmentGroup = await this.qmsAdjustmentGroupService.getQmsAdjustmentGroupById(adjGroupId);
                    if(retrievedQMSAdjustmentGroup != null) {
                        $log.info(`Record found for QMSAdjustmentGroup. id=${adjGroupId}`);
                        let manifestSyncAdjustmentGroup = new ManifestSyncAdjustmentGroup();
                        manifestSyncAdjustmentGroup.id = retrievedQMSAdjustmentGroup._id;
                        manifestSyncAdjustmentGroup.businessType = retrievedQMSAdjustmentGroup.businessType;
                        manifestSyncAdjustmentGroup.effectiveDate = retrievedQMSAdjustmentGroup.effectiveDate;
                        manifestSyncAdjustmentGroup.records = retrievedQMSAdjustmentGroup.records;
                        result.medSuppData.qmsAdjustmentGroup.push(manifestSyncAdjustmentGroup);
                    } else {
                        $log.info(`QMS Adjustment Group record not found for id=${adjGroupId}`);
                    }
                }


                // Process States
                $log.info('Processing States information from the incoming payload');
                if(!states || states==null) {
                    $log.info(`No states present in the incoming request for evaluation`);
                } else {
                    let stateRatesMap = new Map(retrievedProductManifest.medSuppData.stateRates.map(stateRate => {
                        return [stateRate.state, stateRate]
                    }));

                    states.forEach(state=> {
                        $log.info(`Evaluating state=${state} to determine its eligibility`);
                        if(stateRatesMap.get(state) != null) {
                            $log.info(`State=${state} found eligible`);
                            stateResults.push(state);
                        }
                    });

                    result.medSuppData.stateRates = {};
                    for (const state of states) {
                        let qmsAreas = await this.qmsAreaService.getQmsAreaByBusinessTypeState(Util.getBusinessType(product.productCode), state);
                        let qmsRates = await this.qmsRatesService.getQmsRatesByBusinessTypeState(Util.getBusinessType(product.productCode), state); 
                        
                        result.medSuppData.stateRates[state] = {
                            "areas": qmsAreas,
                            "rates": qmsRates
                        }
                    }
                }

                
            // } else {
            //     $log.info('id passed in appManifest does not match with the one present in the database for L030. Returning empty object');
            // }
        // } else {
        //     $log.info('Looks like medSuppData id was not provided in the incoming request');
        // }
        $log.info('ManifestSyncService.processMedSuppData ::: Completed');
        return stateResults;
    }
}
