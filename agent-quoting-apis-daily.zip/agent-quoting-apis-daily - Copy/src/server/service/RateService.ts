import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Rate } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_RATE;
const MANIFEST_ID = 'ratesId';

export class RateService extends GenericModelService {
    public async addUpdateRate(rateDetails: Rate, userHeaderDetails: any) {
        $log.debug('RateService.addUpdateRate..........', rateDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, rateDetails.productCode, rateDetails, userHeaderDetails);
    }


    public async getRate(_productCode: string) {
        $log.debug('RateService.getRate..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getRateById(_id: string) {
        $log.debug('RateService.getRateById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllRates(productCodes?: string[]) {
        $log.debug('RateService.getAllRate..........');
        return productCodes ? super.getAllModels(MODEL_DATABASE, productCodes) : super.getAllModels(MODEL_DATABASE);
    }

    public async deleteRate(_id: string, userHeaderDetails: any) {
        $log.debug('RateService.deleteRate..........', _id, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, _id, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteRateByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('RateService.deleteRateByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('RateService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('RateService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`RateService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}