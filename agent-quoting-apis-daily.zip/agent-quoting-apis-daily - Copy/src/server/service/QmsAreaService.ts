import {$log} from "@tsed/common";
import {ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {ProductManifestService} from './ProductManifestService';
import {QmsArea} from '../models/QmsArea';

import moment from 'moment';
import dbServiceV2 from '../db/DbServiceV2';
import {Util} from "../util/Util";
import {MedSuppData, MedSuppStateData} from "../models";


const _databaseName = DBConstants.TABLE_QMS_AREAS;

const productManifestService = new ProductManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`QmsAreaService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}

export class QmsAreaService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`QmsAreaService..........constructor`);
        if (!QmsAreaService.isInitilized) {
            $log.debug(`QmsAreaService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`QmsAreaService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            QmsAreaService.isInitilized = true;
        }
    }
    public async addUpdateQmsArea(qmsArea: QmsArea, userHeaderDetails: any) {
        const productCode = Util.getProductCode(qmsArea?.businessType);
        const foundModel = await this.getQmsArea(qmsArea.businessType, qmsArea.effectiveDate, qmsArea.state);
        $log.info('addUpdateQmsAdjustmentModel - foundModel..........', foundModel);
        $log.info('addUpdateQmsAdjustmentModel - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateQmsArea - Updated QmsArea ..........', productCode);
            await dbService.getCollection(_databaseName).deleteOne({"_id": foundModel._id});
            //qmsArea._id = foundModel._id;
            qmsArea.createdTimestamp = foundModel.createdTimestamp;
            qmsArea.updatedTimestamp = timestamp;
            qmsArea.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsArea);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: qmsArea });
            returnModelDetails = await this.getQmsArea(qmsArea.businessType, qmsArea.effectiveDate, qmsArea.state);
        } else {
            $log.info("addUpdateQmsArea - Added new QmsArea ..........", productCode);
            qmsArea.createdTimestamp = timestamp;
            qmsArea.updatedTimestamp = timestamp;
            qmsArea.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(qmsArea);
            returnModelDetails = await this.getQmsArea(qmsArea.businessType, qmsArea.effectiveDate, qmsArea.state);
            await this.updateProductManifest(productCode, qmsArea.businessType, qmsArea.state, userHeaderDetails);
        }


        $log.info('addUpdateQmsArea - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }


    public async getQmsArea(_businessType: string, _effectiveDate: string, _state: string) {
        $log.info('getQmsArea..........', _businessType);
        $log.info('getQmsArea..........', _effectiveDate);
        $log.info('getQmsArea..........', _state);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate, state: _state});
        $log.info(`getQmsArea - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getQmsAreaByBusinessTypeState(_businessType: string, _state: string) {
        $log.info('getQmsAreaByBusinessType..........', _businessType);
        $log.info('getQmsAreaByBusinessType..........', _state);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType, state: _state}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getQmsAreaByBusinessType - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    public async getQmsAreaById(_id: string) {
        $log.info('getQmsAreaById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getQmsAreaById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllQmsAreas() {
        $log.info('getAllQmsAreas..........');
        let items: QmsArea[] = null;
        try {
            items = await dbService.getCollection(_databaseName).find().toArray();
            $log.info(`Successfully found AllQmsAreas models from ${_databaseName}.`)
            return items;
        } catch (error) {
            $log.error(`Failed to find modules from ${_databaseName}: ${error}`)
        }
        return items;
        /*return await dbService.getCollection(_databaseName).find().toArray().then(items => {
            $log.info(`Successfully found AllQmsAreas models from ${_databaseName}.`)
            $log.info(items);
            return items;
        }).catch(err => {
            $log.error(`Failed to find modles from ${_databaseName}: ${err}`)
        });*/
    }

    // public async deleteQmsArea(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
    //     $log.info('deleteQmsArea..........', _productCode);
    //     try {
    //         await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
    //         let productManifest = await productManifestService.getProductManifest(_productCode);
    //         $log.info('delete ${_referenceName} from productManifest..........', productManifest);
    //         productManifest[_productManifestReferenceName] = null;
    //         // await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
    //         this.updateProductManifest(_databaseName)

    //         return true;
    //     } catch (e) {
    //         $log.error('Error occurred while deleting the model from ${_database} ' + _productCode, e);
    //         return false;
    //     }
    // }

    public async deleteQmsAreaById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteQmsArea..........', _id);
        try {
            const foundQmsAdjGroup = await this.getQmsAreaById(_id);
            const productCode = Util.getProductCode(foundQmsAdjGroup?.businessType);
            $log.info('foundQmsArea..........', foundQmsAdjGroup);
            if ( foundQmsAdjGroup != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                let productManifest = await productManifestService.getProductManifest(_id);
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundQmsAdjGroup.businessType, foundQmsAdjGroup.state, userHeaderDetails)
                }
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    private async updateProductManifest(_productCode: string, _businessType: string, _state: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let qmsAreas = await this.getQmsAreaByBusinessTypeState(_businessType, _state);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateQmsAreaList = [];
        for (const qmsArea of qmsAreas) {
            if ( qmsArea.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                if ( !updateQmsAreaList.includes(qmsArea._id) ) {
                    updateQmsAreaList.push(qmsArea._id);
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                    if ( !updateQmsAreaList.includes(qmsArea._id) ) {
                        updateQmsAreaList.push(qmsArea._id);
                    }
                    removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${qmsArea.effectiveDate}, ${qmsArea._id} ..........`);
                    await this.deleteQmsAreaById(qmsArea._id, userHeaderDetails, false);
                }
            }
        }
   
        
        $log.info("updateProductManifest - updated Qms Area List ..........", updateQmsAreaList);
        if ( prodManifest.medSuppData == null ) {
            let medSuppData: MedSuppData  = {
                adjGroups: [],
                stateRates: []
            }

            prodManifest.medSuppData = medSuppData;

        }

        if ( prodManifest.medSuppData.stateRates == null || prodManifest.medSuppData.stateRates.length == 0 ) {

            let localStateRates: MedSuppStateData[] = [];
            prodManifest.medSuppData.stateRates = localStateRates;
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: []
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }


        $log.info("updateProductManifest - prodManifest.medSuppData.stateRates .......... " +  prodManifest.medSuppData.stateRates);
        let stateIndex =  prodManifest.medSuppData.stateRates.findIndex((element:MedSuppStateData) => {
            return element.state == _state;
        });
        $log.info("updateProductManifest - stateIndex .......... " +  stateIndex);
        if ( stateIndex != -1 ) {
            prodManifest.medSuppData.stateRates[stateIndex].areas = updateQmsAreaList;
        } else {
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: updateQmsAreaList
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }

        $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('QmsAreaService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`QmsAreaService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

    public async getQMSAreasByBusinessType(_businessType: string) {
        $log.info('getQMSAreasByBusinessType..........', _businessType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getQMSAreasByBusinessType - found models from ${_databaseName}..........`);
        return foundModels;
    }

}