import {$log} from "@tsed/common";
import {ObjectId, ObjectID} from 'mongodb';
import {DbService} from '../db/DbService';
import dbServiceV2 from '../db/DbServiceV2';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {Util} from "../util/Util";
import {ProductManifestService} from './ProductManifestService';
import {MobileRateRates} from '../models/MobileRateRates';

import moment from 'moment';

let dbService: any;

const _databaseName = DBConstants.TABLE_MOBILE_RATE_RATES;

const productManifestService = new ProductManifestService();

const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`MobileRateRatesService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class MobileRateRatesService {
    private static isInitialized: boolean = false;
    constructor() {
        $log.debug(`MobileRateRatesService..........constructor`);
        if (!MobileRateRatesService.isInitialized) {
            $log.debug(`MobileRateRatesService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`MobileRateRatesService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            MobileRateRatesService.isInitialized = true;
        }
    }

    public async addUpdateMobileRateRates(mobileRateRates: MobileRateRates, userHeaderDetails: any) {
        //const productCode = Util.getProductCode(mobileRateRates?.businessType);
        const foundModel = await this.getMobileRateRates(mobileRateRates.businessType, mobileRateRates.effectiveDate, mobileRateRates.state);
        $log.info('addUpdateMobileRateRates - foundModel..........', foundModel);
        $log.info('addUpdateMobileRateRates - userHeaderDetails..........', userHeaderDetails);
        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let returnModelDetails:any;
        if ( foundModel ) {
            $log.info('addUpdateMobileRateRates - Updated MobileRateRates ..........', foundModel.businessType);
            await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(foundModel._id)});
            //mobileRateRates._id = foundModel._id;
            mobileRateRates.createdTimestamp = foundModel.createdTimestamp;
            mobileRateRates.updatedTimestamp = timestamp;
            mobileRateRates.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateRates);
            //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID(foundModel._id)}, { $set: mobileRateRates });
            returnModelDetails = await this.getMobileRateRates(mobileRateRates.businessType, mobileRateRates.effectiveDate, mobileRateRates.state);
        } else {
            $log.info("addUpdateMobileRateRates - Adding new MobileRateRates ..........");
            mobileRateRates.createdTimestamp = timestamp;
            mobileRateRates.updatedTimestamp = timestamp;
            mobileRateRates.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
            await dbService.getCollection(_databaseName).insertOne(mobileRateRates);
            returnModelDetails = await this.getMobileRateRates(mobileRateRates.businessType, mobileRateRates.effectiveDate, mobileRateRates.state);
            //$log.info('addUpdateMobileRateRates..........', returnModelDetails.businessType);
            //$log.info('addUpdateMobileRateRates..........', returnModelDetails.state);
            //await this.updateProductManifest(mobileRateRates.productCode, mobileRateRates.businessType, mobileRateRates.state, userHeaderDetails);
        }
        $log.info('addUpdateMobileRateRates - returnModelDetails..........', returnModelDetails);
        return returnModelDetails;
    }


    public async getMobileRateRates(_businessType: string, _effectiveDate: string, _state: string) {
        $log.info('getMobileRateRates..........', _businessType);
        $log.info('getMobileRateRates..........', _effectiveDate);
        $log.info('getMobileRateRates..........', _state);
        const foundModel = await dbService.getCollection(_databaseName).findOne({businessType: _businessType, effectiveDate: _effectiveDate, state: _state});
        $log.info(`getMobileRateRates - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getMobileRateRatesByBusinessType(_businessType: string) {
        $log.info('getMobileRateRatesByBusinessType..........', _businessType);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType}).sort( {effectiveDate: -1} );
        const foundModel = foundModelsCursor.toArray();
        $log.info(`getMobileRateRatesByBusinessType - found model from ${_databaseName}..........`, foundModel);
        return foundModel;
    }

    public async getMobileRateRatesByBusinessTypeAndState(_businessType: string, _state: string) {
        $log.info('getMobileRateRatesByBusinessTypeAndState..........', _businessType);
        $log.info('getMobileRateRatesByBusinessTypeAndState..........', _state);
        const foundModelsCursor = await dbService.getCollection(_databaseName).find({businessType: _businessType, state: _state}).sort( {effectiveDate: -1} );
        const foundModels = await foundModelsCursor.toArray();
        $log.info(`getMobileRateRatesByBusinessTypeAndState - found models from ${_databaseName}..........`, foundModels);
        return foundModels;
    }

    public async getMobileRateRatesById(_id: string) {
        $log.info('getMobileRateRatesById..........', _id);
        const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectID(_id)});
        $log.info(`getMobileRateRatesById - foundProduct from ${_databaseName}..........`, foundProduct);
        return foundProduct;
    }

    public async getAllMobileRateRates() {
        $log.info('getAllMobileRateRates..........');
        let items: MobileRateRates[] = null;
        try {
            $log.debug(dbService);
            items = await dbService.getCollection(_databaseName).find().toArray()
            $log.info(`Successfully found AllMobileRateRatess models from ${_databaseName}.`)
            return items;
        } catch(error) {
            $log.error(`Failed to find modles from ${_databaseName}: ${error}`)
        }
        return items;
    }

    public async deleteMobileRateRatesById(_id: string, userHeaderDetails: any, _updateManifest: boolean) {
        $log.info('deleteMobileRateRates..........', _id);
        try {
            const foundModel = await this.getMobileRateRatesById(_id);
            const productCode = Util.getProductCode(foundModel?.businessType);
            // $log.info('foundMobileRateRates..........', foundModel);
            if ( foundModel != null ) {
                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectID(_id)});
                let productManifest = await productManifestService.getProductManifest(_id);
                $log.info(`delete ${_id} from ${_databaseName}..........`);
                /*if ( _updateManifest ) {
                    this.updateProductManifest(productCode, foundModel.businessType, foundModel.state, userHeaderDetails)
                }*/
            } else {
                $log.info(`No QMS Adjustment group was deleted from ${_databaseName}.  Could not find QMS Adjustment Group with the id of "${_id}"`);
            }

            return true;
        } catch (e) {
            $log.error(`Error occurred while deleting the model from ${_databaseName} and the id of "${_id}"`, e);
            return false;
        }
    }

    /*private async updateProductManifest(_productCode: string, _businessType: string, _state: string, userHeaderDetails: any) {
        $log.info('updateProductManifest..........');
        let prodManifest = await productManifestService.getProductManifest(_productCode);

        let mobileRateRatess = await this.getMobileRateRatesByProductAndState(_productCode, _state);

        const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
        let removeOldRecords = false;
        const updateMobileRateRatesList = [];
        for (const mobileRateRates of mobileRateRatess) {
            if ( mobileRateRates.effectiveDate > timestamp ) {
                $log.info(`updateProductManifest - Keeping future version ${mobileRateRates.effectiveDate}, ${mobileRateRates._id} ..........`);
                if ( !updateMobileRateRatesList.includes(mobileRateRates._id) ) {
                    updateMobileRateRatesList.push(mobileRateRates._id);
                }
            } else {
                if ( !removeOldRecords ) {
                    $log.info(`updateProductManifest - Keeping one older version ${mobileRateRates.effectiveDate}, ${mobileRateRates._id} ..........`);
                    if ( !updateMobileRateRatesList.includes(mobileRateRates._id) ) {
                        updateMobileRateRatesList.push(mobileRateRates._id);
                    }
                        removeOldRecords = true;
                } else {
                    $log.info(`updateProductManifest - Removing older version ${mobileRateRates.effectiveDate}, ${mobileRateRates._id} ..........`);
                    await this.deleteMobileRateRatesById(mobileRateRates._id, userHeaderDetails, false);
                }
            }
        }
   
        
        $log.info("updateProductManifest - updated Qms Rate List ..........", updateMobileRateRatesList);
        if ( prodManifest.medSuppData == null ) {
            let medSuppData: MedSuppData  = {
                adjGroups: [],
                stateRates: []
            }
            prodManifest.medSuppData = medSuppData;
        }

        if ( prodManifest.medSuppData.stateRates == null || prodManifest.medSuppData.stateRates.length == 0 ) {
            let localStateRates: MedSuppStateData[] = [];
            prodManifest.medSuppData.stateRates = localStateRates;
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: [],
                areas: []
            };
            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }

        $log.info("updateProductManifest - prodManifest.medSuppData.stateRates .......... " +  prodManifest.medSuppData.stateRates);
        let stateIndex =  prodManifest.medSuppData.stateRates.findIndex((element:MedSuppStateData) => {
            return element.state == _state;
        });

        $log.info("updateProductManifest - stateIndex .......... " +  stateIndex);
        if ( stateIndex != -1 ) {
            prodManifest.medSuppData.stateRates[stateIndex].rates = updateMobileRateRatesList;
        } else {
            let medSuppStateData: MedSuppStateData = {
                state: _state,
                rates: updateMobileRateRatesList,
                areas: []
            };

            prodManifest.medSuppData.stateRates.push(medSuppStateData);
        }

        $log.info("updateProductManifest - prodManifest ..........", prodManifest);
        productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);
    }*/

    public validateRequest (data) {
        $log.info('MobileRateRatesService.validateRequest() ::: Start');
        let validRequest: boolean = Object.keys(data).length>0;
        $log.info(`MobileRateRatesService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }

}