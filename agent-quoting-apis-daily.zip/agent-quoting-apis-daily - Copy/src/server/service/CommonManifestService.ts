import { $log } from '@tsed/common';
import { DbService } from '../db/DbService';
import { DBConstants } from '../db/DbConstants';
import { Constants } from '../util/Constants';
import { CommonManifest } from '../models';
import moment, { Moment } from 'moment';
import dbServiceV2 from '../db/DbServiceV2';
import { Util } from "../util/Util";

let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`CommonManifestService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class CommonManifestService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`CommonManifestService..........constructor`);
        if (!CommonManifestService.isInitilized) {
            $log.debug(`CommonManifestService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`CommonManifestService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            CommonManifestService.isInitilized = true;
        }
    }
    public async addUpdateCommonManifest(commonManifestDetails: CommonManifest, userHeaderDetails: any) {
        try {
            let foundCommonManifest = await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).findOne({});
            $log.debug(`addUpdateCommonManifest..........foundCommonManifest`, foundCommonManifest);
            const timestamp = moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
            if (foundCommonManifest == null) {
                $log.info(`addUpdateCommonManifest.......... Inserting the common manifest `, + commonManifestDetails);
    
                commonManifestDetails.updatedTimestamp = timestamp;
                commonManifestDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
                commonManifestDetails.createdTimestamp = timestamp;

                await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).insertOne(commonManifestDetails);
                foundCommonManifest = await this.getCommonManifest();
                $log.info(`addUpdateCommonManifest ..........getCommonManifest foundCommonManifest `, foundCommonManifest);
                return foundCommonManifest;
            } else {
                $log.info(`addUpdateCommonManifest.......... updating the common manifest `);
    
                commonManifestDetails._id = foundCommonManifest._id
                commonManifestDetails.updatedTimestamp = timestamp;
                commonManifestDetails.updatedBy = userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
                commonManifestDetails.createdTimestamp = foundCommonManifest.createdTimestamp;
                const query = { _id: foundCommonManifest._id };

                await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).updateOne(query, { $set: commonManifestDetails });
                foundCommonManifest = await this.getCommonManifest();
                $log.info(`addUpdateCommonManifest ..........getCommonManifest result `, foundCommonManifest);
                return foundCommonManifest;
            }
        } catch (err) {
            $log.error(`addUpdateCommonManifest..........Error `, err);
            throw new Error(err);
        }
    }


    public async getCommonManifest() {
        $log.debug(`getCommonManifest..........`);
        try {
            let commonManifest = await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).findOne({});
            $log.info(`getCommonManifest..........Returned common Manifest.`, commonManifest);
            return commonManifest;
        } catch (err) {
            $log.error(`getCommonManifest..........Error `, err);
            throw new Error(err);
        }
    }


    public async getAllCommonManifests() {
        $log.debug(`getAllCommonManifests..........`);
        try {
            let commonManifests = await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).find().toArray();
            $log.info(`getAllCommonManifests..........common Manifests  `, commonManifests);
            return commonManifests;
        } catch (err) {
            $log.error(`getAllCommonManifests..........Error `, err);
            throw new Error(err);
        }
    }

    public async deleteCommonManifest() {
        $log.debug(`deleteCommonManifest..........`);
        try {
            await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).deleteOne({});
            $log.debug(`deleteCommonManifest..........Deleted common Manifest`);
            return true;
        } catch (err) {
            $log.error(`deleteCommonManifest..........Error `, err);
            throw new Error(err);
        }
    }

}