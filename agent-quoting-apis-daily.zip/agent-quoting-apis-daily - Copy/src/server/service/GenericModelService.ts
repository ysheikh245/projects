import {$log} from "@tsed/common";
import {DbService} from '../db/DbService';
import {DBConstants} from '../db/DbConstants';
import {Constants} from '../util/Constants';
import {ProductManifestService} from './ProductManifestService';

import moment from 'moment';
import {GenericAuditModel} from "../models";
import {ObjectId} from "mongodb";
import dbServiceV2 from '../db/DbServiceV2';
import {Util} from "../util/Util";


const productManifestService = new ProductManifestService();
let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`GenericModelService..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}
export class GenericModelService {
    private static isInitilized: boolean = false;
    constructor() {
        $log.debug(`GenericModelService..........constructor`);
        if (!GenericModelService.isInitilized) {
            $log.debug(`GenericModelService..........not init`);
            if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
                intiDbService();
            } else {
                $log.info(`GenericModelService..........init DB Service V2`);
                dbService = dbServiceV2;
            }
            GenericModelService.isInitilized = true;
        }
    }
    public async addUpdateModel(_databaseName: string, _productManifestReferenceName: string, _productCode: string, auditModel: GenericAuditModel, userHeaderDetails: any) {
        $log.debug(`addUpdateModel - start..........`);
        try {
            let foundModel = await this.getModelObject(_databaseName, _productCode);
            $log.info(`addUpdateModel - foundModel..........`, foundModel);
            $log.info(`addUpdateModel - userHeaderDetails..........`, userHeaderDetails);
            const timestamp =  moment(new Date(), DBConstants.DATE_TIME_FORMAT).format(DBConstants.DATE_TIME_FORMAT);
            let returnModelDetails:any;
            if ( foundModel != null  && foundModel.productCode != null ) {
                $log.info(`addUpdateModel - Updated ${_productManifestReferenceName} ..........`, _productCode);
                //const query = { productCode: _productCode };
                //auditModel._id = foundModel._id;

                await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(foundModel._id)});
                //console.log(`********************* Created Timestamp - {}`, foundModel.createdTimestamp)
                auditModel.createdTimestamp = foundModel.createdTimestamp;
                auditModel.updatedTimestamp = timestamp;
                auditModel.updatedBy = this.getUpdatedBy(userHeaderDetails);

                await dbService.getCollection(_databaseName).insertOne(auditModel);
                //await dbService.getCollection(_databaseName).updateOne({"_id": new ObjectID()}, { $set: auditModel });

                returnModelDetails = await this.getModelObject(_databaseName, _productCode);
                $log.info(`addUpdateModel - Updated ${_productManifestReferenceName}..........`, returnModelDetails);

                returnModelDetails = await this.updateProductManifestReferenceIdCommon(_databaseName, returnModelDetails.productCode, _productManifestReferenceName, userHeaderDetails);
                $log.info(`addUpdateModel - Updated ${_productManifestReferenceName}..........`, returnModelDetails);

                return returnModelDetails;
            } else {
                $log.info(`addUpdateModel - Added new ${_productManifestReferenceName} ..........`, _productCode);
                auditModel.createdTimestamp = timestamp;
                auditModel.updatedTimestamp = timestamp;
                auditModel.updatedBy = this.getUpdatedBy(userHeaderDetails);
    
                await dbService.getCollection(_databaseName).insertOne(auditModel);
                returnModelDetails = await this.getModelObject(_databaseName, _productCode);
                $log.info(`addUpdateModel - Updated ${_productManifestReferenceName}..........`, returnModelDetails);
                returnModelDetails = await this.updateProductManifestReferenceIdCommon(_databaseName, returnModelDetails.productCode, _productManifestReferenceName, userHeaderDetails);
                $log.info(`addUpdateModel - Inserted ${_productManifestReferenceName}..........`, returnModelDetails);
                return returnModelDetails;
            }   
        } catch (e) {
            $log.error(`addUpdateModel - Error occurred while getAllModels from ${_databaseName}`, e);
            throw new Error(e);
        }
    }


    private getUpdatedBy(userHeaderDetails: any) {
        return userHeaderDetails[Constants.HTTPHEADER_END_USER] ? userHeaderDetails[Constants.HTTPHEADER_END_USER] : 'Undefined';
    }

    public async getModelObject(_databaseName: string, _productCode: string) {
        $log.info(`getModelObject..........`, _productCode);
        try {
            const foundModel = await dbService.getCollection(_databaseName).findOne({productCode: _productCode});
            $log.info(`getModelObject - found model from ${_databaseName}..........`, foundModel);
            return foundModel;
        } catch (e) {
            $log.error(`getModelObject - Error occurred while getAllModels from ${_databaseName}`, e);
            throw new Error(e);
        }
    }

    public async getModelById(_databaseName: string, _id: string) {
        $log.info(`getModelById..........`, _id);
        try {
            const foundProduct = await dbService.getCollection(_databaseName).findOne({_id: new ObjectId(_id)});
            $log.info(`getModelById - foundProduct..........`, foundProduct);
            return foundProduct;
        } catch (e) {
            $log.error(`getModelById - Error occurred while getAllModels from ${_databaseName}`, e);
            throw new Error(e);
        }
    }

    public async getAllModels(_databaseName: string, productCodes?: string[]) {
        $log.info(`getAllModels..........`);
        try {
            let items = await(
                productCodes
                  ? dbService
                      .getCollection(_databaseName)
                      .find({
                        productCode: { $nin: Object.values(productCodes) },
                      })
                      .toArray()
                  : dbService
                      .getCollection(_databaseName)
                      .find()
                      .toArray()
              );
            $log.info(`getAllModels - Successfully found all models from ${_databaseName}.`)
            $log.info(items);
            return items;
        } catch (e) {
            $log.error(`getAllModels - Error occurred while getAllModels from ${_databaseName}`, e);
            throw new Error(e);
        }
    }

    public async deleteModel(_databaseName: string, _objectId: string, _productManifestReferenceName: string, userHeaderDetails: any) {
        $log.info(`deleteModel..........`, _objectId);
        let modelProductCode = null;
        try {
            await dbService.getCollection(_databaseName).deleteOne({_id: new ObjectId(_objectId)});
            let productManifest = await productManifestService.getProductManifestByReferenceObjectId(_productManifestReferenceName, _objectId);
            $log.info(`deleteModel - delete ${_productManifestReferenceName}.${_objectId} from productManifest..........`, productManifest);

            // Update the ProductManifest to contain the latest information about the resource
            if(productManifest==null) {
                $log.info(`GenericModelService.deleteModel() - ProductManifest not found. Resource=${_productManifestReferenceName} using ObjectId=${_objectId}. Not updating ProductManifest`);
                return true;
            } else {
                $log.info(`GenericModelService.deleteModel() - ProductManifest found. Resource=${_productManifestReferenceName} using ObjectId=${_objectId}. Updating ProductManifest`);
                productManifest[_productManifestReferenceName] = null;
                await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
                $log.info("GenericModelService.deleteModel() - ProductManifest updated successfully");
                return true;
            }
        } catch (e) {
            $log.error(`deleteModel - Error occurred while deleting the ${_objectId} model from ${_databaseName}`, e);
            throw new Error(e);
        }
    }

    public async deleteModelByProductCode(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
        $log.info(`deleteModel..........`, _productCode);
        try {
            await dbService.getCollection(_databaseName).deleteOne({productCode: _productCode});
            let productManifest = await productManifestService.getProductManifest(_productCode);
            $log.info(`deleteModel - delete ${_productCode} from productManifest..........`, productManifest);

            // Update the ProductManifest to contain the latest information about the resource
            if(productManifest==null) {
                $log.info(`GenericModelService.deleteModelByProductCode() - ProductManifest not found. Resource=${_productManifestReferenceName} using ProductCode=${_productCode}. Not updating ProductManifest`);
                return true;
            } else {
                $log.info(`GenericModelService.deleteModelByProductCode() - ProductManifest not found. Resource=${_productManifestReferenceName} using ProductCode=${_productCode}. Updating ProductManifest`);
                productManifest[_productManifestReferenceName] = null;
                await productManifestService.addUpdateProductManifest(productManifest, userHeaderDetails);
                return true;
            }
        } catch (e) {
            $log.error(`deleteModel - Error occurred while deleting the ${_productCode} model from ${_databaseName}`, e);
            throw new Error(e);
        }
    }

    public async updateProductManifestReferenceIdCommon(_databaseName: string, _productCode: string, _productManifestReferenceName: string, userHeaderDetails: any) {
        $log.info(`updateProductManifestReferenceId..........`, _productCode);
        try {
            let returnModelDetails = await this.getModelObject(_databaseName, _productCode);

            $log.info("updateProductManifestReferenceId - returnModelDetails ..........", returnModelDetails);
            let prodManifest = await productManifestService.getProductManifest(_productCode);
            if ( prodManifest != null ) {
                prodManifest[_productManifestReferenceName] = returnModelDetails._id;
            } else {

                $log.error(`updateProductManifestReferenceId - There was not a product manifest defined with the ${_productCode} model from ${_databaseName}`);
                throw new Error('No Product Manifest Defined');
            }
            
            $log.info("updateProductManifestReferenceId - prodManifest ..........", prodManifest);
            await productManifestService.addUpdateProductManifest(prodManifest, userHeaderDetails);

            return returnModelDetails;
        } catch (e) {
            $log.error(`updateProductManifestReferenceId - Error occurred while updating the manifest with the ${_productCode} model from ${_databaseName}`, e);
            throw e;
        }
    }
}

