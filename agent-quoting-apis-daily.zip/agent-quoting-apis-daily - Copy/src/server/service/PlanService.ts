import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { Plan } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_PLAN;
const MANIFEST_ID = 'planId';

export class PlanService extends GenericModelService {
    public async addUpdatePlan(planDetails: Plan, userHeaderDetails: any) {
        $log.debug('PlanService.addUpdatePlan..........', planDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, planDetails.productCode, planDetails, userHeaderDetails);
    }


    public async getPlan(_productCode: string) {
        $log.debug('PlanService.getPlan..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getPlanById(_id: string) {
        $log.debug('PlanService.getPlanById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllPlans() {
        $log.debug('PlanService.getAllPlan..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deletePlan(_id: string, userHeaderDetails: any) {
        $log.debug('PlanService.deletePlan..........', _id, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, _id, MANIFEST_ID, userHeaderDetails);
    }

    public async deletePlanByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('PlanService.deletePlanByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('PlanService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('PlanService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`PlanService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}