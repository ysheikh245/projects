import { $log } from '@tsed/common';
import { DBConstants } from '../db/DbConstants';
import { NonforfeitureETI } from '../models';
import { GenericModelService } from './GenericModelService';


const MODEL_DATABASE = DBConstants.TABLE_NONFORFEITURE_ETI;
const MANIFEST_ID = 'nonforfeitureETIId';

export class NonforfeitureETIService extends GenericModelService {
    public async addUpdateNonforfeitureETI(nonforfeitureETIDetails: NonforfeitureETI, userHeaderDetails: any) {
        $log.debug('NonforfeitureETIService.addUpdateNonforfeitureETI..........', nonforfeitureETIDetails);
        return await super.addUpdateModel(MODEL_DATABASE, MANIFEST_ID, nonforfeitureETIDetails.productCode, nonforfeitureETIDetails, userHeaderDetails);
    }


    public async getNonforfeitureETI(_productCode: string) {
        $log.debug('NonforfeitureETIService.getNonforfeitureETI..........', _productCode);
        return super.getModelObject(MODEL_DATABASE, _productCode);
    }

    public async getNonforfeitureETIById(_id: string) {
        $log.debug('getNonforfeitureETIById..........', _id);
        return super.getModelById(MODEL_DATABASE, _id);
    }

    public async getAllNonforfeitureETIs() {
        $log.debug('NonforfeitureETIService.getAllNonforfeitureETI..........');
        return super.getAllModels(MODEL_DATABASE);
    }

    public async deleteNonforfeitureETI(_objectId: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureETIService.deleteNonforfeitureETI..........', _objectId, userHeaderDetails);
        await super.deleteModel(MODEL_DATABASE, _objectId, MANIFEST_ID, userHeaderDetails);
    }

    public async deleteNonforfeitureETIByProductCode(_productCode: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureETIService.deleteNonforfeitureETIByProductCode..........', _productCode, userHeaderDetails);
        await super.deleteModelByProductCode(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public async updateProductManifestReferenceId(_productCode: string, userHeaderDetails: any) {
        $log.debug('NonforfeitureETIService.updateProductManifestReferenceId..........', _productCode, userHeaderDetails);
        return await super.updateProductManifestReferenceIdCommon(MODEL_DATABASE, _productCode, MANIFEST_ID, userHeaderDetails);
    }

    public validateRequest (data) {
        $log.info('NonforfeitureETIService.validateRequest() ::: Start');
        let validRequest: boolean = Boolean(Object.keys(data).length>0 && data.productCode);
        $log.info(`NonforfeitureETIService.validateRequest() ::: Completed. Request Valid Flag=${validRequest}`);
        return validRequest;
    }
}