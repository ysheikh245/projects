export function Access(customFunctions?: {getter?: ()=> unknown, setter?: (vale: unknown)=> void}) {
  return function (target: unknown, propertyKey:string) {
  
    let value: string;
    const getter = customFunctions?.getter || function () {
      return value;
    };
    const setter = customFunctions?.setter || function(newVal: string) {
      value = newVal;
    };
    Object.defineProperty(target, propertyKey, {
      get: getter,
      set: setter
    });
  }
}
