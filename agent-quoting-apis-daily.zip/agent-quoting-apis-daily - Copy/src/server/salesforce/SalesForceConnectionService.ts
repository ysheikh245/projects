import jsforce from 'jsforce'
import {Util} from '../util/Util'
import {$log} from '@tsed/common';

export class SalesForceConnectionService {

    //private static salesForceClient;
    private static _connectionMap = new Map();

    private static isInitialized(connectionKey: string) : boolean {
        //return this.salesForceClient !== undefined;
        return this._connectionMap.get(connectionKey) !== undefined || this._connectionMap.get(connectionKey) != null;
    }

    static async getSpecificSalesForceConnection(connectionKey:string, username:string, password:string) {
        let credentials     = Util.config.credentials[connectionKey];
        let SF_LOGIN_URL    = Util.addPathSegment(credentials.host, credentials['context-root']);
        let connection      = await new jsforce.Connection({loginUrl: SF_LOGIN_URL});
        await connection.login(username, password);
        return connection;
    }

    static async getSalesForceConnection(connectionKey: string, force = false) {
        $log.info(`getSalesForceConnection() - Start. ForceFlag=${force}`)

        let connectionFlag : boolean = (Util.config.config['salesForceConnectionFlag'] == 'true');
        $log.debug(`ConnectionFlag in config.json set to : ${connectionFlag}`);

        // Re-establish the connection if needed based on the flags
        if((connectionFlag || force) || !this.isInitialized(connectionKey)) {
            $log.info('********** Initializing *********** ');

            let credentials     = Util.config.credentials[connectionKey];
            const {password, ...logCred} = credentials;
            $log.debug(logCred); // this change was done to remove the password from the logger statements.
            let SF_LOGIN_URL    = Util.addPathSegment(credentials.host, credentials['context-root']);
            let SF_USER         = credentials.username;
            let SF_PASSWORD     = credentials.password;

            let connection      = await new jsforce.Connection({loginUrl: SF_LOGIN_URL});
            await connection.login(SF_USER, SF_PASSWORD);
            //this.salesForceClient = connection
            this._connectionMap.set(connectionKey, connection);
            $log.info('********** Initialization Completed *********** ');
        } else {
            $log.info('********** Initialized - Using Cached Connection *********** ');
        }
        $log.info('getSalesForceConnection() - Completed')
        //return this.salesForceClient;
        return this._connectionMap.get(connectionKey);
    }
}