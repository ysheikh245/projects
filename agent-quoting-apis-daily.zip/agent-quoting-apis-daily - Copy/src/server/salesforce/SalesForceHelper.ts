export class SalesForceHelper {
    public copyTo (source, mapping, dest) {
        if (!source) {
            return;
        }
        Object.keys(mapping).forEach(function (k) {
            var val = null;
            if (typeof (mapping[k]) == "function") {
                val = mapping[k](source);
            } else {
                val = source[mapping[k]];
            }
            if (val) {
                dest[k] = val;
            }
        });
    }
    
    public onlyDigits (s) {
        return s ? s.replace(/[^0-9]+/g, '') : null;
    }
    
    public addressMapping = {
        "addressType": function () {
            return "homeAddress";
        },
        "addressLine1": "street",
        // "addressLine2" : $.addressLine2.value,
        "city": "city",
        "state": "stateCode",
        "zipCode": "postalCode"
    };
    
    public divisionOfficeMapping = {
        "divisionOffice": "Name"
    }
    
    public getUserMapping() {
        return {
            "divisionOffice": "Division",
            // "licensedStates" : $.licensedStates.value.toString(),
        
            // "prefix" : $.prefix.value,
            "firstName": "FirstName",
            // "middleName" : $.middleName.value,
            "lastName": "LastName",
            // "suffix" : $.suffix.value,
        
            //address fields done by addressMapping
        
            "primaryPhone": function () {
                return "cellPhone";
            },
            // "homePhone" : $.homePhone.value,
            // "workPhone" : $.workPhone.value,
            "cellPhone": function (source) {
                return source.Phone ? source.Phone.replace(/[^0-9]+/g, '') : null;
            },
            // "faxNumber" : $.faxNumber.value,
        
            "emailAddress": "Email"
        }
    };
    
    public getContactMapping() {
        return {
                "npn": "DMS_NPN__c",
            // "npn" : $.npn.value,
            // "licensedStates" : $.licensedStates.value.toString(),
        
            // "prefix" : $.prefix.value,
            "firstName": "FirstName",
            // "middleName" : "Middle_Name__c",
            "lastName": "LastName",
            // "suffix" : "Suffix__c",
        
            //address fields done by addressMapping
        
            "primaryPhone": function () {
                return "homePhone";
            },
            "homePhone": function (source) {
                return source.Phone ? source.Phone.replace(/[^0-9]+/g, '') : null;
            },
            // "workPhone" : $.workPhone.value,
            // "cellPhone" : $.cellPhone.value,
            // "faxNumber" : $.faxNumber.value,
        
            "emailAddress": "Email"
        }
    };
}
// exports.copyTo = (source, mapping, dest) => {
//     if (!source) {
//         return;
//     }
//     Object.keys(mapping).forEach(function (k) {
//         var val = null;
//         if (typeof (mapping[k]) == "function") {
//             val = mapping[k](source);
//         } else {
//             val = source[mapping[k]];
//         }
//         if (val) {
//             dest[k] = val;
//         }
//     });
// }

// onlyDigits = (s) => {
//     return s ? s.replace(/[^0-9]+/g, '') : null;
// }

// exports.addressMapping = {
//     "addressType": function () {
//         return "homeAddress";
//     },
//     "addressLine1": "street",
//     // "addressLine2" : $.addressLine2.value,
//     "city": "city",
//     "state": "stateCode",
//     "zipCode": "postalCode"
// };

// exports.divisionOfficeMapping = {
//     "divisionOffice": "Name"
// }

// exports.userMapping = {
//     "divisionOffice": "Division",
//     // "licensedStates" : $.licensedStates.value.toString(),

//     // "prefix" : $.prefix.value,
//     "firstName": "FirstName",
//     // "middleName" : $.middleName.value,
//     "lastName": "LastName",
//     // "suffix" : $.suffix.value,

//     //address fields done by addressMapping

//     "primaryPhone": function () {
//         return "cellPhone";
//     },
//     // "homePhone" : $.homePhone.value,
//     // "workPhone" : $.workPhone.value,
//     "cellPhone": function (source) {
//         return onlyDigits(source.Phone);
//     },
//     // "faxNumber" : $.faxNumber.value,

//     "emailAddress": "Email"
// };

// exports.contactMapping = {
//     "npn": "DMS_NPN__c",
//     // "npn" : $.npn.value,
//     // "licensedStates" : $.licensedStates.value.toString(),

//     // "prefix" : $.prefix.value,
//     "firstName": "FirstName",
//     // "middleName" : "Middle_Name__c",
//     "lastName": "LastName",
//     // "suffix" : "Suffix__c",

//     //address fields done by addressMapping

//     "primaryPhone": function () {
//         return "homePhone";
//     },
//     "homePhone": function (source) {
//         return onlyDigits(source.Phone);
//     },
//     // "workPhone" : $.workPhone.value,
//     // "cellPhone" : $.cellPhone.value,
//     // "faxNumber" : $.faxNumber.value,

//     "emailAddress": "Email"
// };