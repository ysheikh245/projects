import express from 'express'
import { $log } from "@tsed/common";

import modRoutes from './routes/ModRoutes'
import commonManifestRoutes from './routes/CommonManifestRoutes'
import aedRoutes from './routes/AedRoutes'
import aedRoutesv2 from './routes/AedRoutesv2'
import productUIConfigRoutes from './routes/ProductUIConfigRoutes'
import cashValueRoutes from './routes/CashValueRoutes'
import nonforfeitureETIRoutes from './routes/NonforfeitureETIRoutes'
import nonforfeitureRPURoutes from './routes/NonforfeitureRPURoutes'
import planRoutes from './routes/PlanRoutes'
import productRoutes from './routes/ProductRoutes'
import productManifestRoutes from './routes/ProductManifestRoutes'
import qmsAdjustmentGroupRoutes from './routes/QmsAdjustmentGroupRoutes'
import qmsAreaRoutes from './routes/QmsAreaRoutes'
import qmsRatesRoutes from './routes/QmsRatesRoutes'
import rateRoutes from './routes/RateRoutes'
import randomRoute from './routes/RandomRoute'
import userValidityRoute from "./routes/CheckUserValidityRoutes";
import checkForUpdateRoutes from "./routes/CheckForUpdateRoutes";
import salesForceLoginRoutes from "./routes/SalesForceLoginRoutes";
import manifestSyncRoutes from "./routes/ManifestSyncRoutes";
import {performAPIKeyValidation} from "./routes/ApiKeyValidationRoutes";
import dbServiceV2  from './db/DbServiceV2';
import { homedir } from "os";
import { join } from "path";
import { access, constants, createReadStream } from 'fs'
import { createInterface } from 'readline'
import bodyParser from 'body-parser';

import { Util } from './util/Util'
import apiRoutes from "./routes/ApiRoutes";
import environmentVariables from "./routes/EnvironmentVariables";
import mobileRateRatesRoutes from "./routes/MobileRateRatesRoutes";
import mobileRateAreasRoutes from "./routes/MobileRateAreasRoutes";
import mobileRateAdjustmentGroupRoutes from "./routes/MobileRateAdjustmentGroupRoutes";
import agentsRoutes from "./routes/AgentsRoutes";

const app = express()
const port = 3000

// app.all('/*', function(_, res) {
//   res.sendFile('./app/dist/pantry/index.html', { root: path.resolve(`${__dirname}/..`) });
// });


app.use(express.json({limit: '100mb'}));
app.use(express.urlencoded({limit: '100mb'}));
// app.use(bodyParser.json())



async function loadEnvironmentObject() {
  const o:any = {}
  const envHome = process.env['environment.home'] as string ? process.env['environment.home'] as string : homedir()
  const checkFileExists = (s:string) => new Promise(r=>access(s, constants.F_OK, e => r(!e)))
  const envPath = join(envHome, 'environment.properties')
  let envMap:any = {};
  if (await checkFileExists(envPath)) {

    $log.debug(`Reading from ${envPath}`)

    const rl = createInterface({
      input: createReadStream(envPath),
      crlfDelay: Infinity
    });
    // Note: we use the crlfDelay option to recognize all instances of CR LF
    // ('\r\n') in input.txt as a single line break.
    const bool = (flag: string) => Util.get(flag.match(/(y|Y|true)|(n|N|false)/), (m: any[]) => !!m[1])
    for await (const line of rl) {
      if (line.trim()) {
        // $log.trace(`Line from file: ${line}`);
        const m:any = /^pm\.core\.environment\.(istest|name|systemdate|adhoc\.holiday|cycledate)+=(.*)$/g.exec(line)
				if (m) {
          envMap[m[1]] = m[2];
          // $log.debug(`Line from file: ${line}`);
          // $log.debug(`m: ${m}`);
          // $log.debug(`m[1]: ${m[1]}`);
          // $log.debug(`m: ${m}`);
          o[m[1]] = m[1] === 'istest' ? bool(m[2]) : m[2]
				} else {
					$log.info(`${line}: does not match regex.`);
				}
      }
    }
    $log.debug(`envMap`, JSON.stringify(envMap));
    Util.env = envMap;
  }
  return o
}

app.use('/api', performAPIKeyValidation); // performs the API key validation
app.use('/api', productRoutes);
app.use('/api', productManifestRoutes);
app.use('/api', aedRoutes);
app.use('/api', productUIConfigRoutes);
app.use('/api', cashValueRoutes);
app.use('/api', nonforfeitureETIRoutes);
app.use('/api', nonforfeitureRPURoutes);
app.use('/api', planRoutes);
app.use('/api', rateRoutes);

app.use('/api', qmsAdjustmentGroupRoutes);
app.use('/api', qmsAreaRoutes);
app.use('/api', qmsRatesRoutes);

app.use('/api', modRoutes);
app.use('/api', commonManifestRoutes);

app.use('/api', randomRoute);

app.use('/api', userValidityRoute);

app.use('/api', checkForUpdateRoutes);

app.use('/api', environmentVariables);
app.use('/api', apiRoutes);
app.use('/api', salesForceLoginRoutes);
app.use('/api', manifestSyncRoutes);

// Generic Rates
app.use('/api', mobileRateRatesRoutes);
app.use('/api', mobileRateAreasRoutes);
app.use('/api', mobileRateAdjustmentGroupRoutes);

// Agents PMAPI
app.use('/api', agentsRoutes);

dbServiceV2.connect(err => {
  if (err) {
    console.log("Error: ", err);
    process.exit(1);
  }
  console.log('DBService V2 Connected');
  app.listen(port, async () => {
    loadEnvironmentObject();
        
    console.log(`Example app listening at http://localhost:${port}`)
  })
});

module.exports=app;