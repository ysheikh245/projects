import {Element} from "./Element";
import {Property} from "@tsed/schema";

/**
 * @deprecated: Please delete the call once the legacy application is shut down
 */
export class AppManifestProduct {

    productCode: string
    productType: string
    productDescription: string
    active: boolean
    deleteFlag: boolean
    lastUpdated: string
    aed: Element
    plan: Element
    rate: Element
    cashValue: Element
    nonforfeitureRPU: Element
    nonforfeitureETI: Element
    medSuppData: AppManifestMedSuppData

}

export class AppManifestMedSuppData {
    @Property()
    adjGroups: string[] = []

    @Property()
    //stateRates: AppManifestMedSuppStateData[] = []
    stateRates : any = new Object()
}

/*
export class AppManifestMedSuppStateData {
    @Property()
    state: string

    @Property()
    rates: string[] = []

    @Property()
    areas: string[] = []
}*/
