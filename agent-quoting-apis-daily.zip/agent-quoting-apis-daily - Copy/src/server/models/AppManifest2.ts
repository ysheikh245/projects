import {CommonManifest} from "./CommonManifest";
import {AppManifestProduct2} from "./AppManifestProduct2";

export class AppManifest2 {
        commonManifest: CommonManifest;
        products: Array<AppManifestProduct2>;
        lastChecked: string
}