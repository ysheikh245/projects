import {Required} from "@tsed/schema";
import {GenericAuditModel} from '../models'

export class MobileRateRates extends GenericAuditModel {
	@Required()
	businessType: string

	//@Required()
	productCode: string

	@Required()
	state: string

	@Required()
	effectiveDate: string

	@Required()
	records: string

	// @Required()
	// systemType: string // this is not needed
}