import { Required, Property } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class QmsArea extends GenericAuditModel {
	@Required()
	businessType: string

	@Required()
	state: string

	@Required()
	effectiveDate: string

	@Required()
	records: string;
}