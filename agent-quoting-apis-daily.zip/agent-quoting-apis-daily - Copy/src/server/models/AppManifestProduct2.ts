import {Property} from "@tsed/schema";

export class AppManifestProduct2 {
    productCode: string
    productType: string
    productDescription: string
    active: boolean
    deleteFlag: boolean
    lastUpdated: string
    productUIConfigId: string
    planId: string
    rateId: string
    cashValueId: string
    nonforfeitureRPUId: string
    nonforfeitureETIId: string
    mobileData: AppManifestMedSuppData2
}

export class AppManifestMedSuppData2 {
    @Property()
    adjGroups: string[] = []

    @Property()
    //stateRates: AppManifestMedSuppStateData[] = []
    stateRates : any = new Object()
}
