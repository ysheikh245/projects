import { Required, Property } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class Rate extends GenericAuditModel {
	@Required()
	productCode: string

	@Required()
	version: string

	@Required()
	effectiveDate: string

	@Required()
	jsonData: string
}