import { Required, Property } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class QmsAdjustmentGroup extends GenericAuditModel {
	@Required()
	businessType: string

	@Required()
	effectiveDate: string

	@Required()
	records: string
}