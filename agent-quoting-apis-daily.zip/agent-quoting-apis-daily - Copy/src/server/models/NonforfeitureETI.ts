import { Required } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class NonforfeitureETI extends GenericAuditModel {
	@Required()
	productCode: string

	@Required()
	version: string

	@Required()
	effectiveDate: string

	@Required()
	jsonData: string
}