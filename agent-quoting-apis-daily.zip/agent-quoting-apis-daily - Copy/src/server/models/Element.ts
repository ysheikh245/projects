export class Element {
    localId: string
    serverId: string
}