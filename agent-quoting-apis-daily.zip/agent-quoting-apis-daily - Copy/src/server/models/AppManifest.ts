import {Mod} from "./Mod";
import {Product} from "./Product";
import {State} from "./State";

/**
 * @deprecated: Please delete the call once the legacy application is shut down
 */

export class AppManifest {
        mod: Mod;
        products: Array<Product>;
        states: Array<State>;
        //lastUpdated: string;
}