import { Required } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class Product extends GenericAuditModel {
	@Required()
	productCode: string

	@Required()
	kindCode: string

	@Required()
	active: boolean

	@Required()
	deleteFlag: boolean

	@Required()
	type: string

	@Required()
	name: string
}