import {Required} from "@tsed/schema";
import {GenericAuditModel} from '../models'

export class MobileRateAdjustmentGroup extends GenericAuditModel {
	@Required()
	businessType: string

	@Required()
	effectiveDate: string

	@Required()
	records: string

	// @Required()
	// productCode: string // this is not   	needed

	// @Required()
	// state: string // this is not needed; not a state specific data
	//
	// @Required()
	// systemType: string // this is not needed
}