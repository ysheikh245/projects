import { Required } from "@tsed/schema";
import { GenericAuditModel} from '../models'

export class Plan extends GenericAuditModel {
	@Required()
	productCode: string

	@Required()
	version: string

	@Required()
	effectiveDate: string

	@Required()
	jsonData: string
}