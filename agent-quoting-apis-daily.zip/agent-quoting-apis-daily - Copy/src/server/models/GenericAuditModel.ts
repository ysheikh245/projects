import { Property } from "@tsed/schema";

export class GenericAuditModel {
	@Property()
	_id: string
	
	@Property()
	createdTimestamp: string;

	@Property()
	updatedTimestamp: string;

	@Property()
	updatedBy: string;
}