import { Required } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class CommonManifest extends GenericAuditModel {
	@Required()
	modId: string
}