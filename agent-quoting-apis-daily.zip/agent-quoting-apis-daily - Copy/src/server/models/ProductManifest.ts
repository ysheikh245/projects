import { Required, Property } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class ProductManifest extends GenericAuditModel {
	@Required()
	productCode: string

	@Property()
	aedId: string

	@Property()
	productUIConfig: string

	@Property()
	cashValueId: string

	@Property()
	nonforfeitureRPUId: string

	@Property()
	nonforfeitureETIId: string

	@Property()
	planId: string

	@Property()
	ratesId: string

	@Property()
	medSuppData: MedSuppData
}


export class MedSuppData {
	@Property()
	adjGroups: string[]

	@Property()
	stateRates: MedSuppStateData[] = []
}


export class MedSuppStateData {
	@Property()
	state: string

	@Property()
	rates: string[]
	
	@Property()
	areas: string[]
}
