import {Required} from "@tsed/schema";

export class ManifestSync {
    mod: Mod;
    products: Array<Product> = [];
    states: Array<string> = [];
}

export class Mod {
    id: string;
    version: string;
    effectiveDate: string;
    jsonData: string;
}

export class Product {
    productCode: string;
    productType: string;
    productDescription: string;
    update: boolean;

    kindCode: string;
    active: boolean;
    deleteFlag: boolean;
    version: string;
    effectiveDate: string;
    type: string;
    name: string;

    medSuppData: ManifestMedSuppData;

    //spdaData: {};
    //spiaData: {};

    aed: ManifestSyncElement = new ManifestSyncElement();
    plan: ManifestSyncElement = new ManifestSyncElement();
    rate: ManifestSyncElement = new ManifestSyncElement();
    cashValue: ManifestSyncElement = new ManifestSyncElement();
    nonforfeitureRPU: ManifestSyncElement = new ManifestSyncElement();
    nonforfeitureETI: ManifestSyncElement = new ManifestSyncElement();
}

export class ManifestMedSuppData {
    id: string;
    qmsAdjustmentGroup : Array<ManifestSyncAdjustmentGroup> = [];
    stateRates : any;
}

export class ManifestSyncElement {
    id: string;
    productCode: string
    version: string
    effectiveDate: string
    jsonData: string
}

export class ManifestSyncAdjustmentGroup {
    id: string;
    businessType: string
    effectiveDate: string
    records: string
}