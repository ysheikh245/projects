import { GenericAuditModel } from '../models'

export class Mod extends GenericAuditModel {
    // @Required()
	version: string

	// @Required()
	effectiveDate: string

	// @Required()
	jsonData: string
}