export class State {
        id: string;
        localId: string;
        serverId: string;
        code : string;
        name: string;
        active: string;
        serverVersion: string;
        serverEffectiveDate: string;
        deleteFlag: boolean
}