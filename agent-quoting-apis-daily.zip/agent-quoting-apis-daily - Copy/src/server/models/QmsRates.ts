import { Required } from "@tsed/schema";
import { GenericAuditModel } from '../models'

export class QmsRates extends GenericAuditModel {
	@Required()
	businessType: string

	@Required()
	state: string

	@Required()
	effectiveDate: string

	@Required()
	records: string
}