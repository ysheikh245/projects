const Joi = require('joi');
const modSchema = Joi.object().keys({
    "version": Joi.string().required(),
    "effectiveDate": Joi.string().required(),
    "jsonData": Joi.object().required()
}).required()
   
export default modSchema;


