const Joi = require('joi');
const qmsAdjustmentGroupSchema = Joi.object().keys({
    "businessType": Joi.string().required(),
    "effectiveDate": Joi.string().required(),
    "records": Joi.array().required()
}).required()
   
export default qmsAdjustmentGroupSchema;


