const Joi = require('joi');
const qmsAreaSchema = Joi.object().keys({
    "businessType": Joi.string().required(),
    "effectiveDate": Joi.string().required(),
    "state": Joi.string().required(),
    "records": Joi.array().required()
}).required()
   
export default qmsAreaSchema;


