import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { CashValueService }  from '../service/CashValueService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const cashValueService = new CashValueService();



pmRouter.get('/cashvalue/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET CashValueRoutes./cashvalue/:productCode', req);
  cashValueService.getCashValue(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET CashValueRoutes./cashvalue/:productCode');
    let results = []; 
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET CashValueRoutes./cashvalue/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/cashvalue/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET CashValueRoutes./cashvalue/id/:id', req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET CashValueRoutes./cashvalue/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  cashValueService.getCashValueById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET CashValueRoutes./cashvalue/id/:id');
    let results = [];
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET CashValueRoutes./cashvalue/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/cashvalue', async (req, res) => {
  ApiLoggerUtility.logStart('GET CashValueRoutes./cashvalue', req);
  cashValueService.getAllCashValues().then(results => {
    ApiLoggerUtility.logCompletion('GET CashValueRoutes./cashvalue');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET CashValueRoutes./cashvalue', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/cashvalue', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST CashValueRoutes./cashvalue', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!cashValueService.validateRequest(req.body)) {
    $log.error('POST CashValueRoutes./cashvalue - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  cashValueService.addUpdateCashValue(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST CashValueRoutes./cashvalue');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('POST CashValueRoutes./cashvalue', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/cashvalue/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE CashValueRoutes./cashvalue/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  cashValueService.deleteCashValue(req.params.id, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE CashValueRoutes./cashvalue/:id');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE CashValueRoutes./cashvalue/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/cashvalue/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE CashValueRoutes./cashvalue/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  cashValueService.deleteCashValueByProductCode(req.params.productCode, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE CashValueRoutes./cashvalue/productcode/:productCode');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE CashValueRoutes./cashvalue/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;