import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { NonforfeitureETIService }  from '../service/NonforfeitureETIService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const nonforfeitureETIService = new NonforfeitureETIService();


pmRouter.get('/nonforfeitureeti/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET NonforfeitureETIRoutes./nonforfeitureeti/:productCode', req);
  nonforfeitureETIService.getNonforfeitureETI(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET NonforfeitureETIRoutes./nonforfeitureeti/:productCode');
    let results = [];
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET NonforfeitureETIRoutes./nonforfeitureeti/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/nonforfeitureeti/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET NonforfeitureETIRoutes./nonforfeitureeti/id/:id', req);
 // validating id
 if(!Util.validateID(req.params.id)){
  $log.error('GET NonforfeitureETIRoutes./nonforfeitureeti/id/:id - ID Validation Failed');
  return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
}
  nonforfeitureETIService.getNonforfeitureETIById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET NonforfeitureETIRoutes./nonforfeitureeti/id/:id');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET NonforfeitureETIRoutes./nonforfeitureeti/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/nonforfeitureeti', async (req, res) => {
  ApiLoggerUtility.logStart('GET NonforfeitureETIRoutes./nonforfeitureeti', req);
  nonforfeitureETIService.getAllNonforfeitureETIs().then(results => {
    ApiLoggerUtility.logCompletion('GET NonforfeitureETIRoutes./nonforfeitureeti');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET NonforfeitureETIRoutes./nonforfeitureeti', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/nonforfeitureeti', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST NonforfeitureETIRoutes./nonforfeitureeti', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!nonforfeitureETIService.validateRequest(req.body)) {
    $log.error('POST NonforfeitureETIRoutes./nonforfeitureeti - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  nonforfeitureETIService.addUpdateNonforfeitureETI(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST NonforfeitureETIRoutes./nonforfeitureeti');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('POST NonforfeitureETIRoutes./nonforfeitureeti', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/nonforfeitureeti/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE NonforfeitureETIRoutes./nonforfeitureeti/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  nonforfeitureETIService.deleteNonforfeitureETI(req.params.id, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE NonforfeitureETIRoutes./nonforfeitureeti/:id');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE NonforfeitureETIRoutes./nonforfeitureeti/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/nonforfeitureeti/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE NonforfeitureETIRoutes./nonforfeitureeti/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  nonforfeitureETIService.deleteNonforfeitureETIByProductCode(req.params.productCode, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE NonforfeitureETIRoutes./nonforfeitureeti/productcode/:productCode');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE NonforfeitureETIRoutes./nonforfeitureeti/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;