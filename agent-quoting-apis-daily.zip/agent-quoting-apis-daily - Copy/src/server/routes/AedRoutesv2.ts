import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { AedService }  from '../service/AedService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {AedServicev2} from "../service/AedServicev2";

const pmRouter = express.Router();
const aedServicev2 = new AedServicev2();


pmRouter.get('/aed/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutesv2./aed/:productCode', req);
  let results = [];
  aedServicev2.getAed(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET AedRoutesv2./aed/:productCode');
     /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutesv2./aed/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});




pmRouter.get('/aed/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutesv2./aed/id/:id', req);
  // validating ID
  if(!Util.validateID(req.params.id)){
    $log.error('GET AedRoutesv2./aed/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  let results = [];
  aedServicev2.getAedById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET AedRoutesv2./aed/id/:id');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutesv2./aed/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/aed/', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutesv2./aed', req);
  aedServicev2.getAllAeds().then(results => {
    ApiLoggerUtility.logCompletion('GET AedRoutesv2./aed');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    // if(data != null) {
    //   results.push(data);
    // }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutesv2./aed', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/aed/', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST AedRoutesv2./aed', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  // validate the request
  if(!aedServicev2.validateRequest(req.body)) {
    $log.error('POST AedRoutesv2./aed - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  aedServicev2.addUpdateAed(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST AedRoutesv2./aed');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('POST AedRoutesv2./aed', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/aed/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE AedRoutesv2./aed/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  aedServicev2.deleteAed(req.params.id, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE AedRoutesv2./aed/:id');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE AedRoutesv2./aed/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/aed/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE AedRoutesv2./aed/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  aedServicev2.deleteAedByProductCode(req.params.productCode, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE AedRoutesv2./aed/productcode/:productCode');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE AedRoutesv2./aed/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;