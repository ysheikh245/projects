import {$log} from "@tsed/common";
import {pmResponse} from "../util/PmResponse";
import {Util} from "../util/Util";

const apikey = Util.config.credentials.apikey;

export const performAPIKeyValidation = (request, response, next) => {
    $log.info(`----------------------- ApiKeyValidationRoutes.performAPIKeyValidation : Start -----------------------`)
    const apiKey = request.headers['apikey'];
    //$log.debug(`APIKey==> ${apiKey}`)

    if(!apiKey || apiKey==null) {
        $log.info('API key is absent in the request header');
        //response.status(401).send('API Key is absent in the request header')
        pmResponse(response, 401, {'error': 'API key is absent in the request header'});
    } else if(apiKey && apiKey !== apikey) {
        $log.info('Invalid API Key');
        //throw new Error('Invalid API key');
        pmResponse(response, 401, {'error': 'Invalid API key'});
    } else {
        $log.info('Forwarding to the next middleware');
        $log.info(`----------------------- ApiKeyValidationRoutes.performAPIKeyValidation : End ---------------------`)
        next();
    }
  };