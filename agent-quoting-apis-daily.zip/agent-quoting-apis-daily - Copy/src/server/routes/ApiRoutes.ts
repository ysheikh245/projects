import express from 'express'
import {$log} from '@tsed/common';
import {pmResponse} from '../util/PmResponse'
import {SalesforceService} from '../service/SalesforceService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const salesforceService = new SalesforceService();

const OPPORTUNITY_QUOTE_API = 'APIRoutes.opportunity/quote';
const OPPORTUNITY_QUOTE_HISTORY_API = 'APIRoutes.opportunity/quote/history';

pmRouter.post('/opportunity/quote', async (req, res) => {
  ApiLoggerUtility.logStart(OPPORTUNITY_QUOTE_API, req);
  var opportunityJSON = req.body as any;
  $log.debug('opportunityJSON ------------', opportunityJSON);
  $log.debug('opportunityJSON ------------', opportunityJSON.opportunityId);
  if (!opportunityJSON || !opportunityJSON.opportunityId) {
    const error = 'The opportunityId parameter was null or empty'
    $log.error(error);
    return pmResponse(res, 400, { error } );
  }

  try {
    let results = await salesforceService.addOpportunityQuote(opportunityJSON);
    if ( results == null ) {
      ApiLoggerUtility.logCompletion(OPPORTUNITY_QUOTE_API);
      return pmResponse(res, 200, { "message": "Successfully updated opportunity." } );
    } else {
      return pmResponse(res, 404, { "message": `Opportunity id "${req.body.opportunityId}" was not found.` } );
    }
  } catch(error) {
    ApiLoggerUtility.logError(OPPORTUNITY_QUOTE_API, error);
    return pmResponse(res, 500, { "message": "Internal Server error -> " + error } );
  }
});

pmRouter.post('/opportunity/quote/history', async (request, response) => {
  ApiLoggerUtility.logStart(OPPORTUNITY_QUOTE_HISTORY_API, request);
  let opportunityQuote = (request.body) ? request.body.quote : undefined;

  if(!opportunityQuote) {
    response.status(400).json({"message": "body is required"})
  } else {
    try {
      await salesforceService.addOpportunityQuoteHistory(request.body.quote);
      ApiLoggerUtility.logCompletion(OPPORTUNITY_QUOTE_HISTORY_API);
      response.status(200).json({"message": "Successfully added quote history."})
    } catch(error) {
      ApiLoggerUtility.logError(OPPORTUNITY_QUOTE_HISTORY_API, error);
      response.status(error.statusCode || 500).json({"message": error.message || 'Internal Server error'});
    }
  }
});

export default pmRouter;