import express from 'express'
import moment from 'moment'
import {DateUtil} from "../util";
import {$log} from "@tsed/common";
import { CheckForUpdateService }  from '../service/CheckForUpdateService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {pmResponse} from "../util/PmResponse";

const checkForUpdateService = new CheckForUpdateService();

// const checkForUpdateService = require('../service/CheckForUpdateService')

const pmRouter = express.Router();

pmRouter.post('/checkForUpdates', async (request, response, next) => {
    var startTime = new Date();
    const appManifest = request.body.appManifest;

    ApiLoggerUtility.logStart('CheckForUpdateRoutes.checkForUpdates', request);

    if(!checkForUpdateService.validateRequest(appManifest)) {
        $log.error('CheckForUpdateRoutes.checkForUpdates - Request Validation Failed');
        response.status(400).json({ 'message': 'The appManifest.products parameter was null or empty'} );
    } else {
        try {
            //$log.info('CheckForUpdateRoutes checkForUpdates. Start');
            $log.info('Filtering Duplicate Products. Start');
            appManifest.products = checkForUpdateService.filterDuplicateProducts(appManifest.products); // Remove duplicate product from appManifest and re-assign
            $log.info('Filtering Duplicate Products. Completed');

            $log.info('Finding States. Start');
            let states = checkForUpdateService.findStates();
            $log.info('Finding States. Completed');
            $log.info('Processing States in AppManifest. Start');
            appManifest.states = checkForUpdateService.updateStateManifest(appManifest, states); // Process States and re-assign it back to appManifest
            $log.info('Processing States in AppManifest. Completed');

            $log.info('Querying CommonManifest table. Start');
            let commonManifest = await checkForUpdateService.findCommonManifest();
            $log.info('Querying CommonManifest table. Completed');
            $log.info('Processing CommonManifest. Start');
            await checkForUpdateService.updateCommonManifest(appManifest, commonManifest)
            $log.info('Processing CommonManifest. Completed');

            $log.info('Querying Products. Start');
            let products = await checkForUpdateService.findAllProducts();
            $log.info('Querying Products. Completed');
            $log.info('Processing ProductManifest. Start');
            appManifest.products = await checkForUpdateService.updateProductManifest(appManifest.products, products);
            $log.info('Processing ProductManifest. Completed');
            //appManifest.lastChecked = DateUtil.formatCurrentDate('YYYY-MM-DD HH:mm:ss.SSS');
            //$log.info('CheckForUpdateRoutes checkForUpdates. Completed');
            ApiLoggerUtility.logCompletion('CheckForUpdateRoutes.checkForUpdates');
            response.status(200).json({"appManifest": appManifest})
        } catch(error) {
            // $log.error('CheckForUpdateRoutes checkForUpdates. Failed. Error= ' + error.stack);
            ApiLoggerUtility.logError('CheckForUpdateRoutes.checkForUpdates', error);
            response.status(500).json({'error': error.stack} );// "Error: " + error + ", " + error.stack);
        }
    }
});

///
pmRouter.get('/checkForUpdates', async (request, response) => {
    ApiLoggerUtility.logStart('CheckForUpdateRoutes.checkForUpdates - GET', request);
    try {
        let appManifest = await checkForUpdateService.checkForUpdates();
        ApiLoggerUtility.logCompletion('CheckForUpdateRoutes.checkForUpdates - GET');
        return pmResponse(response, 200, { "appManifest" : appManifest });
    } catch(error) {
        ApiLoggerUtility.logError('CheckForUpdateRoutes.checkForUpdates - GET', error);
        return pmResponse(response, 500, {'error': error.stack} );
    }
});
///

export default pmRouter;