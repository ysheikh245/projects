import express from 'express'
import { $log } from '@tsed/common';
import { pmResponse } from '../util/PmResponse'
import { CommonManifestService }  from '../service/CommonManifestService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const commonManifestService = new CommonManifestService();


pmRouter.get('/commonmanifest', async (req, res) => {
  ApiLoggerUtility.logStart('GET CommonManifestRoutes./commonmanifest', req);
  commonManifestService.getAllCommonManifests().then(results => {
    //let results = [];
    ApiLoggerUtility.logCompletion('GET CommonManifestRoutes./commonmanifest');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    // if(data != null) {
    //   results.push(data);
    // }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET CommonManifestRoutes./commonmanifest', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;