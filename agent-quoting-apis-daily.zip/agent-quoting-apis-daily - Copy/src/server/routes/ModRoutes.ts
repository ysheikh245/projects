import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { ModService }  from '../service/ModService';
import { DBConstants } from '../db/DbConstants';
import modSchema from '../schema/mod';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const modService = new ModService();


pmRouter.get('/mod/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart("GET ModRoutes./mod/id/:id",req);
  // validating ID
  if(!Util.validateID(req.params.id)){
    $log.error('GET ModRoutes./mod/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  modService.getModById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('GET ModRoutes./mod/id/:id');
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET ModRoutes./mod/id/:id',error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/mod', async (req, res) => {
  ApiLoggerUtility.logStart("GET ModRoutes./mod",req);
  modService.getAllMods().then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion('GET ModRoutes./mod');
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET ModRoutes./mod',error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/mod', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart("POST ModRoutes./mod",req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!modService.validateRequest(req.body)) {
    $log.error('POST ModRoutes./mod - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }
  modService.addUpdateMod(req.body, userHeaderDetails).then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion("POST ModRoutes./mod");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("POST ModRoutes./mod",error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/mod/', async (req, res) => {
  ApiLoggerUtility.logStart("DELETE ModRoutes./mod/",req);
  let userHeaderDetails = Util.filterHeader(req);
  modService.deleteMod(userHeaderDetails, null).then(result => {
    ApiLoggerUtility.logCompletion("DELETE ModRoutes./mod/");
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE ModRoutes./mod/",error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/mod/:id', async (req, res) => {
  ApiLoggerUtility.logStart("DELETE ModRoutes./mod/:id", req);
  let userHeaderDetails = Util.filterHeader(req);
  // validating ID
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE ModRoutes./mod/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  modService.deleteMod(userHeaderDetails, req.params.id).then(result => {
    ApiLoggerUtility.logCompletion("DELETE ModRoutes./mod/:id")
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE ModRoutes./mod/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;