import express from 'express'
import { $log } from '@tsed/common';
import { pmResponse } from '../util/PmResponse'
import { ProductManifestService }  from '../service/ProductManifestService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import { Util } from '../util/Util';

const pmRouter = express.Router();
const productManifestService = new ProductManifestService();


pmRouter.get('/productmanifest/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductManifestRoutes./productmanifest/:productCode', req);
  productManifestService.getProductManifest(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET ProductManifestRoutes./productmanifest/:productCode');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductManifestRoutes./productmanifest/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/productmanifest', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductManifestRoutes./productmanifest', req);
  productManifestService.getAllProductManifests().then(results => {
    ApiLoggerUtility.logCompletion('GET ProductManifestRoutes./productmanifest');
    /*if ( results != null  ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductManifestRoutes./productmanifest', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/productmanifest/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE ProductManifestRoutes./product/:id', req);
  // let userHeaderDetails = Util.filterHeader(req);
  productManifestService.deleteProductManifestById(req.params.id).then(results => {
    ApiLoggerUtility.logCompletion('DELETE ProductManifestRoutes./product/:id');
    return pmResponse(res, 200, {results});
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE ProductManifestRoutes./product/:id', error);
    return pmResponse(res, 500, { error } );
  });
});


export default pmRouter;