import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {ProductUIConfigService} from "../service/ProductUIConfigService";

const pmRouter = express.Router();
const productUIConfigService = new ProductUIConfigService();


pmRouter.get('/productUIConfig/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductUIConfigRoutesv2./productUIConfig/:productCode', req);
  let results = [];
  productUIConfigService.getProductUIConfig(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET ProductUIConfigRoutesv2./productUIConfig/:productCode');
     /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductUIConfigRoutesv2./productUIConfig/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});




pmRouter.get('/productUIConfig/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductUIConfigRoutesv2./productUIConfig/id/:id', req);
  // validating ID
  if(!Util.validateID(req.params.id)){
    $log.error('GET ProductUIConfigRoutesv2./productUIConfig/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  let results = [];
  productUIConfigService.getProductUIConfigById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET ProductUIConfigRoutesv2./productUIConfig/id/:id');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductUIConfigRoutesv2./productUIConfig/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/productUIConfig/', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductUIConfigRoutesv2./productUIConfig', req);
  productUIConfigService.getAllProductUIConfigs().then(results => {
    ApiLoggerUtility.logCompletion('GET ProductUIConfigRoutesv2./productUIConfig');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    // if(data != null) {
    //   results.push(data);
    // }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductUIConfigRoutesv2./productUIConfig', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/productUIConfig/', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST ProductUIConfigRoutesv2./productUIConfig', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  // validate the request
  if(!productUIConfigService.validateRequest(req.body)) {
    $log.error('POST ProductUIConfigRoutesv2./productUIConfig - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  productUIConfigService.addUpdateProductUIConfig(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST ProductUIConfigRoutesv2./productUIConfig');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('POST ProductUIConfigRoutesv2./productUIConfig', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/productUIConfig/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE ProductUIConfigRoutesv2./productUIConfig/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  productUIConfigService.deleteProductUIConfig(req.params.id, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE ProductUIConfigRoutesv2./productUIConfig/:id');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE ProductUIConfigRoutesv2./productUIConfig/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/productUIConfig/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE ProductUIConfigRoutesv2./productUIConfig/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  productUIConfigService.deleteProductUIConfigByProductCode(req.params.productCode, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE ProductUIConfigRoutesv2./productUIConfig/productcode/:productCode');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE ProductUIConfigRoutesv2./productUIConfig/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;