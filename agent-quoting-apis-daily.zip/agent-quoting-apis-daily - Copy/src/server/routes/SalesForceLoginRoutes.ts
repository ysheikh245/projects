import express from "express";

import {SalesforceService} from "../service/SalesforceService";
import {SalesForceConnectionService} from "../salesforce/SalesForceConnectionService";
import {Constants} from "../util";
import {$log, Constant} from "@tsed/common";
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const salesForceService = new SalesforceService();

pmRouter.post('/login', async (request, response, next) => {

    ApiLoggerUtility.logStart('SalesForceLoginRoutes./login', request);
    let requestBodyFlag : boolean  = request && request.body;  
    let username        : string = (requestBodyFlag && request.body.username) ? request.body.username : "";
    let password        : string = (requestBodyFlag && request.body.password ) ? request.body.password : "";
    let getUserData     : string = (requestBodyFlag && request.body.getUserData) ? request.body.getUserData : "";

    let isActive : boolean = false;
    let connection = null;
    let userInfo = null;
    let finalRecord = null;

    //$log.trace("Data = :"+ username, password, getUserData)

    if (!salesForceService.validateRequest(username, password)) {
        $log.error(`The input request is not a valid request. Missing mandatory fields. Username=${username}`);
        response.status(400).json({'message': 'Bad request: username and password are required'});
    }
    else {
        $log.info(`Valid Request. Validating and querying the user information. Username=${username}`);
        let getUserDataFlag: boolean = getUserData === 'true';
        $log.debug(`GetUserData Flag = ${getUserDataFlag}`);
        try {
            connection = await salesForceService.getSpecificSalesForceConnection(username.trim(), password);
            userInfo = connection.userInfo;

            // Process only if the userInfo.id exists; otherwise send the response back
            if (!userInfo.id) {
                $log.info('The userInfo object does not contain the id field. Its an un-authorized user. Sending 401 in response');
                response.status(401).json({'message': 'Un-authorized User'});
            } else if(userInfo.id && !getUserDataFlag) {
                $log.info('UserId found - attempting to find more information about the user. GetUserData=false')
                isActive = await salesForceService.isUserActive(connection, userInfo.id)
                finalRecord = {"userInfo": userInfo, "validity": (isActive ? "VALID" : "INVALID")}
            } else {
                let userConsolidatedRecord = null;
                $log.info('UserId found - attempting to find more information about the user. GetUserData=true')

                //let identity = await connection.identity();
                //$log.(`Identity= ${JSON.stringify(identity)}`)

                // Query the User table
                let userRecord = await salesForceService.getUserRecord(connection, userInfo.id);
                isActive = userRecord.IsActive;
                $log.info(`UserRecord fetched. IsActive=${isActive}`)
                $log.debug(`UserRecord=${JSON.stringify(userRecord)}`);

                // Query the Contact table
                if (!userRecord.ContactId) {
                    $log.info('UserRecord.ContactId not present in the User table. Returning back an empty contactRecord');
                    userConsolidatedRecord = {userRecord: userRecord, contactRecord: {}};
                } else {
                    $log.info('ContactId found. Extracting contactRecord')
                    let userContactRecord = salesForceService.getUserContactRecord(connection, userRecord.ContactId);
                    userConsolidatedRecord = (userContactRecord == null) ? {userRecord: userRecord, contactRecord: {}}
                                                                         : {userRecord: userRecord, contactRecord: userContactRecord};
                    //$log.debug(`Contact Table. UserConsolidatedRecord=${JSON.stringify(userConsolidatedRecord)}`);
                }

                // Query the Account table
                if (userConsolidatedRecord.contactRecord && userConsolidatedRecord.contactRecord.AccountId) {
                    $log.info('ContactId found. AccountId found. Querying Account and forming UserAccount');
                    let userAccountRecord = await salesForceService.getUserAccountRecord(connection, userConsolidatedRecord.contactRecord.AccountId)
                    if(userAccountRecord != null) {
                        $log.info('UserAccountRecord present in the Account table');
                        userConsolidatedRecord.divisionOfficeRecord = (userAccountRecord.Parent) ? userAccountRecord.Parent : userAccountRecord;
                    }
                    $log.debug(`UserConsolidatedRecord=${JSON.stringify(userConsolidatedRecord)} after querying Contact and Account table`);
                } else {
                    $log.info('ContactId or ContactId.AccountId not present in the CONTACT table');
                }

                // Form DetailedUserConsolidatedRecord
                let detailedUserConsolidatedRecord = await salesForceService.getDetailedUserRecord(username, userConsolidatedRecord);
                //$log.(`DetailedUserConsolidatedRecord-2=${JSON.stringify(detailedUserConsolidatedRecord)}`);

                finalRecord = {
                    "userInfo": userInfo,
                    "userRecord": detailedUserConsolidatedRecord,
                    "validity": (isActive ? "VALID" : "INVALID")
                };
            }
            //$log.info(`---------------------------- SalesForceLoginRoutes./login - Completed ---------------------------`);
            ApiLoggerUtility.logCompletion('SalesForceLoginRoutes./login')
            response.status(200).json(finalRecord);
        } catch (error) {
            ApiLoggerUtility.logError('SalesForceLoginRoutes./login', error);
            //$log.debug(`Error:= ${error.stack}`)
            //$log.debug(`Error_Code = ${error.code}`)
            if (isActive) {
                $log.info('Error Occurred but userInfo object present. Sending userInfo object and validity=VALID');
                response.status(200).json({userInfo: userInfo, validity: "VALID"});
            } else {
                let status: number = (error.message.indexOf('INVALID_LOGIN') > -1) ? 401 : 500;
                //response.status(status).send(`Error: ${error.stack} }`);
                response.status(status).json({'message': `${error.stack}`});
            }
        }
    }
});

export default pmRouter;