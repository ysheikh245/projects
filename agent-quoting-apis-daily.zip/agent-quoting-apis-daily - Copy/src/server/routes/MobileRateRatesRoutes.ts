import express from 'express'
import {$log} from '@tsed/common';
import {Util} from '../util/Util'
import {Constants} from '../util/Constants'
import {pmResponse} from '../util/PmResponse'
import {ApiLoggerUtility} from '../util/ApiLoggerUtility';
import {MobileRateRatesService} from "../service/MobileRateRatesService";

const pmRouter = express.Router();
const mobileRateRatesService = new MobileRateRatesService();

/** Creating the resource **/
pmRouter.post('/mobileRateRates', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart("POST MobileRateRatesRoute./mobileRateRates",req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!mobileRateRatesService.validateRequest(req.body)) {
    $log.info('POST MobileRateRatesRoute./mobileRateRates - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }
  mobileRateRatesService.addUpdateMobileRateRates(req.body, userHeaderDetails).then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion("POST MobileRateRatesRoute./mobileRateRates");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("POST MobileRateRatesRoute./mobileRateRates",error);
    return pmResponse(res, 500, { error } );
  });
});

/** Get mobile-rate by id */
pmRouter.get('/mobileRateRates/:id', async (req, res) => {
  ApiLoggerUtility.logStart("GET MobileRateRatesRoute./mobileRateRates/:id",req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET MobileRateRatesRoute./mobileRateRates/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  mobileRateRatesService.getMobileRateRatesById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates/:id");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

/** Get mobile-rate passing productCode, effectiveDate, state, systemCode as query string **/
pmRouter.get('/mobileRateRates', async (req, res) => {
  ApiLoggerUtility.logStart("GET MobileRateRatesRoute./mobileRateRates",req);
  //let productCode: string = req.query.productCode ? req.query.productCode.toString() : '';
  let businessType: string = req.query.businessType ? req.query.businessType.toString() : '';
  let effectiveDate = req.query.effectiveDate ? req.query.effectiveDate.toString() : '';
  let state = req.query.state ? req.query.state.toString() : '';
  //let systemType = req.query.systemType ? req.query.systemType.toString() : '';

  if ( businessType != '' && effectiveDate != '' && state != '' ) {
    mobileRateRatesService.getMobileRateRates(businessType, effectiveDate, state).then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates",error);
      return pmResponse(res, 500, { error } );
    });
  } else if ( businessType != '' && state != ''  ) {
    mobileRateRatesService.getMobileRateRatesByBusinessTypeAndState(businessType, state).then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates",error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    mobileRateRatesService.getAllMobileRateRates().then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates",error);
      return pmResponse(res, 500, { error } );
    });
  }
});

/** Get mobile-rate passing productCode, systemCode as query string **/
/*pmRouter.get('/mobileRateRates', async (req, res) => {
  ApiLoggerUtility.logStart("GET MobileRateRatesRoute./mobileRateRates",req);
  let productCode = req.query.productCode ? req.query.productCode.toString() : '';
  let systemType = req.query.systemType ? req.query.systemType.toString() : '';

  if (systemType != '' && productCode != '') {
    mobileRateRatesService.getMobileRateRatesByProductAndSystemType(productCode, systemType).then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates",error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    mobileRateRatesService.getAllMobileRateRates().then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateRatesRoute./mobileRateRates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateRatesRoute./mobileRateRates",error);
      return pmResponse(res, 500, { error } );
    });
  }
});*/

/** Delete mobile-rate entry passing id **/
pmRouter.delete('/mobileRateRates/:id', async (req, res) => {
  ApiLoggerUtility.logStart("DELETE MobileRateRatesRoute./mobileRateRates/:id",req);
  let userHeaderDetails = Util.filterHeader(req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE MobileRateRatesRoute./mobileRateRates/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  mobileRateRatesService.deleteMobileRateRatesById(req.params.id, userHeaderDetails, true).then(result => {
    ApiLoggerUtility.logCompletion("DELETE MobileRateRatesRoute./mobileRateRates/:id");
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE MobileRateRatesRoute./mobileRateRates/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;