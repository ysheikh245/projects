import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { QmsRatesService }  from '../service/QmsRatesService';
import { ApiLoggerUtility } from '../util/ApiLoggerUtility';
import qmsRatesSchema from '../schema/qmsRates';


const pmRouter = express.Router();
const qmsRatesService = new QmsRatesService();


pmRouter.get('/qmsrates/:id', async (req, res) => {
  ApiLoggerUtility.logStart("GET QmsRatesRoutes./qmsrates/:id",req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET QmsRatesRoutes./qmsrates/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  qmsRatesService.getQmsRatesById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion("GET QmsRatesRoutes./qmsrates/:id");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("GET QmsRatesRoutes./qmsrates/:id",error);
    return pmResponse(res, 500, { error } );
  });
});



pmRouter.get('/qmsrates', async (req, res) => {
  ApiLoggerUtility.logStart("GET QmsRatesRoutes./qmsrates",req);
  let businessType: string = req.query.businessType ? req.query.businessType.toString() : '';
  let effectiveDate = req.query.effectiveDate ? req.query.effectiveDate.toString() : '';
  let state = req.query.state ? req.query.state.toString() : '';


  if ( businessType != '' && effectiveDate != '' && state != '' ) {
    qmsRatesService.getQmsRates(businessType, effectiveDate, state).then(results => {
      ApiLoggerUtility.logCompletion("GET QmsRatesRoutes./qmsrates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsRatesRoutes./qmsrates",error);
      return pmResponse(res, 500, { error } );
    });
  } else if ( businessType != '' && state != ''  ) {
    qmsRatesService.getQmsRatesByBusinessTypeState(businessType, state).then(results => {
      ApiLoggerUtility.logCompletion("GET QmsRatesRoutes./qmsrates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsRatesRoutes./qmsrates",error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    qmsRatesService.getAllQmsRates().then(results => {
      ApiLoggerUtility.logCompletion("GET QmsRatesRoutes./qmsrates");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsRatesRoutes./qmsrates",error);
      return pmResponse(res, 500, { error } );
    });
  }
});


pmRouter.post('/qmsrates', async (req: express.Request, res: express.Response) => {

  ApiLoggerUtility.logStart("POST QmsRatesRoutes./qmsrates",req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!qmsRatesService.validateRequest(req.body)) {
    $log.info('POST QmsRatesRoutes./qmsrates - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }
  qmsRatesService.addUpdateQmsRates(req.body, userHeaderDetails).then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion("POST QmsRatesRoutes./qmsrates");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("POST QmsRatesRoutes./qmsrates",error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/qmsrates/:id', async (req, res) => {
  ApiLoggerUtility.logStart("DELETE QmsRatesRoutes./qmsrates/:id",req);
  let userHeaderDetails = Util.filterHeader(req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE QmsRatesRoutes./qmsrates/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  qmsRatesService.deleteQmsRatesById(req.params.id, userHeaderDetails, true).then(result => {
    ApiLoggerUtility.logCompletion("DELETE QmsRatesRoutes./qmsrates/:id");
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE QmsRatesRoutes./qmsrates/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;