import express from 'express'
import {pmResponse} from '../util/PmResponse'
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {AgentsService} from "../service/AgentsService";
import {Constants} from "../util";
import {$log} from "@tsed/common";
import {Util} from "../util/Util";
import axios from "axios";

const pmRouter = express.Router();
const agentsService = new AgentsService();

const https = require('https');
const Axios = axios.create({
    httpsAgent: new https.Agent({
        rejectUnauthorized: false
    }),
    responseType: 'json'
});

/*pmRouter.get('/agent/:npn', async (req, res) => {
    ApiLoggerUtility.logStart('GET AgentsRoutes./:npn', req);
    try {
        let data = await agentsService.getAgentDetails(req.params.npn)
        ApiLoggerUtility.logCompletion('GET AgentsRoutes./:npn');
        return pmResponse(res, 200, data)
    } catch (error) {
        ApiLoggerUtility.logError('GET AgentsRoutes./:npn', error);
        return pmResponse(res, 500, {error});
    }
});*/

pmRouter.get('/agent', async (req, res) => {
    ApiLoggerUtility.logStart('GET AgentsRoutes./:npn', req);

    let npn = '';
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    // Look for the token. If token present; hit the KeyCloak service to validate the token
    if (token) {
        let keyCloakConfig = Util.config.credentials[Constants.KEYCLOAK_CONFIG];
        let headers = {
            'Authorization': `Bearer ${token}`,
            'clientId': `${keyCloakConfig['client-id']}`,
        }
        await Axios.get(`${keyCloakConfig['host']}`, {headers}).then(response => {
            if (response && response['data'] && response['data']['pmicnpn']) {
                npn = response['data']['pmicnpn']
                $log.info(`NPN from token: `, npn)
            } else {
                res.status(401).json({'message': 'Un-authorized User'});
            }
        }).catch(error => {
            console.log(error)
            res.status(401).json({'message': 'Un-authorized User'});
        });
    } else {
        res.status(401).json({'message': 'Un-authorized User'});
    }

    // After the token is validated; invoke agentsService to extract the NPN
    if (npn !== '') {
        $log.info('NPN extracted from token successfully. Invoking PMAPI to get agents details')
        try {
            let data = await agentsService.getAgentDetails(npn);
            return pmResponse(res, 200, data);
        } catch(error) {
            if (error) {
                $log.error("Please check the credentials in the configuration file(s). Most likely it could be the CREDENTIAL issue")
                error = Constants.UNKNOWN_ERROR
                return pmResponse(res, 500, {error});
            }
        }
    } else {
        $log.info('NPN extracted from the token was BLANK. Cannot invoke PMAPI api')
        return pmResponse(res, 500, {'message': 'NPN extracted from token is BLANK'});
    }
});

export default pmRouter;