import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { ProductService }  from '../service/ProductService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {Product} from "../models";

const pmRouter = express.Router();
const productService = new ProductService();


pmRouter.get('/product/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductRoutes./product/:productCode', req);
  let results = []
  productService.getProduct(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET ProductRoutes./product/:productCode');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductRoutes./product/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

// pmRouter.get('/product/id/:id', async (req, res) => {
//   $log.debug('Get product.....req.params.id', req.params.id);
//   productService.getProductById(req.params.id).then(results => {
//     if ( results != null ) {
//       return pmResponse(res, 200, { results } );
//     } else {
//       return pmResponse(res, 404, { results } );
//     }
//   }).catch(error => {
//     return pmResponse(res, 500, { error } );
//   });
// });

pmRouter.get('/product', async (req, res) => {
  ApiLoggerUtility.logStart('GET ProductRoutes./product', req);
  productService.getAllProducts().then(results => {
    ApiLoggerUtility.logCompletion('GET ProductRoutes./product');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    //let result = (results != null) ? results : {}
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET ProductRoutes./product', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/product', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST ProductRoutes./product', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!productService.validateRequest(req.body)) {
    $log.error('POST ProductRoutes./product - Request Validation Failed');
    res.status(400).json({ 'message': Constants.INPUT_REQUIRED});
  }
  //Forcing kindCode to be string
  if(req.body.kindCode){
    req.body.kindCode=req.body.kindCode.toString()
  }
  productService.addUpdateProduct(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST ProductRoutes./product');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } )
  }).catch(error => {
    ApiLoggerUtility.logError('POST ProductRoutes./product', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.put('/product/:productCode', async(req, res, ) => {
  ApiLoggerUtility.logStart('PUT ProductRoutes./product/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!productService.validateRequest(req.body)) {
    $log.error('PUT ProductRoutes./product/:productCode - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  productService.addUpdateProduct(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('PUT ProductRoutes./product/:productCode');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('PUT ProductRoutes./product/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.put('/product', async(req, res, ) => {
  ApiLoggerUtility.logStart('PUT ProductRoutes./product', req);
  try {
    let userHeaderDetails = Util.filterHeader(req);
    let body = req.body;
    let productCodes = body.productCodes.split(",");
    let activeFlag = body.active;
    let updatedProducts = [];

    for (const productCode of productCodes) {
      try {
        $log.info(`Attempting to update Product records: Product=${productCode}, Active=${activeFlag}`);
        let retrievedProduct: Product = await productService.getProduct(productCode.trim());
        $log.debug(`Retrieved Product=${JSON.stringify(retrievedProduct)}`);
        retrievedProduct['active'] = activeFlag && (activeFlag === 'true');
        //console.log(`****************************************************************** ActiveFlag=${retrievedProduct['active']}`);
        let updatedProduct = await productService.addUpdateProduct(retrievedProduct, userHeaderDetails);
        updatedProducts.push(updatedProduct);
        $log.info(`Product Updated Completed Successfully. Product=${productCode}, Active=${activeFlag} `);
        ApiLoggerUtility.logCompletion(`PUT ProductRoutes./product`)
      } catch(error) {
        $log.error(`Product Updated Failed. ProductCode=${productCode}, Active=${activeFlag}, Error=${error}`);
      }
    }
    return pmResponse(res, 200, {updatedProducts})
  } catch (error) {
    ApiLoggerUtility.logError('PUT ProductRoutes./product', error);
    return pmResponse(res, 500, {error})
  }
});


pmRouter.delete('/product/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE ProductRoutes./product/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  productService.deleteProduct(req.params.productCode, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('DELETE ProductRoutes./product/:productCode');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE ProductRoutes./product/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/product/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE ProductRoutes./product/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  productService.deleteProductById(req.params.id, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('DELETE ProductRoutes./product/:id');
    return pmResponse(res, 200, {results});
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE ProductRoutes./product/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;