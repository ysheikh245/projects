import express from 'express'
import {$log} from '@tsed/common';
import {Util} from '../util/Util'
import {Constants} from '../util/Constants'
import {pmResponse} from '../util/PmResponse'
import {ApiLoggerUtility} from '../util/ApiLoggerUtility';
import {MobileRateAreasService} from "../service/MobileRateAreasService";

const pmRouter = express.Router();
const mobileRateAreasService = new MobileRateAreasService();

/** Creating the resource **/
pmRouter.post('/mobileRateAreas', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST MobileRateAreasRoutes./mobileRateAreas',req.body);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!mobileRateAreasService.validateRequest(req.body)) {
    $log.info('POST MobileRateAreaRoutes./mobileRateAreas - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }

  mobileRateAreasService.addUpdateMobileRateAreas(req.body, userHeaderDetails).then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion("POST MobileRateAreasRoutes./mobileRateAreas")
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("POST MobileRateAreasRoutes./mobileRateAreas",error);
    return pmResponse(res, 500, { error } );
  });
});

/** Get mobile-rate areas by id */
pmRouter.get('/mobileRateAreas/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET MobileRateAreaRoutes./mobileRateAreas/:id"',req.body);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET MobileRateAreaRoutes./mobileRateAreas/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  mobileRateAreasService.getMobileRateAreaById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion("GET MobileRateAreaRoutes./mobileRateAreas/:id");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("GET MobileRateAreaRoutes./mobileRateAreas/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

/** Get mobile-rate areas passing productCode, effectiveDate, state, systemCode as query string **/
pmRouter.get('/mobileRateAreas', async (req, res) => {
  ApiLoggerUtility.logStart('GET MobileRateAreaRoutes./mobileRateAreas',req.body);

  //let productCode = req.query.productCode ? req.query.productCode.toString() : '';
  let businessType: string = req.query.businessType ? req.query.businessType.toString() : '';
  let effectiveDate = req.query.effectiveDate ? req.query.effectiveDate.toString() : '';
  let state = req.query.state ? req.query.state.toString() : '';
  //let systemType = req.query.systemType ? req.query.systemType.toString() : '';

  if ( businessType != '' && effectiveDate != '' && state != '' ) {
    mobileRateAreasService.getMobileRateAreas(businessType, effectiveDate, state).then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateAreasRoute./mobileRateAreas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateAreasRoute./mobileRateAreas",error);
      return pmResponse(res, 500, { error } );
    });
  } else if ( businessType != '' && state != '' ) {
    mobileRateAreasService.getMobileRateAreasByBusinessTypeAndState(businessType, state).then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateAreasRoute./mobileRateAreas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateAreasRoutes./mobileRateAreas",error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    mobileRateAreasService.getAllMobileRateAreas().then(results => {
      ApiLoggerUtility.logCompletion("GET MobileRateAreasRoutes./mobileRateAreas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET MobileRateAreasRoutes./mobileRateAreas",error);
      return pmResponse(res, 500, { error } );
    });
  }
});


pmRouter.delete('/mobileRateAreas/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE MobileRateAreasRoutes./mobileRateAreas/:id',req.body);
  let userHeaderDetails = Util.filterHeader(req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE MobileRateAreasRoutes./mobileRateAreas/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }

  mobileRateAreasService.deleteMobileRateAreaById(req.params.id, userHeaderDetails, true).then(result => {
    ApiLoggerUtility.logCompletion("DELETE MobileRateAreasRoutes./mobileRateAreas/:id");
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE MobileRateAreasRoutes./mobileRateAreas/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;