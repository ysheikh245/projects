import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { PlanService }  from '../service/PlanService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const planService = new PlanService();


pmRouter.get('/plan/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET PlanRoutes./plan/:productCode', req);
  planService.getPlan(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET PlanRoutes./plan/:productCode');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET PlanRoutes./plan/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/plan/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET PlanRoutes./plan/id/:id', req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET PlanRoutes./plan/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  planService.getPlanById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET PlanRoutes./plan/id/:id');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET PlanRoutes./plan/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/plan', async (req, res) => {
  ApiLoggerUtility.logStart('GET PlanRoutes./plan', req);
  planService.getAllPlans().then(results => {
    ApiLoggerUtility.logCompletion('GET PlanRoutes./plan');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET PlanRoutes./plan', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/plan', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST PlanRoutes./plan', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!planService.validateRequest(req.body)) {
    $log.info('POST PlanRoutes./plan - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  planService.addUpdatePlan(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST PlanRoutes./plan');
   /* if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('POST PlanRoutes./plan', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/plan/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE PlanRoutes./plan/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  planService.deletePlan(req.params.id, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE PlanRoutes./plan/:id');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE PlanRoutes./plan/:id', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/plan/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE PlanRoutes./plan/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  planService.deletePlanByProductCode(req.params.productCode, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE PlanRoutes./plan/productcode/:productCode');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE PlanRoutes./plan/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;