import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { AedService }  from '../service/AedService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const aedService = new AedService();


pmRouter.get('/aed/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutes./aed/:productCode', req);
  let results = [];
  aedService.getAed(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET AedRoutes./aed/:productCode');
     /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutes./aed/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});




pmRouter.get('/aed/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutes./aed/id/:id', req);
  // validating ID
  if(!Util.validateID(req.params.id)){
    $log.error('GET AedRoutes./aed/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  let results = [];
  aedService.getAedById(req.params.id).then(data => {
    ApiLoggerUtility.logCompletion('GET AedRoutes./aed/id/:id');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutes./aed/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.get('/aed', async (req, res) => {
  ApiLoggerUtility.logStart('GET AedRoutes./aed', req);
  aedService.getAllAeds().then(results => {
    ApiLoggerUtility.logCompletion('GET AedRoutes./aed');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    // if(data != null) {
    //   results.push(data);
    // }
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('GET AedRoutes./aed', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.post('/aed', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST AedRoutes./aed', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  // validate the request
  if(!aedService.validateRequest(req.body)) {
    $log.error('POST AedRoutes./aed - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  aedService.addUpdateAed(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST AedRoutes./aed');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('POST AedRoutes./aed', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/aed/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE AedRoutes./aed/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  aedService.deleteAed(req.params.id, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE AedRoutes./aed/:id');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE AedRoutes./aed/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

pmRouter.delete('/aed/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE AedRoutes./aed/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  let results = [];
  aedService.deleteAedByProductCode(req.params.productCode, userHeaderDetails).then(data => {
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('DELETE AedRoutes./aed/productcode/:productCode');
    return pmResponse(res, 200, {results})
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE AedRoutes./aed/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;