import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { RateService }  from '../service/RateService';
import { DBConstants } from '../db/DbConstants';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const pmRouter = express.Router();
const rateService = new RateService();


pmRouter.get('/rate/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('GET RateRoutes./rate/:productCode', req);
  rateService.getRate(req.params.productCode).then(data => {
    ApiLoggerUtility.logCompletion('GET RateRoutes./rate/:productCode');
    let results = [];
    if(data != null) {
      results.push(data);
    }
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET RateRoutes./rate/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/rate/id/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET RateRoutes./rate/id/:id', req);
   // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET RateRoutes./rate/id/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  
  rateService.getRateById(req.params.id).then(data  => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion('GET RateRoutes./rate/id/:id');
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET RateRoutes./rate/id/:id', error);
    return pmResponse(res, 500, { error } );
  });
});

// This Route is only used by the new Quoting application to get all Rates except C254; P154
pmRouter.get('/ratev2', async (req, res) => {
  const filterProducts = Util.config.ratesAPI.filteredProducts;
  rateService.getAllRates(filterProducts.split(",")).then(results => {
    ApiLoggerUtility.logCompletion('GET RateRoutes./ratev2');
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('GET RateRoutes./rate', error);
    return pmResponse(res, 500, {error});
  })
});

pmRouter.get('/rate', async (req, res) => {
  let filterProducts: string[] | undefined = req.query.filter?.toString().split(',');
  ApiLoggerUtility.logStart('GET RateRoutes./rate', req);

  if (filterProducts && filterProducts.length > 0) {
    rateService.getAllRates(filterProducts).then(results => {
      ApiLoggerUtility.logCompletion('GET RateRoutes./rate');
      /*if ( results != null ) {
        return pmResponse(res, 200, { results } );
      } else {
        return pmResponse(res, 404, { results } );
      }*/
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError('GET RateRoutes./rate', error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    rateService.getAllRates().then(results => {
      ApiLoggerUtility.logCompletion('GET RateRoutes./rate');
      /*if ( results != null ) {
        return pmResponse(res, 200, { results } );
      } else {
        return pmResponse(res, 404, { results } );
      }*/
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError('GET RateRoutes./rate', error);
      return pmResponse(res, 500, { error } );
    });
  }
});


pmRouter.post('/rate', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST RateRoutes./rate', req);
  let userHeaderDetails = Util.filterHeader(req);
   // validate the request
   if(!rateService.validateRequest(req.body)) {
    $log.error('POST RateRoutes./rate - Request Validation Failed');
    return pmResponse(res, 400, {"message":Constants.INPUT_REQUIRED} );
  }
  rateService.addUpdateRate(req.body, userHeaderDetails).then(results => {
    ApiLoggerUtility.logCompletion('POST RateRoutes./rate');
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('POST RateRoutes./rate', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/rate/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE RateRoutes./rate/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  rateService.deleteRate(req.params.id, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE RateRoutes./rate/:id');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE RateRoutes./rate/:id', error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/rate/productcode/:productCode', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE RateRoutes./rate/productcode/:productCode', req);
  let userHeaderDetails = Util.filterHeader(req);
  rateService.deleteRateByProductCode(req.params.productCode, userHeaderDetails).then(result => {
    ApiLoggerUtility.logCompletion('DELETE RateRoutes./rate/productcode/:productCode');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE RateRoutes./rate/productcode/:productCode', error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;
