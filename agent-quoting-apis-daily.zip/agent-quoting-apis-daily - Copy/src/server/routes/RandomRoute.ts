import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { pmResponse } from '../util/PmResponse'
import { DbService } from '../db/DbService';
import { DBConstants } from '../db/DbConstants';
import dbServiceV2 from '../db/DbServiceV2';
// import { Constants } from '../util/Constants';
// import { Product } from '../models';
// import { ProductManifest } from '../models';
// import { ProductManifestService } from './ProductManifestService';



const pmRouter = express.Router();


let dbService: any;
const intiDbService = () => {
    DbService.withDbService(async svc => {
        dbService = svc;
        $log.info(`RandomRoutes..........init DB Service V1`);
        return await new Promise((resolve, reject) => {
            // never ending promise to keep connection forever
        });
    })
}

if (Util.config && Util.config.dbServiceConfig && Util.config.dbServiceConfig.version === 'V1') {
  intiDbService();
} else {
  $log.info(`RandomRoutes..........init DB Service V2`);
  dbService = dbServiceV2;
}

pmRouter.get('/versionInfo', async (req, res) => {
  const versionData = {"Environment": Util.env['name'], "System Date": Util.env['systemdate'], "Tag": process.env.VERSION};
  $log.debug('Get /versionInfo', versionData);
  return pmResponse(res, 200, versionData)
});


pmRouter.delete('/clearAll', async (req, res) => {
  // await dbService.getCollection(DBConstants.TABLE_AED).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_AED}...........`);
  // await dbService.getCollection(DBConstants.TABLE_CASH_VALUE).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_CASH_VALUE}...........`);
  // await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_COMMON_MANIFEST}...........`);
  // await dbService.getCollection(DBConstants.TABLE_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_MANIFEST}...........`);
  // await dbService.getCollection(DBConstants.TABLE_MOD).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_MOD}...........`);
  // await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_ETI).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_NONFORFEITURE_ETI}...........`);
  // await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_RPU).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_NONFORFEITURE_RPU}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PLAN).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PLAN}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PRODUCT).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PRODUCT}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PRODUCT_MANIFEST}...........`);
  await dbService.getCollection(DBConstants.TABLE_QMS_ADJUSTMENT_GROUP).deleteMany( {} );
  $log.info(`deleted ${DBConstants.TABLE_QMS_ADJUSTMENT_GROUP}...........`);
  await dbService.getCollection(DBConstants.TABLE_QMS_AREAS).deleteMany( {} );
  $log.info(`deleted ${DBConstants.TABLE_QMS_AREAS}...........`);
  await dbService.getCollection(DBConstants.TABLE_QMS_RATES).deleteMany( {} );
  $log.info(`deleted ${DBConstants.TABLE_QMS_RATES}...........`);
  // await dbService.getCollection(DBConstants.TABLE_RATE).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_RATE}...........`);

  return pmResponse(res, 200, "All Deleted");
});


pmRouter.post('/resetProductManifest/:productCode', async (req, res) => {
  // await dbService.getCollection(DBConstants.TABLE_AED).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_AED}...........`);
  // await dbService.getCollection(DBConstants.TABLE_CASH_VALUE).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_CASH_VALUE}...........`);
  // await dbService.getCollection(DBConstants.TABLE_COMMON_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_COMMON_MANIFEST}...........`);
  // await dbService.getCollection(DBConstants.TABLE_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_MANIFEST}...........`);
  // await dbService.getCollection(DBConstants.TABLE_MOD).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_MOD}...........`);
  // await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_ETI).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_NONFORFEITURE_ETI}...........`);
  // await dbService.getCollection(DBConstants.TABLE_NONFORFEITURE_RPU).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_NONFORFEITURE_RPU}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PLAN).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PLAN}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PRODUCT).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PRODUCT}...........`);
  // await dbService.getCollection(DBConstants.TABLE_PRODUCT_MANIFEST).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_PRODUCT_MANIFEST}...........`);
  // await dbService.getCollection(DBConstants.TABLE_QMS_ADJUSTMENT_GROUP).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_QMS_ADJUSTMENT_GROUP}...........`);
  // await dbService.getCollection(DBConstants.TABLE_QMS_AREAS).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_QMS_AREAS}...........`);
  // await dbService.getCollection(DBConstants.TABLE_QMS_RATES).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_QMS_RATES}...........`);
  // await dbService.getCollection(DBConstants.TABLE_RATE).deleteMany( {} );
  // $log.info(`deleted ${DBConstants.TABLE_RATE}...........`);

  // return pmResponse(res, 200, "All Deleted");
});

export default pmRouter;