import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { QmsAdjustmentGroupService }  from '../service/QmsAdjustmentGroupService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import qmsAdjustmentGroupSchema from '../schema/qmsAdjustmentGroup';


const pmRouter = express.Router();
const qmsAdjustmentGroupService = new QmsAdjustmentGroupService();


pmRouter.get('/qmsadjustmentgroup/:id', async (req, res) => {
  ApiLoggerUtility.logStart("GET QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id",req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET QmsAdjustmentGroupRoutes./qmsadjustmentgroup/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  qmsAdjustmentGroupService.getQmsAdjustmentGroupById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion("GET QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("GET QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id", error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/qmsadjustmentgroup', async (req, res) => {
  ApiLoggerUtility.logStart('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup', req);
  let businessType: string = req.query.businessType ? req.query.businessType.toString() : '';
  let effectiveDate = req.query.effectiveDate ? req.query.effectiveDate.toString() : '';
  if ( businessType != '' && effectiveDate != ''  ) {
    qmsAdjustmentGroupService.getQmsAdjustmentGroup(businessType, effectiveDate).then(results => {
      ApiLoggerUtility.logCompletion('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup');
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup',error);
      return pmResponse(res, 500, { error } );
    });
  } else if ( businessType != ''  ) {
    qmsAdjustmentGroupService.getQmsAdjustmentGroupByBusinessType(businessType).then(results => {
      ApiLoggerUtility.logCompletion('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup');
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup',error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    qmsAdjustmentGroupService.getAllQmsAdjustmentGroups().then(results => {
      ApiLoggerUtility.logCompletion('GET QmsAdjustmentGroupRoute./qmsadjustmentgroup');
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError('GET QmsAdjustmentGroupRoute./qmsadjustmentgroups',error);
      return pmResponse(res, 500, { error } );
    });
  }

});


pmRouter.post('/qmsadjustmentgroup', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST QmsAdjustmentGroupRoute./qmsadjustmentgroup', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!qmsAdjustmentGroupService.validateRequest(req.body)) {
    $log.info('POST QmsAdjustmentGroupRoutes./qmsadjustmentgroup - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }
  
  qmsAdjustmentGroupService.addUpdateQmsAdjustmentGroup(req.body, userHeaderDetails).then(results => {
    /* if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion('POST QmsAdjustmentGroupRoute./qmsadjustmentgroup');
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError('POST QmsAdjustmentGroupRoute./qmsadjustmentgroup',error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/qmsadjustmentgroup/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id', req);
  let userHeaderDetails = Util.filterHeader(req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE QmsAdjustmentGroupRoutes./qmsadjustmentgroup/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }

  qmsAdjustmentGroupService.deleteQmsAdjustmentGroupById(req.params.id, userHeaderDetails, true).then(result => {
    ApiLoggerUtility.logCompletion('DELETE QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id');
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError('DELETE QmsAdjustmentGroupRoute./qmsadjustmentgroup/:id',error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;