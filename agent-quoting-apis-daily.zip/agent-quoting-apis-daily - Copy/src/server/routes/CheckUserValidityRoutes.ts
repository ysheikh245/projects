import express from 'express'
import {$log} from '@tsed/common';
import { CheckUserValidityService }  from '../service/CheckUserValidityService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";

const userValidityService = new CheckUserValidityService();
// const userValidityService = require('../service/CheckUserValidityService')

const pmRouter = express.Router();

pmRouter.post('/checkUserValidity', async (request, response) => {
    ApiLoggerUtility.logStart('CheckUserValidityRoutes./checkUserValidity', request);

    let id: string = request.body.id;

    if (request.body && !userValidityService.validateRequest(id)) {
        $log.error(`Bad request: id is required and must only contain 0-9, a-z, A-Z. Id=${id}`);
        response.status(400).json("Bad request: id is required and must only contain 0-9, a-z, A-Z");
    } else {
        try {
            //console.log(id);
            $log.info(`Valid request. Attempting to check user validity. Id=${id}`);
            let isUserValid: boolean = await userValidityService.checkUserValidity(id.trim());
            //console.log('After method:' + isUserValid);
            //$log.info(`---------------------------- CheckUserValidityRoutes./checkUserValidity - Completed ---------------------------`);
            ApiLoggerUtility.logCompletion('CheckUserValidityRoutes./checkUserValidity')
            response.status(200).json(isUserValid ? 'VALID' : 'INVALID')
        } catch (error) {
            //console.log('Exception block in Routes.ts');
            /*$log.error(`---------------------------- CheckUserValidityRoutes./checkUserValidity - Failed ----------------------------`);
            $log.error(`Error=${error.stack}`)*/
            ApiLoggerUtility.logError('CheckUserValidityRoutes./checkUserValidity', error);
            response.status(500).json("Error: " + error + ", " + error.stack);
        }
    }
});

export default pmRouter;