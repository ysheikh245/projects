import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { Constants } from '../util/Constants'
import { pmResponse } from '../util/PmResponse'
import { QmsAreaService }  from '../service/QmsAreaService';
import { ApiLoggerUtility } from '../util/ApiLoggerUtility';
import qmsAreaSchema from '../schema/qmsArea';


const pmRouter = express.Router();
const qmsAreaService = new QmsAreaService();


pmRouter.get('/qmsareas/:id', async (req, res) => {
  ApiLoggerUtility.logStart('GET QmsAreaRoutes./qmsareas/:id"',req.body);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('GET QmsAreaRoutes./qmsareas/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }
  qmsAreaService.getQmsAreaById(req.params.id).then(data => {
    let results = [];
    if(data != null) {
      results.push(data);
    }
    ApiLoggerUtility.logCompletion("GET QmsAreaRoutes./qmsareas/:id");
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("GET QmsAreaRoutes./qmsareas/:id",error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.get('/qmsareas', async (req, res) => {
  ApiLoggerUtility.logStart('GET QmsAreaRoutes./qms/qmsareas',req.body);

  let businessType: string = req.query.businessType ? req.query.businessType.toString() : '';
  let effectiveDate = req.query.effectiveDate ? req.query.effectiveDate.toString() : '';
  let state = req.query.state ? req.query.state.toString() : '';

  if ( businessType != '' && effectiveDate != '' && state != '' ) {
    qmsAreaService.getQmsArea(businessType, effectiveDate, state).then(results => {
      ApiLoggerUtility.logCompletion("GET QmsAreaRoutes./qms/qmsareas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsAreaRoutes./qms/qmsareas",error);
      return pmResponse(res, 500, { error } );
    });
  } else if ( businessType != '' && state != '' ) {
    qmsAreaService.getQmsAreaByBusinessTypeState(businessType, state).then(results => {
      ApiLoggerUtility.logCompletion("GET QmsAreaRoutes./qms/qmsareas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsAreaRoutes./qms/qmsareas",error);
      return pmResponse(res, 500, { error } );
    });
  } else {
    qmsAreaService.getAllQmsAreas().then(results => {
      ApiLoggerUtility.logCompletion("GET QmsAreaRoutes./qms/qmsareas");
      return pmResponse(res, 200, { results } );
    }).catch(error => {
      ApiLoggerUtility.logError("GET QmsAreaRoutes./qms/qmsareas",error);
      return pmResponse(res, 500, { error } );
    });
  }
});


pmRouter.post('/qmsareas', async (req: express.Request, res: express.Response) => {
  ApiLoggerUtility.logStart('POST QmsAreaRoutes./qms/qmsareas',req.body);
  let userHeaderDetails = Util.filterHeader(req);
  // validate the request
  if(!qmsAreaService.validateRequest(req.body)) {
    $log.info('POST QmsAreaRoutes./qms/qmsareas - Request Validation Failed')
    return pmResponse(res, 400, {"message":Constants.INPUT_QMS} );
  }

  qmsAreaService.addUpdateQmsArea(req.body, userHeaderDetails).then(results => {
    /*if ( results != null ) {
      return pmResponse(res, 200, { results } );
    } else {
      return pmResponse(res, 404, { results } );
    }*/
    ApiLoggerUtility.logCompletion("POST QmsAreaRoutes./qms/qmsareas")
    return pmResponse(res, 200, { results } );
  }).catch(error => {
    ApiLoggerUtility.logError("POST QmsAreaRoutes./qms/qmsareas",error);
    return pmResponse(res, 500, { error } );
  });
});


pmRouter.delete('/qmsareas/:id', async (req, res) => {
  ApiLoggerUtility.logStart('DELETE QmsAreaRoutes./qms/qmsareas/:id',req.body);
  let userHeaderDetails = Util.filterHeader(req);
  // validating id
  if(!Util.validateID(req.params.id)){
    $log.error('DELETE QmsAreaRoutes./qms/qmsareas/:id - ID Validation Failed');
    return pmResponse(res , 400, { 'message': `Invalid object id : '${req.params.id}'`} )
  }

  qmsAreaService.deleteQmsAreaById(req.params.id, userHeaderDetails, true).then(result => {
    ApiLoggerUtility.logCompletion("DELETE QmsAreaRoutes./qms/qmsareas/:id");
    return pmResponse(res, 200, { result } );
  }).catch(error => {
    ApiLoggerUtility.logError("DELETE QmsAreaRoutes./qms/qmsareas/:id",error);
    return pmResponse(res, 500, { error } );
  });
});

export default pmRouter;