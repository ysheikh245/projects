import express from 'express'
import { $log } from '@tsed/common';
import { Util } from '../util/Util'
import { pmResponse } from '../util/PmResponse'
// import { AedService }  from '../service/AedService';
// import { DBConstants } from '../db/DbConstants';


const pmRouter = express.Router();
// const aedService = new AedService();


pmRouter.get('/environmentVariable', async (req, res) => {
  $log.debug('Get all environmentVariable .....');
  
  // $log.debug('Util.config?.environmentVariables .....', Util.config?.environmentVariables);
  var environmentvariables= [];
  if ( Util.config?.environmentVariables ) {
    var keys = Object.keys(Util.config.environmentVariables);
    $log.debug('Get all environmentVariable keys.....', keys);
    var results = Util.config.environmentVariables;
    $log.debug('Get all environmentVariable results.....', results);

    keys.forEach(key => {
      environmentvariables.push({
        id:key,
        environmentKey:key,
        environmentValue:Util.config.environmentVariables[key],
        saveToDevice:true
      });
    });

    $log.debug('Get all environmentVariable environmentvariables.....', environmentvariables);
  }

  return pmResponse(res, 200, { environmentvariables });
});



export default pmRouter;