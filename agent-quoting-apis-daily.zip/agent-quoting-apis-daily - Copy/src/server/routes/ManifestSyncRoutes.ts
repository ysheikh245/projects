import express from 'express'
import {pmResponse} from '../util/PmResponse'
import {ManifestSyncService} from '../service/ManifestSyncService';
import {ApiLoggerUtility} from "../util/ApiLoggerUtility";
import {$log} from "@tsed/common";
import {ManifestSync} from "../models/ManifestSync";


const pmRouter = express.Router();
const manifestSyncService = new ManifestSyncService();

pmRouter.get('/manifestsync', async (req, res) => {
    ApiLoggerUtility.logStart('GET ManifestSyncRoutes./manifestsync', req);
    try {
        let appManifest = await manifestSyncService.getManifestSyncForAllProducts();
        ApiLoggerUtility.logCompletion('GET ManifestSyncRoutes./manifestsync');
        return pmResponse(res, 200, {appManifest});
    } catch(error) {
        ApiLoggerUtility.logError('GET ManifestSyncRoutes./manifestsync', error);
        return pmResponse(res, 500, {error});
    }
});

pmRouter.get('/manifestsync/:productCode', async (req, res) => {
    ApiLoggerUtility.logStart('GET ManifestSyncRoutes./manifestsync/:productCode', req);
    try {
        let appManifest = await manifestSyncService.getManifestSyncByProductCode(req.params.productCode);
        ApiLoggerUtility.logCompletion('GET ManifestSyncRoutes./manifestsync/:productCode');
        return pmResponse(res, 200, {appManifest});
    } catch(error) {
        ApiLoggerUtility.logError('GET ManifestSyncRoutes./manifestsync/:productCode', error);
        return pmResponse(res, 500, {error});
    }
});

pmRouter.post('/manifestsync', async (req, res) => {
    ApiLoggerUtility.logStart('POST ManifestSyncRoutes./manifestsync', req);
    try {
        const requestAppManifest: ManifestSync = req.body.appManifest;
        let results = { appManifest: null };

        // Validate the request
        if(!manifestSyncService.validateRequest(requestAppManifest)) {
            $log.error('POST ManifestSyncRoutes./manifestsync - Request Validation Failed');
            res.status(400).json({ 'message': 'The appManifest parameters were null or empty. Either pass mod or products'});
        } else if(requestAppManifest.products.length > 0) { // manifest sync for Products
            $log.info('ManifestSyncRoutes./manifestsync invoked for Products');
            let appManifest = await manifestSyncService.getManifestSync(requestAppManifest);
            ApiLoggerUtility.logCompletion('POST ManifestSyncRoutes./manifestsync');
            results.appManifest = appManifest;
            return pmResponse(res, 200, {results});
        } else if(Object.keys(requestAppManifest.mod).length>0) { // manifest sync for Mod
            $log.info('ManifestSyncRoutes./manifestsync invoked for Mod');
            let appManifest = await manifestSyncService.getModManifestSync(requestAppManifest.mod)
            ApiLoggerUtility.logCompletion('POST ManifestSyncRoutes./manifestsync');
            results.appManifest = appManifest;
            return pmResponse(res, 200, {results});
        }
    } catch(error) {
        ApiLoggerUtility.logError('ManifestSyncRoutes.manifestsync.POST', error);
        return pmResponse(res, 500, {error});
    }
});

export default pmRouter;