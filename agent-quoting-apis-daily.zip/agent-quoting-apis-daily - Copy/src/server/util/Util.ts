import { $log } from "@tsed/common";
import { Credentials } from '../config/Config';
import { Constants } from './Constants';
import mongoose from 'mongoose';
const config = require('../shared/config.json');


export type ValidCreds = keyof (typeof config.credentials);
export type EnvVariableKeys = keyof (typeof config.environmentVariables);

// @ts-nocheck
export class Util {
  // static config: Config = require('../resources/config.json');
	static env:any
	static config = config;
  // @ts-ignore-block
  public static get<T>(o, ...a): T {
    // @ts-ignore-block
    const stop = o => (typeof o === "undefined" || o === null)
    // @ts-ignore-block
    const reduce = (f, stopFn, acc, a) => (a.find(v => (acc = f(acc, v), stopFn(acc, v))), acc)
    // @ts-ignore-block
    if(stop(o)) {
      // @ts-ignore-block
      return undefined;
    }
    // @ts-ignore-block
    return reduce((o, v) => ({
      // @ts-ignore-block
      'string': () => reduce((o, k) => o[k], stop, o, v.split('.')),
      'function': () => v(o)
    }[typeof v]
      || (() => $log.error("NOT A STRING/FUNCTION")))(), stop,  o,   a) as T
	}

  public static prettyJSON = (o: any) => JSON.stringify(o, null, 2)
  public static getCredentials = (key: ValidCreds): Credentials => Util.config.credentials[key]
  public static getHost = (key: ValidCreds): string => Util.getCredentials(key).host
  public static getContextRoot = (key: ValidCreds): string => (Util.getCredentials(key) as any)["context-root"]
  public static getBaseUrl = (key: ValidCreds): string => Util.addPathSegment(Util.getHost(key), Util.getContextRoot(key))
  public static addPathSegment = (...args: any[]) => (args).map((arg, i) => (arg + '').replace(i === args.length - 1 ? /^\//g : /^\/|\/$/g, '')).join('/')


  public static filterHeader = (req: any) => {
    // $log.info("req.headers", req);
    let filteredHeaders:any = {};
    if (req && req.headers) {
      Constants.HTTPHEADER_FILTER_LIST.filter(tmp =>{
        filteredHeaders[tmp] = req.headers[tmp];
        });
    } else {
      $log.info('Util.filterHeader() - request is empty or does not contain headers');
    }
    return filteredHeaders;
  }

  public static validateID(id: string){
    $log.info('Util.validateID() ::: Start');
    let validID: boolean = mongoose.Types.ObjectId.isValid(id);
    $log.info(`Util.validateID() ::: Completed. ID Valid Flag=${validID}`);
    return validID;
}

public static getProductCode(businessType: string) {
  $log.info('Util.getProductCode ::: Start');
  let productCode = null;

  if(businessType === 'Life Standard - 2020') {
    productCode = "L030"
  } else if(businessType === 'Select Standard - 2023') {
    productCode = "S060"
  } else if((businessType === 'PMIC P154/C254')) {
    productCode = "C254";
  }
  $log.info(`Util.getProductCode ::: Completed. Product Code = ${productCode}`);
  return productCode;
}

public static getBusinessType(productCode: string) {
  $log.info('Util.getBusinessType ::: Start');
  let businessType = null;

  if(productCode = "L030") {
    businessType = "Life Standard - 2020";
  } else if(productCode = "S060") {
    businessType = 'Select Standard - 2023';
  } else if(productCode = 'C254') {
    businessType = 'PMIC P154/C254';
  }
  $log.info(`Util.getBusinessType ::: Completed. Business Type = ${businessType}`);
  return businessType;
}

}