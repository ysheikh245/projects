import {$log} from "@tsed/common";
import { Util } from '../util/Util'
import {Constants} from "./Constants";

export class ApiLoggerUtility {

    private static DASHED_LINES     : string = Constants.DASH_SEPARATOR.repeat(75);

    public static logStart(apiName:string, req) {
        // The below statement decorates the apiName with dashes for easy LOGGER readability
        $log.info(((apiName + Constants.START_IDENTIFIER).
                    padStart(Constants.COUNT/2, Constants.DASH_SEPARATOR)).
                      padEnd(Constants.COUNT,   Constants.DASH_SEPARATOR));
        // console.log((" Log ".padStart(38, '-')).padEnd(76, '-')) // for reference to the above statement. Run it is on CLI to find out what it does
        $log.info(ApiLoggerUtility.DASHED_LINES);
        let userHeaderDetails = Util.filterHeader(req);
        $log.debug(userHeaderDetails);
        $log.info(ApiLoggerUtility.DASHED_LINES);
    }

    public static logError(apiName:string, error) {
        $log.error(((apiName + Constants.FAILED_IDENTIFIER).
                    padStart(Constants.COUNT/2, Constants.DASH_SEPARATOR)).
                    padEnd(Constants.COUNT,   Constants.DASH_SEPARATOR));
        //$log.error(`---------------------------- CheckUserValidityRoutes./checkUserValidity - Failed ----------------------------`);
        $log.error(`Error=${error.stack}`)
    }

    public static logCompletion(apiName) {
        $log.info(((apiName + Constants.COMPLETED_IDENTIFIER).padStart(Constants.COUNT/2, Constants.DASH_SEPARATOR)).
                                                              padEnd(Constants.COUNT,     Constants.DASH_SEPARATOR));
    }
}