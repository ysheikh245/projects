export const isEmpty = (dataElement: string) => {
    return (dataElement && dataElement != null && dataElement.trim().length == 0);
}

export const isNotEmpty = (dataElement: string) => {
    return (dataElement != null && typeof dataElement=='string' && dataElement.trim().length > 0)?true:false;
}

export const isAlphaNumeric = (dataElement: string) => {
    var regex = /[0-9a-zA-Z]/;
    return (regex.test(dataElement)) ;
}

export const isNotAlphaNumeric = (dataElement: string) => {
    var regex = /[^0-9a-zA-Z]/;
    return (regex.test(dataElement)) ;
}

/*
exports.isEmpty = isEmpty;
exports.isNotEmpty = isNotEmpty;
exports.isAlphaNumeric = isAlphaNumeric;
exports.isNotAlphaNumeric = isNotAlphaNumeric;*/
