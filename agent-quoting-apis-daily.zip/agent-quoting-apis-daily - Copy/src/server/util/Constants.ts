export class Constants {
    public static readonly HTTPHEADER_CLIENT_HEADER = 'client-header';
    public static readonly HTTPHEADER_END_USER = 'end-user-id';
    public static readonly HTTPHEADER_FILTER_LIST = [Constants.HTTPHEADER_CLIENT_HEADER, Constants.HTTPHEADER_END_USER];

    public static readonly PRODUCT_API_CONFIG_KEY = "productApi";
    public static readonly AGENTS_PMAPI_CONFIG_KEY = "agentsPMAPI";
    public static readonly KEYCLOAK_CONFIG = "keyCloak";
    public static readonly SALESFORCE_BATCH_CONFIG_KEY = "salesforceBatch";
    public static readonly SALESFORCE_LOGIN_CONFIG_KEY = "salesforceLogin";

    //public static readonly OPPORTUNITY_QUOTE_NOT_FOUND_MESSAGE = "Provided external ID field does not exist";

    // SalesForce
    public static readonly SALES_FORCE_USER_QUERY_FIELDS =
        "Id,Username,LastName,FirstName,Name,CompanyName,Department,Title,Address,Email,Phone,Fax,MobilePhone,Alias,UserType,EmployeeNumber,ContactId,AccountId,CallCenterId,Extension,PortalRole,IsActive";

    public static readonly SALES_FORCE_USER_IS_ACTIVE_COLUMN = 'IsActive';

    public static readonly SALES_FORCE_CONTACT_QUERY_FIELDS = "Id,LastName,FirstName,MailingAddress,Phone,Email,PhotoUrl,DMS_NPN__c,AccountId";

    public static readonly SALES_FORCE_ACCOUNT_QUERY_FIELDS = "Name, Party_Id__c, Parent.Name, Parent.Party_Id__c";

    // ProductCodes
    public static readonly PRODUCT_CODE_L030 = 'L030';
    public static readonly PRODUCT_CODE_S060 = 'S060';

    // Logger Statement
    public static readonly DASH_SEPARATOR : string ='-';
    public static readonly COUNT : number = 76;
    public static readonly START_IDENTIFIER : string  =  ' ::: Start ';
    public static readonly FAILED_IDENTIFIER : string =  ' ::: Failed ';
    public static readonly COMPLETED_IDENTIFIER : string =  ' ::: Completed ';

    // Delimeters
    public static readonly BLANK = "";
    
    // Input Validation 
    public static readonly INPUT_REQUIRED = "Request body is empty or productCode is missing";
    public static readonly INPUT_QMS = "Request body is empty";

    // Error body
    public static readonly UNKNOWN_ERROR = "An unknown error occurred"
}