import moment from 'moment';

export class DateUtil {

  public static formatDateYearFirstDashes(date: Date | string) {
    return moment(date, "MM/DD/YYYY").format('yyyy-MM-DD');
  }

  public static formatCurrentDate(dateFormat: string) {
    return moment(new Date()).format(dateFormat);
  }

  public static formatDate(date: Date, dateFormat: string) {
    return moment(date).format(dateFormat);
  }
}