import express from 'express'

export const pmResponse = <T>(res: express.Response, code: number, body:T, headers?:Map<string, string>) => {
  

    if (headers) {
      headers.forEach((value, key) => {
        res.header(key, value);
      });
      
      if(body instanceof Buffer) {
        res.status(code).send(body).end();
      } else {
        res.status(code).send(body + '').end()
      }
      // res.status(code).end(String(body));
    } else {
      res.header("Content-Type", "application/json")
      res.status(code).send(JSON.stringify(body)).end()
    }
  }