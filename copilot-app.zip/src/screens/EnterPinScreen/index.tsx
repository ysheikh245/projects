import LogRocket from '@logrocket/react-native';
import {useNavigation} from '@react-navigation/native';
import {StackActions} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import * as LocalAuthentication from 'expo-local-authentication';
import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import EnterPinView from './EnterPinView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {AuthStackParamList} from '../../navigation/AuthNavigation';
import {authActions} from '../../redux/slices/authSlice';
import {
  selectBiometricsEnabled,
  selectPMICUser,
  selectSavedPin,
} from '../../redux/slices/authSlice/selectors';

const EnterPinScreen = () => {
  const dispatch = useDispatch();
  const navigation =
    useNavigation<
      NativeStackNavigationProp<AppStackParamList | AuthStackParamList>
    >();

  const biometricsEnabled = useSelector(selectBiometricsEnabled);
  const savedPin = useSelector(selectSavedPin);
  const savedUser = useSelector(selectPMICUser);

  // logrocket the user
  LogRocket.identify(savedUser!.npn || savedUser!.username, {
    name: savedUser!.firstName + ' ' + savedUser!.lastName,
  });

  const [isEnrolled, setIsEnrolled] = useState(false);

  const checkSupportedAuthentication = async () => {
    await LocalAuthentication.isEnrolledAsync().then(enrolled => {
      setIsEnrolled(enrolled);
      if (enrolled && biometricsEnabled) {
        doBiometrics();
      }
    });
  };

  useEffect(() => {
    checkSupportedAuthentication();
  }, []);

  const doBiometrics = async () => {
    try {
      console.log('bio scan');
      const results = await LocalAuthentication.authenticateAsync({
        disableDeviceFallback: true,
        cancelLabel: 'Cancel',
      });
      console.log('bio result', results);

      if (results.success) {
        resolveSuccess();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const doLogout = () => {
    navigation.navigate('Login');
    dispatch(authActions.logout());
  };

  const resolveSuccess = () => {
    dispatch(authActions.authenticate(true));
    navigation.dispatch({
      ...StackActions.replace('Home'),
      source: 'Home',
      target: navigation.getState().key,
    });
  };

  return (
    <EnterPinView
      biometricsEnabled={biometricsEnabled}
      isEnrolled={isEnrolled}
      doBiometrics={doBiometrics}
      savedPin={savedPin}
      resolveSuccess={resolveSuccess}
      doLogout={doLogout}
    />
  );
};

export default EnterPinScreen;
