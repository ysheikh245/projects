/* eslint-disable react-native/no-inline-styles */
import {useFocusEffect} from '@react-navigation/native';
import React, {FC, useCallback, useState} from 'react';
import {Image, LayoutChangeEvent, Platform, Text, View} from 'react-native';
import {StyleSheet} from 'react-native';
import {
  CodeField,
  Cursor,
  isLastFilledCell,
  MaskSymbol,
  RenderCellOptions,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import Toast from 'react-native-root-toast';

import AndroidFace from '../../assets/images/androidFace.svg';
import AndroidFingerprint from '../../assets/images/androidFingerprint.svg';
import FaceID from '../../assets/images/faceID.svg';
import Logo from '../../assets/images/logo2.png';
import TouchID from '../../assets/images/touchID.svg';
import AuthScreenContainer from '../../components/AuthScreenContainer';
import Button from '../../components/Button';
import colors from '../../utils/colors';

interface Props {
  biometricsEnabled: boolean;
  isEnrolled: boolean;
  doBiometrics: () => void;
  resolveSuccess: () => void;
  savedPin?: string;
  doLogout: () => void;
}

interface RenderCellProps extends RenderCellOptions {
  value: string;
  layoutHandler: (index: number) => (event: LayoutChangeEvent) => void;
}

const SetPinView: FC<Props> = ({
  biometricsEnabled,
  isEnrolled,
  doBiometrics,
  resolveSuccess,
  savedPin,
  doLogout,
}) => {
  const [pinValue, setPinValue] = useState('');

  const pinInputRef = useBlurOnFulfill({value: pinValue, cellCount: 6});
  const [pinPros, pinGetCellOnLayoutHandler] = useClearByFocusCell({
    value: pinValue,
    setValue: setPinValue,
  });

  useFocusEffect(
    useCallback(() => {
      pinInputRef.current?.focus();
    }, [pinInputRef]),
  );

  const renderCell = ({
    index,
    symbol,
    isFocused,
    value,
    layoutHandler,
  }: RenderCellProps) => {
    let textChild = null;
    if (symbol) {
      textChild = (
        <MaskSymbol
          maskSymbol="●"
          isLastFilledCell={isLastFilledCell({index, value})}>
          {symbol}
        </MaskSymbol>
      );
    } else if (isFocused) {
      textChild = <Cursor />;
    }

    return (
      <View key={index} onLayout={layoutHandler(index)}>
        <Text style={styles.pinText}>{textChild}</Text>
      </View>
    );
  };

  return (
    <AuthScreenContainer>
      <View style={styles.loginBox}>
        <View style={styles.logoBox}>
          <Image source={Logo} style={styles.logo} />
        </View>
        <Text style={styles.text}>Enter your Pin:</Text>

        <CodeField
          ref={pinInputRef}
          {...pinPros}
          value={pinValue}
          onChangeText={value => {
            setPinValue(value);
            if (value.length === 6) {
              // check pin value
              if (value === savedPin) {
                resolveSuccess();
              } else {
                Toast.show(`Invalid pin`, {
                  duration: Toast.durations.SHORT,
                  position: Toast.positions.CENTER,
                });
                setPinValue('');
              }
            }
          }}
          cellCount={6}
          keyboardType="number-pad"
          textContentType="password"
          renderCell={opts =>
            renderCell({
              ...opts,
              value: pinValue,
              layoutHandler: pinGetCellOnLayoutHandler,
            })
          }
        />

        <Button
          variant="logoutButton"
          textVariant="h6_link"
          testID="logoutButton"
          accessibilityLabel="Forgot Pin?"
          onPress={doLogout}
          title="Forgot Pin?"
        />

        {biometricsEnabled && isEnrolled && (
          <Button
            variant="outlineButton"
            testID="bioButton"
            accessibilityLabel="Biometrics"
            onPress={doBiometrics}
            style={{width: 120, alignSelf: 'center'}}>
            {Platform.OS === 'ios' ? (
              <View style={{flexDirection: 'row'}}>
                <FaceID height={30} width={30} />
                <View style={{width: 10}} />
                <TouchID height={30} width={30} />
              </View>
            ) : (
              <View style={{flexDirection: 'row'}}>
                <AndroidFace height={30} width={30} />
                <View style={{width: 10}} />
                <AndroidFingerprint height={30} width={30} />
              </View>
            )}
          </Button>
        )}
      </View>
    </AuthScreenContainer>
  );
};

const styles = StyleSheet.create({
  loginBox: {
    marginTop: '20%',
    width: '80%',
    maxWidth: 500,
    gap: 20,
  },
  logoBox: {
    flexDirection: 'row',
  },
  logo: {
    flex: 1,
    aspectRatio: 446 / 250,
  },
  spinner: {
    marginTop: 20,
  },
  pinText: {
    backgroundColor: colors.gray200,
    color: colors.black100,
    height: 40,
    width: 40,
    borderRadius: 4,
    padding: 10,
  },
  text: {
    color: colors.black100,
  },
});

export default SetPinView;
