import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import FaciSearchView from './FaciSearchView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectIsGoToPreviousScreen,
  selectIsLoading,
  selectIsPolicySearchResultOpen,
} from '../../redux/slices/faciSlice/selectors';

const FaciSearchScreen = () => {
  const {goBack} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const [searchByPolicy, setSearchByPolicy] = useState<boolean>(true);

  const isPolicySearchResultOpen = useSelector(selectIsPolicySearchResultOpen);
  const isGoBack = useSelector(selectIsGoToPreviousScreen);
  const isLoading = useSelector(selectIsLoading);

  const dispatch = useDispatch();

  if (isGoBack) {
    goBack();
    dispatch(faciActions.goToPreviousScreen(false));
  }

  const hidePolicySearchResultModal = (): void => {
    dispatch(faciActions.hidePolicySearchResult());
  };

  return (
    <FaciSearchView
      searchByPolicy={searchByPolicy}
      setSearchByPolicy={setSearchByPolicy}
      isPolicySearchResultOpen={isPolicySearchResultOpen}
      hidePolicySearchResultModal={hidePolicySearchResultModal}
      isLoading={isLoading}
    />
  );
};
export default FaciSearchScreen;
