import React from 'react';
import {StyleSheet, View} from 'react-native';
import {useDispatch} from 'react-redux';
import {useSelector} from 'react-redux';

import TextInput from '../../components/TextInput';
import {faciActions} from '../../redux/slices/faciSlice';
import {selectSearchPolicyNumber} from '../../redux/slices/faciSlice/selectors';

const FaciPolicyNumberSearchForm = () => {
  const dispatch = useDispatch();
  const policyNumber = useSelector(selectSearchPolicyNumber);
  const onChangePolicyNumber = (text: string) =>
    dispatch(faciActions.updateSearchPolicyNumber(text));

  return (
    <View style={styles.formContainer}>
      <TextInput
        label="Policy Number (Required)"
        onChangeText={onChangePolicyNumber}
        value={policyNumber}
        headerVariant="h4"
        textInputStyle={styles.textInputStyle}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  formContainer: {
    flexGrow: 1,
  },
  textInputStyle: {
    marginTop: 0,
    height: 'auto',
    marginBottom: 5,
  },
});

export default FaciPolicyNumberSearchForm;
