import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import Button from '../../components/Button';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectFirstName,
  selectLastName,
  selectSearchPolicyNumber,
  selectStateName,
} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';

interface Props {
  searchByPolicy: boolean;
}

const SearchButtons: FC<Props> = ({searchByPolicy}) => {
  const dispatch = useDispatch();

  const resetSearch = () => dispatch(faciActions.resetFaciSearch());

  const policyNumber = useSelector(selectSearchPolicyNumber);
  const firstName = useSelector(selectFirstName);
  const lastName = useSelector(selectLastName);
  const stateName = useSelector(selectStateName);

  let isSearchEnabled: boolean;

  if (!searchByPolicy) {
    isSearchEnabled = !(
      firstName.length > 0 &&
      lastName.length > 0 &&
      stateName.length > 0
    );
  } else {
    isSearchEnabled = !(policyNumber.length > 0);
  }

  const onPressSearch = (): void => {
    if (!searchByPolicy) {
      dispatch(faciActions.getFaciCustomerDetailRequest());
    } else {
      dispatch(faciActions.getFaciCustomerByPolicyNumberRequest());
    }
  };

  return (
    <View style={styles.buttonContainer}>
      <Button
        title="Clear All"
        style={styles.leftButton}
        textStyle={styles.resetText}
        variant="tertiary"
        onPress={resetSearch}
      />
      <Button
        disabled={isSearchEnabled}
        title="Search"
        style={isSearchEnabled ? styles.disableButton : styles.rightButton}
        variant="primary"
        onPress={onPressSearch}
        textStyle={isSearchEnabled ? styles.enabledText : styles.disabledText}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    width: '100%',
    marginTop: 20,
    height: 75,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 9,
    marginLeft: -9,
  },
  leftButton: {
    backgroundColor: colors.white,
  },
  disableButton: {
    backgroundColor: colors.gray200,
    borderColor: colors.gray300,
    borderWidth: 2,
    marginLeft: 20,
  },
  rightButton: {
    backgroundColor: colors.blue100,
    borderColor: colors.blue100,
    borderWidth: 2,
    marginLeft: 20,
  },
  resetText: {
    color: colors.blue100,
  },
  enabledText: {
    color: colors.gray300,
  },
  disabledText: {
    color: colors.white,
  },
});

export default SearchButtons;
