import React, {useState} from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';
import {useDispatch} from 'react-redux';
import {useSelector} from 'react-redux';

import DatePicker from '../../components/Picker/DatePicker';
import StatePicker from '../../components/Picker/StatePicker';
import HeaderText from '../../components/Text/HeaderText';
import TextInput from '../../components/TextInput';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectDateOfBirth,
  selectFirstName,
  selectLastName,
  selectStateName,
  selectZip,
} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';

const FaciCustomerSearchForm = () => {
  const dispatch = useDispatch();

  const firstName = useSelector(selectFirstName);
  const lastName = useSelector(selectLastName);
  const stateName = useSelector(selectStateName);
  const zip = useSelector(selectZip);
  const dateOfBirth = useSelector(selectDateOfBirth);
  const [statePickerVisible, setStatePickerVisible] = useState(false);

  const onChangeFirstName = (text: string) =>
    dispatch(faciActions.updateCustomerSearchFirstName(text));
  const onChangeLastName = (text: string) =>
    dispatch(faciActions.updateCustomerSearchLastName(text));
  const onChangeStateName = (text: string) =>
    dispatch(faciActions.updateCustomerSearchStateName(text));
  const onChangeZip = (text: string) =>
    dispatch(faciActions.updateCustomerSearchZip(text));

  const onChangeDateOfBirth = (text: string) => {
    dispatch(faciActions.updateCustomerSearchDOB(text));
  };

  return (
    <>
      <View style={styles.formContainer}>
        <TextInput
          label="First Name (Required)"
          onChangeText={onChangeFirstName}
          value={firstName}
          headerVariant="h4"
          textInputStyle={styles.textInputStyle}
        />
        <TextInput
          label="Last Name (Required)"
          onChangeText={onChangeLastName}
          value={lastName}
          headerVariant="h4"
          textInputStyle={styles.textInputStyle}
        />
        <View style={styles.stateInputContainer}>
          <Pressable onPress={() => setStatePickerVisible(true)}>
            <View>
              <HeaderText variant={'h4'}>State (Required)</HeaderText>
              <Text style={[styles.textInput, styles.textInputStyle]}>
                {stateName}
              </Text>
            </View>
          </Pressable>
          <StatePicker
            pickerVisible={statePickerVisible}
            setPickerVisible={setStatePickerVisible}
            selectedState={stateName}
            setSelectedState={onChangeStateName}
          />
        </View>
        <TextInput
          label="ZIP"
          onChangeText={onChangeZip}
          value={zip}
          headerVariant="h4"
          textInputStyle={styles.textInputStyle}
          keyboardType="number-pad"
        />

        <DatePicker
          value={dateOfBirth}
          label="Date of Birth"
          onChange={onChangeDateOfBirth}
          onSelect={onChangeDateOfBirth}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  formContainer: {
    flexGrow: 1,
  },
  textInputStyle: {
    marginTop: 0,
    height: 'auto',
    marginBottom: 5,
    color: colors.black100,
  },
  calendarIconContainer: {
    position: 'absolute',
    top: 35,
    right: 15,
  },
  calendarIcon: {
    color: colors.black100,
    fontWeight: '400',
    fontSize: 24,
  },
  stateInputContainer: {
    marginBottom: 20,
  },
  textInput: {
    width: '100%',
    height: 62,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: colors.gray100,
    borderWidth: 1,
    marginTop: 8,
    padding: 10,
    color: colors.black300,
    fontWeight: '400',
    fontSize: 18,
  },
  buttonContainer: {
    width: '100%',
    marginTop: 20,
    height: 75,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 9,
    marginLeft: -9,
  },
  leftButton: {
    backgroundColor: colors.white,
  },
  disableButton: {
    backgroundColor: colors.gray200,
    borderColor: colors.gray300,
    borderWidth: 2,
    marginLeft: 20,
  },
  rightButton: {
    backgroundColor: colors.blue100,
    borderColor: colors.blue100,
    borderWidth: 2,
    marginLeft: 20,
  },
});

export default FaciCustomerSearchForm;
