import React, {FC} from 'react';
import {View} from 'react-native';
import {ActivityIndicator, StyleSheet} from 'react-native';

import FaciCustomerSearchForm from './FaciCustomerSearchForm';
import FaciPolicyNumberSearchForm from './FaciPolicyNumberSearchForm';
import SearchButtons from './SearchButtons';
import Divider from '../../components/Divider';
import Modal from '../../components/Modal';
import ScreenContainer from '../../components/ScreenContainer';
import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import colors from '../../utils/colors';

interface Props {
  searchByPolicy: boolean;
  setSearchByPolicy: (val: boolean) => void;
  isPolicySearchResultOpen: boolean;
  hidePolicySearchResultModal: () => void;
  isLoading: boolean;
}

const FaciSearchView: FC<Props> = ({
  searchByPolicy,
  setSearchByPolicy,
  isPolicySearchResultOpen,
  hidePolicySearchResultModal,
  isLoading,
}) => {
  return (
    <ScreenContainer useHeader>
      <Modal
        variant="foundPolicy"
        isModalOpen={isPolicySearchResultOpen}
        setIsModalOpen={hidePolicySearchResultModal}
      />
      {isLoading && (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      <View style={styles.faciCustomerSearchContainer}>
        <View style={styles.headerContainer}>
          <HeaderText variant="h2">FACI - Customer Search</HeaderText>
        </View>
        <Divider style={styles.headerBorder} />

        {searchByPolicy ? (
          <View style={styles.searchByPolicyNumberContainer}>
            <View style={styles.searchByPolicyNumberLink}>
              <BodyText
                onPress={() => setSearchByPolicy(false)}
                variant="regular_link">
                {'By Name and Address'}
              </BodyText>
            </View>
            <FaciPolicyNumberSearchForm />
          </View>
        ) : (
          <View>
            <View style={styles.searchByPolicyNumberLink}>
              <BodyText
                onPress={() => setSearchByPolicy(true)}
                variant="regular_link">
                {'By Policy Number'}
              </BodyText>
            </View>
            <FaciCustomerSearchForm />
          </View>
        )}
        <SearchButtons searchByPolicy={searchByPolicy} />
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  faciCustomerSearchContainer: {
    display: 'flex',
    flexDirection: 'column',
    flexGrow: 1,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerBorder: {
    marginBottom: 12,
  },
  searchByPolicyNumberLink: {
    display: 'flex',
    flexDirection: 'row-reverse',
    marginBottom: 20,
  },
  searchByPolicyNumberContainer: {
    marginBottom: 'auto',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.transparentWhite,
  },
});
export default FaciSearchView;
