import React, {FC, useEffect, useRef} from 'react';
import {Animated, StyleSheet, View} from 'react-native';

import colors from '../../utils/colors';
import {
  SPLASH_SCREEN_FRAME_COUNT,
  SPLASH_SCREEN_FRAME_DURATION,
} from '../../utils/constants';

interface Props {}

const SplashScreenView: FC<Props> = () => {
  const frameCount = SPLASH_SCREEN_FRAME_COUNT;
  const animatedValues = useRef(
    new Array(frameCount).fill(0).map(() => new Animated.Value(0)),
  ).current;

  const frames = [
    require('../../../assets/splash-high/animated-splash-white-1.png'),
    require('../../../assets/splash-high/animated-splash-white-2.png'),
    require('../../../assets/splash-high/animated-splash-white-3.png'),
    require('../../../assets/splash-high/animated-splash-white-4.png'),
    require('../../../assets/splash-high/animated-splash-white-5.png'),
    require('../../../assets/splash-high/animated-splash-white-6.png'),
    require('../../../assets/splash-high/animated-splash-white-7.png'),
    require('../../../assets/splash-high/animated-splash-white-8.png'),
    require('../../../assets/splash-high/animated-splash-white-9.png'),
    require('../../../assets/splash-high/animated-splash-white-10.png'),
    require('../../../assets/splash-high/animated-splash-white-11.png'),
    require('../../../assets/splash-high/animated-splash-white-12.png'),
    require('../../../assets/splash-high/animated-splash-white-13.png'),
    require('../../../assets/splash-high/animated-splash-white-14.png'),
    require('../../../assets/splash-high/animated-splash-white-15.png'),
    require('../../../assets/splash-high/animated-splash-white-16.png'),
    require('../../../assets/splash-high/animated-splash-white-17.png'),
    require('../../../assets/splash-high/animated-splash-white-18.png'),
    require('../../../assets/splash-high/animated-splash-white-19.png'),
    require('../../../assets/splash-high/animated-splash-white-20.png'),
    require('../../../assets/splash-high/animated-splash-white-21.png'),
    require('../../../assets/splash-high/animated-splash-white-22.png'),
    require('../../../assets/splash-high/animated-splash-white-23.png'),
    require('../../../assets/splash-high/animated-splash-white-24.png'),
    require('../../../assets/splash-high/animated-splash-white-25.png'),
    require('../../../assets/splash-high/animated-splash-white-26.png'),
    require('../../../assets/splash-high/animated-splash-white-27.png'),
    require('../../../assets/splash-high/animated-splash-white-28.png'),
    require('../../../assets/splash-high/animated-splash-white-29.png'),
    require('../../../assets/splash-high/animated-splash-white-30.png'),
    require('../../../assets/splash-high/animated-splash-white-31.png'),
    require('../../../assets/splash-high/animated-splash-white-32.png'),
    require('../../../assets/splash-high/animated-splash-white-33.png'),
    require('../../../assets/splash-high/animated-splash-white-34.png'),
    require('../../../assets/splash-high/animated-splash-white-35.png'),
    require('../../../assets/splash-high/animated-splash-white-36.png'),
    require('../../../assets/splash-high/animated-splash-white-37.png'),
    require('../../../assets/splash-high/animated-splash-white-38.png'),
    require('../../../assets/splash-high/animated-splash-white-39.png'),
    require('../../../assets/splash-high/animated-splash-white-40.png'),
  ];
  useEffect(() => {
    const animations = animatedValues.map((animatedValue, index) => {
      const duration =
        index < 15
          ? index < 10
            ? SPLASH_SCREEN_FRAME_DURATION * 0.1
            : SPLASH_SCREEN_FRAME_DURATION * 0.9
          : SPLASH_SCREEN_FRAME_DURATION;
      return Animated.sequence([
        Animated.delay(index * SPLASH_SCREEN_FRAME_DURATION),
        Animated.timing(animatedValue, {
          toValue: 1,
          duration: duration,
          useNativeDriver: true,
        }),
      ]);
    });

    Animated.parallel(animations).start();
  }, []);

  const renderFrames = () => {
    return frames.map((frame, index) => (
      <Animated.Image
        key={index}
        source={frame}
        style={[
          styles.image,
          {
            opacity: animatedValues[index],
          },
        ]}
      />
    ));
  };

  return <View style={styles.container}>{renderFrames()}</View>;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
    position: 'absolute',
  },
});

export default SplashScreenView;
