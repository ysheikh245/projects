import React, {FC} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';

import FaciClaimsDetailItem from './FaciClaimsDetailItem';
import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Header from '../../components/Header';
import ScreenContainer from '../../components/ScreenContainer';
import HeaderText from '../../components/Text/HeaderText';
import {ClaimDetail} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';

interface Props {
  customerName: string;
  claimNumber: string;
  claimDetails: ClaimDetail;
  isLoading: boolean;
}

const FaciClaimsDetailView: FC<Props> = ({
  customerName,
  claimNumber,
  claimDetails,
  isLoading,
}) => {
  return (
    <ScreenContainer useHeader>
      <Header label={`FACI - ${customerName}`} />
      <BackToPreviousScreen screenName="FaciClaimsList" />
      <Header label={`Claim Details (${claimNumber})`} />
      <View>
        {isLoading && (
          <ActivityIndicator
            style={styles.loader}
            size="large"
            color={colors.blue100}
          />
        )}
        <View style={styles.safeAreaView}>
          {claimDetails.payees.map((item, index) => (
            <FaciClaimsDetailItem key={index} item={item} />
          ))}
        </View>
        {!isLoading && claimDetails.payees?.length == 0 && (
          <View>
            <HeaderText> No Payees available </HeaderText>
          </View>
        )}
      </View>

      <BackToPreviousScreen
        style={styles.bottomBackButton}
        screenName="FaciClaimsList"
      />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },

  title: {
    color: colors.blue100,
  },
  titleDivider: {
    marginVertical: 8,
  },
  flatList: {
    marginTop: 22,
  },
  safeAreaView: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  bottomBackButton: {
    alignSelf: 'flex-end',
  },
  loader: {
    alignSelf: 'center',
  },
});

export default FaciClaimsDetailView;
