import {FC} from 'react';
import {StyleSheet} from 'react-native';

import CardContainer from '../../components/Card/components/CardContainer';
import CardText from '../../components/Card/components/CardText';
import BodyText from '../../components/Text/BodyText';
import {Payee} from '../../redux/slices/faciSlice/types';

interface Props {
  item: Payee;
}

const FaciClaimsDetailItem: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <BodyText style={styles.headerContainer}>
        {item?.claimStatusDescription}
      </BodyText>

      <CardText label="Paid" description={`$${item.amountPaid}`} />
      <CardText label="Date Issued" description={item.paymentDate} />
      <CardText
        label="Payee"
        description={
          item.name
            ? `${item.name} ${item.address1} ${item.city} ${item.state} ${item.zip}`
            : 'N/A'
        }
      />
    </CardContainer>
  );
};
const styles = StyleSheet.create({
  headerContainer: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
});

export default FaciClaimsDetailItem;
