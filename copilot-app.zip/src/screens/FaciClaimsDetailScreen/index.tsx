import {RouteProp, useRoute} from '@react-navigation/native';
import React, {FC, useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import FaciClaimsDetailView from './FaciClaimsDetailView';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectClaimDetails,
  selectIsLoading,
  selectSelectedPolicyCustomerName,
} from '../../redux/slices/faciSlice/selectors';
import {ClaimDetail} from '../../redux/slices/faciSlice/types';

type FaciClaimDetailScreenRouteParams = {
  claimNumber: string;
  claimStatus: string;
};

type FaciClaimDetailScreenRouteProp = RouteProp<
  {params: FaciClaimDetailScreenRouteParams},
  'params'
>;

const FaciClaimDetailScreen: FC = () => {
  const route: FaciClaimDetailScreenRouteProp = useRoute();
  const dispatch = useDispatch();
  const [claimNumber, setClaimNumber] = useState('');

  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const claimDetails: ClaimDetail = useSelector(selectClaimDetails);
  const isLoading: ClaimDetail = useSelector(selectIsLoading);

  useEffect(() => {
    setClaimNumber(route.params.claimNumber);
    dispatch(
      faciActions.getClaimDetailsRequest({
        claimNumber: route.params.claimNumber,
        claimStatus: route.params.claimStatus,
      }),
    );
  }, [route, route.params.claimNumber, route.params.claimStatus]);

  return (
    <FaciClaimsDetailView
      customerName={customerName}
      claimNumber={claimNumber}
      claimDetails={claimDetails}
      isLoading={isLoading}
    />
  );
};

export default FaciClaimDetailScreen;
