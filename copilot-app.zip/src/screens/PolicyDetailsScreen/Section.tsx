import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';

import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import colors from '../../utils/colors';

interface Props {
  label: string;
  details: string;
}

const Section: FC<Props> = ({label, details = ''}) => {
  return (
    <View style={styles.section}>
      <HeaderText variant="h3" style={styles.header}>
        {label}
      </HeaderText>
      <BodyText style={styles.details}>{details}</BodyText>
    </View>
  );
};

const styles = StyleSheet.create({
  section: {
    marginBottom: 15,
  },
  header: {
    fontWeight: '600',
    color: colors.black100,
  },
  details: {
    marginLeft: 30,
  },
});

export default Section;
