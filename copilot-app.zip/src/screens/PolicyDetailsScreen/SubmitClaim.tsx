import React, {useCallback, useEffect} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import Button from '../../components/Button';
import BodyText from '../../components/Text/BodyText';
import UploadDocument from '../../components/UploadDocument';
import useDocumentPickerMultiple from '../../hooks/useDocumentPickerMultiple';
import {faciActions} from '../../redux/slices/faciSlice';
import {selectIsLoading} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';

const SubmitClaim = () => {
  const dispatch = useDispatch();
  const [numDocuments, setNumDocuments] = React.useState<number>(1);
  const isLoading = useSelector(selectIsLoading);

  const {
    documents,
    onPressGetDocument,
    onPressResetDocumentPicker,
    resetAllDocuments,
  } = useDocumentPickerMultiple();

  useEffect(() => {
    ``;
    if (!isLoading) {
      resetUploadScreen();
    }
  }, [isLoading]);

  const incrementNumDocuments = () => {
    setNumDocuments(prevNum => Math.min(prevNum + 1, 5));
  };

  const resetDocument = useCallback(
    (index: number) => {
      onPressResetDocumentPicker(index);
      setNumDocuments(prevNum => Math.max(prevNum - 1, 0));
    },
    [onPressResetDocumentPicker],
  );

  const onPressSubmitClaims = () => {
    dispatch(faciActions.selectDocuments(documents));
    dispatch(faciActions.submitClaimDetailsRequest());
  };

  const resetUploadScreen = () => {
    resetAllDocuments();
    setNumDocuments(1);
  };

  return (
    <View style={styles.submitClaimContainer}>
      <BodyText style={styles.submitClaim}>Submit a New Claim</BodyText>
      <BodyText style={styles.uploadFile}>Upload Files</BodyText>
      {Array.from({length: numDocuments}).map((_, index) => (
        <UploadDocument
          key={index}
          onPressResetDocumentPicker={() => resetDocument(index)}
          onPressGetDocument={() => {
            onPressGetDocument(index);
            incrementNumDocuments();
          }}
          documentName={documents[index]?.name}
        />
      ))}
      <View style={styles.bottomButtons}>
        <Button
          title="Submit"
          style={
            documents.length === 0
              ? styles.submitClaimsButtonDisabled
              : styles.submitClaimsButton
          }
          textStyle={
            documents.length === 0 ? styles.buttonOne : styles.buttonTwo
          }
          variant="primary"
          disabled={documents.length === 0}
          onPress={onPressSubmitClaims}
        />
        <Button
          title="Cancel"
          style={styles.rightButton}
          textStyle={styles.buttonThree}
          onPress={resetUploadScreen}
        />
      </View>

      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  submitClaimContainer: {
    backgroundColor: colors.gray600,
    padding: 10,
    borderRadius: 10,
    marginBottom: 15,
    position: 'relative',
  },
  submitClaim: {
    fontWeight: '500',
    marginBottom: 12,
  },
  uploadFile: {
    marginBottom: 12,
  },
  submitClaimsButton: {
    backgroundColor: colors.blue100,
    borderColor: colors.blue100,
    borderWidth: 2,
  },
  submitClaimsButtonDisabled: {
    backgroundColor: colors.gray1000,
    borderColor: colors.gray1000,
    borderWidth: 2,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 200,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparent,
    opacity: 0.5,
    zIndex: 1,
  },
  rightButton: {
    backgroundColor: colors.white,
    borderColor: colors.gray900,
    borderWidth: 2,
    marginLeft: 10,
  },
  bottomButtons: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: '10%',
  },
  buttonOne: {
    color: colors.gray100,
  },
  buttonTwo: {
    color: colors.white,
  },
  buttonThree: {
    color: colors.gray900,
  },
});

export default SubmitClaim;
