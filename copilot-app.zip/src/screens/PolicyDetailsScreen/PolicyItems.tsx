import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import AdditionalPolicyCard from './AdditonalPolicyCard';
import Modal from '../../components/Modal';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectAdditionalPolicyInfo,
  selectIsLoading,
  selectPolicyNumber,
} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';

interface Item {
  label: string;
  onPress: () => void;
  count: number;
}

const PolicyItems = () => {
  const dispatch = useDispatch();

  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const policyNumber = useSelector(selectPolicyNumber);
  const additionalPolicyInfo = useSelector(selectAdditionalPolicyInfo);
  const isLoading = useSelector(selectIsLoading);

  // const [isAlertMessageModal, setIsAlertMessageModal] = useState(false);

  const policyAlertsCount = additionalPolicyInfo?.policyAlertsCount
    ? additionalPolicyInfo.policyAlertsCount
    : 0;
  const rolesCount = additionalPolicyInfo?.rolesCount
    ? additionalPolicyInfo.rolesCount
    : 0;
  const dependentsCount = additionalPolicyInfo?.dependentsCount
    ? additionalPolicyInfo.dependentsCount
    : 0;
  const agentOfRecordsCount = additionalPolicyInfo?.agentsOfRecordCount
    ? additionalPolicyInfo.agentsOfRecordCount
    : 0;
  const discountsCount = additionalPolicyInfo?.discountsCount
    ? additionalPolicyInfo.discountsCount
    : 0;
  const additionalLifeInsuranceRidersCount =
    additionalPolicyInfo?.additionalLifeInsuranceRidersCount
      ? additionalPolicyInfo.additionalLifeInsuranceRidersCount
      : 0;
  const coverageDetailsCount = additionalPolicyInfo?.coverageDetailsCount
    ? additionalPolicyInfo.coverageDetailsCount
    : 0;
  const beneficiaryDetailsCount = additionalPolicyInfo?.beneficiaryDetailsCount
    ? additionalPolicyInfo.beneficiaryDetailsCount
    : 0;
  const rateChangesCount = additionalPolicyInfo?.rateChangesCount
    ? additionalPolicyInfo.rateChangesCount
    : 0;
  const viewCustomerDocumentsCount =
    additionalPolicyInfo?.viewCustomerDocumentsCount
      ? additionalPolicyInfo.viewCustomerDocumentsCount
      : 0;

  const items: Item[] = [
    {
      label: `Policy Alerts (${policyAlertsCount})`,
      onPress: () => {
        dispatch(faciActions.getPolicyAlertsRequest());
      },
      count: policyAlertsCount,
    },
    {
      label: `Roles (${rolesCount})`,
      onPress: () => {
        dispatch(faciActions.getFaciRolesRequest({policyNumber}));
      },
      count: rolesCount,
    },
    {
      label: `Dependents (${dependentsCount})`,
      onPress: () => {
        dispatch(faciActions.getFaciDependentsRequest({policyNumber}));
      },
      count: dependentsCount,
    },
    {
      label: `Agents of Records (${agentOfRecordsCount})`,
      onPress: () => {
        dispatch(faciActions.getAgentRecordsRequest({policyNumber}));
      },
      count: agentOfRecordsCount,
    },
    {
      label: `Discounts (${discountsCount})`,
      onPress: () => {
        dispatch(faciActions.getFaciDiscountsRequest({policyNumber}));
      },
      count: discountsCount,
    },
    {
      label: `Additional Life Insurance Riders (${additionalLifeInsuranceRidersCount})`,
      onPress: () => {
        dispatch(
          faciActions.getPolicyAdditionalCoverageRequest({policyNumber}),
        );
      },
      count: additionalLifeInsuranceRidersCount,
    },
    {
      label: `Coverage Details (${coverageDetailsCount})`,
      onPress: () => {
        dispatch(faciActions.getPolicyCoverageDetailsRequest({policyNumber}));
      },
      count: coverageDetailsCount,
    },
    {
      label: `Beneficiary Details (${beneficiaryDetailsCount})`,
      onPress: () => {
        dispatch(faciActions.getBeneficiaryDetailsRequest({policyNumber}));
      },
      count: beneficiaryDetailsCount,
    },
    {
      label: `Rate Changes (${rateChangesCount})`,
      onPress: () => {
        dispatch(faciActions.getFaciRateChangesRequest({policyNumber}));
      },
      count: rateChangesCount,
    },
    {
      label: `Customer Documents (${viewCustomerDocumentsCount})`,
      onPress: () => {
        dispatch(faciActions.getFaciCustomerDocumentsRequest({policyNumber}));
        navigate('CustomerDocuments');
      },
      count: viewCustomerDocumentsCount,
    },
  ];

  const navigateToClaims = () => {
    dispatch(faciActions.getFaciClaimsRequest({policyNumber}));
    navigate('FaciClaimsSearch');
  };

  return (
    <>
      <Modal variant="alertMessage" />
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      {items.map((item, index) => (
        <AdditionalPolicyCard
          count={item.count}
          label={item.label}
          key={index}
          onPressItem={item.onPress}
        />
      ))}

      <AdditionalPolicyCard
        count={1}
        label="Claims "
        onPressItem={navigateToClaims}
      />
      <Modal variant="roles" />
      <Modal variant="discounts" />
      <Modal variant="dependents" />
      <Modal variant="rateChanges" />
      <Modal variant="agentRecords" />
      <Modal variant="policyAdditionalCoverage" />
      <Modal variant="policyCoverageDetail" />
      <Modal variant="beneficiaryDetails" />
    </>
  );
};
const styles = StyleSheet.create({
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
});
export default PolicyItems;
