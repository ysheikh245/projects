import React, {FC} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';

import Policy from './Policy';
import PolicyItems from './PolicyItems';
import SubmitClaim from './SubmitClaim';
import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Header from '../../components/Header';
import ScreenContainer from '../../components/ScreenContainer';
import BodyText from '../../components/Text/BodyText';
import colors from '../../utils/colors';

interface Props {
  onPressMore: () => void;
  customerName: string;
  isLoading: boolean;
}
const PolicyDetailsView: FC<Props> = ({
  onPressMore,
  customerName,
  isLoading,
}) => {
  return (
    <ScreenContainer useHeader>
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      <Header label={`FACI - ${customerName}`} />
      <BackToPreviousScreen screenName="Customer" />
      <Policy />
      <BodyText
        style={styles.more}
        onPress={onPressMore}
        variant="regular_link">
        More
      </BodyText>
      <Header
        style={styles.additionalHeader}
        label="Additional Policy Information"
      />
      <PolicyItems />
      <SubmitClaim />
      <BackToPreviousScreen
        style={styles.bottomBackButton}
        screenName="Customer"
      />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerBorder: {
    marginBottom: 12,
  },
  title: {
    color: colors.blue100,
  },
  titleDivider: {
    marginVertical: 8,
  },
  section: {
    marginBottom: 15,
  },
  more: {
    marginTop: 15,
    marginBottom: 52,
    alignSelf: 'flex-end',
    display: 'none',
  },
  messageButton: {
    width: 318,
    alignSelf: 'flex-end',
    marginBottom: 15,
  },
  bottomBackButton: {
    alignSelf: 'flex-end',
  },
  additionalHeader: {
    marginTop: 16,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 200,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
});

export default PolicyDetailsView;
