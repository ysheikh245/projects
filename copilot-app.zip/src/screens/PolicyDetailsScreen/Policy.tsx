import moment from 'moment-timezone';
import React from 'react';
import {useSelector} from 'react-redux';

import Section from './Section';
import Header from '../../components/Header';
import {
  selectPolicyDetail,
  selectPolicySearchByPartyIDPolicy,
} from '../../redux/slices/faciSlice/selectors';
import {dateTimeFormat} from '../../utils/constants';

const Policy = () => {
  const policyDetail = useSelector(selectPolicyDetail);
  const policySearchByPartyIDPolicy = useSelector(
    selectPolicySearchByPartyIDPolicy,
  );

  return policyDetail?.productName ? (
    <>
      <Header label={`Policy ${policySearchByPartyIDPolicy?.policyNumber}`} />
      {policyDetail?.productName && (
        <Section label="Product" details={policyDetail.productName} />
      )}
      {policyDetail?.policyStatus && (
        <Section label="Policy Status" details={policyDetail.policyStatus} />
      )}
      {policyDetail?.policyEffectiveDate && (
        <Section
          label="Policy Effective Date"
          details={moment(policyDetail.policyEffectiveDate).format(
            dateTimeFormat,
          )}
        />
      )}
      {policyDetail?.issueDate && (
        <Section
          label="Policy Issue Date"
          details={moment(policyDetail.issueDate).format(dateTimeFormat)}
        />
      )}
      {policyDetail?.lastPaymentDate && (
        <Section
          label="Last Payment Date"
          details={moment(policyDetail.lastPaymentDate).format(dateTimeFormat)}
        />
      )}
      {policyDetail?.paidToDate && (
        <Section
          label="Paid to Date"
          details={moment(policyDetail.paidToDate).format(dateTimeFormat)}
        />
      )}
      {policyDetail?.currentPremium && (
        <Section
          label="Current Premium"
          details={`$${policyDetail.currentPremium}`}
        />
      )}
    </>
  ) : null;
};

export default Policy;
