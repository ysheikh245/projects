import React, {FC} from 'react';
import {Pressable, StyleSheet} from 'react-native';

import CardContainer from '../../components/Card/components/CardContainer';
import BodyText from '../../components/Text/BodyText';
import colors from '../../utils/colors';

interface Props {
  label: string;
  onPressItem: (label: string) => void;
  count: number;
}
const AdditionalPolicyCard: FC<Props> = ({label, onPressItem, count}) => {
  return (
    <CardContainer style={styles.container}>
      <BodyText>{label}</BodyText>
      <Pressable
        // disabled={count === 0}
        onPress={() => onPressItem(label)}>
        <BodyText style={count === 0 && styles.viewText} variant="regular_link">
          View
        </BodyText>
      </Pressable>
    </CardContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  viewText: {
    color: colors.gray200,
  },
});

export default AdditionalPolicyCard;
