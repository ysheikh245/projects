import {RouteProp, useNavigation, useRoute} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import PolicyDetailsView from './PolicyDetailsView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectIsAdditionalInfoLoading,
  selectIsGoToPreviousScreen,
  selectIsLoading,
  selectSelectedPolicyCustomerName,
} from '../../redux/slices/faciSlice/selectors';

interface Route {
  params: {
    policyNumber: string;
  };
}

const PolicyDetailsScreen = () => {
  const dispatch = useDispatch();
  const {goBack} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();
  const route: Route =
    useRoute<RouteProp<AppStackParamList, 'PolicyDetails'>>();

  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const isLoading = useSelector(selectIsLoading);
  const isAdditionalInfoLoading = useSelector(selectIsAdditionalInfoLoading);
  const isGoBack = useSelector(selectIsGoToPreviousScreen);

  if (isGoBack) {
    goBack();
    dispatch(faciActions.goToPreviousScreen(false));
  }
  useEffect(() => {
    dispatch(
      faciActions.getPolicyDetailRequest({
        policyNumber: route.params.policyNumber,
      }),
    );
    dispatch(
      faciActions.getAdditionalPolicyInfoRequest({
        policyNumber: route.params.policyNumber,
      }),
    );
    dispatch(faciActions.resetPolicyDetailAdditionalInfo());
  }, [route.params.policyNumber]);

  const onPressMore = () => {};

  return (
    <PolicyDetailsView
      isLoading={isLoading || isAdditionalInfoLoading}
      onPressMore={onPressMore}
      customerName={customerName}
    />
  );
};

export default PolicyDetailsScreen;
