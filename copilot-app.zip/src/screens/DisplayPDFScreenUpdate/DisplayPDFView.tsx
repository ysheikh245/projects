import React, {FC} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';
import Pdf from 'react-native-pdf';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import PMICIcon from '../../components/PMICIcons';
import ScreenContainer from '../../components/ScreenContainer';
import ScreenLoader from '../../components/ScreenLoader';
import colors from '../../utils/colors';

interface Props {
  onPressDownload: () => void;
  source: {
    uri: string;
  } | null;
  isLoading: boolean;
}

const DisplayPDFView: FC<Props> = ({onPressDownload, source, isLoading}) => {
  return (
    <ScreenContainer style={styles.container}>
      <View style={styles.navigationContainer}>
        <BackToPreviousScreen
          style={{marginBottom: 0}}
          screenName="Statements"
        />
        <Pressable onPress={onPressDownload}>
          <PMICIcon size={50} name="icon-down-load" color={colors.black400} />
        </Pressable>
      </View>
      {source && (
        <Pdf
          source={{uri: source.uri}}
          style={styles.pdf}
          enablePaging={true}
        />
      )}
      <ScreenLoader message="Please wait..." isLoading={isLoading} />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingLeft: -9,
    justifyContent: 'flex-start',
  },
  pdf: {
    flex: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 20,
    paddingRight: 30,
  },
});

export default DisplayPDFView;
