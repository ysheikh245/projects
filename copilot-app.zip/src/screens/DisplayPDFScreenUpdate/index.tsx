import {RouteProp, useRoute} from '@react-navigation/native';
import React, {useEffect} from 'react';
import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import {useDispatch, useSelector} from 'react-redux';

import DisplayPDFView from './DisplayPDFView';
import {myCompensationActions} from '../../redux/slices/myCompensation';
import {
  selectIsLoading,
  selectPDF,
} from '../../redux/slices/myCompensation/selectors';
import {MyCompensationPDF} from '../../redux/slices/myCompensation/types';

const DisplayPDFScreenUpdate = () => {
  const dispatch = useDispatch();
  const route: RouteProp<{params: {pdfData: MyCompensationPDF}}> = useRoute();

  const source = useSelector(selectPDF);
  const isLoading = useSelector(selectIsLoading);

  // Fetch PDF
  useEffect(() => {
    if (route.params.pdfData.fileName.length > 0) {
      dispatch(
        myCompensationActions.getMyCompensationPDFRequest({
          data: route.params.pdfData,
        }),
      );
    }

    return () => {
      dispatch(myCompensationActions.resetPDF());
      if (source) {
        const path = source.uri.replace('file://', '');
        RNFS.unlink(path).catch(console.error);
      }
    };
  }, [route.params.pdfData]);

  const onPressDownload = async () => {
    if (source) {
      const file = route.params.pdfData;
      const fileExt = file.fileExtension === 'PDF' ? 'PDF' : 'pdf';
      const path = `${RNFS.DocumentDirectoryPath}/${file.fileName}.${fileExt}`;
      RNFS.writeFile(path, source.base64, 'base64')
        .then(async () => {
          await Share.open({
            url: 'file://' + path,
            type: 'application/pdf',
          });
        })
        .catch(console.error);
    }
  };

  return (
    <DisplayPDFView
      isLoading={isLoading}
      source={source}
      onPressDownload={onPressDownload}
    />
  );
};

export default DisplayPDFScreenUpdate;
