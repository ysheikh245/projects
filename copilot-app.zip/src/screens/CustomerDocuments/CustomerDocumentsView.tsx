import React, {FC} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Card from '../../components/Card';
import Header from '../../components/Header';
import ScreenContainer from '../../components/ScreenContainer';
import {CustomerDocument} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
interface Props {
  customerDocuments: CustomerDocument[];
  isLoading: boolean;
}

const CustomerDocumentsView: FC<Props> = ({customerDocuments, isLoading}) => {
  return (
    <ScreenContainer useHeader>
      <Header label="Customer Documents" />
      <BackToPreviousScreen screenName="Policy Details" />
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      {customerDocuments.map((customerDocument, index) => {
        return (
          <Card
            key={index}
            variant="customerDocuments"
            item={customerDocument}
          />
        );
      })}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  flatList: {
    marginTop: 45,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
});

export default CustomerDocumentsView;
