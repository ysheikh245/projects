import React from 'react';
import {useSelector} from 'react-redux';

import CustomerDocumentsView from './CustomerDocumentsView';
import {
  selectCustomerDocuments,
  selectIsLoading,
} from '../../redux/slices/faciSlice/selectors';

const CostumerDocumentsScreen = () => {
  const customerDocuments = useSelector(selectCustomerDocuments);
  const isLoading = useSelector(selectIsLoading);

  return (
    <CustomerDocumentsView
      customerDocuments={customerDocuments}
      isLoading={isLoading}
    />
  );
};

export default CostumerDocumentsScreen;
