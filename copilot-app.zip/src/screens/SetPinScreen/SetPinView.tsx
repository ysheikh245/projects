import {useFocusEffect} from '@react-navigation/native';
import React, {FC, useCallback, useState} from 'react';
import {Image, LayoutChangeEvent, Text, View} from 'react-native';
import {StyleSheet} from 'react-native';
import {
  CodeField,
  Cursor,
  isLastFilledCell,
  MaskSymbol,
  RenderCellOptions,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import Toast from 'react-native-root-toast';

import {PinStates} from '.';
import Logo from '../../assets/images/logo2.png';
import AuthScreenContainer from '../../components/AuthScreenContainer';
import Button from '../../components/Button';
import colors from '../../utils/colors';

interface Props {
  pinState: PinStates;
  doSavePin: (pinValue: string) => void;
  doBiometrics: () => void;
  doFinishLogin: () => void;
}

interface RenderCellProps extends RenderCellOptions {
  value: string;
  layoutHandler: (index: number) => (event: LayoutChangeEvent) => void;
}

const SetPinView: FC<Props> = ({
  pinState = PinStates.CREATE_PIN,
  doSavePin,
  doBiometrics,
  doFinishLogin,
}) => {
  const [pinValue, setPinValue] = useState('');
  const [confirmValue, setConfirmValue] = useState('');

  const pinInputRef = useBlurOnFulfill({value: pinValue, cellCount: 6});
  const [pinPros, pinGetCellOnLayoutHandler] = useClearByFocusCell({
    value: pinValue,
    setValue: setPinValue,
  });

  const confirmInputRef = useBlurOnFulfill({value: confirmValue, cellCount: 6});
  const [confirmPros, confirmGetCellOnLayoutHandler] = useClearByFocusCell({
    value: confirmValue,
    setValue: setConfirmValue,
  });

  useFocusEffect(
    useCallback(() => {
      pinInputRef.current?.focus();
    }, [pinInputRef]),
  );

  const renderCell = ({
    index,
    symbol,
    isFocused,
    value,
    layoutHandler,
  }: RenderCellProps) => {
    let textChild = null;
    if (symbol) {
      textChild = (
        <MaskSymbol
          maskSymbol="●"
          isLastFilledCell={isLastFilledCell({index, value})}>
          {symbol}
        </MaskSymbol>
      );
    } else if (isFocused) {
      textChild = <Cursor />;
    }

    return (
      <View key={index} onLayout={layoutHandler(index)}>
        <Text style={styles.pinText}>{textChild}</Text>
      </View>
    );
  };

  return (
    <AuthScreenContainer>
      <View style={styles.loginBox}>
        <View style={styles.logoBox}>
          <Image source={Logo} style={styles.logo} />
        </View>
        {pinState === PinStates.CREATE_PIN ? (
          <>
            <Text style={styles.text}>
              Please enter a new 6-digit pin for future logins
            </Text>

            <CodeField
              ref={pinInputRef}
              {...pinPros}
              value={pinValue}
              onChangeText={value => {
                setPinValue(value);
                if (value.length === 6) {
                  confirmInputRef.current?.focus();
                }
              }}
              cellCount={6}
              keyboardType="number-pad"
              textContentType="password"
              renderCell={opts =>
                renderCell({
                  ...opts,
                  value: pinValue,
                  layoutHandler: pinGetCellOnLayoutHandler,
                })
              }
            />

            <Text style={styles.text}>Please confirm your 6-digit pin</Text>

            <CodeField
              ref={confirmInputRef}
              {...confirmPros}
              value={confirmValue}
              onChangeText={value => {
                setConfirmValue(value);
                if (value.length === 6) {
                  if (value === pinValue) {
                    doSavePin(pinValue);
                  } else {
                    Toast.show('Pins do not match', {
                      duration: Toast.durations.SHORT,
                      position: Toast.positions.CENTER,
                    });
                    setPinValue('');
                    setConfirmValue('');
                    pinInputRef.current?.focus();
                  }
                }
              }}
              cellCount={6}
              keyboardType="number-pad"
              textContentType="password"
              renderCell={opts =>
                renderCell({
                  ...opts,
                  value: confirmValue,
                  layoutHandler: confirmGetCellOnLayoutHandler,
                })
              }
            />
          </>
        ) : pinState === PinStates.ASK_BIOMETRICS ? (
          <>
            <Text>Would you like to enable biometric authentication?</Text>
            <View>
              <Button
                variant="cta"
                textStyle={styles.buttonText}
                buttonColor={colors.yellow100}
                textVariant="h2"
                testID="noButton"
                accessibilityLabel="No"
                title="No"
                onPress={doFinishLogin}
              />
              <Button
                variant="cta"
                textStyle={styles.buttonText}
                buttonColor={colors.yellow100}
                textVariant="h2"
                testID="yesButton"
                accessibilityLabel="Yes"
                title="Yes"
                onPress={doBiometrics}
              />
            </View>
          </>
        ) : (
          <>
            <Text>Authenticating...</Text>
          </>
        )}
      </View>
    </AuthScreenContainer>
  );
};

const styles = StyleSheet.create({
  loginBox: {
    marginTop: '20%',
    width: '80%',
    maxWidth: 500,
    gap: 20,
  },
  logoBox: {
    flexDirection: 'row',
  },
  logo: {
    flex: 1,
    aspectRatio: 446 / 250,
  },
  spinner: {
    marginTop: 20,
  },
  pinText: {
    backgroundColor: colors.gray200,
    color: colors.black100,
    height: 40,
    width: 40,
    borderRadius: 4,
    padding: 10,
  },
  text: {
    color: colors.black100,
  },
  buttonText: {
    color: colors.black100,
  },
});

export default SetPinView;
