import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import Constants from 'expo-constants';
import * as LocalAuthentication from 'expo-local-authentication';
import React, {useEffect, useState} from 'react';
import {useDispatch} from 'react-redux';

import SetPinView from './SetPinView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {authActions} from '../../redux/slices/authSlice';

export enum PinStates {
  CREATE_PIN,
  ASK_BIOMETRICS,
  AUTHENTICATING_BIOMETRICS,
}

export enum EResult {
  CANCELLED = 'CANCELLED',
  DISABLED = 'DISABLED',
  ERROR = 'ERROR',
  SUCCESS = 'SUCCESS',
}

// Endpoint
const discovery = {
  authorizationEndpoint: `${
    Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT
  }/auth`,
  tokenEndpoint: `${Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT}/token`,
};

const SetPinScreen = () => {
  const dispatch = useDispatch();
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const [pinState, setPinState] = useState(PinStates.CREATE_PIN);

  const [isEnrolled, setIsEnrolled] = useState(false);
  const [facialRecognitionAvailable, setFacialRecognitionAvailable] =
    useState(false);
  const [fingerprintAvailable, setFingerprintAvailable] = useState(false);
  const [irisAvailable, setIrisAvailable] = useState(false);

  const checkSupportedAuthentication = async () => {
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    setIsEnrolled(isEnrolled);
    if (isEnrolled) {
      const types =
        await LocalAuthentication.supportedAuthenticationTypesAsync();
      if (types && types.length) {
        setFacialRecognitionAvailable(
          types.includes(
            LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION,
          ),
        );
        setFingerprintAvailable(
          types.includes(LocalAuthentication.AuthenticationType.FINGERPRINT),
        );
        setIrisAvailable(
          types.includes(LocalAuthentication.AuthenticationType.IRIS),
        );
      }
    }
  };

  useEffect(() => {
    checkSupportedAuthentication();
  }, []);

  const doFinishLogin = () => {
    dispatch(authActions.authenticate(true));
    navigate('Home');
  };

  const doSavePin = async (pinValue: string) => {
    dispatch(authActions.savePin(pinValue));
    if (isEnrolled) {
      setPinState(PinStates.ASK_BIOMETRICS);
    } else {
      dispatch(authActions.authenticate(true));
      navigate('Home');
    }
  };

  const doBiometrics = async () => {
    setPinState(PinStates.AUTHENTICATING_BIOMETRICS);

    try {
      console.log('bio scan');
      const results = await LocalAuthentication.authenticateAsync({
        disableDeviceFallback: true,
        cancelLabel: 'Cancel',
      });
      console.log('bio result', results);

      if (results.success) {
        dispatch(authActions.saveBiometrics(true));
        dispatch(authActions.authenticate(true));
        navigate('Home');
      } else {
        setPinState(PinStates.ASK_BIOMETRICS);
      }
    } catch (error) {
      setPinState(PinStates.ASK_BIOMETRICS);
    }
  };

  return (
    <SetPinView
      pinState={pinState}
      doSavePin={doSavePin}
      doBiometrics={doBiometrics}
      doFinishLogin={doFinishLogin}
    />
  );
};

export default SetPinScreen;
