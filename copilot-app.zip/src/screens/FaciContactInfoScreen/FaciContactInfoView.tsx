import React, {FC} from 'react';
import {ActivityIndicator, Pressable, StyleSheet, View} from 'react-native';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Divider from '../../components/Divider';
import PMICIcon from '../../components/PMICIcons';
import ScreenContainer from '../../components/ScreenContainer';
import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import {FaciCustomerDetail} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import UserProfileUtils from '../../utils/UserProfileUtils';

export interface Props {
  isLoading: boolean;
  onPressCreateSecureMessage: () => void;
  onPressSelectPolicy: (policy: any) => void;
  faciCustomerDetail?: FaciCustomerDetail;
}

const FaciContactInfoView: FC<Props> = ({
  isLoading,
  onPressSelectPolicy,
  onPressCreateSecureMessage,
  faciCustomerDetail,
}) => {
  return (
    <ScreenContainer useHeader>
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      {/* <ScreenLoader isLoading={isLoading === true} /> */}
      {faciCustomerDetail &&
        faciCustomerDetail.personNameList &&
        faciCustomerDetail.personNameList.length > 0 && (
          <View style={styles.headerContainer}>
            <HeaderText
              style={styles.header}
              variant="h2">{`FACI - ${faciCustomerDetail.personNameList[0].lastName} ${faciCustomerDetail.personNameList[0].firstName}`}</HeaderText>
          </View>
        )}
      <Divider style={styles.headerBorder} />
      <BackToPreviousScreen
        screenName="Search"
        style={styles.backToPreviousScreen}
      />
      <View style={styles.secondaryHeaderContainer}>
        <HeaderText style={styles.header} variant="h3">
          Contact Information
        </HeaderText>
      </View>
      <View style={styles.cardContainer}>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Name
          </BodyText>
          {faciCustomerDetail &&
            faciCustomerDetail.personNameList &&
            faciCustomerDetail.personNameList.length > 0 && (
              <BodyText>{`${faciCustomerDetail.personNameList[0].firstName} ${faciCustomerDetail.personNameList[0].lastName}`}</BodyText>
            )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Date of Birth
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.birthDate && (
            <BodyText>{faciCustomerDetail.birthDate}</BodyText>
          )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Age
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.birthDate && (
            <BodyText>
              {UserProfileUtils.calculateAge(faciCustomerDetail.birthDate)}
            </BodyText>
          )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Gender
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.gender && (
            <BodyText>
              {UserProfileUtils.getGender(faciCustomerDetail.gender)}
            </BodyText>
          )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Primary Address
          </BodyText>
        </View>
        <View style={styles.addressContainer}>
          {faciCustomerDetail && faciCustomerDetail.homeAddress && (
            <View>
              {faciCustomerDetail.homeAddress.addressLine1 && (
                <BodyText variant="regular">
                  {faciCustomerDetail.homeAddress.addressLine1}
                </BodyText>
              )}
              {faciCustomerDetail.homeAddress.addressLine2 && (
                <BodyText variant="regular">
                  {faciCustomerDetail.homeAddress.addressLine2}
                </BodyText>
              )}
              {(faciCustomerDetail.homeAddress.city ||
                faciCustomerDetail.homeAddress.state) && (
                <BodyText variant="regular">
                  {faciCustomerDetail.homeAddress.city},{' '}
                  {faciCustomerDetail.homeAddress.state}
                </BodyText>
              )}
              {faciCustomerDetail.homeAddress.zipCode && (
                <BodyText variant="regular">
                  {faciCustomerDetail.homeAddress.zipCode}
                </BodyText>
              )}
            </View>
          )}
        </View>
        {/*
                  //TODO: Uncomment when temp address is available
                <View style={styles.textContainer}>
                    <BodyText style={styles.cardText} variant='regular_bold'>Temporary Address</BodyText>
                </View>
                <View style={styles.addressContainer}>
                {
                    faciCustomerDetail && faciCustomerDetail.tempAddress && (
                        <View>
                            {
                                faciCustomerDetail.tempAddress.addressLine1 &&
                                    <BodyText variant='regular'>{faciCustomerDetail.tempAddress.addressLine1}</BodyText>
                            }
                            {
                                faciCustomerDetail.tempAddress.addressLine2 &&
                                    <BodyText variant='regular'>{faciCustomerDetail.tempAddress.addressLine2}</BodyText>
                            }
                            {
                                (faciCustomerDetail.tempAddress.city || faciCustomerDetail.tempAddress.state) &&
                                    <BodyText variant='regular'>
                                        {faciCustomerDetail.tempAddress.city}, {faciCustomerDetail.tempAddress.state}
                                    </BodyText>
                            }
                            {
                                faciCustomerDetail.tempAddress.zipCode &&
                                    <BodyText variant='regular'>{faciCustomerDetail.tempAddress.zipCode}</BodyText>
                            }
                        </View>
                    )
                }
                </View> */}
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Primary Phone
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.phoneNumber && (
            <BodyText variant="regular_link">
              {faciCustomerDetail.phoneNumber}
            </BodyText>
          )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.cardText} variant="regular_bold">
            Secondary Phone
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.phoneNumber && (
            <BodyText variant="regular_link">
              {faciCustomerDetail.secondaryPhoneNumber}
            </BodyText>
          )}
        </View>
        <View style={styles.textContainer}>
          <BodyText style={styles.emailText} variant="regular_bold">
            Email
          </BodyText>
          {faciCustomerDetail && faciCustomerDetail.emailAddress && (
            <BodyText variant="regular_link">
              {faciCustomerDetail.emailAddress}
            </BodyText>
          )}
        </View>
      </View>
      {faciCustomerDetail && faciCustomerDetail.policies && (
        <View style={styles.secondaryHeaderContainer}>
          <HeaderText style={styles.header} variant="h3">
            {`Policies (${faciCustomerDetail.policies.length} Entries)`}
          </HeaderText>
        </View>
      )}
      {faciCustomerDetail &&
        faciCustomerDetail.policies &&
        faciCustomerDetail.policies.map(policy => {
          return (
            <Pressable
              onPress={() => onPressSelectPolicy(policy)}
              key={policy.policyNumber}>
              <View style={styles.cardContainer}>
                <HeaderText style={styles.header} variant="h3">
                  {policy.policyNumber}
                </HeaderText>
                <BodyText variant="regular">{policy.productName}</BodyText>
                <BodyText variant="regular">{policy.status}</BodyText>
                {policy && policy.parties && policy.parties.length > 0 && (
                  <BodyText variant="regular">
                    {policy.parties[0].role}
                  </BodyText>
                )}

                <View style={styles.iconContainer}>
                  <PMICIcon
                    size={50}
                    name="icon-right-chevron"
                    color={colors.blue100}
                  />
                </View>
              </View>
            </Pressable>
          );
        })}
      {/*
                 //TODO: Enable this when secure message is ready
                <View style={styles.footerContainer}>
                <Button
                    title='Create Secure Message'
                    variant='primary'
                    style={styles.secureButton}
                    onPress={onPressCreateSecureMessage}
                    />
                    <BackToPreviousScreen screenName='Search' style={styles.backToPreviousScreen} />
            </View> */}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  header: {
    color: colors.black100,
  },
  secondaryHeaderContainer: {
    marginTop: 12,
  },
  headerBorder: {
    marginBottom: 12,
  },
  backToSearch: {
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 12,
  },
  cardContainer: {
    backgroundColor: colors.white,
    width: '100%',
    marginBottom: 12,
    borderRadius: 10,
    shadowColor: colors.black100,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 8.84,
    elevation: 5,
    padding: 10,
    position: 'relative',
  },
  cardText: {
    marginBottom: 10,
    minWidth: 140,
  },
  emailText: {
    marginBottom: 10,
    minWidth: 75,
  },
  addressContainer: {
    marginLeft: 120,
    marginTop: -10,
    marginBottom: 12,
  },
  textContainer: {
    flexDirection: 'row',
    display: 'flex',
  },
  iconContainer: {
    position: 'absolute',
    right: 0,
    top: '25%',
  },
  footerContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    paddingBottom: 20,
    marginTop: 20,
  },
  secureButton: {
    width: 'auto',
    paddingHorizontal: 10,
    backgroundColor: colors.blue100,
    borderColor: colors.blue100,
  },
  backToPreviousScreen: {
    marginBottom: 0,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
});

export default FaciContactInfoView;
