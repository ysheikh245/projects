import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React from 'react';
import {useDispatch, useSelector} from 'react-redux';

import FaciContactInfoView from './FaciContactInfoView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectIsLoading,
  selectPolicySearchByPartyIDResponse,
} from '../../redux/slices/faciSlice/selectors';

const FaciContactInfoScreen = () => {
  const isLoading = useSelector(selectIsLoading);
  const faciCustomerDetail = useSelector(selectPolicySearchByPartyIDResponse);
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();
  const dispatch = useDispatch();

  const onPressCreateSecureMessage = () => {
    //TODO: implement onPressCreateSecureMessage
    console.log('on press create secure message');
  };

  const onPressSelectPolicy = (policy: any) => {
    //TODO: implement policy detail screen from API
    dispatch(faciActions.updatePolicySearchByPartyIDPolicy(policy));
    navigate('PolicyDetails', {policyNumber: policy.policyNumber});
  };

  return (
    <FaciContactInfoView
      isLoading={isLoading}
      onPressCreateSecureMessage={onPressCreateSecureMessage}
      onPressSelectPolicy={onPressSelectPolicy}
      faciCustomerDetail={faciCustomerDetail}
    />
  );
};

export default FaciContactInfoScreen;
