import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {
  CodeChallengeMethod,
  exchangeCodeAsync,
  makeRedirectUri,
  useAuthRequest,
} from 'expo-auth-session';
import Constants from 'expo-constants';
import jwt_decode, {JwtPayload} from 'jwt-decode';
import React, {useEffect, useState} from 'react';
import EncryptedStorage from 'react-native-encrypted-storage';
import {useDispatch, useSelector} from 'react-redux';

import LoginView from './LoginView';
import {AuthStackParamList} from '../../navigation/AuthNavigation';
import {asFilterActions} from '../../redux/slices/applicationStatusFilterSlice';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {authActions} from '../../redux/slices/authSlice';
import {selectNpn} from '../../redux/slices/authSlice/selectors';
import {menuActions} from '../../redux/slices/menuSlice';
import PMICUser, {
  DecodedIdentityToken,
  USER_TYPE,
  USER_VALIDITY,
} from '../../types/PMICUser';

// Endpoint
const discovery = {
  authorizationEndpoint: `${
    Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT
  }/auth`,
  tokenEndpoint: `${Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT}/token`,
};

const LoginScreen = () => {
  const dispatch = useDispatch();
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AuthStackParamList>>();

  const npn = useSelector(selectNpn);

  const [loading, setLoading] = useState(false);
  const [secretCode, setSecretCode] = useState('');

  const [request, response, promptAsync] = useAuthRequest(
    {
      clientId: Constants.expoConfig!.extra!.KEYCLOAK_CLIENT_ID,
      redirectUri: makeRedirectUri({path: 'auth'}),
      usePKCE: true,
      codeChallenge: '',
      codeChallengeMethod: CodeChallengeMethod.S256,
      responseType: 'code',
      scopes: ['openid', 'profile', 'email', 'phone', 'offline_access'],
    },
    discovery,
  );

  useEffect(() => {
    if (response?.type === 'success') {
      dispatch(applicationStatusActions.setFreshRequest(true));
      const {code} = response.params;
      setSecretCode(code);
      getToken();
    } else {
      setLoading(false);
    }
  }, [response]);

  const getToken = async () => {
    if (response?.type === 'success') {
      try {
        const requestToken = await exchangeCodeAsync(
          {
            code: response.params.code || secretCode,
            redirectUri: makeRedirectUri({path: 'auth'}),
            clientId: Constants.expoConfig!.extra!.KEYCLOAK_CLIENT_ID,
            extraParams: {
              code_verifier: request?.codeVerifier ? request?.codeVerifier : '',
            },
          },
          discovery,
        );

        console.log('requestToken :>> ', requestToken);

        await EncryptedStorage.setItem('accessToken', requestToken.accessToken);
        await EncryptedStorage.setItem(
          'refreshToken',
          requestToken.refreshToken!,
        );

        const access = jwt_decode(requestToken.accessToken!) as JwtPayload;
        const identy = jwt_decode(
          requestToken.idToken!,
        ) as DecodedIdentityToken;
        const refresh = jwt_decode(requestToken.refreshToken!) as JwtPayload;
        console.log('tokens :>> ', {
          access,
          identy,
          refresh,
        });

        const user = new PMICUser({
          id: identy.pmicnpn,
          username: identy.preferred_username,
          npn: identy.pmicnpn,
          userType: USER_TYPE.AGENT, // TODO: set the proper user_type
          firstName: identy.given_name,
          lastName: identy.family_name,
          primaryPhone: '0005550000', // TODO: set the phone number
          emailAddress: identy.email,
          validity: USER_VALIDITY.VALID, // TODO: set the validity
        });

        dispatch(authActions.setUser(user));

        navigate('SetPin');
      } catch (err) {
        console.error(err);
        setLoading(false);
      }
    }
  };

  const doLogin = () => {
    console.log({
      redirectUri: makeRedirectUri({path: 'auth'}),
    });
    setLoading(true);
    promptAsync();
  };

  const doDebug = () => {
    navigate('Debugging');
  };

  useEffect(() => {
    dispatch(menuActions.getMenuItemsRequest());
  }, []);

  useEffect(() => {
    // TODO remove on Productions
    dispatch(applicationStatusActions.applicationStatusSuccess({data: []}));
    dispatch(asFilterActions.resetFilter());
  }, [npn]);

  return <LoginView loading={loading} doLogin={doLogin} doDebug={doDebug} />;
};

export default LoginScreen;
