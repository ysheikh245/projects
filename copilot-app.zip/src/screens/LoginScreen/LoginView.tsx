import React, {FC} from 'react';
import {ActivityIndicator, Image, View} from 'react-native';
import {StyleSheet} from 'react-native';

import Logo from '../../assets/images/logo2.png';
import AuthScreenContainer from '../../components/AuthScreenContainer';
import Button from '../../components/Button';
import colors from '../../utils/colors';

interface Props {
  loading: boolean;
  doLogin: () => void;
  doDebug: () => void;
}

const LoginView: FC<Props> = ({loading, doLogin, doDebug}) => {
  return (
    <AuthScreenContainer>
      <View style={styles.loginBox}>
        <View style={styles.logoBox}>
          <Image source={Logo} style={styles.logo} />
        </View>
        {loading ? (
          <ActivityIndicator size="large" />
        ) : (
          <Button
            variant="cta"
            buttonColor={colors.yellow100}
            textVariant="h2"
            testID="loginButton"
            accessibilityLabel="Login"
            title="Login"
            onPress={doLogin}
            onLongPress={doDebug}
          />
        )}
      </View>
    </AuthScreenContainer>
  );
};

const styles = StyleSheet.create({
  loginBox: {
    marginTop: '20%',
    width: '80%',
    maxWidth: 500,
    gap: 20,
  },
  logoBox: {
    flexDirection: 'row',
  },
  logo: {
    flex: 1,
    aspectRatio: 446 / 250,
  },
  spinner: {
    marginTop: 20,
  },
});

export default LoginView;
