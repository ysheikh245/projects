import {StyleSheet} from 'react-native';

import colors from '../../utils/colors';

const styles = StyleSheet.create({
  homeScreenIconContainer: {
    padding: '2%',
  },
  homeIconsContainer: {
    alignSelf: 'flex-start',
    alignItems: 'center',
  },
  text: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  iconContainer: {
    backgroundColor: colors.gray300,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  expoIcon: {
    top: -2,
    position: 'relative',
  },
  iconText: {
    fontSize: 16,
    textAlign: 'center',
    fontWeight: '400',
    minWidth: 125,
    maxWidth: 125,
    color: colors.black100,
  },
  iconRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  leftIcon: {
    marginLeft: '20%',
  },
  spaceTopRow: {
    marginTop: 25,
  },
  zocialIcon: {
    position: 'relative',
    left: 3,
    top: 5,
  },
  myCompIcon: {
    fontSize: 60,
  },
  hidden: {
    opacity: 0,
  },
  quickLinksContainer: {
    backgroundColor: '#fff',
    padding: 10,
    paddingLeft: 10,
    paddingTop: 50,
  },
  quickLinks: {
    fontSize: 16,
    color: colors.black100,
  },
  appStatusIcon: {
    fontSize: 52,
  },
  secureMessageIcon: {
    position: 'relative',
    top: 14,
    fontSize: 35,
    left: 2,
  },
  myStatusIcon: {
    fontSize: 51,
    position: 'relative',
    top: 5,
    left: 2,
  },
  myContactInfoIcon: {
    position: 'relative',
    top: 5,
  },
  imageIconStyle: {
    position: 'relative',
  },
  foundationIcon: {},
});

export default styles;
