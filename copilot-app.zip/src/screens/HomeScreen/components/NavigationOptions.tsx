import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React from 'react';
import {View} from 'react-native';

import Option from './Option';
import {AppStackParamList} from '../../../navigation/AppNavigation';
import styles from '../styles';

const NavigationOptions = () => {
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  return (
    <>
      <View style={styles.iconRow}>
        <Option
          onPress={() => navigate('ApplicationStatus')}
          screenName="Application Status"
          iconName="icon-app-status"
        />
        <Option
          onPress={() => navigate('FaciSearch')}
          screenName="FACI"
          iconName="icon-faci"
        />
      </View>
      <View style={styles.iconRow}>
        <Option
          onPress={() => navigate('MyCompensation')}
          screenName="View My Compensation"
          iconName="icon-my-compensation"
        />
      </View>
    </>
  );
};

export default NavigationOptions;
