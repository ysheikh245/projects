import React, {FC} from 'react';
import {Pressable, Text, View} from 'react-native';

import {HomeIconColor} from '../../../../constants/colors';
import PMICIcon from '../../../components/PMICIcons';
import styles from '../styles';

interface Props {
  onPress: () => void;
  screenName: string;
  iconName: string;
}

const Option: FC<Props> = ({onPress, iconName, screenName}) => {
  return (
    <Pressable style={styles.homeIconsContainer} onPress={onPress}>
      <View style={styles.iconContainer}>
        <PMICIcon
          name={iconName}
          style={styles.appStatusIcon}
          color={HomeIconColor}
        />
      </View>
      <Text style={styles.iconText}>{screenName}</Text>
    </Pressable>
  );
};

export default Option;
