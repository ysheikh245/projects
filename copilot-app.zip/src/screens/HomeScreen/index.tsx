import React, {useEffect, useState} from 'react';
import {useDispatch} from 'react-redux';

import HomeView from './HomeView';
import {menuActions} from '../../redux/slices/menuSlice';

const HomeScreen = () => {
  const dispatch = useDispatch();

  const [day2MenuItems, setDay2MenuItems] = useState(false);

  useEffect(() => {
    dispatch(menuActions.getMenuItemsRequest());
  }, [dispatch]);

  return <HomeView day2MenuItems={day2MenuItems} />;
};
export default HomeScreen;
