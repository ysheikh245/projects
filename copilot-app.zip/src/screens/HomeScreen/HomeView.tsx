import React, {FC} from 'react';
import {Image, Text, View} from 'react-native';

import NavigationOptions from './components/NavigationOptions';
import styles from './styles';
import {FoundationIcon, HomeIconColor} from '../../../constants/colors';
import {S3BLUE_ICON} from '../../../constants/imageurl';
import PMICIcon from '../../components/PMICIcons';
import ScreenContainer from '../../components/ScreenContainer';

interface Props {
  day2MenuItems: boolean;
}
const HomeView: FC<Props> = ({day2MenuItems}) => {
  return (
    <ScreenContainer useMenuFilter>
      <>
        <View style={styles.quickLinksContainer}>
          <Text style={styles.quickLinks}>Quick Links</Text>
        </View>
        <View style={styles.homeScreenIconContainer}>
          <NavigationOptions />

          {day2MenuItems && (
            <View style={[styles.iconRow, styles.spaceTopRow]}>
              <View style={styles.homeIconsContainer}>
                <View style={styles.iconContainer}>
                  <PMICIcon
                    name="icon-view-my-comp"
                    style={styles.foundationIcon}
                    size={FoundationIcon}
                    color={HomeIconColor}
                  />
                </View>
                <Text style={styles.iconText}>View My Compensation</Text>
              </View>
              <View style={[styles.homeIconsContainer, styles.leftIcon]}>
                <View style={styles.iconContainer}>
                  <PMICIcon
                    name="icon-secure-msg"
                    style={styles.secureMessageIcon}
                    color={HomeIconColor}
                  />
                </View>
                <Text style={styles.iconText}>Secure Message</Text>
              </View>
            </View>
          )}

          {day2MenuItems && (
            <View style={[styles.iconRow, styles.spaceTopRow]}>
              <View style={styles.homeIconsContainer}>
                <View style={styles.iconContainer}>
                  <PMICIcon
                    name="icon-my-status"
                    style={styles.myStatusIcon}
                    color={HomeIconColor}
                  />
                </View>
                <Text style={styles.iconText}>My Status</Text>
              </View>
              <View style={[styles.homeIconsContainer, styles.leftIcon]}>
                <View style={styles.iconContainer}>
                  <PMICIcon
                    name="icon-my-contact-info"
                    style={styles.myContactInfoIcon}
                    size={FoundationIcon}
                    color={HomeIconColor}
                  />
                </View>
                <Text style={styles.iconText}>My Contact Info</Text>
              </View>
            </View>
          )}

          {day2MenuItems && (
            <View style={[styles.iconRow, styles.spaceTopRow]}>
              <View style={styles.homeIconsContainer}>
                <View style={styles.iconContainer}>
                  <Image
                    style={{
                      position: 'relative',
                      height: 47,
                      width: 47,
                      top: 9,
                      left: 7,
                    }}
                    source={S3BLUE_ICON}
                    resizeMode={'cover'}
                  />
                </View>
                <Text style={styles.iconText}>
                  Marketing and Sales Material
                </Text>
              </View>
              <View
                style={[
                  styles.homeIconsContainer,
                  styles.leftIcon,
                  styles.hidden,
                ]}>
                <View style={styles.iconContainer}>
                  <PMICIcon
                    name="icon-my-contact-info"
                    style={styles.myContactInfoIcon}
                    size={FoundationIcon}
                    color={HomeIconColor}
                  />
                </View>
                <Text style={styles.iconText}>My Contact Info</Text>
              </View>
            </View>
          )}
        </View>
      </>
    </ScreenContainer>
  );
};

export default HomeView;
