import React, {FC} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Card from '../../components/Card';
import Divider from '../../components/Divider';
import Header from '../../components/Header';
import ScreenContainer from '../../components/ScreenContainer';
import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import {Claim} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';

interface Props {
  isLoading: boolean;
  customerName: string;
  claims: Claim[];
  isHealth: boolean;
  navigateToClaimDetails: (claim: Claim) => void;
}

const FaciClaimsListView: FC<Props> = ({
  isLoading,
  customerName,
  claims,
  isHealth,
  navigateToClaimDetails,
}) => {
  const lifeDisclaimerText =
    'Benefits are paid subject to final claims approval, and may be impacted by policy exceptions and limitations, loans, graded death benefits and assignments.';
  const healthDisclaimerText =
    'Benefits are paid subject to final claims approval, and may be impacted by policy exceptions and limitations, Medicare deductibles, policy deductibles and provider assignments.';
  return (
    <ScreenContainer useHeader>
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      <Header label={`FACI - ${customerName}`} />
      <BackToPreviousScreen screenName="Search" />
      <HeaderText variant="h3">Claims</HeaderText>
      <Divider style={styles.headerBorder} />
      <View style={styles.flatList}>
        {claims &&
          claims.map((claim, index) => (
            <Card
              variant="claim"
              key={index}
              item={claim}
              navigateToClaimDetails={() => navigateToClaimDetails(claim)}
            />
          ))}
        {claims.length === 0 && (
          <HeaderText variant="h3" style={styles.noClaimsFound}>
            No Claims Found For Given Search Criteria
          </HeaderText>
        )}
      </View>

      <BodyText style={styles.disclaimer}>
        {isHealth ? healthDisclaimerText : lifeDisclaimerText}
      </BodyText>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
  header: {
    color: colors.black100,
  },
  headerBorder: {
    marginBottom: 12,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  disclaimer: {
    fontSize: 16,
    fontStyle: 'italic',
    textDecorationLine: 'underline',
  },
  flatList: {
    flex: 1,
  },
  noClaimsFound: {
    color: colors.black100,
  },
});

export default FaciClaimsListView;
