import {RouteProp, useRoute} from '@react-navigation/native';
import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React from 'react';
import {useDispatch, useSelector} from 'react-redux';

import FaciClaimsListView from './FaciClaimsListView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {
  selectIsLoading,
  selectPolicyDetail,
  selectSelectedPolicyCustomerName,
  selectVisibleClaims,
} from '../../redux/slices/faciSlice/selectors';
import {Claim} from '../../redux/slices/faciSlice/types';

const FaciClaimsSearchScreen = () => {
  const route: RouteProp<{params: {uri: string}}> = useRoute();
  const dispatch = useDispatch();
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const isLoading = useSelector(selectIsLoading);
  const claims = useSelector(selectVisibleClaims);
  const policyDetail = useSelector(selectPolicyDetail);

  const navigateToClaimDetails = (claim: Claim) => {
    navigate('FaciClaimDetail', {
      claimNumber: claim.claimNumber,
      claimStatus: claim.claimStatus,
    });
  };

  return (
    <FaciClaimsListView
      isLoading={isLoading}
      customerName={customerName}
      claims={claims}
      isHealth={policyDetail?.policyType.toLocaleLowerCase() === 'health'}
      navigateToClaimDetails={navigateToClaimDetails}
    />
  );
};

export default FaciClaimsSearchScreen;
