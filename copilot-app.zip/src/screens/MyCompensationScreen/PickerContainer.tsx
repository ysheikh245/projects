import React, {FC} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';

import ArrowDownIcon from '../../assets/icons/ArrowDownIcon';
import HeaderText from '../../components/Text/HeaderText';
import colors from '../../utils/colors';

interface Props {
  label: string;
  value: string;
  onPress: () => void;
}

const PickerContainer: FC<Props> = ({label, value, onPress}) => {
  return (
    <View style={styles.container}>
      <HeaderText style={styles.headerText} variant="h2">
        {label}
      </HeaderText>
      <Pressable onPress={onPress} style={styles.pickerContainer}>
        <HeaderText style={styles.headerText} variant="h2">
          {value}
        </HeaderText>
        <ArrowDownIcon />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  headerText: {
    color: colors.black100,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  pickerContainer: {
    width: 235,
    borderColor: colors.gray100,
    borderWidth: 1,
    paddingHorizontal: 22,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
  },
});

export default PickerContainer;
