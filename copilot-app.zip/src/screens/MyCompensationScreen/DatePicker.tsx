import moment from 'moment-timezone';
import React, {useState} from 'react';
import {StyleSheet} from 'react-native';
import {useDispatch} from 'react-redux';

import PickerContainer from './PickerContainer';
import {getLastDay, getMonth} from './utils';
import Button from '../../components/Button';
import MonthPicker from '../../components/Picker/MonthPicker';
import YearPicker from '../../components/Picker/YearPicker';
import {myCompensationActions} from '../../redux/slices/myCompensation';
import colors from '../../utils/colors';

const momentYear = moment().year();
const momentMonth = moment().month() + 1;

const DatePicker = () => {
  const dispatch = useDispatch();

  const [isYearPickerVisible, setYearPickerVisible] = useState(false);
  const [isMonthPickerVisible, setMonthPickerVisible] = useState(false);
  const [selectedYear, setSelectedYear] = useState(momentYear);
  const [selectedMonth, setSelectedMonth] = useState(momentMonth);

  let beginDate = `${selectedYear}-${selectedMonth}-${1}`;

  const endDay = getLastDay(selectedYear, selectedMonth);
  let endDate = `${selectedYear}-${selectedMonth}-${endDay}`;

  const onPressRetrieve = () => {
    dispatch(
      myCompensationActions.getStatementsRequest({
        beginDate,
        endDate,
      }),
    );
  };

  return (
    <>
      <PickerContainer
        label="Year"
        value={`${selectedYear}`}
        onPress={() => setYearPickerVisible(!isYearPickerVisible)}
      />
      <PickerContainer
        label="Month"
        value={getMonth(selectedMonth)}
        onPress={() => setMonthPickerVisible(!isMonthPickerVisible)}
      />
      <YearPicker
        pickerVisible={isYearPickerVisible}
        setPickerVisible={setYearPickerVisible}
        selectedValue={selectedYear}
        setSelectedValue={setSelectedYear}
      />
      <MonthPicker
        pickerVisible={isMonthPickerVisible}
        setPickerVisible={setMonthPickerVisible}
        selectedValue={selectedMonth}
        setSelectedValue={setSelectedMonth}
      />
      <Button
        onPress={onPressRetrieve}
        style={styles.button}
        variant="primary"
        title="Retrieve"
      />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  pickerContainer: {
    minWidth: 176,
    borderColor: colors.gray100,
    borderWidth: 1,
    paddingHorizontal: 22,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 22,
  },
  button: {
    alignSelf: 'flex-end',
    marginBottom: 25,
  },
});

export default DatePicker;
