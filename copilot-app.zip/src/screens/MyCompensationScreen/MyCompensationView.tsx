import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';

import DatePicker from './DatePicker';
import Card from '../../components/Card';
import Divider from '../../components/Divider';
import ScreenContainer from '../../components/ScreenContainer';
import ScreenLoader from '../../components/ScreenLoader';
import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import {Statement} from '../../redux/slices/myCompensation/types';
import colors from '../../utils/colors';

interface Props {
  statements: Statement[];
  isLoading: boolean;
}

const MyCompensationView: FC<Props> = ({statements, isLoading}) => {
  return (
    <ScreenContainer useHeader>
      <View style={styles.headerContainer}>
        <HeaderText style={styles.headerText} variant="h2">
          My Compensation
        </HeaderText>
      </View>
      <Divider style={styles.headerBorder} />
      <BodyText style={styles.hintText}>
        Statements can be viewed up to 5 years back
      </BodyText>
      <DatePicker />
      <HeaderText style={styles.weeklyStatements} variant="h2">
        Statements
      </HeaderText>
      {statements.length > 0 ? (
        statements.map((statement, index) => {
          return (
            <Card key={index} variant="weeklyStatements" item={statement} />
          );
        })
      ) : (
        <BodyText style={styles.emptyText}>
          Filter dates to retrieve statements
        </BodyText>
      )}
      <ScreenLoader message="Please wait..." isLoading={isLoading} />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  headerText: {
    color: colors.black100,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerBorder: {
    marginBottom: 12,
  },
  hintText: {
    color: colors.gray900,
    marginBottom: 35,
  },
  weeklyStatements: {
    marginBottom: 10,
    color: colors.black100,
  },
  emptyText: {
    alignSelf: 'center',
    color: colors.gray100,
  },
});

export default MyCompensationView;
