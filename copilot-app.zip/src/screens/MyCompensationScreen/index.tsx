import React from 'react';
import {useSelector} from 'react-redux';

import MyCompensationView from './MyCompensationView';
import {
  selectIsLoading,
  selectMutatedStatements,
} from '../../redux/slices/myCompensation/selectors';

const MyCompensationScreen = () => {
  const statements = useSelector(selectMutatedStatements);
  const isLoading = useSelector(selectIsLoading);

  return <MyCompensationView isLoading={isLoading} statements={statements} />;
};

export default MyCompensationScreen;
