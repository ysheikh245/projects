import {StyleSheet} from 'react-native';

const images = {};

const styles = StyleSheet.create({});

export {images, styles};
