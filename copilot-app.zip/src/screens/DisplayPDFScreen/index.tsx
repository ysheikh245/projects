import {RouteProp, useRoute} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';

import DisplayPDFView from './DisplayPDFView';

const DisplayPDFScreen = () => {
  const route: RouteProp<{params: {uri: string}}> = useRoute();

  const [uri, setUri] = useState('');

  useEffect(() => {
    setUri(route.params.uri);
  }, [route, route.params.uri]);

  return <DisplayPDFView uri={uri} />;
};

export default DisplayPDFScreen;
