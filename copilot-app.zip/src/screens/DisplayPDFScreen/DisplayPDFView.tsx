import React, {FC, useEffect, useState} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';
import RNFS from 'react-native-fs';
import Pdf from 'react-native-pdf';
import Share from 'react-native-share';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import PMICIcon from '../../components/PMICIcons';
import ScreenContainer from '../../components/ScreenContainer';
import {fetchPDFService} from '../../services/faciService';
import colors from '../../utils/colors';

interface PdfProps {
  uri: string;
  path: string;
  cache: boolean;
  base64: string;
}

interface Props {
  uri: string;
}

const DisplayPDFView: FC<Props> = ({uri}) => {
  const [source, setSource] = useState<PdfProps | null>(null);

  const parseUrl = (url: string) => {
    const [path, query] = url.split('?');
    const params = query.split('&');
    const file: any = {};
    params.forEach(param => {
      const [key, value] = param.split('=');
      if (key === 'fileName') {
        const [fileName, fileExtension] = value.split('.');
        file.fileName = fileName;
        file.fileExtension = fileExtension;
      } else {
        file[key] = value;
      }
    });
    return file;
  };

  const handleDownload = async () => {
    if (source) {
      const file = parseUrl(uri);
      const fileExt = file.fileExtension === 'PDF' ? 'PDF' : 'pdf';
      const path = `${RNFS.DocumentDirectoryPath}/${file.fileName}.${fileExt}`;
      RNFS.writeFile(path, source.base64, 'base64')
        .then(async () => {
          Share.open({
            url: 'file://' + path,
            type: 'application/pdf',
          });
        })
        .catch(console.error);
    }
  };

  useEffect(() => {
    if (uri.length > 0) {
      const file = parseUrl(uri);
      fetchPDFService(file).then(setSource).catch(console.error);
    }

    return () => {
      if (source) {
        const path = source.uri.replace('file://', '');
        RNFS.unlink(path).catch(console.error);
      }
    };
  }, [uri]);

  return (
    <ScreenContainer style={styles.container}>
      <View style={styles.navigationContainer}>
        <BackToPreviousScreen
          style={{marginBottom: 0}}
          screenName="Documents"
        />
        <Pressable onPress={handleDownload}>
          <PMICIcon size={50} name="icon-down-load" color={colors.black400} />
        </Pressable>
      </View>
      {source && (
        <Pdf
          source={{uri: source.uri}}
          style={styles.pdf}
          enablePaging={true}
        />
      )}
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingLeft: -9,
    justifyContent: 'flex-start',
  },
  pdf: {
    flex: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingLeft: 20,
    paddingRight: 30,
  },
});

export default DisplayPDFView;
