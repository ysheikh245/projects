import React, {FC} from 'react';
import {ActivityIndicator, StyleSheet, View} from 'react-native';

import StatusSection from './StatusSection';
import Divider from '../../components/Divider';
import Modal from '../../components/Modal';
import ScreenContainer from '../../components/ScreenContainer';
import HeaderText from '../../components/Text/HeaderText';
import {ApplicationStatus} from '../../redux/slices/applicationStatusSlice/types';
import colors from '../../utils/colors';
import Colors from '../../utils/colors';

export interface Props {
  data: {
    Pending: ApplicationStatus[];
    Issued: ApplicationStatus[];
    'Decline/Withdrawn': ApplicationStatus[];
    'Not Taken': ApplicationStatus[];
  };
  setIsOpenFilterModalOpen: () => void;
  isFilterModalOpen: boolean;
  isLoading: boolean;
  onScrollToEnd: (event: any) => void;
  pageNumber: number;
}

const ApplicationStatusView: FC<Props> = ({
  data,
  setIsOpenFilterModalOpen,
  isLoading,
  onScrollToEnd,
  pageNumber,
}) => {
  const isScreenEmpty =
    data.Pending.length === 0 &&
    data.Issued.length === 0 &&
    data['Decline/Withdrawn'].length === 0 &&
    data['Not Taken'].length === 0;
  return (
    <ScreenContainer onScroll={onScrollToEnd} useHeader>
      <View style={styles.headerContainer}>
        <HeaderText variant="h2">Application Status</HeaderText>
        <HeaderText
          style={{color: colors.blue100}}
          variant="h2_link"
          onPress={setIsOpenFilterModalOpen}>
          Filter
        </HeaderText>
      </View>
      <Divider style={styles.headerBorder} />
      {isScreenEmpty && !isLoading && (
        <HeaderText style={styles.noDataText}>No Data Available</HeaderText>
      )}
      {data.Pending.length > 0 && (
        <StatusSection
          pageNumber={pageNumber}
          title="Pending"
          data={data.Pending}
        />
      )}
      {data.Issued.length > 0 && (
        <StatusSection
          pageNumber={pageNumber}
          title="Issued"
          data={data.Issued}
        />
      )}
      {data['Decline/Withdrawn'].length > 0 && (
        <StatusSection
          pageNumber={pageNumber}
          title="Decline/Withdrawn"
          data={data['Decline/Withdrawn']}
        />
      )}
      {data['Not Taken'].length > 0 && (
        <StatusSection
          pageNumber={pageNumber}
          title="Not Taken"
          data={data['Not Taken']}
        />
      )}
      {isLoading && <ActivityIndicator size="large" color={Colors.blue100} />}
      <Modal
        pageNumber={pageNumber}
        variant="filter"
        setIsModalOpen={setIsOpenFilterModalOpen}
      />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerBorder: {
    marginBottom: 12,
  },
  noDataText: {
    alignSelf: 'center',
    color: Colors.gray100,
  },
});

export default ApplicationStatusView;
