import {THANKYOU_SENT} from '../../constants/applicationStatus';
import {ApplicationStatus} from '../../redux/slices/applicationStatusSlice/types';

export const updateThankYouButton = (
  policyNumber: string,
  applicationStatusData: ApplicationStatus[],
) => {
  if ((policyNumber || applicationStatusData) === undefined)
    return applicationStatusData;

  const array: ApplicationStatus[] = [];

  applicationStatusData.forEach((data, index) => {
    if (policyNumber === data.policyNumber) {
      data.thankyouEmailStatus = THANKYOU_SENT;
    }
    array.push(data);
  });

  return array;
};
