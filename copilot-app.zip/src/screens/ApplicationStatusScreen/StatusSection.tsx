import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';

import Card from '../../components/Card';
import Divider from '../../components/Divider';
import HeaderText from '../../components/Text/HeaderText';
import {ApplicationStatus} from '../../redux/slices/applicationStatusSlice/types';
import colors from '../../utils/colors';

interface Props {
  title: string;
  data: ApplicationStatus[];
  pageNumber: number;
}
const StatusSection: FC<Props> = ({title, data, pageNumber}) => {
  return (
    <>
      <View style={styles.titleContainer}>
        <HeaderText style={styles.title} variant="h3">
          {title}
        </HeaderText>
        <Divider style={styles.titleDivider} />
      </View>
      {data?.map((item: ApplicationStatus, index: number) => (
        <Card
          pageNumber={pageNumber}
          key={index}
          variant="applicationStatus"
          item={item}
        />
      ))}
    </>
  );
};

const styles = StyleSheet.create({
  titleContainer: {
    backgroundColor: colors.white,
  },
  title: {
    color: colors.blue100,
  },
  titleDivider: {
    marginVertical: 8,
  },
});

export default StatusSection;
