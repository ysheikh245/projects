import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import ApplicationStatusView from './ApplicationStatusView';
import {asFilterActions} from '../../redux/slices/applicationStatusFilterSlice';
import {selectIsFilterActive} from '../../redux/slices/applicationStatusFilterSlice/selectors';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {
  isFreshRequest,
  selectApplicationStatusIsLoading,
  selectMutatedApplicationStatus
} from '../../redux/slices/applicationStatusSlice/selectors';
import {selectPageNumber} from '../../redux/slices/applicationStatusSlice/selectors';

const ApplicationStatusScreen = () => {
  const dispatch = useDispatch();
  const pageNumber = useSelector(selectPageNumber);

  const data = useSelector(selectMutatedApplicationStatus);
  const isLoading = useSelector(selectApplicationStatusIsLoading);

  const isFilterActive = useSelector(selectIsFilterActive);
  const isFreshAppStatusRequest = useSelector(isFreshRequest);

  useEffect(() => {
    if (isFreshAppStatusRequest) {
      dispatch(applicationStatusActions.applicationStatusFreshRequest());
    } else {
      dispatch(applicationStatusActions.applicationStatusRequest());
    }
    dispatch(applicationStatusActions.setFreshRequest(false));
    return () => {
      dispatch(applicationStatusActions.setPageNumber({pageNumber: 0}));
      dispatch(applicationStatusActions.applicationStatusReset(true));
      dispatch(asFilterActions.defaultAsFilter());
    };
  }, [dispatch]);

  const onScrollToEnd = async (e: any) => {
    const paddingToBottom = 20;
    const closeToBottom =
      e.nativeEvent.layoutMeasurement.height + e.nativeEvent.contentOffset.y >=
      e.nativeEvent.contentSize.height - paddingToBottom;

    if (closeToBottom) {
      dispatch(applicationStatusActions.applicationStatusRequest());
    }
  };

  const openFilterModal = () =>
    dispatch(asFilterActions.isFilterModalOpen(true));

  return (
    <ApplicationStatusView
      pageNumber={pageNumber}
      onScrollToEnd={onScrollToEnd}
      isFilterModalOpen={isFilterActive}
      setIsOpenFilterModalOpen={openFilterModal}
      data={data}
      isLoading={isLoading}
    />
  );
};

export default ApplicationStatusScreen;
