import React, {FC} from 'react';
import {Dimensions, StyleSheet, View} from 'react-native';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Button from '../../components/Button';
import {PolicyDetailData} from '../../components/Card/ApplicationStatusCard';
import OutstandingRequirementsCard from '../../components/Card/OutstandingRequirementsCard';
import Header from '../../components/Header';
import Modal from '../../components/Modal';
import ScreenContainer from '../../components/ScreenContainer';
import ScreenLoader from '../../components/ScreenLoader';
import BodyText from '../../components/Text/BodyText';
import {DISABLED} from '../../constants/applicationStatus';
import {Case360Document} from '../../redux/slices/applicationStatusSlice/types';
import colors from '../../utils/colors';

interface Props {
  isSuccessModalOpen: boolean;
  setIsSuccessModalOpen: (val: boolean) => void;
  data: Case360Document[];
  policyDetailData: PolicyDetailData;
  onPressSubmitButton: () => void;
  submitDisabled: string;
  onPressCancel: () => void;
  isLoading: boolean;
}

const {width} = Dimensions.get('window');

const ApplicationStatusDetailsView: FC<Props> = ({
  isSuccessModalOpen,
  setIsSuccessModalOpen,
  data,
  policyDetailData,
  onPressSubmitButton,
  submitDisabled,
  onPressCancel,
  isLoading,
}) => {
  const name = policyDetailData?.name ? policyDetailData.name : '';
  const policyNumber = policyDetailData?.policyNumber
    ? policyDetailData.policyNumber
    : '';
  const productName = policyDetailData?.productName
    ? policyDetailData.productName
    : '';

  return (
    /* make useSecondHeader true when wanting to display create secure message */
    <ScreenContainer
      useHeader
      useSecondHeader={false}
      secondHeaderLabel="Secure Message">
      <Header label={`Application ${policyNumber}`} />
      <BackToPreviousScreen screenName="Applications" />
      <BodyText style={styles.cardText} variant="regular_bold">
        Name <BodyText>{name}</BodyText>
      </BodyText>
      <BodyText style={styles.cardText} variant="regular_bold">
        Policy <BodyText>{policyNumber}</BodyText>
      </BodyText>
      <BodyText style={styles.cardText} variant="regular_bold">
        Product <BodyText>{productName}</BodyText>
      </BodyText>
      <Header
        style={styles.outstandingLabel}
        label="Outstanding Requirement List"
      />
      <View style={styles.flex1View}>
        {data?.length > 0 &&
          data.map((item, index) => {
            const dataSize = data.length - 1;
            return (
              String(item.displayField) !== 'false' && (
                <OutstandingRequirementsCard
                  dataSize={dataSize}
                  index={index}
                  key={index}
                  item={item}
                />
              )
            );
          })}
      </View>
      <View style={styles.buttonContainer}>
        <Button
          disabled={submitDisabled === DISABLED}
          title="Submit"
          style={
            submitDisabled === DISABLED
              ? styles.leftButton
              : styles.leftButtonTwo
          }
          textStyle={
            submitDisabled === DISABLED ? styles.buttonOne : styles.buttonTwo
          }
          onPress={onPressSubmitButton}
        />
        <Button
          onPress={onPressCancel}
          title="Cancel"
          style={styles.rightButton}
          textStyle={styles.buttonThree}
        />
      </View>
      <Modal
        variant="success"
        isModalOpen={isSuccessModalOpen}
        setIsModalOpen={setIsSuccessModalOpen}
      />
      <ScreenLoader message="Please wait..." isLoading={isLoading} />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  divider: {
    marginVertical: 12,
  },
  backLink: {
    marginBottom: 35,
  },
  cardText: {
    marginBottom: 10,
  },
  outstandingLabel: {
    marginTop: 24,
  },
  cardContainer: {
    backgroundColor: colors.gray600,
    minHeight: 186,
    width: '100%',
    marginBottom: 12,
    borderRadius: 10,
    shadowColor: colors.black100,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    paddingHorizontal: 6,
    paddingVertical: 10,
  },
  uploadFileText: {
    marginTop: 16,
    marginBottom: 12,
  },
  buttonContainer: {
    backgroundColor: colors.white,
    height: 75,
    width,
    // position: 'absolute', // commenting as this is making items sneak under and not visible
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 9,
  },
  leftButton: {
    width: 181,
    backgroundColor: colors.gray500,
  },
  leftButtonTwo: {
    width: 181,
    backgroundColor: colors.blue100,
  },
  rightButton: {
    width: 181,
    backgroundColor: colors.white,
    borderColor: colors.gray900,
    borderWidth: 2,
  },
  flex1View: {
    flex: 1,
  },
  buttonOne: {
    color: colors.gray900,
  },
  buttonTwo: {
    color: colors.white,
  },
  buttonThree: {
    color: colors.gray900,
  },
});

export default ApplicationStatusDetailsView;
