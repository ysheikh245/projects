import {RouteProp, useRoute} from '@react-navigation/native';
import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {Alert} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import ApplicationStatusDetailsView from './ApplicationStatusDetailsView';
import {PolicyDetailData} from '../../components/Card/ApplicationStatusCard';
import useDocumentPicker from '../../hooks/useDocumentPicker';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {
  isUploadSuccess,
  selectIsLoading,
  selectIsUploadDocumentDisabled,
  selectSelectedDocument,
  selectWorksheetDetail,
} from '../../redux/slices/applicationStatusSlice/selectors';

const ApplicationStatusDetailsScreen = () => {
  const dispatch = useDispatch();
  const {goBack} = useNavigation();

  const {onPressCancel} = useDocumentPicker();

  const route: RouteProp<{params: {policyDetailData: PolicyDetailData}}> =
    useRoute();
  const worksheetDetail = useSelector(selectWorksheetDetail);
  const selectedDocument = useSelector(selectSelectedDocument);
  const isLoading = useSelector(selectIsLoading);
  const submitDisabled = useSelector(selectIsUploadDocumentDisabled);
  const uploadSuccess = useSelector(isUploadSuccess);

  useEffect(() => {
    if (uploadSuccess) {
      Alert.alert('Success', 'Your Document Uploaded Successfully', [
        {
          text: 'Ok',
          onPress: () => goBack(),
        },
      ]);
    }
    return () => dispatch(applicationStatusActions.resetUploadSuccess());
  }, [dispatch, goBack, uploadSuccess]);

  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);

  const policyNumber = route?.params?.policyDetailData?.policyNumber;

  useEffect(() => {
    if (policyNumber) {
      dispatch(
        applicationStatusActions.getWorksheetDetailRequest({policyNumber}),
      );
    }
  }, [dispatch, policyNumber]);

  const onPressSubmitButton = () => {
    if (isLoading) {
      return;
    }
    dispatch(
      applicationStatusActions.sentDocumentRequest({
        policyDetailData: route?.params?.policyDetailData,
        file: selectedDocument,
      }),
    );
  };

  return (
    <ApplicationStatusDetailsView
      isLoading={isLoading}
      onPressCancel={onPressCancel}
      submitDisabled={submitDisabled}
      onPressSubmitButton={onPressSubmitButton}
      policyDetailData={route.params.policyDetailData}
      isSuccessModalOpen={isSuccessModalOpen}
      setIsSuccessModalOpen={setIsSuccessModalOpen}
      data={worksheetDetail}
    />
  );
};

export default ApplicationStatusDetailsScreen;
