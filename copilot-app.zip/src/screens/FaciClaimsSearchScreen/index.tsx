import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import FaciClaimsSearchView from './FaciClaimsSearchView';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectClaims,
  selectClaimsNumber,
  selectClaimsPeriod,
  selectIsLoading,
  selectPolicyNumber,
  selectSelectedPolicyCustomerName,
} from '../../redux/slices/faciSlice/selectors';
import {Claim} from '../../redux/slices/faciSlice/types';

const FaciClaimsSearchScreen = () => {
  const dispatch = useDispatch();
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const isLoading = useSelector(selectIsLoading);
  const claimsPeriod = useSelector(selectClaimsPeriod);
  const claimsNumber = useSelector(selectClaimsNumber);
  const claims = useSelector(selectClaims);
  const policyNumber = useSelector(selectPolicyNumber);

  const [isSearchByClaimPeriod, setIsSearchByClaimPeriod] = useState(false);

  useEffect(() => {
    return () => {
      dispatch(faciActions.resetClaimsSearch());
    };
  }, [dispatch]);

  const onChangeClaimsPeriod = (text: string) => {
    dispatch(faciActions.setClaimsPeriod(text));
    setIsSearchByClaimPeriod(true);
  };

  const onChangeClaimsNumber = (text: string) => {
    dispatch(faciActions.setClaimsNumber(text));
    setIsSearchByClaimPeriod(false);
  };

  const onPressClearAll = () => {
    dispatch(faciActions.setClaimsPeriod(''));
    dispatch(faciActions.setClaimsNumber(''));
    dispatch(faciActions.setClaimsPeriod(''));
  };

  const searchClaims = () => {
    let visibleClaims: Claim[];

    if (!claims || claims.length === 0) {
      onPressClearAll();
      return alert('No record available');
    }

    if (isSearchByClaimPeriod) {
      visibleClaims = filterClaimsByDate();
    } else {
      visibleClaims = filterClaimsByClaimNUmber();
    }

    dispatch(faciActions.setVisibleClaims(visibleClaims));
    navigate('FaciClaimsList');
  };

  const isDateWithinRange = (
    date: Date,
    startDate: Date,
    endDate: Date,
  ): boolean => {
    return date >= startDate && date <= endDate;
  };

  const filterClaimsByDate = (): Claim[] => {
    const [month, day, year] = claimsPeriod.split('/');
    const inputDate = new Date(`${year}-${month}-${day}`);
    const visibleClaims = claims.filter(claim => {
      const [startDateStr, endDateStr] = claim.benefitPeriod.split(' ');
      const startDate = new Date(startDateStr);
      let endDate = startDate;
      if (endDateStr) {
        endDate = new Date(endDateStr);
      }
      return isDateWithinRange(inputDate, startDate, endDate);
    });
    return visibleClaims;
  };

  const filterClaimsByClaimNUmber = (): Claim[] => {
    return claims.filter(claim => claim.claimNumber === claimsNumber);
  };

  return (
    <FaciClaimsSearchView
      isLoading={isLoading}
      policyNumber={policyNumber}
      customerName={customerName}
      claimsPeriod={claimsPeriod}
      onChangeClaimsPeriod={onChangeClaimsPeriod}
      claimsNumber={claimsNumber}
      onChangeClaimsNumber={onChangeClaimsNumber}
      onPressClearAll={onPressClearAll}
      searchClaims={searchClaims}
    />
  );
};

export default FaciClaimsSearchScreen;
