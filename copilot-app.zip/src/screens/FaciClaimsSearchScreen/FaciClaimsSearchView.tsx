import React, {FC} from 'react';
import {ActivityIndicator, View} from 'react-native';
import {StyleSheet} from 'react-native';

import BackToPreviousScreen from '../../components/BackToPreviousScreen';
import Button from '../../components/Button';
import Header from '../../components/Header';
import DatePicker from '../../components/Picker/DatePicker';
import ScreenContainer from '../../components/ScreenContainer';
import BodyText from '../../components/Text/BodyText';
import HeaderText from '../../components/Text/HeaderText';
import TextInput from '../../components/TextInput';
import colors from '../../utils/colors';

interface Props {
  customerName: string;
  policyNumber: string;
  isLoading: boolean;
  claimsPeriod: string;
  onChangeClaimsPeriod: (text: string) => void;
  claimsNumber: string;
  onChangeClaimsNumber: (text: string) => void;
  onPressClearAll: () => void;
  searchClaims: () => void;
}

const FaciClaimsSearchView: FC<Props> = ({
  customerName,
  policyNumber,
  isLoading,
  claimsPeriod,
  onChangeClaimsPeriod,
  claimsNumber,
  onChangeClaimsNumber,
  onPressClearAll,
  searchClaims,
}) => {
  return (
    <ScreenContainer useHeader>
      {isLoading && (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={colors.blue100} />
        </View>
      )}
      <Header label={`FACI - ${customerName}`} />
      <BackToPreviousScreen screenName="Policy Details" />
      <HeaderText
        variant="h3"
        style={
          styles.headerText
        }>{`Claim Search in Policy ${policyNumber}`}</HeaderText>
      <View style={styles.searchContainerWrapper}>
        <View style={styles.searchContainer}>
          <DatePicker
            value={claimsPeriod}
            label="Date of Service"
            onChange={onChangeClaimsPeriod}
          />

          <View style={styles.orDevider}>
            <BodyText>{` OR `}</BodyText>
          </View>

          <>
            <TextInput
              label="Claim Number"
              value={claimsNumber}
              onChangeText={onChangeClaimsNumber}
              placeholder="Claim Number"
              headerVariant="h3"
              textInputStyle={styles.textInputStyle}
              keyboardType="default"
            />
          </>
        </View>
      </View>
      <View style={styles.buttonContainer}>
        <Button
          title="Clear All"
          style={styles.leftButton}
          variant="tertiary"
          onPress={onPressClearAll}
        />
        <Button
          title="Search"
          style={styles.rightButton}
          variant="primary"
          onPress={searchClaims}
        />
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  headerText: {
    color: colors.black100,
  },
  textInputStyle: {
    marginTop: 0,
    marginBottom: 5,
    height: 50,
    color: colors.black100,
  },
  calendarIcon: {
    position: 'absolute',
    top: 45,
    right: 15,
    color: colors.black100,
    fontWeight: 400,
    fontSize: 24,
  },
  buttonContainer: {
    width: '100%',
    marginTop: 20,
    height: 75,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingHorizontal: 9,
    marginLeft: -9,
  },
  leftButton: {
    backgroundColor: colors.white,
  },
  rightButton: {
    backgroundColor: colors.blue100,
    borderColor: colors.blue100,
    borderWidth: 2,
    marginLeft: 20,
  },
  searchContainer: {
    padding: 10,
    borderColor: colors.black300,
    backgroundColor: colors.white,
    borderWidth: 1,
  },
  searchContainerWrapper: {
    flex: 1,
  },
  orDevider: {
    marginBottom: 10,
    marginLeft: -5,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  headerBorder: {
    marginBottom: 12,
  },
});

export default FaciClaimsSearchView;
