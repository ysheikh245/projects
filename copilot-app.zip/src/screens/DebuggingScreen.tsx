import {useNavigation} from '@react-navigation/native';
import * as Application from 'expo-application';
import {makeRedirectUri} from 'expo-auth-session';
import Constants from 'expo-constants';
import * as Device from 'expo-device';
import moment from 'moment';
import React, {useEffect, useState} from 'react';
import {ScrollView, StyleSheet, Text} from 'react-native';
import {useSelector} from 'react-redux';

import AuthScreenContainer from '../components/AuthScreenContainer';
import Button from '../components/Button';
import {selectPMICUser} from '../redux/slices/authSlice/selectors';

const DebuggingScreen = () => {
  const {goBack} = useNavigation();
  const [deviceType, setDeviceType] = useState<Device.DeviceType>();

  const savedUser = useSelector(selectPMICUser);

  useEffect(() => {
    Device.getDeviceTypeAsync().then((devType: Device.DeviceType) => {
      setDeviceType(devType);
    });
  }, []);

  return (
    <AuthScreenContainer>
      <Button
        title="Go Back"
        variant="primary"
        textStyle={styles.buttonText}
        onPress={goBack}
      />
      <ScrollView>
        <Text>
          App:{'\n'}
          Now: {moment().format('MMMM Do YYYY, h:mm:ss a')}
          {'\n'}
          Branch: {Constants.expoConfig?.extra?.GIT_BRANCH}
          {'\n'}
          Build: {Constants.expoConfig?.extra?.BUILD_NUMBER}
          {'\n'}
          Hash: {Constants.expoConfig?.extra?.GIT_HASH}
          {'\n'}
          API: {Constants.expoConfig?.extra?.APP_API}
          {'\n'}
          Keycloak: {Constants.expoConfig?.extra?.KEYCLOAK_ENDPOINT}
          {'\n'}
          Keycloak Client: {Constants.expoConfig?.extra?.KEYCLOAK_CLIENT_ID}
          {'\n'}
          Keycloak Redirect: {makeRedirectUri({path: 'auth'})}
          {'\n'}
          Version: {Application.nativeApplicationVersion}
          {'\n'}
          Name: {Application.applicationName}
          {'\n'}
          ID: {Application.applicationId}
          {'\n'}
          {'\n'}
          Device:{'\n'}
          Device Name: {Device.deviceName}
          {'\n'}
          Brand: {Device.brand}
          {'\n'}
          Type: {deviceType}
          {'\n'}
          Version: {Device.osVersion}
          {'\n'}
          Memory: {Device.totalMemory}
          {'\n'}
          {'\n'}
          User:{'\n'}
          Username: {savedUser?.username}
          {'\n'}
          NPN: {savedUser?.npn}
          {'\n'}
        </Text>
      </ScrollView>
    </AuthScreenContainer>
  );
};

const styles = StyleSheet.create({
  buttonText: {
    color: '#00f',
  },
});

export default DebuggingScreen;
