import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React, {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import {authActions} from '../redux/slices/authSlice';
import {selectSavedPin} from '../redux/slices/authSlice/selectors';
import DebuggingScreen from '../screens/DebuggingScreen';
import EnterPinScreen from '../screens/EnterPinScreen';
import LoginScreen from '../screens/LoginScreen';
import SetPinScreen from '../screens/SetPinScreen';

export type AuthStackParamList = {
  Login: undefined;
  SetPin: undefined;
  EnterPin: undefined;
  Debugging: undefined;
};

const Stack = createNativeStackNavigator<AuthStackParamList>();

function AuthNavigation() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(authActions.authenticate(false));
  }, []);

  const savedPin = useSelector(selectSavedPin);

  let initialRouteName: keyof AuthStackParamList = savedPin
    ? 'EnterPin'
    : 'Login';

  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName={initialRouteName}
        screenOptions={{headerShown: false, gestureEnabled: false}}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="SetPin" component={SetPinScreen} />
        <Stack.Screen name="EnterPin" component={EnterPinScreen} />
        <Stack.Screen name="Debugging" component={DebuggingScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default AuthNavigation;
