import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';

import {MyCompensationPDF} from '../redux/slices/myCompensation/types';
import ApplicationStatusDetailsScreen from '../screens/ApplicationStatusDetailsScreen';
import ApplicationStatusScreen from '../screens/ApplicationStatusScreen';
import CustomerDocuments from '../screens/CustomerDocuments';
import DebuggingScreen from '../screens/DebuggingScreen';
import DisplayPDFScreen from '../screens/DisplayPDFScreen';
import DisplayPDFScreenUpdate from '../screens/DisplayPDFScreenUpdate';
import FaciClaimsDetailScreen from '../screens/FaciClaimsDetailScreen';
import FaciClaimsListScreen from '../screens/FaciClaimsListScreen';
import FaciClaimsSearchScreen from '../screens/FaciClaimsSearchScreen';
import FaciContactInfoScreen from '../screens/FaciContactInfoScreen';
import FaciSearchScreen from '../screens/FaciSearchScreen';
import HomeScreen from '../screens/HomeScreen';
import MyCompensationScreen from '../screens/MyCompensationScreen';
import PolicyDetailsScreen from '../screens/PolicyDetailsScreen';

export type AppStackParamList = {
  Home: undefined;
  ApplicationStatus: undefined;
  FaciSearch: undefined;
  ApplicationStatusDetails: {
    policyDetailData: {
      name: string;
      policyNumber: string;
      productName: string;
      productCategory: string;
    };
  };
  FaciContactInfo: undefined;
  PolicyDetails: {
    policyNumber: string;
  };
  CustomerDocuments: undefined;
  FaciClaimsSearch: undefined;
  FaciClaimsList: undefined;
  DisplayPDF: {
    uri: string;
  };
  DisplayPDFUpdate: {
    pdfData: MyCompensationPDF;
  };
  FaciClaimDetail: {
    claimNumber: string;
    claimStatus: string;
  };
  Debugging: undefined;
  MyCompensation: undefined;
};

const Stack = createNativeStackNavigator<AppStackParamList>();

function AppNavigation() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="FaciSearch" component={FaciSearchScreen} />
        <Stack.Screen
          name="ApplicationStatus"
          component={ApplicationStatusScreen}
        />
        <Stack.Screen
          name="ApplicationStatusDetails"
          component={ApplicationStatusDetailsScreen}
        />
        <Stack.Screen
          name="FaciContactInfo"
          component={FaciContactInfoScreen}
        />
        <Stack.Screen name="PolicyDetails" component={PolicyDetailsScreen} />
        <Stack.Screen name="CustomerDocuments" component={CustomerDocuments} />
        <Stack.Screen name="DisplayPDF" component={DisplayPDFScreen} />
        <Stack.Screen
          name="DisplayPDFUpdate"
          component={DisplayPDFScreenUpdate}
        />
        <Stack.Screen
          name="FaciClaimsSearch"
          component={FaciClaimsSearchScreen}
        />
        <Stack.Screen name="FaciClaimsList" component={FaciClaimsListScreen} />
        <Stack.Screen
          name="FaciClaimDetail"
          component={FaciClaimsDetailScreen}
        />
        <Stack.Screen name="Debugging" component={DebuggingScreen} />
        <Stack.Screen name="MyCompensation" component={MyCompensationScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default AppNavigation;
