import {PayloadAction} from '@reduxjs/toolkit';
import {Alert} from 'react-native';
import {call, put, select, takeEvery} from 'redux-saga/effects';

import {authActions} from '../redux/slices/authSlice';
import {faciActions} from '../redux/slices/faciSlice';
import {
  selectDateOfBirth,
  selectFirstName,
  selectLastName,
  selectPolicySearchByPartyIDPolicy,
  selectSelectedPolicyDetail,
  selectStateName,
  selectZip,
} from '../redux/slices/faciSlice/selectors';
import {
  selectSearchPolicyNumber,
  selectSelectedDocuments,
} from '../redux/slices/faciSlice/selectors';
import {
  Policy,
  PolicyAlertsDetail,
  SearchByCustomerParams,
  SearchByPolicyParams,
} from '../redux/slices/faciSlice/types';
import {
  cleanPayees,
  getBeneficiaryDetailsService,
  getClaimDetailsService,
  getCustomerContactInfoService,
  getFaciAgentOfRecordsService,
  getFaciClaimsService,
  getFaciCustomerDetailService,
  getFaciCustomerDocumentsService,
  getFaciDependentsService,
  getFaciDiscountsService,
  getFaciRateChangesService,
  getFaciRolesService,
  getFaciSearchRequest,
  getPolicyAdditionalCoverageService,
  getPolicyAdditionalInfo,
  getPolicyAlertsService,
  getPolicyCoverageDetailRequestService,
  getPolicyDetailsService,
  submitClaimDetailsService,
} from '../services/faciService';

function* faciCustomerSearch(): any {
  try {
    const data = yield call(getPolicyAdditionalInfo, '');
    yield put(faciActions.faciCustomerSearchSuccess(data));
  } catch (error: any) {
    console.log(error);
    yield put(faciActions.faciCustomerSearchFailure(error.message));
  }
}

interface FaciItemsInterface {
  policyNumber: string;
}

interface PolicyNumberProps {
  policyNumber: string;
}
interface ClaimNumberProps {
  claimNumber: string;
  claimStatus: string;
}

function* getFaciRoles({payload}: PayloadAction<FaciItemsInterface>): any {
  try {
    const response = yield call(getFaciRolesService, payload.policyNumber);
    if (response.status === 200) {
      yield put(
        faciActions.getFaciRolesSuccess({data: response.data.response}),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getFaciRolesFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getFaciRolesFailure,
    );
  }
}

function* getFaciDiscounts({payload}: PayloadAction<FaciItemsInterface>): any {
  try {
    const response = yield call(getFaciDiscountsService, payload.policyNumber);
    if (response.status === 200) {
      yield put(
        faciActions.getFaciDiscountsSuccess({data: response.data.discounts}),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getFaciDiscountsFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getFaciDiscountsFailure,
    );
  }
}

function* getFaciDependents({payload}: PayloadAction<FaciItemsInterface>): any {
  try {
    const response = yield call(getFaciDependentsService, payload.policyNumber);

    if (response.status === 200) {
      yield put(
        faciActions.getFaciDependentsSuccess({
          data: response.data.response[0].dependents,
        }),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getFaciDependentsFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getFaciDependentsFailure,
    );
  }
}

function* getFaciRateChanges({
  payload,
}: PayloadAction<FaciItemsInterface>): any {
  try {
    const response = yield call(
      getFaciRateChangesService,
      payload.policyNumber,
    );
    if (response.status === 200) {
      yield put(
        faciActions.getFaciRateChangesSuccess({
          data: response.data.rateChanges,
        }),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getFaciRateChangesFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getFaciRateChangesFailure,
    );
  }
}

function* getFaciSearch(): any {
  try {
    const data = yield call(getFaciSearchRequest, '100244106');
    yield put(faciActions.getFaciSearchSuccess(data));
  } catch (error: any) {
    console.log(error);
    yield put(faciActions.getFaciSearchFailure(error.message));
  }
}

function* getFaciCustomerDetailRequest(): any {
  try {
    const firstName = yield select(selectFirstName);
    const lastName = yield select(selectLastName);
    const stateName = yield select(selectStateName);
    const zip = yield select(selectZip);
    const dob = yield select(selectDateOfBirth);

    const params: SearchByCustomerParams = {
      firstName: firstName,
      lastName: lastName,
      state: stateName,
      type: 'searchByCustomerDetails',
    };

    if (zip) {
      params.zip = zip;
    }

    if (dob) {
      params.dateOfBirth = dob;
    }

    const apiResponse = yield call(getFaciCustomerDetailService, params);

    if (
      apiResponse.status === 200 &&
      apiResponse.data[0].policyNumber.length > 3
    ) {
      yield put(faciActions.getFaciSearchSuccess(apiResponse.data));
      yield put(faciActions.showPolicySearchResult());
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getFaciSearchFailure,
      );
    }
  } catch (error: any) {
    console.log(error);
    yield handleFaciAPIError(
      false,
      error,
      'API Error',
      faciActions.getFaciSearchFailure,
    );
  }
}

function* handleFaciAPIError(
  isAPISuccess: boolean,
  apiResponse: any,
  error: any,
  failureAction: any,
) {
  let errorMessage = 'Unknown Error Occurred';

  let badToken = false;

  // Handles try block error
  if (isAPISuccess && apiResponse.status && apiResponse.status) {
    switch (apiResponse.status) {
      case 204:
        errorMessage = `${apiResponse.status} Your Search Didn't Return Any Results`;
        break;
      case 400:
        errorMessage = `${apiResponse.status} Bad Request was made`;
        break;
      case 401:
        errorMessage = `${apiResponse.status} Your session seems to have expired`;
        badToken = true;
        break;
      case 403:
        errorMessage = `${apiResponse.status} Unauthorized access to data not allowed`;
        break;
      case 500:
        errorMessage = `${apiResponse.status} Unknown Error Occurred`;
        break;
      default:
        break;
    }
  }

  // Handles catch block error
  if (apiResponse && apiResponse.response && apiResponse.response.status) {
    switch (apiResponse.response.status) {
      case 400:
        errorMessage = `${apiResponse.response.status} Bad Request was made`;
        break;
      case 401:
        errorMessage = `${apiResponse.response.status} Your session seems to have expired`;
        badToken = true;
        break;
      case 403:
        errorMessage = `${apiResponse.response.status} Unauthorized access to data not allowed`;
        break;
      case 500:
        errorMessage = `${apiResponse.response.status} Unknown Error Occurred`;
        break;
      default:
        break;
    }
  }

  Alert.alert(error, errorMessage);

  if (badToken) {
    yield put(authActions.logout());
  }

  yield put(failureAction(errorMessage));
}

// TODO: refactor this to use the handleFaciAPIError function
function* getCustomerContactInfo(): any {
  try {
    const params: Policy = yield select(selectSelectedPolicyDetail);
    const apiResponse = yield call(getCustomerContactInfoService, params);
    if (apiResponse.status === 200) {
      yield put(faciActions.getFaciCustomerDetailSuccess(apiResponse.data));
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getFaciCustomerDetailFailure,
      );
      yield put(faciActions.goToPreviousScreen(true));
    }
  } catch (err: any) {
    console.log(err);
    yield handleFaciAPIError(
      false,
      err,
      'API Error',
      faciActions.getFaciCustomerDetailFailure,
    );
    yield put(faciActions.goToPreviousScreen(true));
  }
}

function* getFaciCustomerByPolicyNumberRequest(): any {
  try {
    const policyNumber = yield select(selectSearchPolicyNumber);

    const params: SearchByPolicyParams = {
      policyNumber: policyNumber,
      type: 'searchByPolicy',
    };

    const apiResponse = yield call(getFaciCustomerDetailService, params);

    if (
      apiResponse.status === 200 &&
      apiResponse.data[0].policyNumber.length > 3 // Check for N/A response
    ) {
      yield put(faciActions.getFaciSearchSuccess(apiResponse.data));
      yield put(faciActions.showPolicySearchResult());
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getFaciSearchFailure,
      );
    }
  } catch (error: any) {
    console.warn('error', error);
    yield handleFaciAPIError(
      false,
      error,
      'API Error',
      faciActions.getFaciSearchFailure,
    );
  }
}

function* getPolicyAlertsRequest(): any {
  try {
    const policy = yield select(selectPolicySearchByPartyIDPolicy);
    const apiResponse = yield call(getPolicyAlertsService, policy.policyNumber);
    if (apiResponse.status === 200) {
      const policyAlertsResponse: PolicyAlertsDetail = apiResponse.data;
      yield put(faciActions.getPolicyAlertsSuccess(policyAlertsResponse));
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getPolicyAlertsFailure,
      );
    }
  } catch (error: Error | any) {
    console.warn('error', error);
    yield handleFaciAPIError(
      false,
      error,
      'API Error',
      faciActions.getPolicyAlertsFailure,
    );
  }
}

function* getPolicyDetailsRequest({
  payload,
}: PayloadAction<PolicyNumberProps>): any {
  try {
    // const policy = yield select(selectPolicySearchByPartyIDPolicy);
    const apiResponse = yield call(
      getPolicyDetailsService,
      payload.policyNumber,
    );
    if (apiResponse.status === 200) {
      yield put(faciActions.getPolicyDetailSuccess(apiResponse.data));
    } else {
      console.warn('status failed');
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getPolicyDetailFailure,
      );
      yield put(faciActions.goToPreviousScreen(true));
    }
  } catch (error: Error | any) {
    console.warn('error', error);
    yield handleFaciAPIError(
      false,
      error,
      'API Error',
      faciActions.getPolicyDetailFailure,
    );
    yield put(faciActions.goToPreviousScreen(true));
  }
}

function* getAdditionalPolicyInfoRequest({
  payload,
}: PayloadAction<PolicyNumberProps>): any {
  try {
    const response = yield call(getPolicyAdditionalInfo, payload.policyNumber);
    if (response.status === 200) {
      yield put(
        faciActions.getAdditionalPolicyInfoSuccess({data: response.data}),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getAdditionalPolicyInfoFailure,
      );
      yield put(faciActions.goToPreviousScreen(true));
    }
  } catch (error: Error | any) {
    console.warn('error', error);
    yield handleFaciAPIError(
      false,
      error,
      'API Error',
      faciActions.getAdditionalPolicyInfoFailure,
    );
    yield put(faciActions.goToPreviousScreen(true));
  }
}

function* getPolicyCoverageDetailRequest(): any {
  try {
    const policy = yield select(selectPolicySearchByPartyIDPolicy);
    const apiResponse = yield call(
      getPolicyCoverageDetailRequestService,
      policy.policyNumber,
    );

    if (apiResponse.status === 200) {
      yield put(
        faciActions.getPolicyCoverageDetailsSuccess(
          apiResponse.data.coverageDetails,
        ),
      );
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getPolicyCoverageDetailsFailure,
      );
    }
  } catch (error: any) {
    console.log(error);
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getPolicyCoverageDetailsFailure,
    );
  }
}

function* getPolicyAdditionalCoverageRequest(): any {
  try {
    const policy = yield select(selectPolicySearchByPartyIDPolicy);
    const apiResponse = yield call(
      getPolicyAdditionalCoverageService,
      policy.policyNumber,
    );

    if (apiResponse.status === 200) {
      yield put(
        faciActions.getPolicyAdditionalCoverageSuccess(
          apiResponse.data.additionalCoverages,
        ),
      );
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getPolicyAdditionalCoverageFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getPolicyAdditionalCoverageFailure,
    );
  }
}

function* getAgentRecords({payload}: PayloadAction<FaciItemsInterface>): any {
  try {
    const apiResponse = yield call(
      getFaciAgentOfRecordsService,
      payload.policyNumber,
    );
    if (apiResponse.status === 200) {
      yield put(faciActions.getAgentRecordSuccess(apiResponse.data?.response));
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getAgentOfRecordsFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getAgentOfRecordsFailure,
    );
  }
}

function* getCustomerDocuments({
  payload,
}: PayloadAction<FaciItemsInterface>): any {
  try {
    const response = yield call(
      getFaciCustomerDocumentsService,
      payload.policyNumber,
    );
    if (response.status === 200) {
      yield put(
        faciActions.getFaciCustomerDocumentsSuccess({
          data: response.data.response.documents,
        }),
      );
    } else {
      yield handleFaciAPIError(
        true,
        response,
        'API Error',
        faciActions.getFaciCustomerDocumentsFailure,
      );
    }
  } catch (error: any) {
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getFaciCustomerDocumentsFailure,
    );
  }
}

function* getBeneficiaryDetails({
  payload,
}: PayloadAction<FaciItemsInterface>): any {
  try {
    const apiResponse = yield call(
      getBeneficiaryDetailsService,
      payload.policyNumber,
    );
    if (apiResponse.status === 200) {
      yield put(
        faciActions.getBeneficiaryDetailsSuccess(
          apiResponse.data.beneficiaryDetails,
        ),
      );
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getBeneficiaryDetailsFailure,
      );
    }
  } catch (error: any) {
    console.log(error);
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getBeneficiaryDetailsFailure,
    );
  }
}
function* getClaimDetails({payload}: PayloadAction<ClaimNumberProps>): any {
  try {
    const apiResponse = yield call(
      getClaimDetailsService,
      payload.claimNumber,
      payload.claimStatus,
    );
    if (apiResponse.status === 200) {
      if (payload.claimStatus.toLowerCase() === 'closed') {
        const payees = cleanPayees(apiResponse.data.claim.payees);
        apiResponse.data.claim.payees = payees;
      }
      yield put(faciActions.getClaimDetailsSuccess(apiResponse.data.claim));
    } else {
      yield handleFaciAPIError(
        true,
        apiResponse,
        'API Error',
        faciActions.getClaimDetailsFailure,
      );
    }
  } catch (error: any) {
    console.log(error);
    yield handleFaciAPIError(
      true,
      error,
      'API Error',
      faciActions.getClaimDetailsFailure,
    );
  }
}

function* getFaciClaimsRequest({
  payload,
}: PayloadAction<PolicyNumberProps>): any {
  try {
    const policyNumber = payload.policyNumber;
    const response = yield call(getFaciClaimsService, policyNumber);
    yield put(faciActions.getFaciClaimsSuccess(response.data.claims));
  } catch (error: any) {
    console.log(error);
    yield put(faciActions.getFaciClaimsFailure(error.message));
  }
}

function* submitClaimDetails(): any {
  try {
    const policy = yield select(selectPolicySearchByPartyIDPolicy);
    const document = yield select(selectSelectedDocuments);
    const apiResponse = yield call(
      submitClaimDetailsService,
      policy.policyNumber,
      document,
    );
    const failedResponse = apiResponse.filter(
      (response: any) => response && response.status !== 200,
    );

    if (failedResponse.length === 0) {
      yield put(faciActions.submitClaimDetailsSuccess());
      Alert.alert('Success', 'Your Claims Uploaded Successfully', [
        {text: 'OK', onPress: () => console.log('OK Pressed')},
      ]);
    } else {
      Alert.alert('Failed', 'Your Claims Failed To Uploaded, Try Again', [
        {text: 'OK', onPress: () => console.log('OK Pressed')},
      ]);
      yield put(faciActions.submitClaimDetailsFailure());
    }
  } catch (error: any) {
    console.log(error);
    Alert.alert('Failed', 'Your Claims Failed To Uploaded, Try Again', [
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);
    yield put(faciActions.submitClaimDetailsFailure());
  }
}

function* faciSaga() {
  yield takeEvery(
    faciActions.faciCustomerSearchRequest.type,
    faciCustomerSearch,
  );
  yield takeEvery(faciActions.getFaciRolesRequest.type, getFaciRoles);
  yield takeEvery(faciActions.getFaciDiscountsRequest.type, getFaciDiscounts);
  yield takeEvery(faciActions.getFaciDependentsRequest.type, getFaciDependents);
  yield takeEvery(
    faciActions.getFaciCustomerDetailRequest.type,
    getFaciCustomerDetailRequest,
  );
  yield takeEvery(faciActions.getFaciSearchRequest.type, getFaciSearch);
  yield takeEvery(
    faciActions.getCustomerContactInfo.type,
    getCustomerContactInfo,
  );
  yield takeEvery(
    faciActions.getFaciCustomerByPolicyNumberRequest.type,
    getFaciCustomerByPolicyNumberRequest,
  );
  yield takeEvery(
    faciActions.getPolicyAlertsRequest.type,
    getPolicyAlertsRequest,
  );
  yield takeEvery(
    faciActions.getPolicyAdditionalCoverageRequest.type,
    getPolicyAdditionalCoverageRequest,
  );
  yield takeEvery(
    faciActions.getPolicyCoverageDetailsRequest.type,
    getPolicyCoverageDetailRequest,
  );
  yield takeEvery(
    faciActions.getPolicyDetailRequest.type,
    getPolicyDetailsRequest,
  );
  yield takeEvery(
    faciActions.getAdditionalPolicyInfoRequest.type,
    getAdditionalPolicyInfoRequest,
  );
  yield takeEvery(faciActions.getAgentRecordsRequest.type, getAgentRecords);
  yield takeEvery(
    faciActions.getFaciRateChangesRequest.type,
    getFaciRateChanges,
  );
  yield takeEvery(
    faciActions.getFaciCustomerDocumentsRequest.type,
    getCustomerDocuments,
  );
  yield takeEvery(
    faciActions.getBeneficiaryDetailsRequest.type,
    getBeneficiaryDetails,
  );
  yield takeEvery(faciActions.getFaciClaimsRequest.type, getFaciClaimsRequest);
  yield takeEvery(faciActions.getClaimDetailsRequest.type, getClaimDetails);
  yield takeEvery(
    faciActions.submitClaimDetailsRequest.type,
    submitClaimDetails,
  );
}

export default faciSaga;
