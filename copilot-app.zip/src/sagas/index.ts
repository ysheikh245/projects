import {all, fork} from 'redux-saga/effects';

import applicationStatusSaga from './applicationStatusSaga';
import faciSaga from './faciSaga';
import menuSaga from './menuSaga';
import myCompensationSaga from './myCompensationSaga';

export default function* main() {
  yield all([
    fork(applicationStatusSaga),
    fork(faciSaga),
    fork(menuSaga),
    fork(myCompensationSaga),
  ]);
}
