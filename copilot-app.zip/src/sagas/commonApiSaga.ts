// src/commonApiSaga.ts
import {PayloadAction} from '@reduxjs/toolkit';
import {call, put} from 'redux-saga/effects';

import axiosInstance from '../services/axiosInstance';

export interface ApiAction {
  type: string;
  payload: {
    endpoint: string;
    onSuccess: (data: unknown) => PayloadAction<unknown>;
    onFailure: (error: Error) => PayloadAction<Error>;
  };
}

export function* commonApiSaga(action: ApiAction) {
  const {endpoint, onSuccess, onFailure} = action.payload;
  try {
    const response = yield call(axiosInstance.get, endpoint);
    yield put(onSuccess(response.data));
  } catch (error) {
    yield put(onFailure(error));
  }
}
