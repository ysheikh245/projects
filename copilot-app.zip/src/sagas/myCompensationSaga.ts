import {PayloadAction} from '@reduxjs/toolkit';
import {call, put, select, takeEvery} from 'redux-saga/effects';

import {selectNpn} from '../redux/slices/authSlice/selectors';
import {myCompensationActions} from '../redux/slices/myCompensation';
import {MyCompensationPDF} from '../redux/slices/myCompensation/types';
import {
  getMyCompensationPDFService,
  getStatementsService,
} from '../services/myCompensationService';
import {verificationAlert} from '../utils/alert';

function* getStatements({
  payload,
}: PayloadAction<{beginDate: string; endDate: string}>): any {
  try {
    const npn = yield select(selectNpn);
    const response = yield call(() =>
      getStatementsService(npn, payload.beginDate, payload.endDate),
    );

    if (response.status === 200) {
      yield put(
        myCompensationActions.getStatementsSuccess({
          data: response.data.agentCompensationStatements,
        }),
      );
    }

    if (response.status === 204) {
      yield put(myCompensationActions.getStatementsSuccess({data: []}));
    }
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(myCompensationActions.getStatementsFailure());
  }
}

function* getMyCompensationPDF({
  payload,
}: PayloadAction<{data: MyCompensationPDF}>): any {
  try {
    const response = yield call(() =>
      getMyCompensationPDFService(payload.data),
    );

    yield put(
      myCompensationActions.getMyCompensationPDFSuccess({
        data: response,
      }),
    );
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(myCompensationActions.getMyCompensationPDFFailure());
  }
}

function* myCompensationSaga() {
  yield takeEvery(
    myCompensationActions.getStatementsRequest.type,
    getStatements,
  );
  yield takeEvery(
    myCompensationActions.getMyCompensationPDFRequest.type,
    getMyCompensationPDF,
  );
}

export default myCompensationSaga;
