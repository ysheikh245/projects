import {PayloadAction} from '@reduxjs/toolkit';
import _ from 'lodash';
import moment from 'moment-timezone';
import {call, put, select, takeEvery} from 'redux-saga/effects';

import {PolicyDetailData} from '../components/Card/ApplicationStatusCard';
import {asFilterActions} from '../redux/slices/applicationStatusFilterSlice';
import {
  selectDeclineWithdrawn,
  selectFirstName,
  selectIssued,
  selectLastName,
  selectNotTaken,
  selectPending,
  selectPolicyNumber,
  selectSearchFromDate,
  selectSearchToDate,
  selectSortByOldest,
} from '../redux/slices/applicationStatusFilterSlice/selectors';
import {applicationStatusActions} from '../redux/slices/applicationStatusSlice';
import {
  selectApplicationStatusData,
  selectPageNumber,
  selectResetApplicationStatus,
  selectSelectedDocuments,
} from '../redux/slices/applicationStatusSlice/selectors';
import {
  ApplicationStatus,
  Case360Document,
  Document,
  ThankYou,
} from '../redux/slices/applicationStatusSlice/types';
import {selectNpn} from '../redux/slices/authSlice/selectors';
import {updateThankYouButton} from '../screens/ApplicationStatusScreen/helpers';
import {
  getCacheResultsService,
  getWorksheetDetailService,
  postApplicationStatusService,
  sendDocumentService,
  sendThankYouEmailService,
} from '../services/applicationStatusService';
import {verificationAlert} from '../utils/alert';

function* getApplicationStatus({
  payload,
}: PayloadAction<{pageNumber: number}>): any {
  try {
    const npn = yield select(selectNpn);
    const policyNumber = yield select(selectPolicyNumber);
    const sortByOldest = yield select(selectSortByOldest);
    let searchFromDate = yield select(selectSearchFromDate);
    let searchToDate = yield select(selectSearchToDate);
    const pending = yield select(selectPending);
    const issued = yield select(selectIssued);
    const declineWithdrawn = yield select(selectDeclineWithdrawn);
    const notTaken = yield select(selectNotTaken);
    let firstName = yield select(selectFirstName);
    let lastName = yield select(selectLastName);
    const applicationStatusData = yield select(selectApplicationStatusData);
    const resetApplicationStatus = yield select(selectResetApplicationStatus);
    const pageNumber = yield select(selectPageNumber);

    if (searchFromDate === null && searchToDate === null) {
      searchFromDate = moment().subtract(0, 'days').format('YYYY-MM-DD');
      searchToDate = moment().subtract(7, 'days').format('YYYY-MM-DD');
    }

    firstName = firstName === null ? '' : firstName;
    lastName = lastName === null ? '' : lastName;

    const status = yield getStatusFilters(
      pending,
      issued,
      declineWithdrawn,
      notTaken,
    );
    const customerName = `${firstName} ${lastName}`.trim();

    const response = yield call(() =>
      postApplicationStatusService({
        agentInformation: {
          npn,
        },
        filterCriteria: {
          days: 7,
          status,
          policyNumber,
          customerName,
          sortOrder: sortByOldest ? 'ASC' : 'DESC',
          pageNumber: resetApplicationStatus ? 0 : pageNumber,
          pageSize: 10,
          searchFromDate: searchToDate,
          searchToDate: searchFromDate,
        },
      }),
    );

    let arr: ApplicationStatus[] = response.data.policy
      ? [...applicationStatusData, ...response.data.policy]
      : [...applicationStatusData];
    let mergedArr = [...new Set(arr)];

    if (response.status === 200) {
      yield put(
        applicationStatusActions.applicationStatusSuccess({data: mergedArr}),
      );
      yield put(
        applicationStatusActions.setPageNumber({
          pageNumber: pageNumber + 1,
        }),
      );

      yield put(applicationStatusActions.applicationStatusReset(false));
    }

    if (response.status === 204) {
      yield put(
        applicationStatusActions.setPageNumber({
          pageNumber: pageNumber,
        }),
      );
    }
  } catch (error: Error | any) {
    console.warn(error);
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(applicationStatusActions.applicationStatusFailure(error.message));
  }
}

function* getApplicationFreshStatus({
  payload,
}: PayloadAction<{pageNumber: number}>): any {
  try {
    const npn = yield select(selectNpn);
    const policyNumber = yield select(selectPolicyNumber);
    const sortByOldest = yield select(selectSortByOldest);
    const pending = yield select(selectPending);
    const issued = yield select(selectIssued);
    const declineWithdrawn = yield select(selectDeclineWithdrawn);
    const notTaken = yield select(selectNotTaken);
    let firstName = yield select(selectFirstName);
    let lastName = yield select(selectLastName);
    const applicationStatusData = yield select(selectApplicationStatusData);
    const resetApplicationStatus = yield select(selectResetApplicationStatus);
    const pageNumber = yield select(selectPageNumber);

    firstName = firstName === null ? '' : firstName;
    lastName = lastName === null ? '' : lastName;

    const status = yield getStatusFilters(
      pending,
      issued,
      declineWithdrawn,
      notTaken,
    );
    const customerName = `${firstName} ${lastName}`.trim();

    const response = yield call(() =>
      postApplicationStatusService({
        agentInformation: {
          npn,
        },
        filterCriteria: {
          days: 7,
          status,
          policyNumber,
          customerName,
          sortOrder: sortByOldest ? 'ASC' : 'DESC',
          pageNumber: resetApplicationStatus ? 0 : pageNumber,
          pageSize: 10,
          searchFromDate: null,
          searchToDate: null,
        },
      }),
    );

    let arr: ApplicationStatus[] = response.data.policy
      ? [...applicationStatusData, ...response.data.policy]
      : [...applicationStatusData];
    let mergedArr = [...new Set(arr)];

    if (response.status === 200) {
      yield put(
        applicationStatusActions.applicationStatusSuccess({data: mergedArr}),
      );
      yield put(
        applicationStatusActions.setPageNumber({
          pageNumber: pageNumber + 1,
        }),
      );

      yield put(applicationStatusActions.applicationStatusReset(false));
    }

    if (response.status === 204) {
      yield put(
        applicationStatusActions.setPageNumber({
          pageNumber: pageNumber,
        }),
      );
    }
  } catch (error: Error | any) {
    console.warn(error);
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(applicationStatusActions.applicationStatusFailure(error.message));
  }
}

function* filterApplicationStatus(): any {
  try {
    const npn = yield select(selectNpn);
    let policyNumber = yield select(selectPolicyNumber);
    if (policyNumber === '') {
      policyNumber = null;
    }
    const sortByOldest = yield select(selectSortByOldest);
    const searchFromDate = yield select(selectSearchFromDate);
    const searchToDate = yield select(selectSearchToDate);
    const pending = yield select(selectPending);
    const issued = yield select(selectIssued);
    const declineWithdrawn = yield select(selectDeclineWithdrawn);
    const notTaken = yield select(selectNotTaken);
    let firstName = yield select(selectFirstName);
    let lastName = yield select(selectLastName);

    firstName = firstName === null ? '' : firstName;
    lastName = lastName === null ? '' : lastName;

    const status = yield getStatusFilters(
      pending,
      issued,
      declineWithdrawn,
      notTaken,
    );
    const customerName = `${firstName} ${lastName}`.trim();

    const response = yield call(() =>
      postApplicationStatusService({
        agentInformation: {
          npn,
        },
        filterCriteria: {
          days: 7,
          status,
          policyNumber,
          customerName,
          sortOrder: sortByOldest ? 'ASC' : 'DESC',
          pageNumber: 0,
          pageSize: 10,
          searchFromDate: searchToDate,
          searchToDate: searchFromDate,
        },
      }),
    );

    if (response.status === 200) {
      asFilterActions.isFilterModalOpen(false);
      yield put(asFilterActions.filterApplicationStatusSuccess());
      yield put(applicationStatusActions.setPageNumber({pageNumber: 1}));
      yield put(applicationStatusActions.applicationStatusReset(false));
      yield put(
        applicationStatusActions.applicationStatusSuccess({
          data: response.data.policy,
        }),
      );
      yield put(asFilterActions.isFilterModalOpen(false));
    }

    if (response.status === 204) {
      yield put(applicationStatusActions.applicationStatusSuccess({data: []}));
      yield put(asFilterActions.filterApplicationStatusSuccess());
      yield put(asFilterActions.isFilterModalOpen(false));
    }
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(asFilterActions.filterApplicationStatusFailure(error.message));
    yield put(asFilterActions.isFilterModalOpen(false));
  }
}

interface ThankYouParams {
  data: ThankYou;
  pageNumber: number;
}

function* sendThankYou({payload}: PayloadAction<ThankYouParams>): any {
  try {
    const response = yield call(() =>
      sendThankYouEmailService({data: payload.data}),
    );
    const applicationStatusData = yield select(selectApplicationStatusData);
    const applicationStatuses = _.cloneDeep(applicationStatusData);

    if (response.status === 200) {
      yield put(applicationStatusActions.sendThankYouSuccess());
      yield put(
        applicationStatusActions.applicationStatusSuccess({
          data: updateThankYouButton(
            payload.data.policyNumber,
            applicationStatuses,
          ),
        }),
      );
      yield verificationAlert(
        'Success',
        'Thank you message was successfully sent.',
      );
    }
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(
      applicationStatusActions.sendThankYouFailure({message: error.message}),
    );
  }
}

/**
 * HELPER FUNCTIONS
 */
const getStatusFilters = (
  pending: boolean,
  issued: boolean,
  declineWithdrawn: boolean,
  notTaken: boolean,
) => {
  let statusFilters: string[] = [];

  if (pending) {
    statusFilters.push('PENDING');
  }

  if (issued) {
    statusFilters.push('ISSUED');
  }

  if (declineWithdrawn) {
    statusFilters.push('DECLINE_WITHDRAWN');
  }

  if (notTaken) {
    statusFilters.push('NOT_TAKEN');
  }

  statusFilters.push('EXCLUDE');

  return statusFilters;
};

function* getWorksheetDetail({
  payload,
}: PayloadAction<{policyNumber: string}>): any {
  try {
    const response = yield call(() =>
      getWorksheetDetailService(payload.policyNumber),
    );

    let data: Case360Document[] = response.data.case360Documents;

    data.forEach(val => {
      val.document = '';
    });

    if (response.status === 200) {
      yield put(
        applicationStatusActions.getWorksheetDetailSuccess({data: data}),
      );
    }

    if (response.status === 204) {
      yield put(applicationStatusActions.getWorksheetDetailSuccess({data: []}));
    }
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(
      applicationStatusActions.getWorksheetDetailFailure({data: error.message}),
    );
  }
}

function* sendDocument({
  payload,
}: PayloadAction<{policyDetailData: PolicyDetailData; file: Document}>): any {
  try {
    const applicationStatusDocuments = yield select(selectSelectedDocuments);
    const apiResponse = yield call(() =>
      sendDocumentService(applicationStatusDocuments, payload.policyDetailData),
    );
    const failedResponse = apiResponse.filter(
      (response: any) => response && response.status !== 200,
    );

    if (failedResponse.length === 0) {
      yield put(applicationStatusActions.sentDocumentSuccess());
    } else {
      yield put(
        applicationStatusActions.sentDocumentFailure({data: apiResponse}),
      );
      yield verificationAlert(`Failure in uploading`, apiResponse);
    }
  } catch (error: Error | any) {
    yield put(
      applicationStatusActions.sentDocumentFailure({data: error.message}),
    );
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
  }
}

function* getCacheResults({}: PayloadAction): any {
  const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

  try {
    let retryCount = 0;
    const maxDelay = 16000;
    let delayTime = 1000;
    const totalDuration = 180000; // retry at least for 3 mins
    const maxRetries = Math.ceil(totalDuration / maxDelay);

    while (retryCount < maxRetries) {
      const response = yield call(() => getCacheResultsService());

      if (response.data.backgroundPolicySearchProcess.searchCompleted) {
        yield put(asFilterActions.cacheResultsSuccess());
        yield put(asFilterActions.filterApplicationStatusRequest());
        return;
      }

      yield call(delay, delayTime);
      delayTime = Math.min(delayTime * 2, maxDelay); // increase delay exponentially till it hits 16 seconds ceiling
      retryCount++;
    }
  } catch (error: Error | any) {
    yield verificationAlert(`Failure ${error.response.status}`, error.message);
    yield put(asFilterActions.cacheResultsFailure());
  }
}

function* applicationStatusSaga() {
  yield takeEvery(
    applicationStatusActions.applicationStatusRequest.type,
    getApplicationStatus,
  );
  yield takeEvery(
    applicationStatusActions.applicationStatusFreshRequest.type,
    getApplicationFreshStatus,
  );
  yield takeEvery(
    applicationStatusActions.sendThankYouRequest.type,
    sendThankYou,
  );
  yield takeEvery(
    applicationStatusActions.getWorksheetDetailRequest.type,
    getWorksheetDetail,
  );
  yield takeEvery(
    applicationStatusActions.sentDocumentRequest.type,
    sendDocument,
  );
  yield takeEvery(
    asFilterActions.filterApplicationStatusRequest.type,
    filterApplicationStatus,
  );
  yield takeEvery(asFilterActions.cacheResultsRequest.type, getCacheResults);
}

export default applicationStatusSaga;
