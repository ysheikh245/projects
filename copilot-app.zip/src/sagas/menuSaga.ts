import {call, put, takeEvery} from 'redux-saga/effects';

import {menuActions} from '../redux/slices/menuSlice';
import appMenuItems from '../redux/slices/menuSlice/mockdata';

function* getMenuDetails() {
  try {
    // TODO functionality will be added when endpoint is complete
    const {data} = yield call(() => 'GET_MENU_DETAILS');
    yield put(menuActions.getMenuItemsSuccess(appMenuItems));
  } catch (e) {
    yield put(menuActions.getMenuItemsFailure(e.message));
  }
}

function* menuSaga() {
  yield takeEvery(menuActions.getMenuItemsRequest.type, getMenuDetails);
}

export default menuSaga;
