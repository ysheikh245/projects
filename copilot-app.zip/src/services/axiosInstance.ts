import axios from 'axios';
import {refreshAsync} from 'expo-auth-session';
import Constants from 'expo-constants';
import EncryptedStorage from 'react-native-encrypted-storage';

// Endpoint
const discovery = {
  authorizationEndpoint: `${
    Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT
  }/auth`,
  tokenEndpoint: `${Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT}/token`,
};

const doRefreshToken = async () => {
  const refreshToken = await EncryptedStorage.getItem('refreshToken');

  return refreshAsync(
    {
      clientId: Constants.expoConfig!.extra!.KEYCLOAK_CLIENT_ID,
      refreshToken: refreshToken!,
    },
    discovery,
  )
    .then(async response => {
      if (response.accessToken) {
        await EncryptedStorage.setItem('accessToken', response.accessToken);
        await EncryptedStorage.setItem('refreshToken', response.refreshToken!);
        console.log('expired token refreshed');
        Promise.resolve(response.accessToken);
      }
    })
    .catch(error => {
      if (
        [
          'invalid_grant',
          'unauthorized_client',
          'access_denied',
          'invalid_client',
        ].includes(error.code)
      ) {
        console.error('REFRESH ERROR - Log out', error);
      }
    });
};

const instance = axios.create({
  baseURL: Constants.expoConfig!.extra!.APP_API,
});

instance.interceptors.request.use(
  async config => {
    const access_token = await EncryptedStorage.getItem('accessToken');
    config.headers.apikey = 'xPk22k9irftlkLwaRSuHv8FJWx44mjw5';
    config.headers.Authorization = `Bearer ${access_token}`;
    return config;
  },
  error => {
    return Promise.reject(error);
  },
);

// Response interceptor for API calls
instance.interceptors.response.use(
  response => {
    return response;
  },
  async function (error) {
    const originalRequest = error.config;
    if (error.response.status === 401 && !originalRequest._retry) {
      console.log('token expired auto-refreshing');
      originalRequest._retry = true;
      const access_token = await doRefreshToken();
      axios.defaults.headers.common.Authorization = 'Bearer ' + access_token;
      return instance(originalRequest);
    }
    return Promise.reject(error);
  },
);

export default instance;
