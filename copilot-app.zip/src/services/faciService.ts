import {AxiosRequestConfig} from 'axios';
import base64 from 'base64-js';
import RNFS from 'react-native-fs';

import axiosInstance from './axiosInstance';
import {Document} from '../redux/slices/applicationStatusSlice/types';
import {
  Policy,
  SearchByCustomerParams,
  SearchByPolicyParams,
} from '../redux/slices/faciSlice/types';

export const getPolicyAdditionalInfo = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/additional-info/${policyNumber}`);
};

export const getFaciRolesService = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/policy-detail/${policyNumber}/roles`);
};

export const getFaciDiscountsService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/discounts`,
  );
};

export const getFaciDependentsService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/dependents`,
  );
};

export const getFaciSearchRequest = async (policyNumber: string) => {
  const response = await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}`,
  );
  return response.data;
};

export const getFaciCustomerDetailService = async (
  params: SearchByCustomerParams | SearchByPolicyParams,
) => {
  return await axiosInstance.post('/faci/customer-detail/', params);
};

export const getCustomerContactInfoService = async (params: Policy) => {
  return await axiosInstance.get(
    `/faci/customer-detail/${params.policyNumber}/party/${params.partyId}`,
  );
};

export const getPolicyAlertsService = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/customer-detail/alert/${policyNumber}`);
};

export const getFaciRateChangesService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/rate-changes`,
  );
};

export const getPolicyDetailsService = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/policy-detail/${policyNumber}`);
};

export const getPolicyAdditionalCoverageService = async (
  policyNumber: string,
) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/additional-coverages`,
  );
};

export const getPolicyCoverageDetailRequestService = async (
  policyNumber: string,
) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/coverage-details`,
  );
};

export const getFaciAgentOfRecordsService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/agent-roles`,
  );
};

export const getFaciCustomerDocumentsService = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/document-details/${policyNumber}`);
};

export const getBeneficiaryDetailsService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/faci/policy-detail/${policyNumber}/beneficiary-detail`,
  );
};

export const getPolicyDocumentDetailsService = async () => {
  return await axiosInstance.get(
    `/pmapi/agency-copilot/web/faci/document-details/H100047354`,
  );
};

export const getFaciClaimsService = async (policyNumber: string) => {
  return await axiosInstance.get(`/faci/claims/${policyNumber}`);
};

export const fetchPDFService = async (payload: any) => {
  const response = await axiosInstance.post(
    '/faci/documents/download',
    payload,
    {responseType: 'arraybuffer'},
  );

  const binaryString = base64.fromByteArray(new Uint8Array(response.data));
  const fileExt = payload.fileExtension === 'PDF' ? 'PDF' : 'pdf';
  const path = `${RNFS.DocumentDirectoryPath}/${payload.fileName}.${fileExt}`;
  await RNFS.writeFile(path, binaryString, 'base64');
  return {uri: 'file://' + path, path, cache: true, base64: binaryString};
};

export const getClaimDetailsService = async (
  claimNumber: string,
  claimStatus: string,
) => {
  return await axiosInstance.get(
    `/faci/claim-details/${claimNumber}/${claimStatus}`,
  );
};

export const submitClaimDetailsService = async (
  policyNumber: string,
  files: Document[],
) => {
  const promises = files.map(file => {
    const formData = new FormData();
    const obj = {
      policyNumber: policyNumber,
      source: 'FACI_CLAIMS',
    };

    formData.append('request', JSON.stringify(obj));
    formData.append('file', {
      uri: file.uri,
      name: file.name,
      type: file.type,
    });
    console.warn('faci formData', JSON.stringify(formData));
    const config: AxiosRequestConfig = {
      method: 'post',
      url: '/documents/upload',
      responseType: 'json',
      data: formData,
    };
    console.warn('config', config);
    return axiosInstance(config);
  });

  return Promise.all(promises);
};

export const cleanPayees = (payees: any[]): any[] => {
  const uniquePayees = new Map<string, any>();

  payees.forEach(payee => {
    const payeeKey = JSON.stringify(payee);
    if (!uniquePayees.has(payeeKey)) {
      uniquePayees.set(payeeKey, payee);
    }
  });

  return Array.from(uniquePayees.values());
};
