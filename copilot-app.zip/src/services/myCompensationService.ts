import base64 from 'base64-js';
import RNFS from 'react-native-fs';

import axiosInstance from './axiosInstance';
import {MyCompensationPDF} from '../redux/slices/myCompensation/types';

export const getStatementsService = async (
  npnId: string,
  beginDate: string,
  endDate: string,
) => {
  return await axiosInstance.get(`/compensations/list/${beginDate}/${endDate}`);
};

export const getMyCompensationPDFService = async (
  params: MyCompensationPDF,
) => {
  const response = await axiosInstance.post('/documents/download', params, {
    responseType: 'arraybuffer',
  });

  const binaryString = base64.fromByteArray(new Uint8Array(response.data));
  const fileExt = params.fileExtension === 'PDF' ? 'PDF' : 'pdf';
  const path = `${RNFS.DocumentDirectoryPath}/${params.fileName}.${fileExt}`;
  await RNFS.writeFile(path, binaryString, 'base64');

  return {uri: 'file://' + path, path, cache: true, base64: binaryString};
};
