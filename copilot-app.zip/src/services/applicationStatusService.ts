import {AxiosRequestConfig} from 'axios';
import FormData from 'form-data';

import axiosInstance from './axiosInstance';
import {PolicyDetailData} from '../components/Card/ApplicationStatusCard';
import {Document, ThankYou} from '../redux/slices/applicationStatusSlice/types';

interface PostApplicationStatusParams {
  token?: string;
  agentInformation: {
    npn: string;
  };
  filterCriteria: {
    days: number;
    status: string[];
    policyNumber: string | null;
    customerName: string | null;
    sortOrder: string;
    pageNumber: number;
    pageSize: number;
    searchFromDate: string | null;
    searchToDate: string | null;
  };
}

export const getCacheResultsService = async () => {
  return await axiosInstance.get(`/application-status/cache-results/`);
};

export const postApplicationStatusService = async (
  params: PostApplicationStatusParams,
) => {
  return await axiosInstance.post(`/application-status`, params);
};

export const sendThankYouEmailService = async (params: {data: ThankYou}) => {
  return await axiosInstance.post(`/send-email`, {
    recipientFirstName: params.data.recipientFirstName,
    recipientLastName: params.data.recipientLastName,
    recipientEmailAddress: params.data.recipientEmailAddress,
    recipientState: params.data.recipientState,
    npn: params.data.npn,
    productCode: params.data.productCode,
    messageCode: params.data.messageCode,
    partyId: params.data.partyId,
    policyNumber: params.data.policyNumber,
    notes: params.data.notes,
  });
};

export const getWorksheetDetailService = async (policyNumber: string) => {
  return await axiosInstance.get(
    `/application-status/worksheet-detail/${policyNumber}`,
  );
};

interface SendDocument {
  policyDetailData: PolicyDetailData;
  file: Document;
}

export const sendDocumentService = async (
  documents: any[],
  policyDetailData: any,
) => {
  const promises = documents.map(file => {
    const formData = new FormData();

    const obj = {
      policyNumber: policyDetailData.policyNumber,
      documentDescription: file.documentDescription,
      source: 'WORKSHEET_REQUIREMENT_POLICY',
    };

    formData.append('request', JSON.stringify(obj));
    formData.append('file', {
      uri: file.uri,
      name: file.name,
      type: file.type,
    });

    const config: AxiosRequestConfig = {
      method: 'post',
      url: '/documents/upload',
      responseType: 'json',
      data: formData,
    };
    return axiosInstance(config);
  });

  return Promise.all(promises);
};
