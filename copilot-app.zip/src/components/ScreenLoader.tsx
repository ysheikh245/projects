import React, {FC} from 'react';
import {ActivityIndicator, Modal, StyleSheet, View} from 'react-native';

import HeaderText from './Text/HeaderText';
import colors from '../utils/colors';

interface Props {
  isLoading: boolean;
  message?: string;
}
const ScreenLoader: FC<Props> = ({isLoading, message}) => {
  return (
    <Modal animationType="fade" transparent={true} visible={isLoading}>
      <View style={styles.modalContainer}>
        <HeaderText style={styles.headerText} variant="h2">
          {message}
        </HeaderText>
        <ActivityIndicator size="large" color={colors.blue100} />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    marginBottom: 10,
  },
});

export default ScreenLoader;
