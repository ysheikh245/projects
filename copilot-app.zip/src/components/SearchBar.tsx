import React, {FC} from 'react';
import {StyleSheet, TextInput, View} from 'react-native';

import PMICIcon from './PMICIcons';
import colors from '../utils/colors';

interface Props {
  onChangeText: (text: string) => void;
  value: string;
}
const SearchBar: FC<Props> = ({onChangeText, value}) => {
  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={value}
        placeholder="Search"
      />
      <PMICIcon
        name="icon-magnifying-glass"
        style={styles.iconButton}
        color={colors.black100}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.gray100,
    borderRadius: 0,
    paddingHorizontal: 10,
    marginBottom: 30,
  },
  input: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 0,
    fontSize: 16,
  },
  iconButton: {
    margin: 0,
    padding: 0,
    fontSize: 18,
  },
});

export default SearchBar;
