import React, {FC} from 'react';
import {StyleProp, StyleSheet, View, ViewStyle} from 'react-native';

import Divider from './Divider';
import HeaderText from './Text/HeaderText';
import colors from '../utils/colors';

interface Props {
  label: string;
  style?: StyleProp<ViewStyle>;
}

const Header: FC<Props> = ({label, style}) => {
  return (
    <View style={style}>
      <HeaderText style={styles.text} variant="h2">
        {label}
      </HeaderText>
      <Divider style={styles.divider} />
    </View>
  );
};

const styles = StyleSheet.create({
  divider: {
    marginBottom: 12,
  },
  text: {
    color: colors.black100,
  },
});

export default Header;
