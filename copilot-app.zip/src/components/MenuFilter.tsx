import React, {useState} from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {useSelector} from 'react-redux';

import Modal from './Modal';
import PMICIcon from './PMICIcons';
import {selectPMICUser} from '../redux/slices/authSlice/selectors';
import colors from '../utils/colors';

const MenuFilter: React.FC = () => {
  const [isFilterModalOpen, setIsOpenFilterModalOpen] = useState(false);
  const savedUser = useSelector(selectPMICUser);

  const onHamburgerPress = () => {
    setIsOpenFilterModalOpen(true);
  };

  return (
    <View>
      <View style={styles.menuBarContainer}>
        <Text style={styles.menuBarUser}>
          Welcome {savedUser?.firstName} {savedUser?.lastName}
        </Text>
        <TouchableOpacity onPress={onHamburgerPress}>
          <PMICIcon
            name="icon-hamburger-menu"
            style={styles.menuBarIcon}
            color={colors.green100}
          />
        </TouchableOpacity>
      </View>
      <Modal
        variant="menu"
        isModalOpen={isFilterModalOpen}
        setIsModalOpen={setIsOpenFilterModalOpen}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.transparent,
    zIndex: 1000,
  },
  menuBarContainer: {
    display: 'flex',
    flexDirection: 'row',
  },
  menuBarUser: {
    fontSize: 20,
    color: colors.black300,
    marginRight: 'auto',
    paddingTop: 7,
  },
  menuBarIcon: {
    position: 'relative',
    fontSize: 40,
    top: 0,
  },
});

export default MenuFilter;
