import moment from 'moment-timezone';
import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {Discount} from '../../redux/slices/faciSlice/types';
import {dateTimeFormat} from '../../utils/constants';

interface Props {
  item: Discount;
}

const DiscountsCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText label="Description" description={item.name} />
      <CardText label="Status" description={item.status} />
      {item?.discountPercent && (
        <CardText label="Percentage" description={item.discountPercent} />
      )}
      <CardText label="Amount" description={item.amount} />
      <CardText
        label="Term Date"
        description={moment(item.effectiveDate).format(dateTimeFormat)}
      />
    </CardContainer>
  );
};

export default DiscountsCard;
