import moment from 'moment-timezone';
import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {RateChange} from '../../redux/slices/faciSlice/types';
import {dateTimeFormat} from '../../utils/constants';

interface Props {
  item: RateChange;
}
const RateChangesCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText
        label="Received Date"
        description={moment(item.effectiveDate).format(dateTimeFormat)}
      />
      <CardText label="Premium" description={item.premium} />
      <CardText label="Mode" description={item.mode} />
      <CardText label="Area Rate" description={item.area} />
      <CardText label="State" description={item.state} />
      <CardText
        label="Letter Due"
        description={moment(item.letterDueDate).format(dateTimeFormat)}
      />
      {item?.controlNumber && (
        <CardText label="Letter #" description={item.controlNumber} />
      )}
      <CardText
        label="Date Sent"
        description={moment(item.letterSentDate).format(dateTimeFormat)}
      />
      {item?.status && (
        <CardText
          label="Bill Sent"
          description={moment(item.effectiveDate).format(dateTimeFormat)}
        />
      )}
    </CardContainer>
  );
};

export default RateChangesCard;
