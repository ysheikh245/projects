import React, {FC} from 'react';

import AgentRecordCard from './AgentRecordsCard';
import AlertMessageCard from './AlertMessageCard';
import ApplicationStatusCard, {PolicyDetailData} from './ApplicationStatusCard';
import BeneficiaryDetailsCard from './BeneficiaryDetailCard';
import ClaimCard from './ClaimCard';
import CustomerDocumentsCard from './CustomerDocumentsCard';
import DependentsCard from './DependentsCard';
import DiscountsCard from './DiscountsCard';
import FoundPolicyCard from './FoundPolicyCard';
import OutstandingRequirementsCard from './OutstandingRequirementsCard';
import PolicyAdditionalCoverageCard from './PolicyAdditionalCoverageCard';
import PolicyCoverageDetailCard from './PolicyCoverageDetailCard';
import RateChangesCard from './RateChangesCard';
import RolesCard from './RolesCard';
import WeeklyStatementsCard from './WeeklyStatementsCard';

type CardVariant =
  | 'applicationStatus'
  | 'role'
  | 'foundPolicy'
  | 'policyCoverageDetail'
  | 'alertMessage'
  | 'dependents'
  | 'discounts'
  | 'rateChanges'
  | 'agentRecord'
  | 'policyAdditionalCoverage'
  | 'customerDocuments'
  | 'claim'
  | 'beneficiaryDetails'
  | 'outstandingRequirements'
  | 'weeklyStatements';

interface Props {
  variant?: CardVariant;
  item: any;
  policyDetailData?: PolicyDetailData;
  onPressSelectPolicy?: () => void;
  policyNumber?: string;
  pageNumber?: number;
  navigateToClaimDetails?: () => void;
}

const Card: FC<Props> = ({
  variant = 'applicationStatus',
  item,
  onPressSelectPolicy,
  navigateToClaimDetails,
  pageNumber,
}) => {
  switch (variant) {
    case 'applicationStatus':
      // @ts-ignore
      return <ApplicationStatusCard pageNumber={pageNumber} item={item} />;
    case 'role':
      return <RolesCard item={item} />;
    case 'foundPolicy':
      return (
        <FoundPolicyCard
          item={item}
          onPressSelectPolicy={onPressSelectPolicy}
        />
      );
    case 'dependents':
      return <DependentsCard item={item} />;
    case 'discounts':
      return <DiscountsCard item={item} />;
    case 'alertMessage':
      return <AlertMessageCard item={item} />;
    case 'agentRecord':
      return <AgentRecordCard item={item} />;
    case 'policyAdditionalCoverage':
      return <PolicyAdditionalCoverageCard item={item} />;
    case 'rateChanges':
      return <RateChangesCard item={item} />;
    case 'policyCoverageDetail':
      return <PolicyCoverageDetailCard item={item} />;
    case 'customerDocuments':
      return <CustomerDocumentsCard item={item} />;
    case 'beneficiaryDetails':
      return <BeneficiaryDetailsCard item={item} />;
    case 'claim':
      return (
        <ClaimCard
          item={item}
          navigateToClaimDetails={navigateToClaimDetails}
        />
      );
    case 'outstandingRequirements':
      return <OutstandingRequirementsCard item={item} />;
    case 'weeklyStatements':
      return <WeeklyStatementsCard item={item} />;
  }
};

export default Card;
