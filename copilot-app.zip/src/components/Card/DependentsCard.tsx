import moment from 'moment-timezone';
import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {Dependent} from '../../redux/slices/faciSlice/types';
import {dateTimeFormat} from '../../utils/constants';

interface Props {
  item: Dependent;
}

const DependentsCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText
        label="Name"
        description={`${item.firstName} ${item.lastName}`}
      />
      <CardText
        label="Date of Birth"
        description={moment(item.dateOfBirth).format(dateTimeFormat)}
      />
      <CardText label="Gender" description={item.gender} />
      <CardText label="Issue Age" description={item.issueAge} />
      <CardText
        label="Effective Date"
        description={moment(item.effectiveDate).format(dateTimeFormat)}
      />
      <CardText
        label="Termination Date"
        description={moment(item.effectiveDate).format(dateTimeFormat)}
      />
      <CardText label="Status" description={item.status} />
    </CardContainer>
  );
};

export default DependentsCard;
