import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import moment from 'moment-timezone';
import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import styles from './styles';
import {SEND_THANKYOU, THANKYOU_SENT} from '../../constants/applicationStatus';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {ApplicationStatus} from '../../redux/slices/applicationStatusSlice/types';
import {selectNpn} from '../../redux/slices/authSlice/selectors';
import colors from '../../utils/colors';
import {dateTimeFormat} from '../../utils/constants';
import Button from '../Button';
import PMICIcon from '../PMICIcons';

export interface PolicyDetailData {
  policyNumber: string;
  name: string;
  productName: string;
  productCategory: string;
}

interface Props {
  item: ApplicationStatus;
  pageNumber: number;
}

const ApplicationStatusCard: FC<Props> = ({item, pageNumber}) => {
  const dispatch = useDispatch();

  const npn = useSelector(selectNpn);
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const goToApplicationStatusDetails = (
    workSheetRequirementCount: number | undefined,
  ) => {
    if (!workSheetRequirementCount) return;

    const policyDetailData: PolicyDetailData = {
      name: item.parties[0].fullName,
      policyNumber: item.policyNumber,
      productName: item.productName,
      productCategory: item.productCategory,
    };

    if (workSheetRequirementCount > 0) {
      navigate('ApplicationStatusDetails', {policyDetailData});
    }
  };

  const thankYouParams = {
    recipientFirstName: item.parties[0].firstName,
    recipientLastName: item.parties[0].lastName,
    recipientEmailAddress: item.parties[0].emailAddress,
    recipientState: item.parties[0].homeAddress.state,
    npn,
    productCode: item.productCode,
    messageCode: 'AGENCY_EML_COPILOT_APP_THANKYOU',
    partyId: item.parties[0].partyId,
    policyNumber: item.policyNumber,
    notes: 'Thankyou',
  };

  const workSheetRequirementCondition = !!(
    item?.workSheetRequirementCount && item.workSheetRequirementCount > 0
  );
  const cardContentStyle = workSheetRequirementCondition
    ? customStyles.contentContainer
    : customStyles.contentContainerDefault;

  const onPressSendThankYou = () => {
    dispatch(
      applicationStatusActions.sendThankYouRequest({
        data: thankYouParams,
        pageNumber,
      }),
    );
  };

  const workSheetRequirementCount =
    item?.workSheetRequirementCount !== undefined &&
    item?.workSheetRequirementCount >= 0;

  const workSheetRequirementCountColumn =
    item?.workSheetRequirementCount !== undefined &&
    item?.workSheetRequirementCount >= -1;

  return (
    <CardContainer
      disabled={!workSheetRequirementCondition}
      style={customStyles.cardContainer}
      onPress={() =>
        goToApplicationStatusDetails(item?.workSheetRequirementCount)
      }>
      <View style={cardContentStyle}>
        <CardText
          label="Name"
          description={`${item.parties[0].firstName} ${item.parties[0].lastName}`}
        />
        <CardText label="Policy" description={item.policyNumber} />
        <CardText label="Product" description={item.productName} />
        <CardText label="Status" description={item.policyStatus} />
        {item.policyStatus === 'Pending' ? (
          <CardText label="Submit Date" description={item.displaySubmitDate} />
        ) : (
          <>
            <CardText label="Issued Date" description={item.displayIssueDate} />
            <CardText
              label="Submit Date"
              description={item.displaySubmitDate}
            />
          </>
        )}
        {workSheetRequirementCountColumn && (
          <CardText
            label="Outstanding Requirement Count"
            description={`${item.workSheetRequirementCount}`}
          />
        )}
        {item.thankyouEmailStatus === SEND_THANKYOU && (
          <Button
            style={[
              styles.applicationStatusButton,
              customStyles.thankYouButton,
            ]}
            title="Send Thank You"
            onPress={onPressSendThankYou}
          />
        )}
        {item.thankyouEmailStatus === THANKYOU_SENT && (
          <Button
            variant="quaternary"
            style={styles.applicationStatusButton}
            title="Thank You Sent"
          />
        )}
      </View>
      {workSheetRequirementCondition && (
        <PMICIcon size={50} name="icon-right-chevron" color={colors.blue100} />
      )}
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  cardContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  contentContainerDefault: {
    width: '100%',
  },
  contentContainer: {
    width: '90%',
  },
  thankYouButton: {
    backgroundColor: colors.blue100,
  },
});
export default ApplicationStatusCard;
