import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {AgentRecord} from '../../redux/slices/faciSlice/types';

interface Props {
  item: AgentRecord;
}

const AgentRecordCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText label="Name" description={item.firstName} />
      <CardText label="NPN" description={item.nationalProducerNumber} />
      <CardText label="Status" description={item.agentStatus} />
      <CardText label="Role" description={item.policyRole} />
      <CardText label="Split%" description={item.splitPercentage} />
    </CardContainer>
  );
};

export default AgentRecordCard;
