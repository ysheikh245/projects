import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import moment from 'moment-timezone';
import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {CustomerDocument} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import {dateTimeFormat} from '../../utils/constants';
import PMICIcon from '../PMICIcons';

interface Props {
  item: CustomerDocument;
}
const CustomerDocumentsCard: FC<Props> = ({item}) => {
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const onPressDisplayPDFScreen = () => navigate('DisplayPDF', {uri: item.uri});

  return (
    <CardContainer
      onPress={onPressDisplayPDFScreen}
      style={customStyles.container}>
      <View>
        <CardText label="Communication Type" description={item.documentType} />
        <CardText
          label="Date sent"
          description={moment(item.receivedDateTime).format(dateTimeFormat)}
        />
      </View>
      <PMICIcon
        size={50}
        name="icon-right-chevron"
        color={colors.blue100}
        style={customStyles.rightArrow}
      />
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  textContainer: {
    justifyContent: 'center',
    flexDirection: 'column',
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  rightArrow: {
    position: 'absolute',
    right: 0,
  },
  cardTextContainer: {
    display: 'flex',
    flexDirection: 'column',
  },
  cardText: {
    minWidth: 200,
  },
});

export default CustomerDocumentsCard;
