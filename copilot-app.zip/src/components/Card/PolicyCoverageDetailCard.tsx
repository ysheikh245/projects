import moment from 'moment-timezone';
import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {PolicyCoverageDetail} from '../../redux/slices/faciSlice/types';
import {dateTimeFormat} from '../../utils/constants';
import UserProfileUtils from '../../utils/UserProfileUtils';

interface Props {
  item: PolicyCoverageDetail;
}

const PolicyCoverageDetailCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      {item.status && <CardText label="Status" description={item.status} />}
      {item.coverageCode && (
        <CardText label="Coverage Codes" description={item.coverageCode} />
      )}
      {item.coverageDesc && (
        <CardText label="Coverage Desc" description={item.coverageDesc} />
      )}
      {item.benDed && (
        <CardText
          label="Ben/Ded"
          description={UserProfileUtils.formatCurrency(item.benDed)}
        />
      )}
      {item.effectiveDate && (
        <CardText
          label="Effective Date"
          description={moment(item.effectiveDate).format(dateTimeFormat)}
        />
      )}
      <CardText
        label="Term Date"
        description={
          item?.term ? moment(item.term).format(dateTimeFormat) : 'N/A'
        }
      />
      <CardText
        label="Term Date"
        description={
          String(item.premium)
            ? UserProfileUtils.formatCurrency(item.premium)
            : 'N/A'
        }
      />
      <CardText
        label="Name"
        description={
          item.firstName || item.middleName || item.lastName
            ? `${item.firstName} ${item.middleName} ${item.lastName}`
            : 'N/A'
        }
      />
    </CardContainer>
  );
};

export default PolicyCoverageDetailCard;
