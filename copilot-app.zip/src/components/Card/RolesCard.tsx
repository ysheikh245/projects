import React, {FC} from 'react';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {Role} from '../../redux/slices/faciSlice/types';

interface Props {
  item: Role;
}

const RolesCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText label="Name" description={item.name} />
      <CardText label="Role" description={item.role} />
      <CardText label="Current Age" description={item.currentAge} />
      <CardText label="Issue Age" description={item.issueAge} />
    </CardContainer>
  );
};

export default RolesCard;
