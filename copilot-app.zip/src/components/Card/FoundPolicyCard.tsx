import React, {FC} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {Policy} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import PMICIcon from '../PMICIcons';

interface Props {
  item: Policy;
  onPressSelectPolicy?: () => void;
}
const FoundPolicyCard: FC<Props> = ({item, onPressSelectPolicy}) => {
  return (
    <CardContainer>
      <Pressable onPress={onPressSelectPolicy}>
        <View>
          {item && (
            <>
              {item.personNameList && item.personNameList.length > 0 && (
                <CardText
                  label="Name"
                  description={`${item.personNameList[0].firstName} ${item.personNameList[0].lastName}`}
                />
              )}
              <CardText label="Policy" description={item.policyNumber} />
              <CardText label="Role" description={item.role} />
            </>
          )}

          <View style={customStyles.iconContainer}>
            <PMICIcon
              size={50}
              name="icon-right-chevron"
              color={colors.blue100}
            />
          </View>
        </View>
      </Pressable>
    </CardContainer>
  );
};
const customStyles = StyleSheet.create({
  lineHeaderText: {
    minWidth: 100,
  },
  iconContainer: {
    position: 'absolute',
    right: 0,
    top: '25%',
  },
});

export default FoundPolicyCard;
