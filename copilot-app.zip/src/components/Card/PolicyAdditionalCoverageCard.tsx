import moment from 'moment-timezone';
import React, {FC} from 'react';
import {StyleSheet} from 'react-native';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {PolicyAdditionalCoverage} from '../../redux/slices/faciSlice/types';
import {dateTimeFormat} from '../../utils/constants';
import UserProfileUtils from '../../utils/UserProfileUtils';

interface Props {
  item: PolicyAdditionalCoverage;
}

const PolicyAdditionalCoverageCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText
        label="Status"
        description={
          item.statusLongDescription ? item.statusLongDescription : 'N/A'
        }
      />
      <CardText
        label="Coverage Code"
        description={item.coverageCode ? item.coverageCode : 'N/A'}
      />
      <CardText
        label="Description"
        description={item.descrip ? item.descrip : 'N/A'}
      />
      <CardText
        label="Ben/Ded"
        description={
          item.benefitAmt
            ? UserProfileUtils.formatCurrency(item.benefitAmt)
            : 'N/A'
        }
      />
      <CardText
        label="Modified Ben Amt"
        description={
          item.covGradedDeathBenefit
            ? UserProfileUtils.formatCurrency(item.covGradedDeathBenefit)
            : 'N/A'
        }
      />
      <CardText
        label="Effective Date"
        description={
          item.effDate ? moment(item.effDate).format(dateTimeFormat) : 'N/A'
        }
      />
      <CardText
        label="Reinstatement Date"
        description={
          item.reinstatementDate
            ? moment(item.reinstatementDate).format(dateTimeFormat)
            : 'N/A'
        }
      />
      <CardText
        label="Term Date"
        description={
          item.termDate ? moment(item.termDate).format(dateTimeFormat) : 'N/A'
        }
      />
      <CardText
        label="Record #"
        description={item.recordNumber ? item.recordNumber : 'N/A'}
      />
      <CardText
        label="Replaces Record #"
        description={
          item.replacesRecordNumber ? item.replacesRecordNumber : 'N/A'
        }
      />
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  textContainer: {
    flexDirection: 'row',
    display: 'flex',
  },
  lineHeaderText: {
    minWidth: 170,
  },
  text: {
    flex: 1,
  },
});

export default PolicyAdditionalCoverageCard;
