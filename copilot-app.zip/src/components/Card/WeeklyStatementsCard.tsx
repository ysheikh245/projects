import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import moment from 'moment-timezone';
import React, {FC} from 'react';
import {Pressable, StyleSheet} from 'react-native';

import CardContainer from './components/CardContainer';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {Statement} from '../../redux/slices/myCompensation/types';
import colors from '../../utils/colors';
import {dateTimeFormat} from '../../utils/constants';
import HeaderText from '../Text/HeaderText';

interface Props {
  item: Statement;
}

const WeeklyStatementsCard: FC<Props> = ({item}) => {
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const onPressDisplayPDF = () => {
    const fileName = item.fileName.replace(/\.[^/.]+$/, '');
    const fileExtension = item.fileName.split('.').pop();

    navigate('DisplayPDFUpdate', {
      pdfData: {
        documentId: item.documentId,
        version: item.version,
        fileExtension: fileExtension ? fileExtension : 'PDF',
        fileName,
      },
    });
  };

  return (
    <CardContainer style={customStyles.container}>
      {item?.endDate && (
        <HeaderText style={customStyles.headerText} variant="h2">
          {moment(item.endDate).format(dateTimeFormat)}
        </HeaderText>
      )}
      <Pressable onPress={onPressDisplayPDF}>
        <HeaderText variant="h2_link">View</HeaderText>
      </Pressable>
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  headerText: {
    color: colors.black100,
  },
});

export default WeeklyStatementsCard;
