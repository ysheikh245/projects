import {StyleSheet} from 'react-native';

import colors from '../../utils/colors';

const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: colors.gray600,
    width: '100%',
    marginBottom: 12,
    borderRadius: 10,
    shadowColor: colors.black100,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    paddingHorizontal: 6,
    paddingVertical: 10,
  },
  cardText: {
    fontSize: 16,
    marginBottom: 5,
    paddingRight: 2,
  },
  applicationStatusButton: {
    width: 200,
    alignSelf: 'flex-end',
    marginRight: 18,
  },
  textContainer: {
    width: '100%',
    flexDirection: 'row',
    display: 'flex',
  },
  indentedCardText: {
    paddingHorizontal: 10,
    marginTop: -10,
  },
});

export default styles;
