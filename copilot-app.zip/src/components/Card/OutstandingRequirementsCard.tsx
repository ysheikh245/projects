import _ from 'lodash';
import moment from 'moment-timezone';
import React, {FC, useEffect} from 'react';
import {StyleSheet} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import useDocumentPicker from '../../hooks/useDocumentPicker';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {selectSelectedDocument} from '../../redux/slices/applicationStatusSlice/selectors';
import {Case360Document} from '../../redux/slices/applicationStatusSlice/types';
import {dateTimeFormat} from '../../utils/constants';
import BodyText from '../Text/BodyText';
import UploadDocument from '../UploadDocument';

interface Props {
  item: Case360Document;
  dataSize: number;
  index: number;
}

const OutstandingRequirementsCard: FC<Props> = ({item, dataSize, index}) => {
  const dispatch = useDispatch();
  const selectedDocument = useSelector(selectSelectedDocument);

  const {document, onPressGetDocument, onPressResetDocumentPicker} =
    useDocumentPicker();

  const clonedDocument = _.cloneDeep(document);
  clonedDocument.documentDescription = item.description;

  useEffect(() => {
    if (document.fileCopyUri) {
      dispatch(applicationStatusActions.selectDocument({data: clonedDocument}));
    }
  }, [document]);

  const cardStyle = dataSize === index ? 80 : 12;

  const onPressResetDocument = (idx: number) => {
    dispatch(applicationStatusActions.selectDocument({data: clonedDocument}));
    onPressResetDocumentPicker(idx);
  };

  return (
    <CardContainer style={{marginBottom: cardStyle}}>
      <CardText
        label="Date Required"
        description={moment(item.dateRequired).format(dateTimeFormat)}
      />
      {item.dateReceived.length > 0 && (
        <CardText
          label="Date Received"
          description={moment(item.dateReceived).format(dateTimeFormat)}
        />
      )}
      <CardText label="Description" description={item.description} />
      <CardText label="Comments" description={item.comments} />
      {item.uploadButton !== 'None' && (
        <>
          <BodyText style={styles.uploadFileText}>Upload File</BodyText>
          <UploadDocument
            documentName={item.document}
            onPressGetDocument={() => onPressGetDocument(index)}
            onPressResetDocumentPicker={() => onPressResetDocument(index)}
          />
        </>
      )}
    </CardContainer>
  );
};

const styles = StyleSheet.create({
  uploadFileText: {
    marginTop: 16,
    marginBottom: 12,
  },
});

export default OutstandingRequirementsCard;
