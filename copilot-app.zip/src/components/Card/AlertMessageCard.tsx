import React, {FC} from 'react';
import {StyleSheet} from 'react-native';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {AlertMessage} from '../../redux/slices/faciSlice/types';

interface Props {
  item: AlertMessage;
}
const AlertMessageCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText label="Alert Level" description={item.alertLevel} />
      <CardText label="Message" description={item.message} />
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  lineHeaderText: {
    minWidth: 100,
  },
  textContainer: {
    flexDirection: 'row',
    display: 'flex',
  },
  indentedCardText: {
    paddingHorizontal: 10,
    marginTop: -10,
  },
});

export default AlertMessageCard;
