import React, {FC} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';

import CardContainer from './components/CardContainer';
import {Claim} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import PMICIcon from '../PMICIcons';
import BodyText from '../Text/BodyText';
import HeaderText from '../Text/HeaderText';

interface Props {
  item: Claim;
  navigateToClaimDetails?: () => void;
}

const ClaimCard: FC<Props> = ({item, navigateToClaimDetails}) => {
  const getClaimServiceDate = (claim: Claim) => {
    const claimServiceDate = claim.benefitPeriod;
    const claimsServiceDateArray = claimServiceDate.split(' ');
    const [originDate, endDate] = claimsServiceDateArray;

    if (originDate === endDate) {
      return originDate;
    } else {
      return claimServiceDate;
    }
  };

  return (
    <CardContainer style={styles.cardContainer}>
      <Pressable onPress={navigateToClaimDetails}>
        <View style={styles.rowContainer}>
          <View style={styles.textContainer}>
            <HeaderText variant="h2" style={styles.headerText}>
              {item.claimNumber}
            </HeaderText>
            <BodyText
              variant="regular"
              style={styles.bodyText}>{`Date of Service ${getClaimServiceDate(
              item,
            )}`}</BodyText>
            <BodyText
              variant="regular"
              style={
                styles.bodyText
              }>{`Overall Claim Status "${item.claimStatus}"`}</BodyText>
          </View>
          <View style={styles.verticalItem}>
            <PMICIcon
              size={60}
              name="icon-right-chevron"
              color={colors.black100}
            />
          </View>
        </View>
      </Pressable>
    </CardContainer>
  );
};

const styles = StyleSheet.create({
  headerText: {
    color: colors.black100,
  },
  textContainer: {
    flex: 1,
  },
  verticalItem: {
    justifyContent: 'center',
  },
  rowContainer: {
    display: 'flex',
    flexDirection: 'row',
    paddingLeft: 10,
  },
  cardContainer: {
    padding: 0,
  },
  bodyText: {
    marginBottom: 5,
    color: colors.black100,
  },
});

export default ClaimCard;
