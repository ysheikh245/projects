import React, {FC} from 'react';
import {StyleSheet} from 'react-native';

import CardContainer from './components/CardContainer';
import CardText from './components/CardText';
import {BeneficiaryDetails} from '../../redux/slices/faciSlice/types';
import {beneficiaryRankMap} from '../../utils/constants';

interface Props {
  item: BeneficiaryDetails;
}
const BeneficiaryDetailCard: FC<Props> = ({item}) => {
  return (
    <CardContainer>
      <CardText label="Name" description={item.beneficiaryName} />
      <CardText
        label="Rank"
        description={beneficiaryRankMap[item.beneficiaryRank]}
      />
      <CardText label="Share %" description={`${item.sharePercent}%`} />
      <CardText label="Relationship" description={item.beneRelationship} />
    </CardContainer>
  );
};

const customStyles = StyleSheet.create({
  lineHeaderText: {
    minWidth: 140,
  },
  textContainer: {
    flexDirection: 'row',
    display: 'flex',
  },
  indentedCardText: {
    paddingHorizontal: 10,
    marginTop: -10,
  },
});

export default BeneficiaryDetailCard;
