import React, {FC} from 'react';
import {StyleProp, TextStyle, View} from 'react-native';

import BodyText from '../../Text/BodyText';
import styles from '../styles';

interface Props {
  label: string;
  description?: string | number;
  style?: StyleProp<TextStyle>;
}

const CardText: FC<Props> = ({label, description, style}) => {
  return (
    <View style={styles.textContainer}>
      <View style={{width: '48%'}}>
        <BodyText style={styles.cardText} variant="regular_bold">
          {label}
        </BodyText>
      </View>
      <View style={{width: '48%'}}>
        <BodyText style={{fontSize: 16}}>
          {description ? description : 'N/A'}
        </BodyText>
      </View>
    </View>
  );
};

export default CardText;
