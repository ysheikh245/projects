import React, {FC} from 'react';
import {StyleSheet, View} from 'react-native';
import {useSelector} from 'react-redux';

import {
  selectSelectedPolicyCustomerName,
  selectSelectedPolicyDetail,
} from '../../../redux/slices/faciSlice/selectors';
import colors from '../../../utils/colors';
import HeaderText from '../../Text/HeaderText';

const CustomerAndPolicy: FC = () => {
  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const selectedPolicyDetail = useSelector(selectSelectedPolicyDetail);

  return (
    <>
      <View style={styles.headerContainer}>
        <HeaderText style={styles.headerText} variant="h2">
          Customer
        </HeaderText>
        {customerName && (
          <HeaderText variant="h2" style={styles.text}>
            {customerName}
          </HeaderText>
        )}
      </View>

      <View style={styles.headerContainer}>
        <HeaderText style={styles.headerText} variant="h2">
          Policy
        </HeaderText>
        {selectedPolicyDetail && selectedPolicyDetail.policyNumber && (
          <HeaderText variant="h2" style={styles.text}>
            {selectedPolicyDetail.policyNumber}
          </HeaderText>
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
  },
  headerText: {
    minWidth: 150,
    color: colors.black100,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
    color: colors.black100,
  },
});

export default CustomerAndPolicy;
