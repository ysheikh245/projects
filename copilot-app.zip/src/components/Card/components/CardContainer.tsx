import React, {FC, ReactNode} from 'react';
import {Pressable, StyleProp, ViewStyle} from 'react-native';

import styles from '../styles';

interface Props {
  children: ReactNode;
  onPress?: (workSheetRequirementCount: any) => void;
  style?: StyleProp<ViewStyle>;
  disabled?: boolean;
}
const CardContainer: FC<Props> = ({children, onPress, style, disabled}) => {
  return (
    <Pressable
      disabled={disabled}
      style={[styles.cardContainer, style]}
      onPress={onPress}>
      {children}
    </Pressable>
  );
};

export default CardContainer;
