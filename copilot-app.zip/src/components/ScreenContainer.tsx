import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {FC, ReactNode} from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleProp,
  StyleSheet,
  View,
  ViewStyle,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {useDispatch} from 'react-redux';

import MenuFilter from './MenuFilter';
import HeaderText from './Text/HeaderText';
import ScreenBanner from '../assets/icons/ScreenBannerIcon';
import {AppStackParamList} from '../navigation/AppNavigation';
import {applicationStatusActions} from '../redux/slices/applicationStatusSlice';
import colors from '../utils/colors';

export interface Props {
  children: ReactNode;
  useHeader?: boolean;
  useSecondHeader?: boolean;
  useMenuFilter?: boolean;
  secondHeaderLabel?: string;
  onPressSecondHeader?: () => void;
  style?: StyleProp<ViewStyle>;
  onScroll?: (e: any) => void;
}

const ScreenContainer: FC<Props> = ({
  children,
  useHeader,
  useSecondHeader,
  useMenuFilter,
  secondHeaderLabel,
  onPressSecondHeader,
  style,
  onScroll,
}) => {
  const dispatch = useDispatch();

  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const onPressHome = () => {
    navigate('Home');
    dispatch(applicationStatusActions.applicationStatusSuccess({data: []}));
  };

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <KeyboardAwareScrollView
        style={styles.keyboardAwareScrollView}
        contentContainerStyle={styles.keyboardAwareScrollViewContainerStyle}
        extraScrollHeight={75}
        enableOnAndroid
        onScroll={onScroll}
        scrollEventThrottle={3000}>
        <StatusBar barStyle="light-content" />
        <View style={[styles.screenContainer, style]}>
          <ScreenBanner />
          {useMenuFilter && <MenuFilter />}
          <View
            style={[
              styles.navigationContainer,
              useSecondHeader && styles.secondNavigationLink,
            ]}>
            {useHeader && (
              <HeaderText variant="h1_link" onPress={onPressHome}>
                Home
              </HeaderText>
            )}
            {useSecondHeader && (
              <HeaderText variant="h1_link" onPress={onPressSecondHeader}>
                {secondHeaderLabel}
              </HeaderText>
            )}
          </View>
          {children}
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeAreaView: {
    flex: 1,
    backgroundColor: colors.black100,
  },
  screenContainer: {
    backgroundColor: colors.white,
    flex: 1,
    paddingHorizontal: 9,
  },
  navigationContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  secondNavigationLink: {
    justifyContent: 'space-between',
  },
  keyboardAwareScrollView: {
    flex: 1,
  },
  keyboardAwareScrollViewContainerStyle: {
    flexGrow: 1,
  },
});

export default ScreenContainer;
