import React, {FC} from 'react';
import {Pressable, StyleSheet, View} from 'react-native';

import Button from './Button';
import PMICIcon from './PMICIcons';
import BodyText from './Text/BodyText';
import colors from '../utils/colors';

interface Props {
  onPressGetDocument: () => void;
  documentName?: string;
  onPressResetDocumentPicker: () => void;
}

const UploadDocument: FC<Props> = ({
  onPressGetDocument,
  documentName,
  onPressResetDocumentPicker,
}) => {
  const getDocumentName = (name: string) => {
    let [fileName, prefix] = name.split('.');
    if (fileName.length > 22) {
      fileName = `${fileName.slice(0, 22)}...`;
    }
    return `${fileName}.${prefix}`;
  };
  return (
    <View style={styles.uploadTypeContainer}>
      <Button
        textStyle={documentName ? styles.buttonTextOne : styles.buttonTextTwo}
        style={documentName ? styles.disabledButton : styles.uploadClaimsButton}
        variant="tertiary"
        title="Upload"
        onPress={onPressGetDocument}
        disabled={!!documentName}
      />
      <View style={styles.uploadTypeContent}>
        <BodyText variant="xs" numberOfLines={1} style={styles.bodyTextStyle}>
          {documentName
            ? getDocumentName(documentName)
            : '.jpg, .jpeg, .pdf, or .png'}
        </BodyText>
        {documentName && (
          <Pressable onPress={onPressResetDocumentPicker}>
            <PMICIcon size={30} name="icon-clear-x" color={colors.green} />
          </Pressable>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  uploadTypeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  uploadTypeContent: {
    paddingHorizontal: 5,
    backgroundColor: colors.gray1000,
    marginLeft: 10,
    flex: 1,
    height: 52,
    borderRadius: 5,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.gray200,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bodyTextStyle: {
    maxWidth: '100%',
  },
  buttonTextOne: {
    color: colors.gray100,
  },
  buttonTextTwo: {
    color: colors.blue100,
  },
  uploadClaimsButton: {
    backgroundColor: colors.gray600,
  },
  disabledButton: {
    backgroundColor: colors.gray1000,
    borderColor: colors.gray1000,
    borderWidth: 2,
    alignSelf: 'center',
  },
});

export default UploadDocument;
