import React, {FC} from 'react';
import {Pressable, StyleSheet} from 'react-native';

import PMICIcon from './PMICIcons';
import colors from '../utils/colors';

interface Props {
  onPress: () => void;
  isActive: boolean;
}

const Checkbox: FC<Props> = ({onPress, isActive}) => {
  return (
    <Pressable onPress={onPress} style={styles.checkbox}>
      {isActive && (
        <PMICIcon size={15} name="icon-checkmark" color={colors.blue100} />
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  checkbox: {
    height: 16,
    width: 16,
    borderColor: colors.gray200,
    borderWidth: 1,
    marginRight: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default Checkbox;
