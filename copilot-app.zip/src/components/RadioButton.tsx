import React, {FC} from 'react';
import {Pressable, StyleSheet} from 'react-native';

import colors from '../utils/colors';

interface Props {
  onPress: () => void;
  isActive: boolean;
}
const RadioButton: FC<Props> = ({onPress, isActive}) => {
  return (
    <Pressable
      onPress={onPress}
      style={isActive ? styles.activeRadioButton : styles.radioButton}
    />
  );
};

const styles = StyleSheet.create({
  radioButton: {
    height: 16,
    width: 16,
    borderRadius: 16 / 2,
    borderColor: colors.gray200,
    borderWidth: 1,
    marginRight: 10,
  },
  activeRadioButton: {
    backgroundColor: colors.gray200,
    height: 16,
    width: 16,
    borderRadius: 16 / 2,
    borderColor: colors.gray200,
    borderWidth: 1,
    marginRight: 10,
  },
});

export default RadioButton;
