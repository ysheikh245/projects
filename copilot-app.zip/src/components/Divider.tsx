import React, {FC} from 'react';
import {StyleProp, StyleSheet, Text, TextProps, ViewStyle} from 'react-native';

import colors from '../utils/colors';

type Props = {
  style?: StyleProp<ViewStyle>;
} & TextProps;

const Divider: FC<Props> = ({style}) => {
  return <Text style={[styles.divider, style]} />;
};

const styles = StyleSheet.create({
  divider: {
    height: 1,
    backgroundColor: colors.gray100,
  },
});

export default Divider;
