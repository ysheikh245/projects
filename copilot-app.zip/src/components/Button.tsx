import React, {FunctionComponent} from 'react';
import {
  Pressable,
  PressableProps,
  StyleProp,
  StyleSheet,
  TextStyle,
  ViewStyle,
} from 'react-native';

import {HeaderVariant} from './Text/HeaderText';
import HeaderText from './Text/HeaderText';
import colors from '../utils/colors';

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'tertiary'
  | 'quaternary'
  | 'cta'
  | 'outlineButton'
  | 'logoutButton';

type Props = {
  variant?: ButtonVariant;
  title?: string;
  textVariant?: HeaderVariant;
  buttonColor?: string;
  textStyle?: StyleProp<TextStyle>;
  style?: StyleProp<ViewStyle>;
} & Omit<PressableProps, 'style'>;

const Button: FunctionComponent<Props> = ({
  title,
  variant = 'primary',
  textVariant = 'h3',
  textStyle,
  style,
  children,
  ...rest
}) => {
  return (
    <Pressable style={[styles[variant], style]} {...rest}>
      {children ? (
        children
      ) : (
        <HeaderText
          style={[styles[`text_${variant}`], textStyle]} // TODO: Never add new styles
          variant={textVariant}>
          {title}
        </HeaderText>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  primary: {
    backgroundColor: colors.blue100,
    width: 153,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 52,
    marginBottom: 10,
  },
  secondary: {
    backgroundColor: colors.gray1000,
    width: 153,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 52,
    marginBottom: 10,
  },
  tertiary: {
    backgroundColor: colors.white,
    width: 153,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 52,
    marginBottom: 10,
    borderColor: colors.blue100,
    borderWidth: 2,
  },
  quaternary: {
    backgroundColor: colors.gray500,
    width: 153,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 52,
    marginBottom: 10,
    borderColor: colors.gray900,
    borderWidth: 2,
  },
  cta: {
    backgroundColor: colors.yellow300,
    height: 50,
    borderWidth: 0,
    borderColor: colors.yellow300,
    borderRadius: 4,
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  outlineButton: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    color: colors.black300,
    height: 52,
    borderWidth: 1,
    borderColor: colors.black300,
    borderRadius: 20,
    fontSize: 12,
    marginBottom: 20,
  },
  logoutButton: {
    alignSelf: 'center',
    backgroundColor: 'transparent',
    color: colors.blue100,
    height: 52,
    borderWidth: 0,
    borderColor: 'transparent',
    borderRadius: 1,
    fontSize: 12,
    marginTop: 20,
    marginBottom: 20,
  },
  text_primary: {
    color: colors.white,
  },
  text_secondary: {
    color: colors.black300,
  },
  text_tertiary: {
    color: colors.blue100,
  },
  text_quaternary: {
    color: colors.gray900,
  },
  text_cta: {
    color: colors.black300,
  },
});

export default Button;
