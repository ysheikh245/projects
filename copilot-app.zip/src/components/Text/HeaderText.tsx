import React, {FC, ReactNode} from 'react';
import {StyleProp, StyleSheet, Text, TextProps, TextStyle} from 'react-native';

import colors from '../../utils/colors';

export type HeaderVariant =
  | 'h1'
  | 'h1_link'
  | 'h2'
  | 'h2_link'
  | 'h3'
  | 'h4'
  | 'h5'
  | 'h6_link'
  | 'h6';

type Props = {
  variant?: HeaderVariant;
  children: string | ReactNode;
  style?: StyleProp<TextStyle>;
} & TextProps;

const HeaderText: FC<Props> = ({variant = 'h1', children, style, ...rest}) => {
  return (
    <Text
      adjustsFontSizeToFit
      style={[styles[variant], style]} // TODO: Never add new styles
      {...rest}>
      {children}
    </Text>
  );
};

const styles = StyleSheet.create({
  h1: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 28,
    lineHeight: 40,
  },
  h1_link: {
    color: colors.blue100,
    fontWeight: '500',
    fontSize: 28,
    lineHeight: 40,
    textDecorationLine: 'underline',
    marginBottom: 25,
  },
  h2: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 24,
    lineHeight: 39,
  },
  h2_link: {
    color: colors.blue100,
    fontWeight: '400',
    fontSize: 24,
    lineHeight: 39,
    textDecorationLine: 'underline',
  },
  h3: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 20,
    lineHeight: 34,
  },
  h4: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 16,
    lineHeight: 24,
  },
  h5: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 14,
    lineHeight: 21,
  },
  h6: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 12,
    lineHeight: 16,
  },
  h6_link: {
    color: colors.blue100,
    fontWeight: '500',
    fontSize: 12,
    lineHeight: 16,
    textDecorationLine: 'underline',
  },
});

export default HeaderText;
