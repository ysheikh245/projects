import React, {FC, ReactNode} from 'react';
import {StyleProp, StyleSheet, Text, TextProps, TextStyle} from 'react-native';

import colors from '../../utils/colors';

export type BodyVariant =
  | 'regular'
  | 'regular_link'
  | 'regular_bold'
  | 'sm'
  | 'xs';

type Props = {
  variant?: BodyVariant;
  children: string | ReactNode;
  style?: StyleProp<TextStyle>;
} & TextProps;

const BodyText: FC<Props> = ({
  variant = 'regular',
  children,
  style,
  ...rest
}) => {
  return (
    <Text adjustsFontSizeToFit style={[styles[variant], style]} {...rest}>
      {children}
    </Text>
  );
};

const styles = StyleSheet.create({
  regular: {
    color: colors.black300,
    fontWeight: '400',
    fontSize: 18,
    lineHeight: 24,
  },
  regular_bold: {
    color: colors.black300,
    fontWeight: '500',
    fontSize: 18,
    lineHeight: 24,
  },
  regular_link: {
    color: colors.blue100,
    fontWeight: '500',
    fontSize: 18,
    lineHeight: 24,
    textDecorationLine: 'underline',
  },
  sm: {
    color: colors.black300,
    fontWeight: '400',
    fontSize: 16,
    lineHeight: 21,
  },
  xs: {
    color: colors.black300,
    fontWeight: '400',
    fontSize: 12,
    lineHeight: 16,
  },
});

export default BodyText;
