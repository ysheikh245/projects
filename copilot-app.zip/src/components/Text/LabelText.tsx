import React, {FC} from 'react';
import {StyleSheet, Text, TextProps} from 'react-native';

export type LabelVariant = 'l1' | 'l2';

type Props = {
  variant: LabelVariant;
  children: string;
  color?: string;
} & TextProps;

const LabelText: FC<Props> = ({variant = 'l1', children, color, ...rest}) => {
  return (
    <Text adjustsFontSizeToFit style={[styles[variant], {color}]} {...rest}>
      {children}
    </Text>
  );
};

const styles = StyleSheet.create({
  l1: {
    color: '#2D2926',
    fontWeight: '500',
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 0.4,
  },
  l2: {
    color: '#2D2926',
    fontWeight: '500',
    fontSize: 14,
    lineHeight: 21,
    letterSpacing: 0.5,
  },
});

export default LabelText;
