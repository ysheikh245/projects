import React, {FC} from 'react';
import {
  KeyboardType,
  Pressable,
  TextInput as RNTextInput,
  StyleSheet,
  View,
  ViewStyle,
} from 'react-native';

import PMICIcon from './PMICIcons';
import HeaderText from './Text/HeaderText';
import {HeaderVariant} from './Text/HeaderText';
import colors from '../utils/colors';

interface Props {
  label?: string;
  onChangeText: (text: string) => void;
  value: string;
  headerVariant?: HeaderVariant;
  textInputStyle?: ViewStyle;
  keyboardType?: KeyboardType;
  placeholder?: string;
  useDatePicker?: boolean;
  onPressIcon?: () => void;
}
const TextInput: FC<Props> = ({
  label,
  onChangeText,
  value,
  headerVariant = 'h3',
  textInputStyle = {},
  keyboardType = 'default',
  placeholder = '',
  useDatePicker,
  onPressIcon,
}) => {
  return useDatePicker ? (
    <View style={styles.container}>
      <HeaderText color={colors.black100} variant={headerVariant}>
        {label}
      </HeaderText>
      <View style={styles.datePickerContainer}>
        <RNTextInput
          style={styles.pickerInput}
          onChangeText={onChangeText}
          value={value}
          keyboardType={keyboardType}
          placeholder={placeholder}
        />
        <Pressable onPress={onPressIcon}>
          <PMICIcon name="icon-calender" style={styles.calendarIcon} />
        </Pressable>
      </View>
    </View>
  ) : (
    <View style={styles.container}>
      <HeaderText style={styles.headerText} variant={headerVariant}>
        {label}
      </HeaderText>
      <RNTextInput
        style={[styles.textInput, textInputStyle]}
        onChangeText={onChangeText}
        value={value}
        keyboardType={keyboardType}
        placeholder={placeholder}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginBottom: 20,
  },
  headerText: {
    color: colors.black100,
  },
  textInput: {
    width: '100%',
    height: 62,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: colors.gray100,
    borderWidth: 1,
    marginTop: 8,
    padding: 10,
    color: colors.black300,
    fontWeight: '400',
    fontSize: 18,
  },
  datePickerContainer: {
    width: '100%',
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderColor: colors.gray100,
    borderWidth: 1,
    marginTop: 8,
    padding: 10,
  },
  pickerInput: {
    color: colors.black300,
    fontWeight: '400',
    fontSize: 18,
    paddingVertical: 0,
  },
  calendarIcon: {
    color: colors.black100,
    fontWeight: '400',
    fontSize: 24,
  },
});

export default TextInput;
