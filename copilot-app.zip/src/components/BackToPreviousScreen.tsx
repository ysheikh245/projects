import {useNavigation} from '@react-navigation/native';
import React, {FC} from 'react';
import {StyleProp, StyleSheet, ViewStyle} from 'react-native';

import BodyText from './Text/BodyText';

interface Props {
  screenName: string;
  style?: StyleProp<ViewStyle>;
}
const BackToPreviousScreen: FC<Props> = ({screenName, style}) => {
  const {goBack} = useNavigation();
  return (
    <BodyText
      onPress={goBack}
      style={[styles.backLink, style]}
      variant="regular_link">
      {`< Back to ${screenName}`}
    </BodyText>
  );
};

const styles = StyleSheet.create({
  backLink: {
    marginBottom: 35,
  },
});

export default BackToPreviousScreen;
