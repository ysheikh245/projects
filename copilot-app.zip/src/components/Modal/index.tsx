import React, {FC} from 'react';

import AgentRecordsModal from './AgentRecordsModal';
import AlertMessageModal from './AlertMessageModal';
import BeneficiaryDetailsModal from './BeneficiaryDetailsModal';
import DependentsModal from './DependentsModal';
import DiscountsModal from './DiscountsModal';
import FilterModal from './FilterModal';
import FoundPolicyModal from './FoundPolicyModal';
import MenuModal from './MenuModal';
import PolicyAdditionalCoverageModal from './PolicyAdditionalCoverageModal';
import PolicyCoverageDetailModal from './PolicyCoverageDetailModal';
import RateChangesModal from './RateChangesModal';
import RolesModal from './RolesModal';
import SuccessModal from './SuccessModal';

type ModalVariant =
  | 'filter'
  | 'success'
  | 'roles'
  | 'menu'
  | 'policyCoverageDetail'
  | 'foundPolicy'
  | 'alertMessage'
  | 'discounts'
  | 'dependents'
  | 'rateChanges'
  | 'agentRecords'
  | 'policyAdditionalCoverage'
  | 'beneficiaryDetails';

export interface ModalProps {
  data?: any;
  variant?: ModalVariant;
  isModalOpen?: boolean;
  setIsModalOpen?: (val: boolean) => void;
  pageNumber?: number;
}

const Modal: FC<ModalProps> = ({
  data,
  variant,
  isModalOpen,
  setIsModalOpen,
  pageNumber,
}) => {
  switch (variant) {
    case 'filter':
      // @ts-ignore
      return (
        <FilterModal pageNumber={pageNumber} setIsModalOpen={setIsModalOpen} />
      );
    case 'success':
      return (
        <SuccessModal
          setIsModalOpen={setIsModalOpen}
          isModalOpen={isModalOpen}
        />
      );
    case 'roles':
      return <RolesModal />;
    case 'discounts':
      return <DiscountsModal />;
    case 'dependents':
      return <DependentsModal />;
    case 'rateChanges':
      return <RateChangesModal />;
    case 'menu':
      return (
        <MenuModal setIsModalOpen={setIsModalOpen} isModalOpen={isModalOpen} />
      );
    case 'foundPolicy':
      return (
        <FoundPolicyModal
          data={data}
          setIsModalOpen={setIsModalOpen}
          isModalOpen={isModalOpen}
        />
      );
    case 'alertMessage':
      return <AlertMessageModal />;
    case 'agentRecords':
      return <AgentRecordsModal />;
    case 'policyAdditionalCoverage':
      return <PolicyAdditionalCoverageModal />;
    case 'policyCoverageDetail':
      return <PolicyCoverageDetailModal />;
    case 'beneficiaryDetails':
      return <BeneficiaryDetailsModal />;
  }
};

export default Modal;
