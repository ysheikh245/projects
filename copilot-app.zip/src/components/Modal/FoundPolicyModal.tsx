import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {FC} from 'react';
import {FlatList, Modal, StyleSheet, View} from 'react-native';
import {useSelector} from 'react-redux';
import {useDispatch} from 'react-redux';

import {ModalProps} from './index';
import CloseIcon from '../../assets/icons/CloseIcon';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectIsSearchByPolicy,
  selectPolicyDetails,
} from '../../redux/slices/faciSlice/selectors';
import {Policy} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import Card from '../Card';
import Divider from '../Divider';
import HeaderText from '../Text/HeaderText';

type Props = {
  data: Policy[];
} & ModalProps;
const FoundPolicyModal: FC<Props> = ({isModalOpen, setIsModalOpen}) => {
  const isSearchByPolicy = useSelector(selectIsSearchByPolicy);
  const policyDetails = useSelector(selectPolicyDetails);
  const {navigate} =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();
  const dispatch = useDispatch();

  const onPressSelectPolicy = (item: Policy) => {
    dispatch(faciActions.getCustomerContactInfo(item));
    if (setIsModalOpen) {
      setIsModalOpen(false);
    }
    navigate('FaciContactInfo');
  };

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isModalOpen}
      onRequestClose={() => setIsModalOpen && setIsModalOpen(false)}>
      <View style={styles.modalContainer}>
        <View style={styles.card}>
          <CloseIcon
            style={styles.closeButton}
            onPress={() => setIsModalOpen && setIsModalOpen(false)}
          />
          <HeaderText style={styles.title} variant="h2">
            {isSearchByPolicy ? 'Found Policy' : 'Found Customers'}
          </HeaderText>
          <Divider style={styles.divider} />
          <HeaderText style={styles.headerText} variant="h3">
            {isSearchByPolicy
              ? 'Select a policy to continue'
              : 'Select a customer to continue'}
          </HeaderText>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            contentContainerStyle={styles.contentContainer}
            data={policyDetails}
            renderItem={({item}) => (
              <Card
                variant="foundPolicy"
                item={item}
                onPressSelectPolicy={() => onPressSelectPolicy(item)}
              />
            )}
          />
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  headerText: {
    color: colors.black100,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    paddingHorizontal: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  card: {
    backgroundColor: colors.white,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
    color: colors.black100,
  },
  divider: {
    marginTop: 6,
    marginBottom: 12,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  flatList: {
    marginTop: 20,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  buttonContainer: {
    backgroundColor: colors.white,
    marginLeft: -16,
    width: '100%',
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'absolute',
    paddingTop: 10,
    paddingHorizontal: 9,
    bottom: 0,
    borderBottomColor: colors.gray100,
    borderBottomWidth: 1,
    borderLeftColor: colors.gray100,
    borderLeftWidth: 1,
    borderRightColor: colors.gray100,
    borderRightWidth: 1,
  },
});

export default FoundPolicyModal;
