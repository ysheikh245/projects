import React, {FC} from 'react';
import {FlatList, Modal, StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import CloseIcon from '../../assets/icons/CloseIcon';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectDependents,
  selectFaciDependentsModal,
  selectPolicyNumber,
  selectSelectedPolicyCustomerName,
} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';
import Button from '../Button';
import Card from '../Card';
import CustomerAndPolicy from '../Card/components/CustomerNameAndPolicy';
import Divider from '../Divider';
import HeaderText from '../Text/HeaderText';

const DependentsModal: FC = () => {
  const dispatch = useDispatch();
  const dependents = useSelector(selectDependents);
  const faciDependentsModal = useSelector(selectFaciDependentsModal);
  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const policyNumber = useSelector(selectPolicyNumber);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={faciDependentsModal}
      onRequestClose={() => dispatch(faciActions.resetFaciModals())}>
      <View style={styles.modalContainer}>
        <View style={styles.card}>
          <CloseIcon
            style={styles.closeButton}
            onPress={() => dispatch(faciActions.resetFaciModals())}
          />
          <HeaderText style={styles.title} variant="h2">
            Dependents
          </HeaderText>
          <Divider style={styles.divider} />
          <CustomerAndPolicy />
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            contentContainerStyle={styles.contentContainer}
            data={dependents}
            renderItem={({item}) => <Card variant="dependents" item={item} />}
          />
          <View style={styles.buttonContainer}>
            <Button
              style={styles.button}
              variant="primary"
              title="Close"
              onPress={() => dispatch(faciActions.resetFaciModals())}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    paddingHorizontal: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  card: {
    backgroundColor: colors.white,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
  },
  divider: {
    marginTop: 6,
    marginBottom: 12,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  flatList: {
    marginTop: 45,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  buttonContainer: {
    backgroundColor: colors.white,
    width: '109%',
    alignItems: 'flex-end',
    position: 'absolute',
    paddingTop: 10,
    paddingHorizontal: 9,
    bottom: 0,
    borderRightColor: colors.gray100,
    borderRightWidth: 1,
  },
  button: {
    backgroundColor: colors.blue100,
    width: 153,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 52,
    marginBottom: 10,
  },
});

export default DependentsModal;
