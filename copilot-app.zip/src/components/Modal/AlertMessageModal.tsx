import React, {FC, useEffect, useState} from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  StyleSheet,
  View,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import {ModalProps} from './index';
import CloseIcon from '../../assets/icons/CloseIcon';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectFaciAlertModal,
  selectPolicyAlertsDetail,
  selectSelectedPolicyCustomerName,
  selectSelectedPolicyDetail,
} from '../../redux/slices/faciSlice/selectors';
import {selectIsLoading} from '../../redux/slices/faciSlice/selectors';
import {PolicyAlertsDetail} from '../../redux/slices/faciSlice/types';
import {AlertMessage} from '../../redux/slices/faciSlice/types';
import colors from '../../utils/colors';
import Button from '../Button';
import Card from '../Card';
import CustomerAndPolicy from '../Card/components/CustomerNameAndPolicy';
import Divider from '../Divider';
import HeaderText from '../Text/HeaderText';

type Props = {} & ModalProps;
const AlertMessageModal: FC<Props> = ({isModalOpen, setIsModalOpen}) => {
  const dispatch = useDispatch();
  const policyAlertsDetail: PolicyAlertsDetail | undefined | null = useSelector(
    selectPolicyAlertsDetail,
  );
  const isLoading = useSelector(selectIsLoading);
  const customerName = useSelector(selectSelectedPolicyCustomerName);
  const isFaciModalVisible = useSelector(selectFaciAlertModal);
  const selectedPolicyDetail = useSelector(selectSelectedPolicyDetail);
  const [alertMessages, setAlertMessages] = useState<AlertMessage[]>([]);

  useEffect(() => {
    let alertMessages: AlertMessage[] = [];
    if (
      policyAlertsDetail &&
      policyAlertsDetail.response &&
      policyAlertsDetail.response.customerMessages &&
      policyAlertsDetail.response.customerMessages.length > 0
    ) {
      alertMessages = [...policyAlertsDetail.response.customerMessages];
    }

    if (
      policyAlertsDetail &&
      policyAlertsDetail.response &&
      policyAlertsDetail.response.policyMessages &&
      policyAlertsDetail.response.policyMessages.length > 0
    ) {
      policyAlertsDetail.response.policyMessages.forEach(policyMessage => {
        if (
          policyMessage &&
          policyMessage.messages &&
          policyMessage.messages.length > 0
        ) {
          policyMessage.messages.forEach(message => {
            alertMessages.push(message);
          });
        }
      });
    }
    setAlertMessages(alertMessages);
  }, [policyAlertsDetail]);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isFaciModalVisible}
      onRequestClose={() => dispatch(faciActions.resetFaciModals())}>
      <View style={styles.modalContainer}>
        <View style={styles.card}>
          <CloseIcon
            style={styles.closeButton}
            onPress={() => dispatch(faciActions.resetFaciModals())}
          />
          <HeaderText style={styles.title} variant="h2">
            Policy Alerts
          </HeaderText>
          <Divider style={styles.divider} />
          <CustomerAndPolicy />
          {isLoading && (
            <View style={styles.loading}>
              <ActivityIndicator size="large" color={colors.blue100} />
            </View>
          )}
          {alertMessages && alertMessages.length > 0 && (
            <FlatList
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
              contentContainerStyle={styles.contentContainer}
              data={alertMessages}
              renderItem={({item}) => (
                <Card variant="alertMessage" item={item} />
              )}
            />
          )}

          <View style={styles.buttonContainer}>
            <Button
              variant="primary"
              title="Close"
              style={styles.closeButtonPrimary}
              onPress={() => dispatch(faciActions.resetFaciModals())}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    paddingHorizontal: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  card: {
    backgroundColor: colors.white,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
    color: colors.black100,
  },
  divider: {
    marginTop: 6,
    marginBottom: 12,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  flatList: {
    marginTop: 15,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  buttonContainer: {
    display: 'flex',
    flexDirection: 'row-reverse',
  },
  closeButtonPrimary: {
    backgroundColor: colors.blue100,
  },
  headerContainer: {
    flexDirection: 'row',
  },
  headerText: {
    minWidth: 150,
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.transparentWhite,
    opacity: 0.5,
    zIndex: 1,
  },
});

export default AlertMessageModal;
