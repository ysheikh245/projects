import React, {FC} from 'react';
import {Modal, StyleSheet, View} from 'react-native';

import {ModalProps} from './index';
import CloseIcon from '../../assets/icons/CloseIcon';
import colors from '../../utils/colors';
import Divider from '../Divider';
import HeaderText from '../Text/HeaderText';

const SuccessModal: FC<ModalProps> = ({isModalOpen, setIsModalOpen}) => {
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isModalOpen}
      onRequestClose={() => setIsModalOpen(!isModalOpen)}>
      <View style={styles.modalContainer}>
        <View style={styles.successCard}>
          <CloseIcon
            style={styles.closeButton}
            onPress={() => setIsModalOpen(false)}
          />
          <HeaderText style={styles.title} variant="h2">
            Success!
          </HeaderText>
          <Divider style={styles.divider} />
          <HeaderText style={styles.message} variant="h2">
            File(s) successfully submitted!
          </HeaderText>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    paddingTop: 56,
    paddingHorizontal: 9,
  },
  successCard: {
    backgroundColor: colors.white,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: 190,
    paddingHorizontal: 21,
    paddingVertical: 16,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
  },
  divider: {
    marginTop: 6,
    marginBottom: 25,
  },
  message: {
    fontWeight: '400',
    alignSelf: 'center',
  },
});

export default SuccessModal;
