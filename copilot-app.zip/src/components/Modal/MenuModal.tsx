import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import React, {FC, useEffect, useState} from 'react';
import {
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import {ModalProps} from './index';
import {AppStackParamList} from '../../navigation/AppNavigation';
import {asFilterActions} from '../../redux/slices/applicationStatusFilterSlice';
import {applicationStatusActions} from '../../redux/slices/applicationStatusSlice';
import {authActions} from '../../redux/slices/authSlice';
import {faciActions} from '../../redux/slices/faciSlice';
import {menuActions} from '../../redux/slices/menuSlice';
import {selectVisibleItems} from '../../redux/slices/menuSlice/selectors';
import {AppMenuItem} from '../../redux/slices/menuSlice/types';
import {myCompensationActions} from '../../redux/slices/myCompensation';
import colors from '../../utils/colors';
import Button from '../Button';
import PMICIcon from '../PMICIcons';

const MenuModal: FC<ModalProps> = ({isModalOpen, setIsModalOpen}) => {
  const dispatch = useDispatch();
  const menuItems = useSelector(selectVisibleItems);

  const navigation =
    useNavigation<NativeStackNavigationProp<AppStackParamList>>();

  const [filteredItems, setFilteredItems] = useState(menuItems);

  const renderDot = (hasSubMenu: boolean) => {
    if (hasSubMenu) {
      return (
        <PMICIcon
          name="icon-right-triangle"
          style={styles.subItemTriangle}
          color={colors.blue100}
        />
      );
    }
    return <View style={styles.dot} />;
  };

  useEffect(() => {
    setFilteredItems(menuItems);
  }, [menuItems]);

  const renderItem = ({item, index}: {item: AppMenuItem; index: number}) => {
    return (
      <TouchableOpacity
        key={item.id}
        onPress={() => {
          console.log(item);
          onPressMenuOption(item.navigateToPage);
        }}
        onLongPress={() => {
          navigation.navigate('Debugging');
        }}
        style={item.subItems ? styles.subItem : styles.mainItem}>
        {item.subItems ? renderDot(true) : renderDot(false)}
        {renderItemTitleWithCount(item)}
        {item.subItems ? (
          <FlatList
            data={item.subItems}
            renderItem={renderItem}
            keyExtractor={item => item.id.toString()}
          />
        ) : (
          ''
        )}
      </TouchableOpacity>
    );
  };

  const onPressMenuOption = (pageName: any) => {
    navigation.navigate(pageName);

    if (setIsModalOpen) {
      setIsModalOpen(false);
    }
  };

  const renderItemTitleWithCount = (item: AppMenuItem) => {
    return (
      <View style={styles.menuItemContainer}>
        <Text style={styles.listItemStyle}>{item.title}</Text>
        {item.count ? (
          <View
            style={[
              styles.menuNumberItemContainer,
              {backgroundColor: item.countColor},
            ]}>
            <Text style={[styles.listItemStyle, styles.itemCountText]}>
              {item.count}
            </Text>
          </View>
        ) : (
          <View />
        )}
      </View>
    );
  };

  const onPressLogout = () => {
    dispatch(authActions.logout());
    dispatch(applicationStatusActions.defaultApplicationStatus());
    dispatch(asFilterActions.defaultAsFilter());
    dispatch(authActions.defaultAuth());
    dispatch(faciActions.defaultFaci());
    dispatch(menuActions.defaultMenu());
    dispatch(myCompensationActions.defaultMyCompensation());
  };

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isModalOpen}
      onRequestClose={() => setIsModalOpen && setIsModalOpen(false)}>
      <TouchableWithoutFeedback
        onPress={() => setIsModalOpen && setIsModalOpen(false)}>
        <View style={styles.backdrop}>
          <View style={styles.modalContainer}>
            <View style={styles.card}>
              <View>
                <FlatList
                  data={filteredItems}
                  renderItem={renderItem}
                  style={styles.flatList}
                  keyExtractor={item => item.id.toString()}
                />
              </View>
              <View style={styles.buttonContainer}>
                <Button
                  variant="primary"
                  title="Logout"
                  onPress={onPressLogout}
                  style={styles.logoutButton}
                />
              </View>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  backdrop: {
    backgroundColor: colors.transparentBlackLight,
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  keyboardAvoidingStyle: {
    flex: 1,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    alignItems: 'center',
    justifyContent: 'flex-start',
    height: '100%',
    marginTop: 75,
    marginBottom: 100,
    marginHorizontal: 10,
  },
  card: {
    backgroundColor: colors.transparentWhite,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 15,
    paddingVertical: 30,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    opacity: 1,
    position: 'relative',
    minHeight: 300,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
  },
  divider: {
    marginTop: 6,
    marginBottom: 12,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  flatList: {
    marginTop: -20,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 10,
    left: 10,
  },
  logoutButton: {
    backgroundColor: colors.blue100,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 10,
    marginRight: 0,
    backgroundColor: colors.blue100,
    position: 'relative',
    top: 18,
    right: 25,
  },
  subItemTriangle: {
    fontSize: 18,
    position: 'absolute',
    left: 0,
    top: 5,
  },
  listItemStyle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.black100,
  },
  mainItem: {
    paddingLeft: 30,
  },
  subItem: {
    marginTop: 10,
    paddingLeft: 30,
  },
  searchBar: {
    backgroundColor: colors.white,
    borderRadius: 0,
    borderWidth: 1,
    borderColor: colors.gray100,
  },
  menuItemContainer: {
    display: 'flex',
    flexDirection: 'row',
  },
  menuNumberItemContainer: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    marginLeft: 5,
    borderRadius: 12,
  },
  itemCountText: {
    color: colors.white,
    fontSize: 12,
  },
});

export default MenuModal;
