import React, {FC} from 'react';
import {FlatList, Modal, StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import {ModalProps} from './index';
import CloseIcon from '../../assets/icons/CloseIcon';
import {faciActions} from '../../redux/slices/faciSlice';
import {
  selectBeneficiaryDetails,
  selectBeneficiaryDetailsModal,
  selectSearchPolicyNumber,
  selectSelectedPolicyCustomerName,
} from '../../redux/slices/faciSlice/selectors';
import colors from '../../utils/colors';
import Button from '../Button';
import Card from '../Card';
import Divider from '../Divider';
import HeaderText from '../Text/HeaderText';

type Props = {} & ModalProps;
const BeneficiaryDetailsModal: FC = () => {
  const dispatch = useDispatch();
  const beneficiaryDetails = useSelector(selectBeneficiaryDetails);
  const policyNumber = useSelector(selectSearchPolicyNumber);
  const beneficiaryDetailsModal = useSelector(selectBeneficiaryDetailsModal);
  const customerName = useSelector(selectSelectedPolicyCustomerName);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={beneficiaryDetailsModal}
      onRequestClose={() => dispatch(faciActions.resetFaciModals())}>
      <View style={styles.modalContainer}>
        <View style={styles.card}>
          <CloseIcon
            style={styles.closeButton}
            onPress={() => dispatch(faciActions.resetFaciModals())}
          />
          <HeaderText style={styles.title} variant="h2">
            Beneficiary Details
          </HeaderText>
          <Divider style={styles.divider} />
          <View style={styles.headerContainer}>
            <HeaderText style={styles.headerText} variant="h2">
              Customer
            </HeaderText>
            <HeaderText variant="h2" style={styles.text}>
              {customerName}
            </HeaderText>
          </View>

          <View style={styles.headerContainer}>
            <HeaderText style={styles.headerText} variant="h2">
              Policy
            </HeaderText>
            <HeaderText variant="h2" style={styles.text}>
              {policyNumber}
            </HeaderText>
          </View>
          {beneficiaryDetails && beneficiaryDetails.length > 0 && (
            <FlatList
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
              contentContainerStyle={styles.contentContainer}
              data={beneficiaryDetails}
              renderItem={({item}) => (
                <Card variant="beneficiaryDetails" item={item} />
              )}
            />
          )}

          <View style={styles.buttonContainer}>
            <Button
              variant="primary"
              title="Close"
              style={styles.closeButtonPrimary}
              onPress={() => dispatch(faciActions.resetFaciModals())}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparentWhite,
    paddingHorizontal: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  card: {
    backgroundColor: colors.white,
    borderColor: colors.gray100,
    borderWidth: 1,
    width: '100%',
    height: '100%',
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  title: {
    alignSelf: 'center',
  },
  divider: {
    marginTop: 6,
    marginBottom: 12,
  },
  text: {
    fontWeight: '400',
    fontSize: 20,
  },
  flatList: {
    marginTop: 15,
  },
  contentContainer: {
    paddingBottom: 50,
  },
  buttonContainer: {
    display: 'flex',
    flexDirection: 'row-reverse',
  },
  closeButtonPrimary: {
    backgroundColor: colors.blue100,
  },
  headerContainer: {
    flexDirection: 'row',
  },
  headerText: {
    minWidth: 150,
  },
});

export default BeneficiaryDetailsModal;
