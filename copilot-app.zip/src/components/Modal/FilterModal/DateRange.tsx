import moment from 'moment-timezone';
import React, {useEffect, useState} from 'react';
import {Pressable, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import styles from './styles';
import {asFilterActions} from "../../../redux/slices/applicationStatusFilterSlice";
import {
  selectEndDate,
  selectSearchFromDate,
  selectSearchToDate,
  selectStartDate,
} from '../../../redux/slices/applicationStatusFilterSlice/selectors';
import colors from '../../../utils/colors';
import {dateTimeFormat} from '../../../utils/constants';
import NumberPicker from '../../Picker/NumberPicker';
import BodyText from '../../Text/BodyText';
import HeaderText from '../../Text/HeaderText';

const DateRange = () => {
  const dispatch = useDispatch();
  const startDate = useSelector(selectStartDate);
  const endDate = useSelector(selectEndDate);
  const searchFromDate = useSelector(selectSearchFromDate);
  const searchToDate = useSelector(selectSearchToDate);
  const [startDateModal, openStartDateModal] = useState(false);
  const [endDateModal, openEndDateModal] = useState(false);

  useEffect(() => {
    if (searchFromDate === null || searchToDate === null) {
      dispatch(asFilterActions.updateStartDate(0));
      dispatch(asFilterActions.updateEndDate(7));
    }
  }, []);

  const updateStartDate = (day: number) =>
    dispatch(asFilterActions.updateStartDate(day));
  const updateEndDate = (day: number) =>
    dispatch(asFilterActions.updateEndDate(day));

  return (
    <>
      <HeaderText variant="h3">Submit Date</HeaderText>
      <View style={styles.dateRangeContainer}>
        <View>
          <View style={styles.dateRangeContent}>
            <HeaderText variant="h3">Between</HeaderText>
            <Pressable
              onPress={() => openStartDateModal(true)}
              style={[styles.numberContainer, {marginLeft: 5}]}>
              <BodyText>{startDate.toString()}</BodyText>
            </Pressable>
          </View>
          <View style={styles.dateContainer}>
            {searchFromDate !== null && (
              <BodyText>
                {moment().subtract(startDate, 'days').format(dateTimeFormat)}
              </BodyText>
            )}
          </View>
        </View>
        <HeaderText variant="h3">and</HeaderText>
        <View>
          <View style={styles.dateRangeContent}>
            <Pressable
              onPress={() => openEndDateModal(true)}
              style={[styles.numberContainer, {marginRight: 5}]}>
              <BodyText>{endDate.toString()}</BodyText>
            </Pressable>
            <HeaderText variant="h3">Day(s) Ago</HeaderText>
          </View>
          <View style={styles.dateContainer}>
            {searchToDate !== null && (
              <BodyText>
                {moment().subtract(endDate, 'days').format(dateTimeFormat)}
              </BodyText>
            )}
          </View>
        </View>
        <NumberPicker
          setSelectedNumber={updateStartDate}
          selectedNumber={startDate}
          setPickerVisible={openStartDateModal}
          pickerVisible={startDateModal}
        />
        <NumberPicker
          setSelectedNumber={updateEndDate}
          selectedNumber={endDate}
          setPickerVisible={openEndDateModal}
          pickerVisible={endDateModal}
        />
      </View>
    </>
  );
};

export default DateRange;
