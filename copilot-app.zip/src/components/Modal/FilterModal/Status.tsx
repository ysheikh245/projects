import React from 'react';
import {StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import styles from './styles';
import {asFilterActions} from '../../../redux/slices/applicationStatusFilterSlice';
import {
  selectDeclineWithdrawn,
  selectIssued,
  selectNotTaken,
  selectPending,
} from '../../../redux/slices/applicationStatusFilterSlice/selectors';
import colors from '../../../utils/colors';
import Checkbox from '../../Checkbox';
import BodyText from '../../Text/BodyText';
import HeaderText from '../../Text/HeaderText';

const Status = () => {
  const dispatch = useDispatch();
  const pending = useSelector(selectPending);
  const issued = useSelector(selectIssued);
  const declineWithdrawn = useSelector(selectDeclineWithdrawn);
  const notTaken = useSelector(selectNotTaken);

  return (
    <>
      <HeaderText variant="h3">Status</HeaderText>
      <View style={customStyles.selectionContainer}>
        <View
          style={[styles.checkBoxContainer, customStyles.noBorderBottomWidth]}>
          <View style={styles.radioButtonContent}>
            <Checkbox
              onPress={() =>
                dispatch(asFilterActions.updateStatusPending(!pending))
              }
              isActive={pending}
            />
            <BodyText variant="sm">Pending</BodyText>
          </View>
        </View>
        <View
          style={[
            styles.checkBoxContainer,
            styles.radioButtonContainerNoBorder,
            customStyles.noBorderBottomWidth,
          ]}>
          <View style={styles.radioButtonContent}>
            <Checkbox
              onPress={() =>
                dispatch(asFilterActions.updateStatusIssued(!issued))
              }
              isActive={issued}
            />
            <BodyText variant="sm">Issued</BodyText>
          </View>
        </View>
      </View>

      <View style={customStyles.selectionContainer}>
        <View style={styles.checkBoxContainer}>
          <View style={styles.radioButtonContent}>
            <Checkbox
              onPress={() =>
                dispatch(
                  asFilterActions.updateStatusDeclineWithdrawn(
                    !declineWithdrawn,
                  ),
                )
              }
              isActive={declineWithdrawn}
            />
            <BodyText variant="sm">Decline/Withdrawn</BodyText>
          </View>
        </View>
        <View style={[styles.checkBoxContainer, customStyles.lastCheckBox]}>
          <View style={styles.radioButtonContent}>
            <Checkbox
              onPress={() =>
                dispatch(asFilterActions.updateStatusNotTaken(!notTaken))
              }
              isActive={notTaken}
            />
            <BodyText variant="sm">Not Taken</BodyText>
          </View>
        </View>
      </View>
    </>
  );
};

const customStyles = StyleSheet.create({
  fistCheckBox: {
    marginTop: 8,
  },
  lastCheckBox: {
    borderLeftWidth: 0,
  },
  selectionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  noBorderBottomWidth: {
    borderBottomWidth: 0,
  },
});

export default Status;
