import {StyleSheet} from 'react-native';

import colors from '../../../utils/colors';

const styles = StyleSheet.create({
  filterModal: {
    flex: 1,
    backgroundColor: colors.transparent,
    paddingTop: 63,
    paddingHorizontal: 9,
  },
  filterContainer: {
    backgroundColor: colors.white,
    width: '100%',
    height: '100%',
    padding: 9,
  },
  closeButton: {
    alignSelf: 'flex-end',
    marginBottom: 10,
  },
  divider: {
    marginTop: 12,
    marginBottom: 8,
  },
  dateRangeContainer: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
    alignSelf: 'center',
  },
  numberContainer: {
    width: 29,
    height: 29,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: colors.gray100,
    borderWidth: 1,
  },
  dateRangeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dateContainer: {
    width: 132,
    height: 29,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: colors.gray100,
    borderWidth: 1,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 16,
  },
  checkBoxContainer: {
    height: 50,
    alignItems: 'flex-start',
    justifyContent: 'center',
    borderColor: colors.gray200,
    borderWidth: 1,
    paddingHorizontal: 20,
  },
  radioButtonContainer: {
    width: 132,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: colors.gray200,
    borderWidth: 1,
  },
  radioButtonContainerNoBorder: {
    borderBottomWidth: 0,
    width: 194,
  },
  radioButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 22,
    paddingBottom: 80,
  },
});

export default styles;
