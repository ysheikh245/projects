import React from 'react';
import {View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import styles from './styles';
import {asFilterActions} from '../../../redux/slices/applicationStatusFilterSlice';
import {
  selectSortByNewest,
  selectSortByOldest,
} from '../../../redux/slices/applicationStatusFilterSlice/selectors';
import Divider from '../../Divider';
import RadioButton from '../../RadioButton';
import BodyText from '../../Text/BodyText';
import HeaderText from '../../Text/HeaderText';

const SortBy = () => {
  const dispatch = useDispatch();
  const newest = useSelector(selectSortByNewest);
  const oldest = useSelector(selectSortByOldest);

  const onPressSelectNewest = () => {
    dispatch(
      asFilterActions.updateSortBy({
        oldestToNewest: false,
        newestToOldest: true,
      }),
    );
  };

  const onPressSelectOldest = () => {
    dispatch(
      asFilterActions.updateSortBy({
        oldestToNewest: true,
        newestToOldest: false,
      }),
    );
  };
  return (
    <>
      <HeaderText variant="h2">Sort by</HeaderText>
      <Divider style={styles.divider} />
      <View
        style={[
          styles.radioButtonContainer,
          styles.radioButtonContainerNoBorder,
        ]}>
        <View style={styles.radioButtonContent}>
          <RadioButton onPress={onPressSelectOldest} isActive={oldest} />
          <BodyText variant="sm">Oldest to Newest</BodyText>
        </View>
      </View>
      <View style={[styles.radioButtonContainer, {width: 194}]}>
        <View style={styles.radioButtonContent}>
          <RadioButton onPress={onPressSelectNewest} isActive={newest} />
          <BodyText variant="sm">Newest to Oldest</BodyText>
        </View>
      </View>
    </>
  );
};

export default SortBy;
