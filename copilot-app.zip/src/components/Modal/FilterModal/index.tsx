import React, {FC} from 'react';
import {Modal, ScrollView, StyleSheet, View} from 'react-native';
import {useDispatch, useSelector} from 'react-redux';

import DateRange from './DateRange';
import SortBy from './SortBy';
import Status from './Status';
import styles from './styles';
import CloseIcon from '../../../assets/icons/CloseIcon';
import {asFilterActions} from '../../../redux/slices/applicationStatusFilterSlice';
import {
  selectFirstName,
  selectIsFilterActive,
  selectIsFilterLoading,
  selectLastName,
  selectPolicyNumber,
} from '../../../redux/slices/applicationStatusFilterSlice/selectors';
import {applicationStatusActions} from '../../../redux/slices/applicationStatusSlice';
import colors from '../../../utils/colors';
import Button from '../../Button';
import Divider from '../../Divider';
import ScreenLoader from '../../ScreenLoader';
import HeaderText from '../../Text/HeaderText';
import TextInput from '../../TextInput';
import {ModalProps} from '../index';

const FilterModal: FC<ModalProps> = () => {
  const dispatch = useDispatch();

  const policyNumber = useSelector(selectPolicyNumber);
  const firstName = useSelector(selectFirstName);
  const lastName = useSelector(selectLastName);
  const isLoading = useSelector(selectIsFilterLoading);
  const isFilterActive = useSelector(selectIsFilterActive);

  const onChangePolicyNumber = (text: string) =>
    dispatch(asFilterActions.updatePolicyNumber(text));
  const onChangeFirstName = (text: string) =>
    dispatch(asFilterActions.updateFirstName(text));
  const onChangeLastName = (text: string) =>
    dispatch(asFilterActions.updateLastName(text));
  const resetFilter = () => {
    dispatch(asFilterActions.resetFilter());
  };

  const onPressApplyFilter = () => {
    dispatch(asFilterActions.cacheResultsRequest());
    dispatch(applicationStatusActions.applicationStatusReset(true));
  };

  const closeFilterModal = () =>
    dispatch(asFilterActions.isFilterModalOpen(false));

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isFilterActive}
      onRequestClose={closeFilterModal}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={styles.filterModal}>
        <View style={styles.filterContainer}>
          <CloseIcon style={styles.closeButton} onPress={closeFilterModal} />
          <HeaderText variant="h2">Filter</HeaderText>
          <Divider style={styles.divider} />

          <DateRange />

          <Status />

          <TextInput
            label="Policy Number"
            onChangeText={onChangePolicyNumber}
            value={policyNumber}
          />
          <TextInput
            label="First Name"
            onChangeText={onChangeFirstName}
            value={firstName}
          />
          <TextInput
            label="Last Name"
            onChangeText={onChangeLastName}
            value={lastName}
          />

          <SortBy />

          <View style={styles.buttonContainer}>
            <Button variant="tertiary" title="Reset" onPress={resetFilter} />
            <Button
              style={customStyles.primaryButton}
              variant="primary"
              title="Apply"
              onPress={onPressApplyFilter}
            />
          </View>
        </View>
      </ScrollView>
      <ScreenLoader message="Please wait..." isLoading={isLoading} />
    </Modal>
  );
};

const customStyles = StyleSheet.create({
  primaryButton: {
    backgroundColor: colors.blue100,
  },
  secondaryButton: {
    backgroundColor: colors.gray1000,
  },
});

export default FilterModal;
