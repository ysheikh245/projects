import React, {FC, ReactNode} from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View,
  ViewProps,
} from 'react-native';

export interface Props extends ViewProps {
  children: ReactNode;
}

const AuthScreenContainer: FC<Props> = ({children, ...props}) => {
  return (
    <SafeAreaView style={{flex: 1}} {...props}>
      {Platform.OS === 'ios' ? (
        <KeyboardAvoidingView style={{flex: 1}} behavior="padding">
          <ScrollView>
            <View style={styles.centeredScreen}>{children}</View>
          </ScrollView>
        </KeyboardAvoidingView>
      ) : (
        <ScrollView>
          <View style={styles.centeredScreen}>{children}</View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  centeredScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default AuthScreenContainer;
