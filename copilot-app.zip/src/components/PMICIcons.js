import React from 'react';
import {Platform, StyleSheet} from 'react-native';
import {createIconSet} from 'react-native-vector-icons';

const glyphMap = {
  'icon-app-status': 0xe929,
  'icon-faci': 0xe853,
  'icon-view-my-comp': 0xe931,
  'icon-secure-msg': 0xe91a,
  'icon-my-status': 0xe970,
  'icon-my-contact-info': 0xe065,
  'icon-hamburger-menu': 0xe5d2,
  'icon-right-triangle': 0xe037,
  'icon-magnifying-glass': 0xe955,
  'icon-right-chevron': 0xe315,
  'icon-checkmark': 0xe876,
  'icon-trash-can': 0xe871,
  'icon-calender': 0xe021,
  'icon-down-load': 0xe884,
  'icon-clear-x': 0xe5cd,
  'icon-my-compensation': 0xe931,
};

// PMIC Icon file name causing issue
const iconName =
  Platform.OS === 'ios' ? 'physicians-mutual-icons' : 'physicians_mutual_icons';
const CustomIcon = createIconSet(glyphMap, iconName);

const PMICIcon = props => (
  <CustomIcon {...props} style={[styles.icon, props.style]} />
);

const styles = StyleSheet.create({
  icon: {},
});

export default PMICIcon;
