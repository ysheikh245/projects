import {Picker} from '@react-native-picker/picker';
import React, {FC} from 'react';
import {Modal, Pressable, StyleSheet, Text, View} from 'react-native';

import {getMonth} from '../../screens/MyCompensationScreen/utils';
import colors from '../../utils/colors';

let months: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

interface Props {
  pickerVisible: boolean;
  setPickerVisible: (val: boolean) => void;
  selectedValue: number;
  setSelectedValue: (val: number) => void;
}
const MonthPicker: FC<Props> = ({
  pickerVisible,
  setPickerVisible,
  selectedValue,
  setSelectedValue,
}) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={pickerVisible}
      onRequestClose={() => {
        setPickerVisible(false);
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.pickerContainer}>
          <Pressable
            onPress={() => setPickerVisible(false)}
            style={styles.closeButton}>
            <Text style={styles.closeText}>Close</Text>
          </Pressable>
          <Picker
            mode="dialog"
            selectedValue={selectedValue}
            onValueChange={itemValue => setSelectedValue(itemValue)}>
            {months?.map((num, index) => (
              <Picker.Item key={index} label={getMonth(num)} value={num} />
            ))}
          </Picker>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  pickerContainer: {
    position: 'absolute',
    bottom: 0,
    backgroundColor: colors.white,
    width: '100%',
    height: '35%',
  },
  closeButton: {
    width: '100%',
    backgroundColor: colors.gray700,
    borderTopColor: colors.gray500,
    borderBottomColor: colors.gray500,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    padding: 10,
  },
  closeText: {
    fontWeight: '500',
    color: colors.blue500,
    alignSelf: 'flex-end',
    fontSize: 18,
  },
});

export default MonthPicker;
