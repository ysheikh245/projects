import {Picker} from '@react-native-picker/picker';
import React, {FC, useRef} from 'react';
import {Modal, Pressable, StyleSheet, Text, View} from 'react-native';

import colors from '../../utils/colors';

const numbers = [
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
  22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
  60,
];

interface Props {
  pickerVisible: boolean;
  setPickerVisible: (val: boolean) => void;
  selectedNumber: number;
  setSelectedNumber: (val: number) => void;
}
const NumberPicker: FC<Props> = ({
  pickerVisible,
  setPickerVisible,
  selectedNumber,
  setSelectedNumber,
}) => {
  const pickerRef = useRef();

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={pickerVisible}
      onRequestClose={() => {
        setPickerVisible(false);
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.pickerContainer}>
          <Pressable
            onPress={() => setPickerVisible(false)}
            style={styles.closeButton}>
            <Text style={styles.closeText}>Close</Text>
          </Pressable>
          <Picker
            mode="dialog"
            selectedValue={selectedNumber}
            onValueChange={(itemValue, itemIndex) =>
              setSelectedNumber(itemValue)
            }>
            {numbers.map((num, index) => (
              <Picker.Item key={index} label={num.toString()} value={num} />
            ))}
          </Picker>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  pickerContainer: {
    position: 'absolute',
    bottom: 0,
    backgroundColor: colors.white,
    width: '100%',
    height: '35%',
  },
  closeButton: {
    width: '100%',
    backgroundColor: colors.gray700,
    borderTopColor: colors.gray500,
    borderBottomColor: colors.gray500,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    padding: 10,
  },
  closeText: {
    fontWeight: '500',
    color: colors.blue500,
    alignSelf: 'flex-end',
    fontSize: 18,
  },
});

export default NumberPicker;
