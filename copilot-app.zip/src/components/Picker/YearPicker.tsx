import {Picker} from '@react-native-picker/picker';
import React, {FC} from 'react';
import {Modal, Pressable, StyleSheet, Text, View} from 'react-native';

import colors from '../../utils/colors';

const currentYear = new Date().getFullYear();
const range = (start: number, stop: number, step: number) =>
  Array.from({length: (stop - start) / step + 1}, (_, i) => start + i * step);

interface Props {
  pickerVisible: boolean;
  setPickerVisible: (val: boolean) => void;
  selectedValue: number;
  setSelectedValue: (val: number) => void;
}
const YearPicker: FC<Props> = ({
  pickerVisible,
  setPickerVisible,
  selectedValue,
  setSelectedValue,
}) => {
  const years: number[] = range(currentYear, currentYear - 5, -1);

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={pickerVisible}
      onRequestClose={() => {
        setPickerVisible(false);
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.pickerContainer}>
          <Pressable
            onPress={() => setPickerVisible(false)}
            style={styles.closeButton}>
            <Text style={styles.closeText}>Close</Text>
          </Pressable>
          <Picker
            mode="dialog"
            selectedValue={selectedValue}
            onValueChange={(itemValue, itemIndex) =>
              setSelectedValue(itemValue)
            }>
            {years?.map((num, index) => (
              <Picker.Item key={index} label={num.toString()} value={num} />
            ))}
          </Picker>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  pickerContainer: {
    position: 'absolute',
    bottom: 0,
    backgroundColor: colors.white,
    width: '100%',
    height: '35%',
  },
  closeButton: {
    width: '100%',
    backgroundColor: colors.gray700,
    borderTopColor: colors.gray500,
    borderBottomColor: colors.gray500,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    padding: 10,
  },
  closeText: {
    fontWeight: '500',
    color: colors.blue500,
    alignSelf: 'flex-end',
    fontSize: 18,
  },
});

export default YearPicker;
