import {DateTimePickerAndroid} from '@react-native-community/datetimepicker';
import React, {FC, useEffect, useState} from 'react';
import {Platform} from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {useDispatch, useSelector} from 'react-redux';

import TextInput from '../../components/TextInput';
import {faciActions} from '../../redux/slices/faciSlice';
import {selectDateOfBirth} from '../../redux/slices/faciSlice/selectors';
import {selectClaimsPeriod} from '../../redux/slices/faciSlice/selectors';

interface Props {
  value: string;
  label: string;
  onChange: (val: string) => void;
}
const DatePicker: FC<Props> = ({value, label, onChange}) => {
  const dispatch = useDispatch();

  const dateOfBirth = useSelector(selectDateOfBirth);
  const claimsPeriod = useSelector(selectClaimsPeriod);

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [date, setDate] = useState(new Date(1598051730000));
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [inputDate, setInputDate] = useState(value);

  useEffect(() => {
    if (dateOfBirth === '') {
      setInputDate('');
    }
  }, [dateOfBirth]);

  useEffect(() => {
    if (claimsPeriod === '') {
      setInputDate('');
    }
  }, [claimsPeriod]);

  const onPressShowDatePicker = () => setDatePickerVisibility(true);

  const onPressHideDatePicker = () => setDatePickerVisibility(false);

  const handleIOSDateChange = (selectDate: Date) => {
    const year: number = selectDate.getFullYear();
    const month: number = selectDate.getMonth() + 1;
    const day: number = selectDate.getDate();

    let formattedMonth = ('0' + month).slice(-2);
    let formattedDay = ('0' + day).slice(-2);

    const momentDate = `${formattedMonth}/${formattedDay}/${year}`;
    setInputDate(momentDate);
    dispatch(faciActions.setClaimsPeriod(momentDate));
    dispatch(faciActions.updateCustomerSearchDOB(momentDate));
    setDatePickerVisibility(false);
  };

  const handleDateChange = (event: any, selectDate: Date) => {
    if (Platform.OS === 'android') {
      if (event.type === 'set' || event.type === 'dismissed') {
        onPressHideDatePicker();
      }
    }

    const year: number = selectDate.getFullYear();
    const month: number = selectDate.getMonth() + 1;
    const day: number = selectDate.getDate();

    let formattedMonth = ('0' + month).slice(-2);
    let formattedDay = ('0' + day).slice(-2);

    const momentDate = `${formattedMonth}/${formattedDay}/${year}`;
    setInputDate(momentDate);
    dispatch(faciActions.setClaimsPeriod(momentDate));
    dispatch(faciActions.updateCustomerSearchDOB(momentDate));
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const formatInputDate = (text: string) => {
    const textWithNumbersOnly = text.replace(/[^\d]/g, '');
    const maxLength = 10;
    if (textWithNumbersOnly.length <= 2) {
      return textWithNumbersOnly;
    } else if (textWithNumbersOnly.length <= 4) {
      return `${textWithNumbersOnly.substring(
        0,
        2,
      )}/${textWithNumbersOnly.substring(2)}`;
    } else {
      return `${textWithNumbersOnly.substring(
        0,
        2,
      )}/${textWithNumbersOnly.substring(2, 4)}/${textWithNumbersOnly.substring(
        4,
        maxLength,
      )}`;
    }
  };

  const inputValueChange = (text: string) => {
    const formattedValue = formatInputDate(text);
    setInputDate(formattedValue);
    const dateObj = new Date(formattedValue) as any;
    if (dateObj !== 'Invalid Date') {
      setSelectedDate(dateObj);
    }
    onChange(formattedValue);
  };

  return (
    <>
      <TextInput
        label={label}
        value={inputDate}
        onChangeText={inputValueChange}
        placeholder="mm/dd/yyyy"
        headerVariant="h4"
        keyboardType="number-pad"
        useDatePicker
        onPressIcon={onPressShowDatePicker}
      />
      {Platform.OS === 'android' &&
        isDatePickerVisible &&
        DateTimePickerAndroid.open({
          value: date,
          onChange: handleDateChange,
          mode: 'date',
          is24Hour: true,
        })}

      {Platform.OS === 'ios' && (
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          onConfirm={handleIOSDateChange}
          onCancel={hideDatePicker}
        />
      )}
    </>
  );
};

export default DatePicker;
