import {Picker} from '@react-native-picker/picker';
import React, {FC, useRef} from 'react';
import {Modal, Pressable, StyleSheet, Text, View} from 'react-native';

import colors from '../../utils/colors';

const states = {
  AL: 'Alabama',
  AK: 'Alaska',
  AZ: 'Arizona',
  AR: 'Arkansas',
  CA: 'California',
  CO: 'Colorado',
  CT: 'Connecticut',
  DE: 'Delaware',
  FL: 'Florida',
  GA: 'Georgia',
  HI: 'Hawaii',
  ID: 'Idaho',
  IL: 'Illinois',
  IN: 'Indiana',
  IA: 'Iowa',
  KS: 'Kansas',
  KY: 'Kentucky',
  LA: 'Louisiana',
  ME: 'Maine',
  MD: 'Maryland',
  MA: 'Massachusetts',
  MI: 'Michigan',
  MN: 'Minnesota',
  MS: 'Mississippi',
  MO: 'Missouri',
  MT: 'Montana',
  NE: 'Nebraska',
  NV: 'Nevada',
  NH: 'New Hampshire',
  NJ: 'New Jersey',
  NM: 'New Mexico',
  NY: 'New York',
  NC: 'North Carolina',
  ND: 'North Dakota',
  OH: 'Ohio',
  OK: 'Oklahoma',
  OR: 'Oregon',
  PA: 'Pennsylvania',
  RI: 'Rhode Island',
  SC: 'South Carolina',
  SD: 'South Dakota',
  TN: 'Tennessee',
  TX: 'Texas',
  UT: 'Utah',
  VT: 'Vermont',
  VA: 'Virginia',
  WA: 'Washington',
  WV: 'West Virginia',
  WI: 'Wisconsin',
  WY: 'Wyoming',
};

interface Props {
  pickerVisible: boolean;
  setPickerVisible: (val: boolean) => void;
  selectedState: string;
  setSelectedState: (val: string) => void;
}
const StatePicker: FC<Props> = ({
  pickerVisible,
  setPickerVisible,
  selectedState,
  setSelectedState,
}) => {
  const pickerRef = useRef();
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={pickerVisible}
      onRequestClose={() => {
        setPickerVisible(false);
      }}>
      <View style={styles.modalContainer}>
        <View style={styles.pickerContainer}>
          <Pressable
            onPress={() => setPickerVisible(false)}
            style={styles.closeButton}>
            <Text style={styles.closeText}>Close</Text>
          </Pressable>
          <Picker
            mode="dialog"
            selectedValue={selectedState}
            onValueChange={(itemValue, itemIndex) =>
              setSelectedState(itemValue)
            }>
            {Object.entries(states).map(([abbreviation, stateName]) => (
              <Picker.Item
                key={abbreviation}
                label={stateName}
                value={abbreviation}
              />
            ))}
          </Picker>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: colors.transparent,
  },
  pickerContainer: {
    position: 'absolute',
    bottom: 0,
    backgroundColor: colors.white,
    width: '100%',
    height: '35%',
  },
  closeButton: {
    width: '100%',
    backgroundColor: colors.gray700,
    borderTopColor: colors.gray500,
    borderBottomColor: colors.gray500,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    padding: 10,
  },
  closeText: {
    fontWeight: '500',
    color: colors.blue500,
    alignSelf: 'flex-end',
    fontSize: 18,
  },
  label: {
    fontWeight: 'bold',
    fontSize: 16,
    color: 'black',
  },
});

export default StatePicker;
