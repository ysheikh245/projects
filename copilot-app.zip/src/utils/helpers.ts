import {createRef} from 'react';

export const navigateRef = createRef<any>();

export function navigate(name: string, params?: any) {
  navigateRef.current.navigate(name, params);
}

export function goBack() {
  navigateRef.current.goBack();
}
