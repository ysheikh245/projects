const colors = {
  white: '#ffffff',

  black100: '#000000',
  black200: '#070707',
  black300: '#212529',
  black400: '#333333',
  black500: '#060606',

  blue100: '#0B6CB6',
  blue200: '#2D94FC',
  blue300: '#0D6DB6',
  blue400: '#0A4A79',
  blue500: '#007AFF',

  gray100: '#707070',
  gray200: '#CED4DA',
  gray300: '#EEEEEE',
  gray400: '#F8F8F8',
  gray500: '#D9D9D9',
  gray600: '#EDEFF1',
  gray700: '#F1F1F1',
  gray800: '#4D505F',
  gray900: '#666666',
  gray1000: '#DEE2E6',

  transparent: 'rgba(238,238,238, 0.8)',
  transparentWhite: 'rgba(255,255,255, 0.8)',
  transparentBlackLight: 'rgba(0, 0, 0, 0.2)',

  green: '#009B88',
  green100: '#1E4A75',

  yellow100: '#FEBE0E',
  yellow200: '#FEBD10',
  yellow300: '#F3C23A',

  red: '#FF0000',
} as const;

export type Color = keyof typeof colors;

export default colors;
