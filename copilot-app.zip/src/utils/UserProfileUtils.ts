class UserProfileUtils {
  static genderMap = {
    M: 'Male',
    F: 'Female',
    O: 'Other',
    N: 'Prefer not to say',
  };

  static calculateAge(dob: string) {
    const dobDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - dobDate.getFullYear();
    const m = today.getMonth() - dobDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < dobDate.getDate())) {
      age--;
    }
    return age;
  }

  static getGender(genderCode: string) {
    if (genderCode in this.genderMap) {
      return this.genderMap[genderCode];
    }
    return 'N/A';
  }
  static formatDate(dateStr: string) {
    const date = new Date(dateStr);

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // January is 0!
    const year = date.getFullYear();

    return `${month}/${day}/${year}`;
  }

  static formatCurrency(amount: number): string {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    });

    return formatter.format(amount);
  }
}

export default UserProfileUtils;
