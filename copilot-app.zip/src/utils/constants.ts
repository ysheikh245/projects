export const SPLASH_SCREEN_ANIMATION_DURARION = 4000;
export const SPLASH_SCREEN_FRAME_DURATION = 50;
export const SPLASH_SCREEN_FRAME_COUNT = 40;
export const dateTimeFormat: string = 'MM/DD/YYYY';
export const beneficiaryRankMap = {
  '1': 'First',
  '2': 'Second',
  '3': 'Third',
  '4': 'Fourth',
  '5': 'fifth',
};
