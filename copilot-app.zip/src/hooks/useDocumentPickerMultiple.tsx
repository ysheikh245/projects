import {useState} from 'react';
import DocumentPicker, {types} from 'react-native-document-picker';
import RNFS from 'react-native-fs';

import {Document} from '../redux/slices/applicationStatusSlice/types';

const useDocumentPickerMultiple = () => {
  const [documents, setDocuments] = useState<Document[]>([]);

  const onPressGetDocument = async (index: number) => {
    try {
      const response: Document | any = await DocumentPicker.pickSingle({
        type: [types.pdf, types.images],
        presentationStyle: 'fullScreen',
        copyTo: 'cachesDirectory',
      });
      const encodedFileUri = decodeURI(response.fileCopyUri);
      const fileData = await RNFS.readFile(encodedFileUri, 'base64');
      const newDocument = {...response, fileData};
      const newDocuments: Document[] | any = [...documents];
      newDocuments[index] = newDocument;
      setDocuments(newDocuments);
    } catch (err) {
      console.log(err);
    }
  };

  const onPressResetDocumentPicker = (index: number) => {
    const newDocuments: Document[] | any = documents.filter(
      (_, i) => i !== index,
    );
    setDocuments(newDocuments);
  };

  const resetAllDocuments = () => {
    setDocuments([]);
  };

  return {
    documents,
    onPressGetDocument,
    onPressResetDocumentPicker,
    resetAllDocuments,
  };
};

export default useDocumentPickerMultiple;
