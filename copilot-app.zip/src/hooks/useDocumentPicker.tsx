import {cloneDeep} from 'lodash';
import {useState} from 'react';
import DocumentPicker, {types} from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import {useSelector} from 'react-redux';
import {useDispatch} from 'react-redux';

import {applicationStatusActions} from '../redux/slices/applicationStatusSlice';
import {selectWorksheetDetail} from '../redux/slices/applicationStatusSlice/selectors';
import {
  Case360Document,
  Document,
} from '../redux/slices/applicationStatusSlice/types';

const useDocumentPicker = () => {
  const dispatch = useDispatch();
  const [document, setDocument] = useState<Document>({
    documentDescription: '',
    fileCopyUri: '',
    name: '',
    size: 0,
    type: '',
    uri: '',
    fileData: '',
    document: '',
  });
  const [documentName, setDocumentName] = useState<string>('');
  const worksheetDetail = useSelector(selectWorksheetDetail);

  const clonedWorksheetDetail = cloneDeep(worksheetDetail);

  const onPressGetDocument = (index: number) => {
    DocumentPicker.pickSingle({
      type: [types.pdf, types.images],
      presentationStyle: 'fullScreen',
      copyTo: 'cachesDirectory',
    }).then((response: Document | any) => {
      clonedWorksheetDetail[index].document = response.name;
      // clonedWorksheetDetail[index].uri = response.fileCopyUri;
      // clonedWorksheetDetail[index].type = response.type;

      dispatch(
        applicationStatusActions.getWorksheetDetailSuccess({
          data: clonedWorksheetDetail,
        }),
      );
      const encodedFileUri = decodeURI(response.fileCopyUri);
      RNFS.readFile(encodedFileUri, 'base64')
        .then(result => {
          setDocument({...response, fileData: result});
          setDocumentName(response.name);
        })
        .catch(err => {
          console.log(err.message, err.code);
        });
    });
  };

  const onPressResetDocumentPicker = (index: number) => {
    setDocument({
      fileCopyUri: '',
      name: '',
      size: 0,
      type: '',
      uri: '',
      fileData: '',
      documentDescription: '',
      document: '',
    });
    clonedWorksheetDetail[index].document = '';
    // clonedWorksheetDetail[index].uri = '';
    // clonedWorksheetDetail[index].type = '';
    dispatch(
      applicationStatusActions.getWorksheetDetailSuccess({
        data: clonedWorksheetDetail,
      }),
    );
    setDocumentName('');
  };

  const onPressCancel = () => {
    setDocument({
      fileCopyUri: '',
      name: '',
      size: 0,
      type: '',
      uri: '',
      fileData: '',
      documentDescription: '',
      document: '',
    });

    clonedWorksheetDetail.map((detail: Document | Case360Document) => {
      detail.document = '';
      detail.uri = '';
      detail.type = '';
    });

    dispatch(
      applicationStatusActions.getWorksheetDetailSuccess({
        data: clonedWorksheetDetail,
      }),
    );
    setDocumentName('');
  };

  return {
    document,
    documentName,
    onPressGetDocument,
    onPressResetDocumentPicker,
    onPressCancel,
  };
};

export default useDocumentPicker;
