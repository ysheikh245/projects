export const THANKYOU_SENT = 'THANKYOU_SENT';
export const SEND_THANKYOU = 'SEND_THANKYOU';
export const DISABLED = 'disabled';
export const ENABLED = 'enabled';
