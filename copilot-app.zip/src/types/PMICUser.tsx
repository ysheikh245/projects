import {JwtPayload} from 'jwt-decode';

export const enum USER_VALIDITY {
  VALID = 'VALID',
  POSSIBLY_INVALID = 'POSSIBLY_INVALID',
  INVALID = 'INVALID',
}

export const enum USER_TYPE {
  EMPLOYEE = 'EMPLOYEE',
  AGENT = 'AGENT',
  HOMETOWN_AGENT = 'HOMETOWN_AGENT',
}

export interface DecodedIdentityToken extends JwtPayload {
  email: string;
  email_verified: boolean;
  family_name: string;
  given_name: string;
  name: string;
  pmicnpn: string;
  preferred_username: string;
}

export interface IPMICUser {
  id: string;
  username: string;
  npn: string;
  organizationId?: string;
  url?: string;
  userType: USER_TYPE;
  firstName: string;
  lastName: string;
  primaryPhone: string;
  cellPhone?: string;
  emailAddress: string;
  validity: USER_VALIDITY;
}

export default class PMICUser implements IPMICUser {
  id!: string;
  username!: string;
  npn!: string;
  organizationId?: string;
  url?: string;
  userType!: USER_TYPE;
  firstName!: string;
  lastName!: string;
  primaryPhone!: string;
  cellPhone?: string;
  emailAddress!: string;
  validity!: USER_VALIDITY;

  constructor(user: Partial<IPMICUser>) {
    let tempUser: any = {};

    // pass in properties as top-level
    Object.assign(tempUser, user);

    // removes empty values from the final object
    Object.assign(
      this,
      Object.fromEntries(
        Object.entries(tempUser).filter(([_, v]) => v != null && v !== ''),
      ),
    );
  }

  get isValid(): boolean {
    if (this.validity === USER_VALIDITY.INVALID) {
      return false;
    }
    if (!this.npn) {
      return false;
    }
    if (!this.firstName) {
      return false;
    }
    if (!this.lastName) {
      return false;
    }
    if (!this.emailAddress) {
      return false;
    }
    if (!this.primaryPhone) {
      return false;
    }

    return true;
  }

  toImmutable(): IPMICUser {
    return {
      id: this.id,
      username: this.username,
      npn: this.npn,
      organizationId: this.organizationId,
      url: this.url,
      userType: this.userType,
      firstName: this.firstName,
      lastName: this.lastName,
      primaryPhone: this.primaryPhone,
      cellPhone: this.cellPhone,
      emailAddress: this.emailAddress,
      validity: this.validity,
    };
  }

  toJSON() {
    return JSON.stringify({
      id: this.id,
      username: this.username,
      npn: this.npn,
      organizationId: this.organizationId,
      url: this.url,
      userType: this.userType,
      firstName: this.firstName,
      lastName: this.lastName,
      primaryPhone: this.primaryPhone,
      cellPhone: this.cellPhone,
      emailAddress: this.emailAddress,
      validity: this.validity,
    });
  }
}

/*
    Sample Identity Token
    {
        "at_hash": "Rk69urpRdh8RSOaK24fIOQ",
        "aud": "agent-quoting-clientid",
        "auth_time": 1690387829,
        "azp": "agent-quoting-clientid",
        "email": "testnpn@pmic.com",
        "email_verified": true,
        "exp": 1690389908,
        "family_name": "npn",
        "given_name": "test",
        "iat": 1690389608,
        "iss": "https://auth.physiciansmutual.com/realms/dev",
        "jti": "183d0377-7a9a-405d-9f70-0411975dcc75",
        "name": "test npn",
        "pmicnpn": "12345678",
        "preferred_username": "testnpn",
        "session_state": "db896b55-0d9b-4e2a-b19c-463070de06fd",
        "sid": "db896b55-0d9b-4e2a-b19c-463070de06fd",
        "sub": "e88452f5-fb29-45d6-9066-9e15e5cea97e",
        "typ": "ID"
    }
*/
