import {configureStore} from '@reduxjs/toolkit';
import EncryptedStorage from 'react-native-encrypted-storage';
import {createLogger} from 'redux-logger';
import {
  createMigrate,
  persistCombineReducers,
  persistStore,
} from 'redux-persist';
import createSagaMiddleware from 'redux-saga';

import migrations from './migrations';
import {reducers} from './slices';
import mainSaga from '../sagas';

const persistConfig = {
  key: 'root',
  version: 1,
  storage: EncryptedStorage,
  migrate: createMigrate(migrations, {debug: false}),
  blacklist: [
    'applicationStatus',
    'faci',
    'asFilter',
    'menuState',
    'myCompensation',
  ],
  whitelist: ['auth'],
};

const persistedReducer = persistCombineReducers(persistConfig, reducers);

const logger = createLogger();
const saga = createSagaMiddleware();

const middleware = [logger, saga];

export const store = configureStore({
  reducer: persistedReducer,
  middleware,
});

saga.run(mainSaga);

const persistor = persistStore(store);

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export default persistor;
