import {createSlice, PayloadAction} from '@reduxjs/toolkit';

import {AppMenuItem} from './types';

type MenuState = {
  isLoading: boolean;
  errorMessage: string;
  appMenuItems: AppMenuItem[];
};

const initialState: MenuState = {
  isLoading: false,
  errorMessage: '',
  appMenuItems: [],
};

const MenuSlice = createSlice({
  name: 'menuState',
  initialState,
  reducers: {
    getMenuItemsRequest: state => {
      state.isLoading = true;
    },
    getMenuItemsSuccess: (state, action: PayloadAction<AppMenuItem[]>) => {
      state.isLoading = false;
      state.appMenuItems = action.payload;
      state.errorMessage = '';
    },
    getMenuItemsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    defaultMenu: () => initialState,
  },
});

export const {actions: menuActions, reducer: menuReducer} = MenuSlice;
