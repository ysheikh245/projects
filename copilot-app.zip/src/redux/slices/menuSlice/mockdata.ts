import {AppMenuItem} from './types';
import colors from '../../../utils/colors';

const appMenuItems: AppMenuItem[] = [
  {
    id: 1,
    title: 'Application Status',
    navigateToPage: 'ApplicationStatus',
    visible: true,
  },
  {id: 2, title: 'FACI', navigateToPage: 'FaciSearch', visible: true},
  {
    id: 3,
    title: 'View My Compensation',
    navigateToPage: 'MyCompensation',
    visible: true,
  },
  {
    id: 4,
    title: 'Secure Message',
    navigateToPage: '',
    count: 1,
    countColor: colors.red,
    visible: false,
  },
  {id: 5, title: 'My Status', navigateToPage: '', visible: false},
  {
    id: 6,
    title: 'My Contact Information',
    navigateToPage: '',
    subItems: [
      {
        id: 8,
        title: 'View Contact QR Code',
        navigateToPage: '',
        visible: true,
      },
      {
        id: 9,
        title: 'View Web QR Code',
        navigateToPage: '',
        visible: true,
      },
      {
        id: 10,
        title: 'Sent Via Text',
        navigateToPage: '',
        visible: true,
      },
      {
        id: 11,
        title: 'Send Via Email',
        navigateToPage: '',
        visible: true,
      },
    ],
    visible: false,
  },
  {
    id: 7,
    title: 'Marketing & Sale Material (S3)',
    navigateToPage: '',
    visible: false,
  },
];

export default appMenuItems;
