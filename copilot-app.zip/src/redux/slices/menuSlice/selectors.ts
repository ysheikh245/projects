import {createSelector} from '@reduxjs/toolkit';

import {RootState} from '../../store';

export const selectMenuItems = (state: RootState) => state.menu.appMenuItems;
export const selectVisibleItems = createSelector([selectMenuItems], data => {
  return data.filter(item => item.visible);
});
