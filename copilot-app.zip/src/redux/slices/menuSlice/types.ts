export interface AppMenuItem {
  id: number;
  title: string;
  navigateToPage: string;
  subItems?: AppMenuItem[];
  count?: number;
  countColor?: string;
  visible: boolean;
}
