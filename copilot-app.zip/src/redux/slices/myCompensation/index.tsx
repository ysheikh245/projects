import {createSlice, PayloadAction} from '@reduxjs/toolkit';

import {MyCompensationPDF, MyCompensationState, PDF, Statement} from './types';

export const initialState: MyCompensationState = {
  isLoading: false,
  statements: [],
  pdfUrl: '',
  pdf: null,
};

const myCompensationSlice = createSlice({
  name: 'myCompensation',
  initialState,
  reducers: {
    getStatementsRequest: (
      state,
      _action: PayloadAction<{
        beginDate: string | Date;
        endDate: string | Date;
      }>,
    ) => {
      state.isLoading = true;
    },
    getStatementsSuccess: (
      state,
      action: PayloadAction<{data: Statement[]}>,
    ) => {
      state.isLoading = false;
      state.statements = action.payload.data;
    },
    getStatementsFailure: state => {
      state.isLoading = false;
    },
    getMyCompensationPDFRequest: (
      state,
      _action: PayloadAction<{data: MyCompensationPDF}>,
    ) => {
      state.isLoading = true;
    },
    getMyCompensationPDFSuccess: (
      state,
      action: PayloadAction<{data: PDF}>,
    ) => {
      state.isLoading = false;
      state.pdf = action.payload.data;
    },
    getMyCompensationPDFFailure: state => {
      state.isLoading = false;
    },
    resetPDF: state => {
      state.pdf = null;
    },
    defaultMyCompensation: () => initialState,
  },
});

export const {actions: myCompensationActions, reducer: myCompensationReducer} =
  myCompensationSlice;
