export interface MyCompensationState {
  isLoading: boolean;
  statements: Statement[];
  pdfUrl: string;
  pdf: PDF | null;
}

export interface PDF {
  base64: string;
  cache: boolean;
  path: string;
  uri: string;
}

export interface Statement {
  endDate: string;
  documentIndexCode: string;
  documentType: string;
  documentId: string;
  version: string;
  fileName: string;
}

export interface MyCompensationPDF {
  documentId: string;
  version: string;
  fileName: string;
  fileExtension: string;
}
