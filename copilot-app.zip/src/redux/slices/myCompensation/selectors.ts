import {createSelector} from '@reduxjs/toolkit';

import {Statement} from './types';
import {RootState} from '../../store';

export const selectStatements = (state: RootState) =>
  state.myCompensation.statements;

export const selectMutatedStatements = createSelector(
  [selectStatements],
  statements => {
    const newStatements: Statement[] = [];

    statements.map(item => {
      if (item?.endDate) {
        newStatements.push(item);
      }
    });

    return newStatements;
  },
);

export const selectIsLoading = (state: RootState) =>
  state.myCompensation.isLoading;

export const selectPDF = (state: RootState) => state.myCompensation.pdf;
