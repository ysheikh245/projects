export interface Role {
  name: string;
  role: string;
  currentAge: string;
  issueAge: string;
}

export interface InsuredPersonName {
  nameType?: string;
  firstName?: string;
  lastName?: string;
  middleName?: string;
}
export interface Policy {
  partyId: string;
  role: string;
  gender: string;
  personNameList: InsuredPersonName[];
  policyNumber: string;
}

export interface PolicyDetail {
  issueDate: string;
  productName: string;
  policyStatus: string;
  parties: any[];
  policyEffectiveDate: string;
  lastPaymentDate: string;
  paidToDate: string;
  currentPremium: number;
  policyType: string;
}

export interface SearchByCustomerParams {
  firstName: string;
  lastName: string;
  state: string;
  zip?: string;
  dateOfBirth?: string;
  type: string;
}

export interface SearchByPolicyParams {
  policyNumber: string;
  type: string;
}

export interface InsuredCustomerAddress {
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
}
export interface ExternalReferencePolicyDetail {
  policyNumber?: string;
  policyStatus?: string;
  policyRoleList?: Role[];
}

export interface ExternalReference {
  customerId?: string;
  customerIdType?: string;
  policyList?: ExternalReferencePolicyDetail[];
}
export interface PolicySearchByPartyIDPolicy {
  policyNumber: string;
  productName: string;
  status: string;
  parties: Role[];
}

export interface FaciCustomerDetail {
  gender?: string;
  phoneNumber?: string;
  secondaryPhoneNumber?: string;
  emailAddress?: string;
  birthDate?: string;
  homeAddress?: InsuredCustomerAddress;
  tempAddress?: Partial<InsuredCustomerAddress>;
  personNameList?: InsuredPersonName[];
  externalReferenceList?: ExternalReference[];
  policies?: PolicySearchByPartyIDPolicy[];
}

export type AlertMessage = {
  messageCode: string;
  message: string;
  alertLevel: string;
};

export type AdditionalPolicyInfo = {
  rolesCount: number;
  dependentsCount: number;
  agentsOfRecordCount: number;
  discountsCount: number;
  additionalLifeInsuranceRidersCount: number;
  coverageDetailsCount: number;
  beneficiaryDetailsCount: number;
  rateChangesCount: number;
  viewCustomerDocumentsCount: number;
  policyAlertsCount: number;
};
export type PolicyMessage = {
  policyNumber?: string;
  messages?: AlertMessage[];
};

export type PolicyAlertMessages = {
  customerMessages?: AlertMessage[];
  policyMessages?: PolicyMessage[];
};

export type PolicyAlertsDetail = {
  response?: PolicyAlertMessages;
};

export type Discount = {
  name: string;
  amount: number;
  effectiveDate: string;
  status: string;
  discountPercent?: string;
};

export interface PolicyCoverageDetail {
  status: string;
  coverageCode: string;
  coverageDesc: string;
  offer: string;
  benDed: number;
  effectiveDate: string;
  premium: number;
  firstName: string;
  middleName: string;
  lastName: string;
  term: string;
}
export interface PolicyAdditionalCoverage {
  policyNumber: string;
  companyCode: string;
  recordNumber: number;
  replacesRecordNumber: number;
  personNumber: number;
  baseRiderInd: string;
  statusCode: string;
  coverageCode: string;
  effDate: string;
  termDate: string;
  reinstatementDate: string;
  benefitAmt: number;
  covGradedDeathBenefit: number;
  descrip: string;
  monthlyPremium: number;
  quartPremium: number;
  semiPremium: number;
  recurringPremium: number;
  annualPremium: number;
  firstName: string;
  middleName: string;
  lastName: string;
  paidToDate: string;
  statusLongDescription: string;
}

export type Dependent = {
  firstName: string;
  middleName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  issueAge: string;
  effectiveDate: string;
  status: string;
  studentInd: string;
  disabledInd: string;
};

export interface AgentRecord {
  agentRoleOnPolicyId: number;
  agentStatus: string;
  firstName: string;
  lastName: string;
  nationalProducerNumber: string;
  policyNumber: string;
  policyRole: string;
  salesforceContactId: string;
  splitPercentage: number;
}

export type RateChange = {
  receivedDate: string;
  effectiveDate: string;
  premium: number;
  mode: string;
  area: string;
  state: string;
  controlNumber?: string;
  letterDueDate: string;
  letterSentDate: string;
  status?: string;
};

export type CustomerDocument = {
  createdDateTime: string;
  documentId: string;
  documentLocation: string;
  documentScannedDate: string;
  documentSource: string;
  documentType: string;
  fileName: string;
  policyNumber: string;
  receivedDateTime: string;
  uri: string;
  versionNumber: number;
};

export type BeneficiaryDetails = {
  companyCode: string;
  policyNumber: string;
  personNumber: number;
  accountNumber: number;
  beneficiaryRank: number;
  statusCode: string;
  statusReason: string;
  beneficiaryType: string;
  sharePercent: number;
  lastName: string;
  firstName: string;
  rankDescrip: string;
  beneRelationship: string;
  beneficiaryName: string;
};

export type Claim = {
  claimNumber: string;
  policyNumber: string;
  claimStatus: string;
  benefitPeriod: string;
};
export type ClaimDetail = {
  claimNumber: string;
  claimStatus: string;
  dateOfBirth: string;
  claimantName: string;
  claimType: string;
  payees: Payee[];
};
export type Payee = {
  zip: string;
  sequence: string;
  city: string;
  address1: string;
  name: string;
  state: string;
  amountPaid: number;
  paymentDate: string;
  claimStatusDescription: string;
};

export interface PolicyDetail {
  issueDate: string;
  productName: string;
  status: string;
  parties: any[];
  policyEffectiveDate: string;
  lastPaymentDate: string;
  paidToDate: string;
  currentPremium: number;
  policyStatus: string;
}
