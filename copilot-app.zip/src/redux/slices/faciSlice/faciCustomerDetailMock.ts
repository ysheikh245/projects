import {FaciCustomerDetail} from './types';

const faciCustomerDetailMock: FaciCustomerDetail = {
  gender: 'F',
  phoneNumber: '6058868542',
  secondaryPhoneNumber: '',
  emailAddress: 'WICKS@WAT.MIDCO.NET',
  birthDate: '1950-08-09',
  homeAddress: {
    addressLine1: '219 Sica Hollow Cir',
    city: 'Watertown',
    state: 'SD',
    zipCode: '572019402',
    country: 'US',
  },
  tempAddress: {
    addressLine1: '219 Temp Address',
    city: 'Watertown',
    state: 'SD',
    zipCode: '572019402',
    country: 'US',
  },
  personNameList: [
    {
      nameType: 'Preferred',
      firstName: 'Patricia',
      lastName: 'Wicks',
      middleName: 'M',
    },
  ],
  externalReferenceList: [
    {
      customerId: '6001023541',
      customerIdType: 'Cogen',
      policyList: [
        {
          policyNumber: 'H100047354',
          policyStatus: 'A01',
          policyRoleList: [
            {
              role: 'Insured',
            },
            {
              role: 'Owner',
            },
          ],
        },
        {
          policyNumber: '100156131',
          policyStatus: 'ACTIVE',
          policyRoleList: [
            {
              role: 'Insured',
            },
          ],
        },
      ],
    },
    {
      customerId: '9999347038760283',
      customerIdType: 'FTNI',
    },
    {
      customerId: 'I_9012967927_001',
      customerIdType: 'Inspro',
      policyList: [
        {
          policyNumber: 'H100047354',
          policyStatus: 'A01',
          policyRoleList: [
            {
              role: 'Owner',
            },
            {
              role: 'Insured',
            },
          ],
        },
      ],
    },
    {
      customerId: '4US02PN8EK6ZW',
      customerIdType: 'Consumer_Link',
    },
    {
      customerId: '012716550',
      customerIdType: 'Individual',
    },
    {
      customerId: '4US032ZFQ2YBQ',
      customerIdType: 'Address_Link',
    },
  ],
  policies: [
    {
      policyNumber: 'H100047354',
      productName: 'P150 - Individual Dental',
      status: 'A01',
      parties: [
        {
          role: 'Insured,Owner',
        },
      ],
    },
    {
      policyNumber: '100156131',
      productName: '026-10-Medicare Supplement',
      status: 'ACTIVE',
      parties: [
        {
          role: 'Insured',
        },
      ],
    },
  ],
};

export default faciCustomerDetailMock;
