import {createSlice, PayloadAction} from '@reduxjs/toolkit';

import {
  AdditionalPolicyInfo,
  AgentRecord,
  BeneficiaryDetails,
  Claim,
  ClaimDetail,
  CustomerDocument,
  Dependent,
  Discount,
  FaciCustomerDetail,
  Policy,
  PolicyAdditionalCoverage,
  PolicyAlertsDetail,
  PolicyCoverageDetail,
  PolicyDetail,
  PolicySearchByPartyIDPolicy,
  RateChange,
  Role,
} from './types';
import {Document} from '../applicationStatusSlice/types';

type FACIState = {
  isLoading: boolean;
  isAdditionalInfoLoading: boolean;
  data: unknown;
  roles: Role[];
  discounts: Discount[];
  dependents: Dependent[];
  rateChanges: RateChange[];
  customerDocuments: CustomerDocument[];
  customerSearch: {
    firstName: string;
    lastName: string;
    stateName: string;
    zip: string;
    dob: string;
  };
  searchPolicyNumber: string;
  error?: Error | null;
  errorMessage: string;
  policyDetails: PolicyDetail[];
  claims: Claim[];
  visibleClaims: Claim[];
  policyDetail: PolicyDetail;
  additionalPolicyInfo: AdditionalPolicyInfo;
  policyAdditionalCoverage: PolicyAdditionalCoverage[];
  policyCoverageDetails: PolicyCoverageDetail[];
  faciCustomerDetail?: FaciCustomerDetail;
  isPolicySearchResultOpen: boolean;
  isPolicySearchResultError: boolean;
  selectedPolicy: Policy;
  policySearchByPartyIDPolicy: PolicySearchByPartyIDPolicy;
  policyAlertsDetail?: PolicyAlertsDetail;
  modals: {
    roles: boolean;
    discounts: boolean;
    dependents: boolean;
    agentOfRecords: boolean;
    policyAdditionalCoverage: boolean;
    policyCoverageDetail: boolean;
    rateChanges: boolean;
    beneficiaryDetails: boolean;
    alertMessage: boolean;
  };
  agentRecords: AgentRecord[] | null;
  showAgentRecords: boolean;
  beneficiaryDetails: BeneficiaryDetails[] | null;
  claimsPeriod: string;
  claimsNumber: string;
  claimDetails: ClaimDetail;
  isGoToPreviousScreen: boolean;
  selectedDocuments: Document[];
};

const SELECTED_POLICY_INITIAL_STATE = {
  partyId: '',
  role: '',
  gender: '',
  personNameList: [],
  policyNumber: '',
};

const MODALS_INITIAL_STATE = {
  roles: false,
  discounts: false,
  dependents: false,
  agentOfRecords: false,
  rateChanges: false,
  customerDocuments: false,
  policyAdditionalCoverage: false,
  policyCoverageDetail: false,
  beneficiaryDetails: false,
  alertMessage: false,
};

const POLICY_DETAIL_INITIAL_STATE: PolicyDetail = {
  issueDate: '',
  productName: '',
  status: '',
  parties: [],
  policyEffectiveDate: '',
  lastPaymentDate: '',
  paidToDate: '',
  currentPremium: 0,
  policyStatus: '',
  policyType: '',
};

const ADDITIONAL_POLICY_INFO_INITIAL_STATE = {
  rolesCount: 0,
  dependentsCount: 0,
  agentsOfRecordCount: 0,
  discountsCount: 0,
  additionalLifeInsuranceRidersCount: 0,
  coverageDetailsCount: 0,
  beneficiaryDetailsCount: 0,
  rateChangesCount: 0,
  viewCustomerDocumentsCount: 0,
  policyAlertsCount: 0,
};

const POLICY_SEARCH_BY_PARTY_ID_POLICY = {
  policyNumber: '',
  productName: '',
  status: '',
  parties: [],
};

const CLAIM_DETAIL_INITIAL_STATE: ClaimDetail = {
  claimNumber: '',
  claimStatus: '',
  dateOfBirth: '',
  claimantName: '',
  claimType: '',
  payees: [],
};

const CUSTOMER_SEARCH_DEFAULT = {
  firstName: '',
  lastName: '',
  stateName: '',
  zip: '',
  dob: '',
};

const initialState: FACIState = {
  isLoading: false,
  isAdditionalInfoLoading: false,
  data: {},
  roles: [],
  discounts: [],
  dependents: [],
  agentRecords: [],
  rateChanges: [],
  customerDocuments: [],
  showAgentRecords: false,
  customerSearch: CUSTOMER_SEARCH_DEFAULT,
  searchPolicyNumber: '',
  error: null,
  errorMessage: '',
  policyDetails: [],
  claims: [],
  isPolicySearchResultOpen: false,
  isPolicySearchResultError: false,
  selectedPolicy: SELECTED_POLICY_INITIAL_STATE,
  additionalPolicyInfo: ADDITIONAL_POLICY_INFO_INITIAL_STATE,
  policyAdditionalCoverage: [],
  policyCoverageDetails: [],
  policyAlertsDetail: undefined,
  policyDetail: POLICY_DETAIL_INITIAL_STATE,
  modals: MODALS_INITIAL_STATE,
  policySearchByPartyIDPolicy: POLICY_SEARCH_BY_PARTY_ID_POLICY,
  beneficiaryDetails: [],
  claimsPeriod: '',
  claimsNumber: '',
  claimDetails: CLAIM_DETAIL_INITIAL_STATE,
  isGoToPreviousScreen: false,
  visibleClaims: [],
  selectedDocuments: [],
};

const FACISlice = createSlice({
  name: 'faci',
  initialState,
  reducers: {
    faciCustomerSearchRequest: state => {
      state.isLoading = true;
    },
    faciCustomerSearchSuccess: (state, action: PayloadAction<unknown>) => {
      state.data = action.payload;
      state.isLoading = false;
      state.error = null;
    },
    faciCustomerSearchFailure: (state, action: PayloadAction<Error>) => {
      state.isLoading = false;
      state.error = action.payload;
    },
    getFaciRolesRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getFaciRolesSuccess: (state, action: PayloadAction<{data: Role[]}>) => {
      state.isLoading = false;
      state.modals.roles = true;
      state.roles = action.payload.data;
      state.errorMessage = '';
    },
    getFaciRolesFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getFaciCustomerDocumentsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
      state.customerDocuments = initialState.customerDocuments;
    },
    getFaciCustomerDocumentsSuccess: (
      state,
      action: PayloadAction<{data: CustomerDocument[]}>,
    ) => {
      state.isLoading = false;
      state.customerDocuments = action.payload.data;
      state.errorMessage = '';
    },
    getFaciCustomerDocumentsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getFaciDiscountsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getFaciDiscountsSuccess: (
      state,
      action: PayloadAction<{data: Discount[]}>,
    ) => {
      state.isLoading = false;
      state.modals.discounts = true;
      state.discounts = action.payload.data;
      state.errorMessage = '';
    },
    getFaciDiscountsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getFaciDependentsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getFaciDependentsSuccess: (
      state,
      action: PayloadAction<{data: Dependent[]}>,
    ) => {
      state.isLoading = false;
      state.modals.dependents = true;
      state.dependents = action.payload.data;
      state.errorMessage = '';
    },
    getFaciDependentsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getFaciRateChangesRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getFaciRateChangesSuccess: (
      state,
      action: PayloadAction<{data: RateChange[]}>,
    ) => {
      state.isLoading = false;
      state.modals.rateChanges = true;
      state.rateChanges = action.payload.data;
    },
    getFaciRateChangesFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    updateCustomerSearchFirstName: (state, action: PayloadAction<string>) => {
      state.customerSearch.firstName = action.payload;
    },
    updateCustomerSearchLastName: (state, action: PayloadAction<string>) => {
      state.customerSearch.lastName = action.payload;
    },
    updateCustomerSearchStateName: (state, action: PayloadAction<string>) => {
      state.customerSearch.stateName = action.payload;
    },
    updateCustomerSearchZip: (state, action: PayloadAction<string>) => {
      state.customerSearch.zip = action.payload;
    },
    updateCustomerSearchDOB: (state, action: PayloadAction<string>) => {
      state.customerSearch.dob = action.payload;
    },
    updateSearchPolicyNumber: (state, action: PayloadAction<string>) => {
      state.searchPolicyNumber = action.payload;
    },
    getFaciSearchRequest: state => {
      state.isLoading = true;
    },
    getFaciSearchSuccess: (state, action: PayloadAction<PolicyDetail[]>) => {
      state.isLoading = false;
      state.policyDetails = action.payload;
    },
    getFaciSearchFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.isPolicySearchResultError = true;
      state.errorMessage = action.payload;
    },
    getFaciCustomerDetailRequest: state => {
      state.isLoading = true;
    },
    getFaciCustomerByPolicyNumberRequest: state => {
      state.isLoading = true;
    },
    getFaciCustomerDetailSuccess: (
      state,
      action: PayloadAction<FaciCustomerDetail>,
    ) => {
      state.isLoading = false;
      state.faciCustomerDetail = action.payload;
    },
    getFaciCustomerDetailFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    showPolicySearchResult: state => {
      state.isPolicySearchResultOpen = true;
    },
    hidePolicySearchResult: state => {
      state.isPolicySearchResultOpen = false;
    },
    hidePolicySearchResultError: state => {
      state.isPolicySearchResultError = false;
    },
    getCustomerContactInfo: (state, action: PayloadAction<Policy>) => {
      state.isLoading = true;
      state.selectedPolicy = action.payload;
      state.faciCustomerDetail = initialState.faciCustomerDetail;
    },
    getPolicyAlertsRequest: state => {
      state.isLoading = true;
      state.policyAlertsDetail = initialState.policyAlertsDetail;
    },
    getPolicyAlertsSuccess: (
      state,
      action: PayloadAction<PolicyAlertsDetail>,
    ) => {
      state.isLoading = false;
      state.policyAlertsDetail = action.payload;
      state.modals.alertMessage = true;
    },
    getPolicyAlertsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    updatePolicySearchByPartyIDPolicy: (
      state,
      action: PayloadAction<PolicySearchByPartyIDPolicy>,
    ) => {
      state.policySearchByPartyIDPolicy = action.payload;
    },
    getPolicyDetailRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getPolicyDetailSuccess: (state, action: PayloadAction<PolicyDetail>) => {
      state.isLoading = false;
      state.policyDetail = action.payload;
    },
    getPolicyDetailFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getAdditionalPolicyInfoRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isAdditionalInfoLoading = true;
    },
    getAdditionalPolicyInfoSuccess: (
      state,
      action: PayloadAction<{data: AdditionalPolicyInfo}>,
    ) => {
      state.isAdditionalInfoLoading = false;
      state.additionalPolicyInfo = action.payload.data;
    },
    getAdditionalPolicyInfoFailure: (state, action: PayloadAction<string>) => {
      state.isAdditionalInfoLoading = false;
      state.errorMessage = action.payload;
    },
    getPolicyAdditionalCoverageRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getPolicyAdditionalCoverageSuccess: (
      state,
      action: PayloadAction<PolicyAdditionalCoverage[]>,
    ) => {
      state.isLoading = false;
      state.modals.policyAdditionalCoverage = true;
      state.policyAdditionalCoverage = action.payload;
    },
    getPolicyAdditionalCoverageFailure: (
      state,
      action: PayloadAction<string>,
    ) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getPolicyCoverageDetailsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getPolicyCoverageDetailsSuccess: (
      state,
      action: PayloadAction<PolicyCoverageDetail[]>,
    ) => {
      state.isLoading = false;
      state.modals.policyCoverageDetail = true;
      state.policyCoverageDetails = action.payload;
    },
    getPolicyCoverageDetailsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    resetFaciModals: state => {
      state.modals = MODALS_INITIAL_STATE;
    },
    resetFaciSearch: () => initialState,
    getAgentRecordsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getAgentRecordSuccess: (state, action: PayloadAction<AgentRecord[]>) => {
      state.isLoading = false;
      state.agentRecords = action.payload;
      state.modals.agentOfRecords = true;
    },
    getAgentOfRecordsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getBeneficiaryDetailsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getBeneficiaryDetailsSuccess: (
      state,
      action: PayloadAction<BeneficiaryDetails[]>,
    ) => {
      state.isLoading = false;
      state.beneficiaryDetails = action.payload;
      state.modals.beneficiaryDetails = true;
    },
    getBeneficiaryDetailsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    setClaimsPeriod: (state, action: PayloadAction<string>) => {
      state.claimsPeriod = action.payload;
    },
    setClaimsNumber: (state, action: PayloadAction<string>) => {
      state.claimsNumber = action.payload;
    },
    setVisibleClaims: (state, action: PayloadAction<Claim[]>) => {
      state.visibleClaims = action.payload;
    },
    getFaciClaimsRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.isLoading = true;
    },
    getFaciClaimsSuccess: (state, action: PayloadAction<Claim[]>) => {
      state.isLoading = false;
      state.claims = action.payload;
    },
    getFaciClaimsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    getClaimDetailsRequest: (
      state,
      _action: PayloadAction<{claimNumber: string; claimStatus: string}>,
    ) => {
      state.isLoading = true;
    },
    getClaimDetailsSuccess: (state, action: PayloadAction<ClaimDetail>) => {
      state.isLoading = false;
      state.claimDetails = action.payload;
    },
    getClaimDetailsFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.claimDetails = initialState.claimDetails;
      state.errorMessage = action.payload;
    },
    resetPolicyDetailAdditionalInfo: state => {
      state.roles = initialState.roles;
      state.discounts = initialState.discounts;
      state.dependents = initialState.dependents;
      state.agentRecords = initialState.agentRecords;
      state.rateChanges = initialState.rateChanges;
      state.customerDocuments = initialState.customerDocuments;
      state.beneficiaryDetails = initialState.beneficiaryDetails;
      state.policyAlertsDetail = initialState.policyAlertsDetail;
    },
    openAgentRecords: state => {
      state.showAgentRecords = true;
    },
    goToPreviousScreen: (state, action: PayloadAction<boolean>) => {
      state.isGoToPreviousScreen = action.payload;
    },
    selectDocuments: (state, action: PayloadAction<Document[]>) => {
      state.selectedDocuments = [...action.payload];
    },
    submitClaimDetailsRequest: state => {
      state.isLoading = true;
    },
    submitClaimDetailsSuccess: state => {
      state.isLoading = false;
    },
    submitClaimDetailsFailure: state => {
      state.isLoading = false;
    },
    resetCustomerSearch: state => {
      state.customerSearch = CUSTOMER_SEARCH_DEFAULT;
    },
    resetClaimsSearch: state => {
      state.claimsPeriod = '';
      state.claimsNumber = '';
    },
    defaultFaci: () => initialState,
  },
});

export const {actions: faciActions, reducer: faciReducer} = FACISlice;
