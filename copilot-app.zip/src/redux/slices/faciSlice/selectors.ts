import {createSelector} from '@reduxjs/toolkit';

import {RootState} from '../../store';

export const selectFirstName = (state: RootState) =>
  state.faci.customerSearch.firstName;
export const selectLastName = (state: RootState) =>
  state.faci.customerSearch.lastName;
export const selectStateName = (state: RootState) =>
  state.faci.customerSearch.stateName;
export const selectZip = (state: RootState) => state.faci.customerSearch.zip;
export const selectDateOfBirth = (state: RootState) =>
  state.faci.customerSearch.dob;
export const selectIsSearchByPolicy = (state: RootState) =>
  state.faci.searchByPolicy;
export const selectSearchPolicyNumber = (state: RootState) =>
  state.faci.searchPolicyNumber;
export const selectPolicySearchByPartyIDResponse = (state: RootState) =>
  state.faci.faciCustomerDetail;
export const selectPolicyDetails = (state: RootState) =>
  state.faci.policyDetails;
export const selectIsPolicySearchResultOpen = (state: RootState) =>
  state.faci.isPolicySearchResultOpen;
export const selectIsPolicySearchResultError = (state: RootState) =>
  state.faci.isPolicySearchResultError;
export const selectErrorMessage = (state: RootState) => state.faci.errorMessage;
export const selectSelectedPolicyDetail = (state: RootState) =>
  state.faci.selectedPolicy;
export const selectIsLoading = (state: RootState) => state.faci.isLoading;
export const selectIsAdditionalInfoLoading = (state: RootState) =>
  state.faci.isAdditionalInfoLoading;
export const selectPolicyAlertsDetail = (state: RootState) =>
  state.faci.policyAlertsDetail;
export const selectSelectedPolicyCustomerName = (state: RootState) => {
  const selectedPolicy = state.faci.selectedPolicy;
  if (
    selectedPolicy &&
    selectedPolicy.personNameList &&
    selectedPolicy.personNameList.length > 0
  ) {
    return `${selectedPolicy.personNameList[0].lastName} ${selectedPolicy.personNameList[0].firstName}`;
  }
  return 'N/A';
};
export const selectRoles = (state: RootState) => state.faci.roles;
export const selectCustomerDocuments = (state: RootState) =>
  state.faci.customerDocuments;
export const selectDiscounts = (state: RootState) => state.faci.discounts;
export const selectDependents = (state: RootState) => state.faci.dependents;
export const selectRateChanges = (state: RootState) => state.faci.rateChanges;
export const selectPolicyNumber = createSelector(
  [selectSelectedPolicyDetail],
  selectedPolicyDetail => {
    if (selectedPolicyDetail) {
      return selectedPolicyDetail.policyNumber;
    }
    return '';
  },
);
export const selectPolicySearchByPartyIDPolicy = (state: RootState) =>
  state.faci.policySearchByPartyIDPolicy;
export const selectAdditionalPolicyInfo = (state: RootState) =>
  state.faci.additionalPolicyInfo;
export const selectPolicyDetail = (state: RootState) => state.faci.policyDetail;
export const selectFaciPolicyAdditionalCoverageModal = (state: RootState) =>
  state.faci.modals.policyAdditionalCoverage;
export const selectFaciPolicyAdditionalCoverage = (state: RootState) =>
  state.faci.policyAdditionalCoverage;
export const selectFaciPolicyCoverageDetailsModal = (state: RootState) =>
  state.faci.modals.policyCoverageDetail;
export const selectFaciPolicyCoverageDetails = (state: RootState) =>
  state.faci.policyCoverageDetails;
export const selectFaciRolesModal = (state: RootState) =>
  state.faci.modals.roles;
export const selectFaciDiscountsModal = (state: RootState) =>
  state.faci.modals.discounts;
export const selectFaciDependentsModal = (state: RootState) =>
  state.faci.modals.dependents;
export const selectFaciAgentOfRecordsModal = (state: RootState) =>
  state.faci.modals.agentOfRecords;
export const selectFaciAlertModal = (state: RootState) =>
  state.faci.modals.alertMessage;
export const selectAgentRecords = (state: RootState) => state.faci.agentRecords;
export const selectFaciRateChangesModal = (state: RootState) =>
  state.faci.modals.rateChanges;

export const selectBeneficiaryDetails = (state: RootState) =>
  state.faci.beneficiaryDetails;
export const selectBeneficiaryDetailsModal = (state: RootState) =>
  state.faci.modals.beneficiaryDetails;
export const selectClaimsPeriod = (state: RootState) => state.faci.claimsPeriod;
export const selectClaimsNumber = (state: RootState) => state.faci.claimsNumber;
export const selectClaims = (state: RootState) => state.faci.claims;
export const selectVisibleClaims = (state: RootState) =>
  state.faci.visibleClaims;
export const selectClaimDetails = (state: RootState) => state.faci.claimDetails;
export const selectIsGoToPreviousScreen = (state: RootState) =>
  state.faci.isGoToPreviousScreen;
export const selectSelectedDocuments = (state: RootState) =>
  state.faci.selectedDocuments;
