import {asFilterReducer} from './applicationStatusFilterSlice';
import {applicationStatusReducer} from './applicationStatusSlice';
import {authReducer} from './authSlice';
import {faciReducer} from './faciSlice';
import {menuReducer} from './menuSlice';
import {myCompensationReducer} from './myCompensation';

export const reducers = {
  auth: authReducer,
  applicationStatus: applicationStatusReducer,
  asFilter: asFilterReducer,
  faci: faciReducer,
  menu: menuReducer,
  myCompensation: myCompensationReducer,
};
