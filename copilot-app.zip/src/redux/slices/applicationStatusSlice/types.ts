export interface ApplicationStatus {
  policyDisplayText: string;
  policyNumber: string;
  policyStatus: string;
  policyStatusCode: string;
  policyStatusLongName: string;
  productCode: string;
  productName: string;
  submitDate: string;
  thankyouEmailStatus: string;
  workSheetRequirementCount?: number;
  productCategory: string;
  displayIssueDate?: string;
  displaySubmitDate?: string;
  parties: [
    {
      fullName: string;
      partyId: string;
      role: string;
      firstName: string;
      lastName: string;
      emailAddress: string;
      messageCode: string;
      productCode: string;
      homeAddress: {
        addressLine1: string;
        addressLine2: string;
        addressLine3: string;
        city: string;
        state: string;
        zipCode: string;
      };
    },
  ];
  fullProductCode: string;
  issueDate: string;
}

export interface ThankYou {
  recipientFirstName: string;
  recipientLastName: string;
  recipientEmailAddress: string;
  recipientState: string;
  npn: string;
  productCode: string;
  messageCode: string;
  partyId: string;
  policyNumber: string;
  notes: string;
}

export interface Case360Document {
  comments: string;
  dateReceived: string;
  dateRequired: string;
  description: string;
  displayField: string;
  uploadButton: string;
  document: string;
  // uri: string;
  // type: string;
}

export interface Document {
  fileCopyUri: string;
  size: number;
  name: string;
  type: string;
  uri: string;
  fileData: string;
  documentDescription: string;
  document: string;
}

export interface CacheResults {
  npnId: string;
  defaultPolicySearchProcess: {
    startedAt: string;
    endedAt: string;
    totalPoliciesFetched: number;
    searchCompleted: boolean;
  };
  backgroundPolicySearchProcess: {
    startedAt: string;
    endedAt: string;
    totalPoliciesFetched: number;
    searchCompleted: boolean;
  };
  totalPoliciesFetchedCount: number;
  createDate: string;
}
