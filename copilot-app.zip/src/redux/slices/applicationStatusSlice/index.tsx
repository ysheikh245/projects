import {createSlice, PayloadAction} from '@reduxjs/toolkit';

import {ApplicationStatus, Case360Document, Document, ThankYou} from './types';
import {PolicyDetailData} from '../../../components/Card/ApplicationStatusCard';

const DOCUMENT_INITIAL_STATE: Document = {
  fileCopyUri: '',
  size: 0,
  name: '',
  type: '',
  uri: '',
  fileData: '',
  documentDescription: '',
  document: '',
};

export interface ApplicationStatusState {
  errorMessage: string;
  isLoading: boolean;
  data: ApplicationStatus[];
  worksheetDetail: Case360Document[];
  selectedDocument: Document;
  selectedDocuments: Document[];
  pageNumber: number;
  uploadSuccess: boolean;
  resetApplicationStatus: boolean;
  freshRequest: boolean;
}

export const initialState: ApplicationStatusState = {
  errorMessage: '',
  isLoading: false,
  data: [],
  worksheetDetail: [],
  selectedDocument: DOCUMENT_INITIAL_STATE,
  freshRequest: false,
  selectedDocuments: [],
  pageNumber: 0,
  uploadSuccess: false,
  resetApplicationStatus: false,
};

const applicationStatusSlice = createSlice({
  name: 'applicationStatus',
  initialState,
  reducers: {
    applicationStatusRequest: state => {
      state.isLoading = true;
    },
    applicationStatusFreshRequest: state => {
      state.isLoading = true;
    },
    applicationStatusSuccess: (
      state,
      action: PayloadAction<{data: ApplicationStatus[]}>,
    ) => {
      state.isLoading = false;
      state.data = action.payload.data;
      state.errorMessage = initialState.errorMessage;
    },
    applicationStatusFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    sendThankYouRequest: (
      state,
      _action: PayloadAction<{data: ThankYou; pageNumber: number}>,
    ) => {
      state.isLoading = true;
    },
    sendThankYouSuccess: (state, action: PayloadAction) => {
      state.isLoading = false;
      state.errorMessage = initialState.errorMessage;
    },
    sendThankYouFailure: (state, action: PayloadAction<{message: string}>) => {
      state.isLoading = false;
      state.errorMessage = action.payload.message;
    },
    getWorksheetDetailRequest: (
      state,
      _action: PayloadAction<{policyNumber: string}>,
    ) => {
      state.errorMessage = '';
    },
    getWorksheetDetailSuccess: (state, action: PayloadAction<{data: any}>) => {
      state.worksheetDetail = action.payload.data;
    },
    getWorksheetDetailFailure: (
      state,
      action: PayloadAction<{data: string}>,
    ) => {
      state.errorMessage = action.payload.data;
      state.errorMessage = '';
    },
    selectDocument: (state, action: PayloadAction<{data: Document}>) => {
      state.selectedDocument = action.payload.data;
      const idx = state.selectedDocuments.findIndex(
        doc => doc.fileCopyUri === action.payload.data.fileCopyUri,
      );
      if (idx === -1) {
        state.selectedDocuments.push(action.payload.data);
      } else {
        state.selectedDocuments.splice(idx, 1);
      }
    },
    sentDocumentRequest: (
      state,
      _action: PayloadAction<{
        policyDetailData: PolicyDetailData;
        file: Document | Case360Document;
      }>,
    ) => {
      state.isLoading = true;
      state.uploadSuccess = false;
    },
    sentDocumentSuccess: state => {
      state.isLoading = false;
      state.uploadSuccess = true;
      state.selectedDocuments = [];
    },
    sentDocumentFailure: (state, action: PayloadAction<{data: string}>) => {
      state.errorMessage = action.payload.data;
      state.isLoading = false;
      state.uploadSuccess = false;
    },
    resetUploadSuccess: state => {
      state.uploadSuccess = false;
    },
    setPageNumber: (state, action: PayloadAction<{pageNumber: number}>) => {
      state.pageNumber = action.payload.pageNumber;
      state.isLoading = false;
    },
    applicationStatusReset: (state, action: PayloadAction<boolean>) => {
      state.resetApplicationStatus = action.payload;
    },
    setFreshRequest: (state, action: PayloadAction<boolean>) => {
      state.freshRequest = action.payload;
    },
    defaultApplicationStatus: () => initialState,
  },
});

export const {
  actions: applicationStatusActions,
  reducer: applicationStatusReducer,
} = applicationStatusSlice;
