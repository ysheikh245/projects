import {createSelector} from '@reduxjs/toolkit';

import {ApplicationStatus} from './types';
import {RootState} from '../../store';
import {} from 'lodash';
import {DISABLED, ENABLED} from '../../../constants/applicationStatus';

export const selectApplicationStatusData = (state: RootState) =>
  state.applicationStatus.data;

export const selectApplicationStatusIsLoading = (state: RootState) =>
  state.applicationStatus.isLoading;

export const selectResetApplicationStatus = (state: RootState) =>
  state.applicationStatus.resetApplicationStatus;

export const selectMutatedApplicationStatus = createSelector(
  [selectApplicationStatusData],
  (data: ApplicationStatus[]) => {
    let mutatedData = {
      Pending: 'Pending',
      Issued: 'Issued',
      'Decline/Withdrawn': 'Decline/Withdrawn',
      'Not Taken': 'Not Taken',
    };

    let policyNumber = {};
    let mutatedArray: ApplicationStatus[] = [];

    data.forEach(card => {
      if (!policyNumber[card.policyNumber]) {
        policyNumber[card.policyNumber] = card.policyNumber;
        mutatedArray.push(card);
      }
    });

    console.log('policy=Number', policyNumber);
    console.log('mutataed: ', mutatedArray);

    if (data !== undefined && data.length > 0) {
      const pendingData: ApplicationStatus[] = mutatedArray.filter(
        value => mutatedData.Pending === value.policyStatus,
      );
      const issuedData: ApplicationStatus[] = mutatedArray.filter(
        value => mutatedData.Issued === value.policyStatus,
      );
      const declineWithdrawnData: ApplicationStatus[] = mutatedArray.filter(
        value => mutatedData['Decline/Withdrawn'] === value.policyStatus,
      );
      const notTakenData: ApplicationStatus[] = mutatedArray.filter(
        value => mutatedData['Not Taken'] === value.policyStatus,
      );

      return {
        Pending: pendingData,
        Issued: issuedData,
        'Decline/Withdrawn': declineWithdrawnData,
        'Not Taken': notTakenData,
      };
    }

    return {
      Pending: [],
      Issued: [],
      'Decline/Withdrawn': [],
      'Not Taken': [],
    };
  },
);

export const selectWorksheetDetail = (state: RootState) =>
  state.applicationStatus.worksheetDetail;
export const selectSelectedDocument = (state: RootState) =>
  state.applicationStatus.selectedDocument;
export const selectSelectedDocuments = (state: RootState) =>
  state.applicationStatus.selectedDocuments;
export const selectPageNumber = (state: RootState) =>
  state.applicationStatus.pageNumber;

export const selectIsUploadDocumentDisabled = createSelector(
  selectWorksheetDetail,
  workSheetDetail => {
    let disabled = DISABLED;
    workSheetDetail.map(val => {
      if (val.document.length > 0) {
        disabled = ENABLED;
      }
    });

    return disabled;
  },
);

// export const selectUploadDocuments = createSelector(
//   [selectWorksheetDetail],
//   documents => {
//     let docs: Case360Document[] = [];
//
//     documents.map(document => {
//       if (document?.uri?.length > 0) {
//         docs.push(document);
//       }
//     });
//
//     return docs;
//   },
// );

export const selectIsLoading = (state: RootState) =>
  state.applicationStatus.isLoading;

export const isUploadSuccess = (state: RootState) =>
  state.applicationStatus.uploadSuccess;

export const isFreshRequest = (state: RootState) =>
  state.applicationStatus.freshRequest;
