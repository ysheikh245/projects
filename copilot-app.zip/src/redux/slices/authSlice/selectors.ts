import {createSelector} from '@reduxjs/toolkit';

import PMICUser from '../../../types/PMICUser';
import {RootState} from '../../store';

export const selectUser = (state: RootState) => state.auth.user;
export const selectSavedPin = (state: RootState) => state.auth.savedPin;
export const selectBiometricsEnabled = (state: RootState) =>
  state.auth.biometricsEnabled;
export const selectIsAuthenticated = (state: RootState) =>
  state.auth.isAuthenticated;

export const selectPMICUser = createSelector([selectUser], user => {
  if (user) {
    return new PMICUser(user);
  } else {
    return undefined;
  }
});

export const selectNpn = createSelector([selectUser], user => {
  if (user) {
    return user.npn;
  }

  return undefined;
});
