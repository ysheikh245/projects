import LogRocket from '@logrocket/react-native';
import {createSlice} from '@reduxjs/toolkit';
import Constants from 'expo-constants';
import EncryptedStorage from 'react-native-encrypted-storage';

import PMICUser, {IPMICUser} from '../../../types/PMICUser';
import type {PayloadAction} from '@reduxjs/toolkit';

export interface AuthState {
  user: IPMICUser | undefined;
  savedPin?: string;
  biometricsEnabled: boolean;
  isAuthenticated: boolean; // this determines the current app state
}

const initialState: AuthState = {
  user: undefined,
  savedPin: undefined,
  biometricsEnabled: false,
  isAuthenticated: false,
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setUser: (state, _action: PayloadAction<PMICUser>) => {
      state.user = _action.payload.toImmutable();
      // logrocket the user
      LogRocket.identify(_action.payload.npn || _action.payload.username, {
        name: _action.payload.firstName + ' ' + _action.payload.lastName,
      });
    },
    authenticate: (state, action: PayloadAction<boolean>) => {
      state.isAuthenticated = action.payload;
    },
    savePin: (state, action: PayloadAction<string>) => {
      state.savedPin = action.payload;
    },
    saveBiometrics: (state, action: PayloadAction<boolean>) => {
      state.biometricsEnabled = action.payload;
    },
    logout: state => {
      // KeyCloak logout command
      const logoutURL = `${
        Constants.expoConfig!.extra!.KEYCLOAK_ENDPOINT
      }/logout`;

      EncryptedStorage.getItem('refreshToken').then(refreshToken => {
        const body = new URLSearchParams({
          client_id: Constants.expoConfig!.extra!.KEYCLOAK_CLIENT_ID,
          refresh_token: refreshToken!,
        }).toString();

        const requestOptions: any = {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body,
        };

        console.log('requestOptions :>> ', requestOptions);

        const thisFetch = fetch(logoutURL, requestOptions)
          .then(response =>
            console.log('keycloak logout response :>> ', response),
          )
          .catch(error => console.error('keycloak logout error :>> ', error))
          .finally(() => {
            EncryptedStorage.removeItem('accessToken');
            EncryptedStorage.removeItem('refreshToken');
          });

        console.log('thisFetch :>> ', thisFetch);
      });

      state.savedPin = undefined;
      state.biometricsEnabled = false;
      state.isAuthenticated = false;
    },
    defaultAuth: () => initialState,
  },
});

// Action creators are generated for each case reducer function
export const {actions: authActions, reducer: authReducer} = authSlice;
