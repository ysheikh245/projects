import {RootState} from '../../store';
import {} from 'lodash';

export const selectIssued = (state: RootState) =>
  state.asFilter.filter.status.issued;
export const selectPending = (state: RootState) =>
  state.asFilter.filter.status.pending;
export const selectDeclineWithdrawn = (state: RootState) =>
  state.asFilter.filter.status.declineWithdrawn;
export const selectNotTaken = (state: RootState) =>
  state.asFilter.filter.status.notTaken;

export const selectPolicyNumber = (state: RootState) =>
  state.asFilter.filter.policyNumber;
export const selectFirstName = (state: RootState) =>
  state.asFilter.filter.firstName;
export const selectLastName = (state: RootState) =>
  state.asFilter.filter.lastName;
export const selectSortByOldest = (state: RootState) =>
  state.asFilter.filter.sortBy.oldestToNewest;
export const selectSortByNewest = (state: RootState) =>
  state.asFilter.filter.sortBy.newestToOldest;

export const selectStartDate = (state: RootState) =>
  state.asFilter.filter.startDate;
export const selectEndDate = (state: RootState) =>
  state.asFilter.filter.endDate;

export const selectSearchFromDate = (state: RootState) =>
  state.asFilter.filter.searchFromDate;
export const selectSearchToDate = (state: RootState) =>
  state.asFilter.filter.searchToDate;

export const selectApplicationStatusIsLoading = (state: RootState) =>
  state.asFilter.isLoading;

export const selectIsFilterLoading = (state: RootState) =>
  state.asFilter.isLoading;

export const selectIsFilterActive = (state: RootState) =>
  state.asFilter.isFilterActive;
