import {createSlice, PayloadAction} from '@reduxjs/toolkit';
import moment from 'moment-timezone';

export interface ASFilterState {
  isLoading: boolean;
  filter: {
    startDate: number;
    endDate: number;
    searchFromDate: string | null;
    searchToDate: string | null;
    status: {
      pending: boolean;
      issued: boolean;
      declineWithdrawn: boolean;
      notTaken: boolean;
    };
    policyNumber: string | null;
    firstName: string | null;
    lastName: string | null;
    sortBy: {
      oldestToNewest: boolean;
      newestToOldest: boolean;
    };
  };
  isFilterActive: boolean;
  errorMessage: string;
}

const RESET_FILTER = {
  startDate: 0,
  endDate: 7,
  searchFromDate: moment().subtract(0, 'days').format('YYYY-MM-DD'),
  searchToDate: moment().subtract(7, 'days').format('YYYY-MM-DD'),
  status: {
    pending: true,
    issued: true,
    declineWithdrawn: true,
    notTaken: true,
  },
  policyNumber: null,
  firstName: null,
  lastName: null,
  sortBy: {
    oldestToNewest: true,
    newestToOldest: false,
  },
};

export const initialState: ASFilterState = {
  isLoading: false,
  filter: {
    startDate: 0,
    endDate: 7,
    searchFromDate: null,
    searchToDate: null,
    status: {
      pending: true,
      issued: true,
      declineWithdrawn: true,
      notTaken: true,
    },
    policyNumber: '',
    firstName: '',
    lastName: '',
    sortBy: {
      oldestToNewest: true,
      newestToOldest: false,
    },
  },
  isFilterActive: false,
  errorMessage: '',
};

const asFilterSlice = createSlice({
  name: 'asFilter',
  initialState,
  reducers: {
    cacheResultsRequest: (state, _action: PayloadAction) => {
      state.isLoading = true;
    },
    cacheResultsSuccess: (_state, _action: PayloadAction) => {},
    cacheResultsFailure: (state, _action: PayloadAction) => {
      state.isLoading = false;
    },
    filterApplicationStatusRequest: (state, _action: PayloadAction) => {
      state.isLoading = true;
      // state.pageNumber = 0;
    },
    filterApplicationStatusSuccess: state => {
      state.isLoading = false;
    },
    filterApplicationStatusFailure: (state, action: PayloadAction<string>) => {
      state.isLoading = false;
      state.errorMessage = action.payload;
    },
    resetFilter: state => {
      state.filter = RESET_FILTER;
    },
    isFilterModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isFilterActive = action.payload;
    },
    updateStatusPending: (state, action: PayloadAction<boolean>) => {
      state.filter.status.pending = action.payload;
    },
    updateStatusIssued: (state, action: PayloadAction<boolean>) => {
      state.filter.status.issued = action.payload;
    },
    updateStatusNotTaken: (state, action: PayloadAction<boolean>) => {
      state.filter.status.notTaken = action.payload;
    },
    updateStatusDeclineWithdrawn: (state, action: PayloadAction<boolean>) => {
      state.filter.status.declineWithdrawn = action.payload;
    },
    updatePolicyNumber: (state, action: PayloadAction<string>) => {
      state.filter.policyNumber = action.payload;
    },
    updateFirstName: (state, action: PayloadAction<string>) => {
      state.filter.firstName = action.payload;
    },
    updateLastName: (state, action: PayloadAction<string>) => {
      state.filter.lastName = action.payload;
    },
    updateSortBy: (
      state,
      action: PayloadAction<{
        oldestToNewest: boolean;
        newestToOldest: boolean;
      }>,
    ) => {
      state.filter.sortBy = action.payload;
    },
    updateStartDate: (state, action: PayloadAction<number>) => {
      state.filter.startDate = action.payload;
      state.filter.searchFromDate = moment()
        .subtract(action.payload, 'days')
        .format('YYYY-MM-DD');
    },
    updateEndDate: (state, action: PayloadAction<number>) => {
      state.filter.endDate = action.payload;
      state.filter.searchToDate = moment()
        .subtract(action.payload, 'days')
        .format('YYYY-MM-DD');
    },
    defaultAsFilter: () => initialState,
  },
});

export const {actions: asFilterActions, reducer: asFilterReducer} =
  asFilterSlice;
