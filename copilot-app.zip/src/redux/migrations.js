// migrations are used to update the shape of state between
// versions configured in the persistConfig object
// example: https://github.com/rt2zz/redux-persist/blob/master/docs/migrations.md

const migrations = {
  1: state => state,
};

export default migrations;
