/**
 * @format
 */
import 'react-native-gesture-handler';
import LogRocket from '@logrocket/react-native';
import Constants from 'expo-constants';
import {AppRegistry} from 'react-native';
import {Provider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';

import App from './App';
import {name as appName} from './app.json';
import persistor, {store} from './src/redux/store';

if (!__DEV__) {
  console.log(
    'init logrocket for',
    Constants.expoConfig.extra.LOG_ROCKET_APP_ID,
  );
  LogRocket.init(Constants.expoConfig.extra.LOG_ROCKET_APP_ID, {
    release: Constants.expoConfig.extra.GIT_HASH,
  });
}
const Root = () => {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <App />
      </PersistGate>
    </Provider>
  );
};

AppRegistry.registerComponent(appName, () => Root);
