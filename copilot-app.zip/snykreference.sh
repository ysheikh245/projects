#!/bin/bash 
# Snyk is a platform allowing users to scan, prioritize, and fix security vulnerabilities in code, open source dependencies and container images. 
# The below monitor command will update snyk org agency-copilot.  This will setup a monitor for open source vulnerabilities and license issues. 
# After running this command, log in to the Snyk website and view your projects and to see the monitor.
#   Possible exit codes and their meaning: 
#      0: success, snapshot created 
#      2: failure, try to re-run command 
#      3: failure, no supported projects detected 
# 
# snyk organization id for agency-copilot: 5e12213d-9be7-49bf-9a08-5d327cf9ce7f 
# snyk monitor command: snyk monitor --org=5e12213d-9be7-49bf-9a08-5d327cf9ce7f 
# 
 
snyk monitor --scan-all-unmanaged --all-sub-projects --org=5e12213d-9be7-49bf-9a08-5d327cf9ce7f 
snyk monitor --scan-all-unmanaged --all-projects --org=5e12213d-9be7-49bf-9a08-5d327cf9ce7f 
