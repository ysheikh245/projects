export const BLACK = '#000';
export const IconFontSize = 64;
export const FoundationIcon = 60;
export const ZocialIconSize = 55;
export const HomeIconColor = '#0B6CB6';
