import React, {FC, useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';

import AppNavigation from './src/navigation/AppNavigation';
import AuthNavigation from './src/navigation/AuthNavigation';
import {authActions} from './src/redux/slices/authSlice';
import {selectIsAuthenticated} from './src/redux/slices/authSlice/selectors';
import SplashScreenView from './src/screens/Splashscreen/SplashscreenView';
import {SPLASH_SCREEN_ANIMATION_DURARION} from './src/utils/constants';

const App: FC = () => {
  const [isSplashVisible, setIsSplashVisible] = useState(true);
  const dispatch = useDispatch();
  const isAuthenticated = useSelector(selectIsAuthenticated);

  useEffect(() => {
    dispatch(authActions.authenticate(false));
  }, []);

  useEffect(() => {
    setTimeout(() => {
      setIsSplashVisible(false);
    }, SPLASH_SCREEN_ANIMATION_DURARION);
  }, []);

  if (isSplashVisible) {
    return <SplashScreenView />;
  }

  return isAuthenticated ? <AppNavigation /> : <AuthNavigation />;
};

export default App;
