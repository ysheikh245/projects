#!/bin/zsh 

export JOB_NAME="shan/local"
export BUILD_NUMBER="1"
export BRANCH_NAME="release/2023i12"
export PROJECT_NAME="agency-copilot-app"
export MOBILEBUILDS="./release/"
export GIT_TAG_NAME="0.0.4"
